// A backup you have never tested is only a hope.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['admin', 'official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '8.3',
  actors: { admin: 'desk', official: 'beside', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'pair'], [S(1), 'display'], [S(2), 'file'], [S(3), 'pair'], [S(5), 'staff'], [S(9), 'desk'], [S(10), 'counterDisplay'], [S(11), 'pair'], [S(12), 'staff'], [S(13), 'her']],
  actions: {
    admin: [[0, S(3), 'type'], [S(3), S(10), 'read'], [S(10), D.T, 'type']],
    official: [[0, S(3), 'paper'], [S(3), S(5), 'talk', 'omar'], [S(5), S(10), 'paper'], [S(10), S(12), 'talk', 'maya'], [S(12), D.T, 'paper']],
    maya: [[0, S(2), 'read'], [S(2), S(3), 'file'], [S(3), S(10), 'listen', 'official'], [S(10), S(11), 'file'], [S(11), S(12), 'listen', 'official'], [S(12), D.T, 'listen', 'omar']],
    omar: [[0, S(5), 'listen', 'official'], [S(5), S(6), 'talk', 'official'], [S(6), S(9), 'listen', 'official'], [S(9), S(10), 'paper'], [S(10), S(12), 'listen', 'official'], [S(12), D.T, 'talk', 'maya']],
  },
  displays: {
    desk: [
      [0, S(10), 'folder', 'Recovery test · Case 2048', 'neutral'],
      [S(10), D.T, 'tools', 'Missing page logged · Fixing', 'safe'],
    ],
    counter: [
      [0, S(10), 'file', 'Checking restored pages', 'neutral'],
      [S(10), S(12), 'zoom', 'Test gap · One page missing', 'alert'],
      [S(12), D.T, 'tick', 'Approved backup only', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Recovery test · Separate computer'],
    [S(2), E(2), 'Page-by-page paper check'],
    [S(10), E(10), 'Gap found before a real incident'],
    [S(12), E(12), 'No personal drives'],
  ],
  screens: [
    [S(1), S(3), win('Recovery test · Test computer', row('Record', 'Case 2048 · From backup', 'hi') + row('Environment', 'Separate test device', 'ok') + row('Check', 'Page-by-page vs. paper', 'wait'))],
    [S(9), S(10), win('Recovery test · Timing', row('Restore duration', 'Recorded by Omar', 'hi') + row('Compared to', 'Recovery time objective', 'ok'))],
    [S(10), S(12), win('Recovery test sheet', row('Scanned pages', '1 page missing', 'warn') + row('Action', 'Logged for IT to fix', 'ok') + note('Finding a gap in a test is a success.', ''), 'good')],
  ],
  pages: [
    hero(S(3), S(5), 'Test that recovery really works', 'made/laptop+made/own_tick', [
      ['Untested backups may fail on the real day', S(3), 'v-amber'],
      ['Periodic recovery tests are required', S(4), 'v-teal'],
    ]),
    hero(S(5), S(9), 'Keep backups apart from the network', 'made/backup_tape+made/own_backup_drive+made/safe', [
      ['Ransomware groups delete reachable backups', S(6), 'v-coral'],
      ['Keep backups offline, encrypted and tested', S(7), 'v-teal'],
      ['66% restored from backups in 2026', S(8), 'v-navy'],
    ]),
    hero(S(12), S(13), 'No private copies on personal drives', 'made/usb_stick+made/own_warning_beacon', [
      ['Personal drives are unprotected and unrecovered', S(12), 'v-coral'],
    ]),
    hero(S(13), D.T, 'Report backup warnings at once', 'made/own_backup_drive+made/own_bell', [
      ['Save in approved locations; join recovery tests', S(13), 'v-teal'],
      ['Report missing files or warnings at once', (S(13) + E(13)) / 2, 'v-amber'],
    ]),
  ],
}));
