// Readable close-up screens for Chapters 2-10 (audit round 1, 2026-11-22).
// Same look as screens.js, but every short text is translated on its own (onscreen-ar.json entries per label),
// so new scenes need one Arabic entry per label, not one per whole screen. Addresses, names and numbers pass through as written.
import { tr } from './i18n.js';
import * as s from './screens.js';

export const win = (title, body, tone = '') => s.win(tr(title), body, tone);
export const phone = (title, body) => s.phone(tr(title), body);
export const row = (label, value = '', state = '') => s.row(tr(label), tr(value), state);
export const note = (text, tone = '') => s.note(tr(text), tone);
export const head = (text, sub = '') => s.head(tr(text), sub ? tr(sub) : '');
export const mail = (from, address, subject, body) => s.mail(tr(from), address, tr(subject), tr(body));
export const btn = (text, tone = '') => s.btn(tr(text), tone);
export const chain = items => s.chain(items.map(([t, sub, st]) => [tr(t), sub ? tr(sub) : sub, st]));
export const cols = s.cols;
export const reveal = s.reveal;
export const mark = s.mark;
