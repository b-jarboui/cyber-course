// Rules, owners, accountability.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '10.1',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 0, 0]],
  shots: [[0, 'counter'], [S(1), 'staff'], [S(2), 'her'], [S(5), 'counterDisplay'], [S(7), 'staff'], [S(10), 'her'], [S(13), 'counterDisplay'], [S(14), 'staff']],
  actions: {
    maya: [[0, S(1), 'paper'], [S(1), S(2), 'listen', 'omar'], [S(2), S(13), 'paper'], [S(13), S(14), 'read'], [S(14), D.T, 'talk', 'omar']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(2), 'talk', 'maya'], [S(2), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(5), 'file', 'Updated security policy', 'neutral'],
      [S(5), S(13), 'shield', 'Case records · Named risk owner', 'neutral'],
      [S(13), D.T, 'tick', 'Policy reviewed · Owner noted', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Updated security policy · Case 2048'],
    [S(1), E(1), 'Why policy matters at the desk'],
    [S(13), E(13), 'Named risk owner noted'],
  ],
  screens: [
    [S(0), S(2), win('Updated security policy', row('Document', 'Authority security rules', 'hi') + row('Applies to', 'All staff · Every desk', 'ok') + row('Status', 'Updated · New section', 'warn'))],
    [S(13), S(14), win('Policy · Risk owners', row('System', 'Case records system', 'hi') + row('Risk owner', 'Director of Service Operations', 'ok') + row('Role', 'Decides how risks are treated', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(5), 'Policy: set, communicated, enforced', 'made/own_policy_binder+made/own_megaphone', [
      ['Sets rules for information and services', S(2), 'v-navy'],
      ['Leaders set, share and enforce rules', S(3), 'v-teal'],
      ['Roles and authorities are written down', S(4), 'v-navy'],
    ]),
    hero(S(5), S(10), 'Every risk has an owner', 'made/id_badge+made/case_folder+made/own_shield', [
      ['Each key system has a named risk owner', S(5), 'v-teal'],
      ['Gulf authorities set baseline controls', S(7), 'v-navy'],
      ['Keep records to prove compliance', S(8), 'v-teal'],
    ]),
    hero(S(10), S(13), 'Exceptions: documented and time-limited', 'made/own_signed_document+made/own_clock', [
      ['Do not invent your own workaround', S(10), 'v-coral'],
      ['Ask your manager via the approved route', S(11), 'v-teal'],
      ['Documented, time-limited, risk-justified', S(12), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Know the rules and owners', 'made/own_policy_binder+made/id_badge', [
      ['Rules apply to every staff member', S(14), 'v-navy'],
      ['Accountability starts with clear owners', (S(14) + E(14)) / 2, 'v-teal'],
    ]),
  ],
}));
