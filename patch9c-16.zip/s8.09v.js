// When one service stops, many people feel it.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '8.2',
  actors: { official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'gathering'], [S(1), 'counterDisplay'], [S(2), 'gathering'], [S(3), 'staff'], [S(6), 'gathering'], [S(11), 'her'], [S(12), 'staff'], [S(13), 'gathering']],
  actions: {
    official: [[0, S(2), 'paper'], [S(2), S(3), 'talk', 'maya'], [S(3), S(6), 'listen', 'omar'], [S(6), S(11), 'talk', 'maya'], [S(11), D.T, 'paper']],
    maya: [[0, S(3), 'listen', 'official'], [S(3), S(6), 'listen', 'omar'], [S(6), S(11), 'listen', 'official'], [S(11), S(12), 'file'], [S(12), D.T, 'listen', 'omar']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), S(6), 'talk', 'maya'], [S(6), S(12), 'listen', 'official'], [S(12), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(6), 'calendar', 'Postponed appointments · Case 2048', 'alert'],
      [S(6), S(12), 'link', 'Authority · Partners · Applicants', 'neutral'],
      [S(12), D.T, 'shield', 'Reports protected partner entities', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Postponed appointments list'],
    [S(2), E(2), 'Authority · Partners · Suppliers'],
    [S(11), E(11), 'People waiting · Public trust'],
    [S(13), E(13), 'Every link is a door'],
  ],
  screens: [
    [S(0), S(2), win('Postponed appointments · Week', row('Case 2048', 'Postponed', 'warn') + row('Other applicants', 'Dozens waiting', 'warn') + note('Service outage delayed real people.', 'warn'), 'alert')],
    [S(2), S(3), win('Whiteboard · Linked services', row('Sadeed Authority', 'Core service', 'hi') + row('Connected to', 'Partners and suppliers', 'hi') + row('Shared services', 'Payments and applicants', 'hi'))],
  ],
  pages: [
    hero(S(3), S(6), 'Linked entities share risk', 'made/own_whiteboard+made/own_link', [
      ['A weakness in one entity reaches its partners', S(3), 'v-amber'],
      ['One careless click can open a path to many', S(5), 'v-coral'],
    ]),
    hero(S(6), S(11), 'Harm reaches people, money and trust', 'made/hospital_bed+made/own_money+made/substation', [
      ['Disrupts care, schools, transport and travel', S(7), 'v-coral'],
      ['Single attacks cost hundreds of millions', S(9), 'v-amber'],
      ['204 nationally significant UK incidents', S(10), 'v-navy'],
    ]),
    hero(S(11), S(13), 'One staff report can protect many', 'made/own_calendar+made/own_bell', [
      ['Behind every delay is a person waiting', S(11), 'v-navy'],
      ['Early reports protect applicants and partners', S(12), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Verify, report, use the backup procedure', 'made/own_shield+made/own_policy_binder', [
      ['Every link and sign-in is a door to services', S(13), 'v-amber'],
      ['Verify, report early, keep serving safely', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
