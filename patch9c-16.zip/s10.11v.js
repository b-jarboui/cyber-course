// Connected services, changing threats.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen', 'citizenYoung'];
export default chapterHall((S, E, D) => ({
  lesson: '10.3',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor', citizenYoung: 'counterEnd' },
  file: [[0, D.T, 0, 0]],
  landline: true,
  shots: [[0, 'hall'], [S(1), 'staff'], [S(2), 'counter'], [S(7), 'counterDisplay'], [S(12), 'her'], [S(13), 'counter'], [S(14), 'staff'], [S(15), 'hall']],
  actions: {
    maya: [[0, S(1), 'read'], [S(1), S(2), 'talk', 'omar'], [S(2), S(12), 'read'], [S(12), S(13), 'paper'], [S(13), S(14), 'talk', 'citizen'], [S(14), S(15), 'extension'], [S(15), D.T, 'paper']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(2), 'talk', 'maya'], [S(2), S(12), 'paper'], [S(12), D.T, 'listen', 'maya']],
    citizen: [[0, D.T, 'listen', 'maya']],
    citizenYoung: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(13), 'clock', 'Appointment screen · Slow service', 'alert'],
      [S(13), S(14), 'file', 'Continuity procedure · Active', 'neutral'],
      [S(14), D.T, 'bell', 'Slowdown reported · IR team', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Slow-service notice · Applicants waiting'],
    [S(12), E(12), 'Do not restart · Continuity procedure'],
    [S(14), E(14), 'Slowdown reported · Fault or attack?'],
  ],
  screens: [
    [S(0), S(2), win('Appointment screen · Hall', row('Service status', 'Slow response · Delays', 'warn') + row('Counter queue', 'Applicants waiting', 'warn') + row('Cause', 'Unknown — do not guess', 'hi') + note('Could be a fault or an attack.', 'warn'), 'alert')],
  ],
  pages: [
    hero(S(2), S(7), 'Every connection is a dependency', 'made/network_switch+made/queue_display', [
      ['Public admin faced 38% of EU-tracked hits', S(5), 'v-coral'],
      ['Attackers target digital supply chains', (S(5) + E(5)) / 2, 'v-amber'],
      ['Install approved updates when requested', S(6), 'v-teal'],
    ]),
    hero(S(7), S(12), 'Changing threats at scale', 'made/server_rack+made/own_warning_beacon', [
      ['94% expect AI as biggest change in 2026', S(8), 'v-amber'],
      ['Stolen data and logins traded in bulk', S(9), 'v-coral'],
      ['FBI 2025: 1M+ complaints, ~$21B losses', S(11), 'v-coral'],
    ]),
    hero(S(12), S(15), 'Follow the continuity procedure', 'made/own_policy_binder+made/own_bell', [
      ['Do not restart or test the system', S(12), 'v-coral'],
      ['Give applicants only the approved message', S(13), 'v-teal'],
      ['Do not guess the cause, report', S(14), 'v-teal'],
    ]),
    hero(S(15), D.T, 'Threats change, habits stay', 'made/own_shield+made/own_tick', [
      ['Verify, use needed access, check AI', S(15), 'v-teal'],
      ['Report early via the approved route', (S(15) + E(15)) / 2, 'v-navy'],
    ]),
  ],
}));
