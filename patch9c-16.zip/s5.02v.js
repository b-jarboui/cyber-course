// Send it safely, or not at all.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'visitor'];
export default chapterHall((S, E, D) => ({
  lesson: '5.1',
  actors: { maya: 'counter', visitor: 'door' },
  landline: true,
  leave: { visitor: S(12) },
  file: [[0, E(0), 0, 1]],
  handsets: { visitor: [[0, S(12), 'mobile']] },
  shots: [[0, 'counter'], [S(1), 'door'], [S(2), 'her'], [S(8), 'counterDisplay'], [S(12), 'her'], [S(13), 'counter'], [S(14), 'her']],
  actions: {
    maya: [[0, S(12), 'extension'], [S(12), S(13), 'read'], [S(13), S(14), 'extension'], [S(14), D.T, 'type']],
    visitor: [[0, S(12), 'call']],
  },
  displays: {
    counter: [
      [0, S(8), 'folder', 'Case 2048', 'neutral'],
      [S(8), S(12), 'mail', 'Personal mailbox request', 'alert'],
      [S(12), S(14), 'mobile', 'Official directory', 'safe'],
      [S(14), D.T, 'bell', 'Report sent', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Partner office caller'],
    [S(1), E(1), 'Personal mailbox request'],
    [S(12), E(12), 'Official directory'],
    [S(13), E(13), 'No request made'],
  ],
  screens: [
    [S(1), S(3), win('Incoming call', row('Caller', 'Claims partner office', 'warn') + row('Request', 'Case 2048 supporting files', 'warn') + row('Send to', 'partner.desk@free-mail.example', 'no') + note('Calm, urgent — asks for personal email.', 'no'), 'alert')],
    [S(12), S(13), win('Official directory', row('Partner office', '+971 50 000 0512', 'ok') + row('Files sent', 'None', 'ok') + note('Called the official directory number.'), 'good')],
  ],
  pages: [
    hero(S(3), S(6), 'Check the level', 'lock+made/case_folder', [
      ['Confidentiality in storage and transit', S(4), 'v-teal'],
    ]),
    hero(S(6), S(8), 'Encryption', 'lock+key+mail', [
      ['Unreadable to anyone who intercepts it', S(7), 'v-teal'],
    ]),
    hero(S(8), S(11), 'Approved channel only', 'mail+shield', [
      ['No personal mailbox for work files', S(8), 'v-coral'],
      ['Resist pressure to act fast', S(10), 'v-amber'],
    ]),
    hero(S(13), D.T, 'Verify through a known contact', 'made/register_book+mobile+bell', [
      ['Use the official directory number', S(13), 'v-teal'],
      ['Report unusual requests early', S(15), 'v-teal'],
    ]),
  ],
}));
