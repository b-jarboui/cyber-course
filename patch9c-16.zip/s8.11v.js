// How long, and how much.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '8.3',
  actors: { official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'gathering'], [S(1), 'staff'], [S(4), 'gathering'], [S(9), 'counterDisplay'], [S(10), 'staff'], [S(11), 'gathering'], [S(12), 'her']],
  actions: {
    official: [[0, S(1), 'talk', 'maya'], [S(1), S(4), 'listen', 'omar'], [S(4), S(9), 'talk', 'maya'], [S(9), S(11), 'listen', 'omar'], [S(11), D.T, 'paper']],
    maya: [[0, S(1), 'listen', 'official'], [S(1), S(4), 'listen', 'omar'], [S(4), S(9), 'listen', 'official'], [S(9), S(10), 'file'], [S(10), S(11), 'listen', 'omar'], [S(11), S(12), 'listen', 'official'], [S(12), D.T, 'type']],
    omar: [[0, S(1), 'listen', 'official'], [S(1), S(4), 'talk', 'maya'], [S(4), S(10), 'listen', 'official'], [S(10), S(11), 'talk', 'maya'], [S(11), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(9), 'clock', 'How long? · How much data?', 'neutral'],
      [S(9), S(12), 'file', 'Desktop notes · Not backed up', 'alert'],
      [S(12), D.T, 'folder', 'Approved folder · Backed up', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'How long? · How much data?'],
    [S(5), E(5), 'Recovery time objective'],
    [S(8), E(8), 'Recovery point objective'],
    [S(10), E(10), 'Desktop files are not backed up'],
  ],
  screens: [
    [S(0), S(1), win('Whiteboard · Recovery targets', row('Question 1', 'How long can service stop?', 'hi') + row('Question 2', 'How much recent work lost?', 'hi'))],
    [S(9), S(11), win('File storage · Case 2048', row('Approved folder', 'Case 2048 · Restored', 'ok') + row('Local desktop', 'Morning notes · Lost', 'no') + note('Desktop files are missed by backups.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(1), S(4), 'Cyber resilience: withstand, then recover', 'made/own_shield+made/own_tools', [
      ['Keep critical services going during an attack', S(1), 'v-teal'],
      ['Disaster recovery restores systems and data', S(2), 'v-navy'],
    ]),
    hero(S(4), S(7), 'Recovery time objective: how long', 'made/own_clock+made/own_whiteboard', [
      ['How long a system can stay down', S(5), 'v-navy'],
      ['Must fit within the maximum tolerable stop', S(6), 'v-amber'],
    ]),
    hero(S(7), S(9), 'Recovery point objective: how much data', 'made/own_backup_drive+made/own_calendar', [
      ['Point in time to which data is restored', S(8), 'v-navy'],
      ['Shows how much recent work could be lost', (S(8) + E(8)) / 2, 'v-amber'],
    ]),
    hero(S(12), D.T, 'Save work only in approved locations', 'made/filing_cabinet+made/own_bell', [
      ['Desktop files are missed by central backups', S(12), 'v-coral'],
      ['Save in approved folders; report lost data', S(13), 'v-teal'],
    ]),
  ],
}));
