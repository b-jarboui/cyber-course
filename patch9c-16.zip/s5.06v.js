// One click, a whole file gone.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, btn } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '5.2',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'staff'], [S(2), 'counterDisplay'], [S(4), 'her'], [S(12), 'counter'], [S(13), 'counterDisplay'], [S(14), 'her']],
  actions: {
    maya: [[0, S(12), 'paper'], [S(12), S(13), 'talk', 'omar'], [S(13), D.T, 'type']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(3), 'talk', 'maya'], [S(3), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'file-text', 'Medical report · 2048', 'neutral'],
      [S(1), S(13), 'computer', 'Free AI file upload', 'alert'],
      [S(13), D.T, 'tick', 'Approved translation route', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Medical report · Case 2048'],
    [S(2), E(2), 'Free AI file upload'],
    [S(12), E(12), 'Upload refused'],
    [S(13), E(13), 'Approved translation route'],
  ],
  screens: [
    [S(1), S(3), win('free-ai-translate.example', row('Offer', 'Translate & summarise free', 'warn') + row('Action', 'Upload your document', 'no') + row('Found via', 'Web search · Unreviewed', 'no') + btn('Upload file', 'no'), 'alert')],
    [S(3), S(5), win('Medical report · Case 2048', row('Applicant', 'Full name & ID number', 'warn') + row('Medical', 'Diagnoses & prescriptions', 'no') + row('Data type', 'Sensitive personal data', 'no') + note('Given to the Authority for one purpose.', 'warn'), 'alert')],
    [S(12), S(14), win('Approved translation route', row('Free AI upload', 'Refused · Not uploaded', 'ok') + row('Request', 'Approved translator or tool', 'ok') + row('Route', 'Official request channel', 'ok'), 'good')],
  ],
  pages: [
    hero(S(5), S(7), 'Uploading is sharing', 'file-text+wifi', [
      ['Sends a complete copy outside', S(5), 'v-coral'],
      ['Cannot be recalled once uploaded', S(5), 'v-amber'],
    ]),
    hero(S(7), S(10), 'Health records stay out', 'made/case_folder+lock', [
      ['Sensitive personal data', S(7), 'v-coral'],
      ['Authority files follow stricter rules', S(9), 'v-navy'],
    ]),
    hero(S(10), S(12), 'Approved tool only', 'computer+shield+tick', [
      ['No unreviewed commercial AI tools', S(11), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Ask before you upload', 'file-text+zoom+bell', [
      ['Approved? Allowed? Whole file needed?', S(14), 'v-teal'],
      ['Already uploaded? Report at once', S(16), 'v-amber'],
    ]),
  ],
}));
