// AI advises, people decide.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['priya', 'omar', 'maya', 'lena'];
export default chapterHall((S, E, D) => ({
  lesson: '9.4',
  actors: { priya: 'counter', omar: 'colleague', maya: 'director', lena: 'team' },
  habits: true,
  file: [[0, S(11), 1, 1], [S(11), E(11), 1, 0]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(6), 'file'], [S(7), 'counterDisplay'], [S(8), 'staff'], [S(11), 'habits'], [S(12), 'gathering'], [S(15), 'habits']],
  actions: {
    priya: [[0, S(6), 'read'], [S(6), S(7), 'file'], [S(7), S(8), 'type'], [S(8), S(12), 'talk', 'omar'], [S(12), D.T, 'listen', 'lena']],
    omar: [[0, S(6), 'listen', 'priya'], [S(6), S(8), 'paper'], [S(8), S(12), 'listen', 'priya'], [S(12), D.T, 'listen', 'lena']],
    maya: [[0, S(11), 'listen', 'priya'], [S(11), S(14), 'talk', 'omar'], [S(14), D.T, 'listen', 'lena']],
    lena: [[0, S(12), 'listen', 'maya'], [S(12), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(6), 'zoom', 'High risk · Omar backup download', 'alert'],
      [S(6), S(7), 'file', 'Authorization record · Verified', 'safe'],
      [S(7), D.T, 'tick', 'False alert closed · Account safe', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'AI alert · High-risk download'],
    [S(1), E(1), 'Approved recovery backup'],
    [S(6), E(6), 'Authorization verified · Closed'],
    [S(11), E(11), 'Chapter 9 · Four key habits'],
  ],
  screens: [
    [S(0), S(2), win('AI alert · High risk', row('Account', 'omar@sadeed.gov.example', 'warn') + row('Activity', 'Large backup download', 'warn') + row('Suggested step', 'Disable account automatically', 'no') + note('Omar ran an approved recovery backup.', 'warn'), 'alert')],
    [S(6), S(8), win('Analyst review · Rania', row('Authorization record', 'Approved recovery test', 'ok') + row('Device & time', 'Matched work schedule', 'ok') + row('Decision', 'False alert closed · Account kept', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(6), 'AI can be wrong', 'made/robot_arm+made/own_warning_beacon', [
      ['False positive: normal work flagged as threat', S(2), 'v-amber'],
      ['66% report many false positives from AI', S(3), 'v-coral'],
      ['Confident AI answers can be wrong or partial', S(5), 'v-amber'],
    ]),
    hero(S(8), S(11), 'Verify before consequential action', 'made/balance_scale+made/own_signed_document', [
      ['Limit AI autonomy on consequential steps', S(8), 'v-navy'],
      ['Check evidence, context and authorization', S(9), 'v-teal'],
      ['People stay accountable for every decision', S(10), 'v-teal'],
    ]),
    hero(S(12), D.T, 'Notice · Record · Report · Follow', 'made/own_zoom+made/own_incident_binder+made/own_bell', [
      ['Notice odd signs; record without deleting', S(12), 'v-navy'],
      ['Report immediately through approved route', S(14), 'v-teal'],
      ['Follow the team; AI advises, people decide', S(15), 'v-teal'],
    ]),
  ],
}));
