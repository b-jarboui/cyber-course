// Everyone is part of the defence.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen', 'citizenYoung'];
export default chapterHall((S, E, D) => ({
  lesson: '10.4',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor', citizenYoung: 'counterEnd' },
  file: [[0, S(14), 0, 0], [S(14), E(14), 0, 1]],
  shots: [[0, 'hall'], [S(1), 'counter'], [S(2), 'her'], [S(3), 'staff'], [S(8), 'counter'], [S(13), 'counter'], [S(14), 'file'], [S(15), 'counterDisplay']],
  actions: {
    maya: [[0, S(2), 'listen', 'citizen'], [S(2), S(13), 'read'], [S(13), S(14), 'talk', 'citizen'], [S(14), S(15), 'file'], [S(15), D.T, 'type']],
    citizen: [[0, S(2), 'talk', 'maya'], [S(2), D.T, 'listen', 'maya']],
    omar: [[0, D.T, 'listen', 'maya']],
    citizenYoung: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(13), 'lock', 'Identity check · Required', 'alert'],
      [S(13), S(15), 'shield', 'Official identity check done', 'safe'],
      [S(15), D.T, 'tick', 'Sent to registered file contact', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Busy hall · Applicant in a hurry'],
    [S(1), E(1), 'Asked to skip identity check'],
    [S(13), E(13), 'Took a beat · Identity verified'],
    [S(15), E(15), 'Recipient checked twice'],
  ],
  screens: [
    [S(0), S(2), win('Counter · Case 2048', row('Identity check', 'Required before release', 'warn') + row('Visitor request', 'Skip check — in a hurry', 'no') + row('Registered contact', 'Check file before sending', 'hi') + note('Pressure pushes toward shortcuts.', 'warn'), 'alert')],
    [S(2), S(3), win('Counter · Paused', row('Action', 'Paused above keyboard', 'hi') + row('Identity check', 'Not skipped', 'ok') + note('Pause before acting under pressure.'), 'good')],
  ],
  pages: [
    hero(S(3), S(8), 'Cybersecurity is a shared responsibility', 'made/own_shield+made/id_badge', [
      ['Not only the work of the IT team', S(3), 'v-navy'],
      ['Every action matters in a shared mission', S(4), 'v-teal'],
      ['Culture is habit, even when no one checks', S(6), 'v-teal'],
    ]),
    hero(S(8), S(13), 'Pressure is a warning sign', 'made/own_clock+made/own_warning_beacon', [
      ['Human element in 62% of 2026 breaches', S(8), 'v-coral'],
      ['69% in public admin, mostly wrong recipient', S(10), 'v-coral'],
      ['Pressure pushes people toward shortcuts', S(11), 'v-amber'],
    ]),
    hero(S(13), D.T, 'Take a beat, then verify', 'made/own_badge_reader+made/case_folder', [
      ['Resist pressure and verify via procedure', S(13), 'v-teal'],
      ['Use only the contact already in the file', S(14), 'v-navy'],
      ['Check the recipient twice', S(15), 'v-teal'],
    ]),
  ],
}));
