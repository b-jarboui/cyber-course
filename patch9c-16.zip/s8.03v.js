// Pressure from every side, and a stolen password.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '8.1',
  actors: { maya: 'counter', omar: 'colleague', official: 'director', citizen: 'visitor' },
  handsets: { citizen: [[0, S(7), 'chat']] },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'counter'], [S(2), 'staff'], [S(5), 'counter'], [S(7), 'gathering'], [S(8), 'counterDisplay'], [S(9), 'staff'], [S(11), 'gathering'], [S(13), 'her']],
  actions: {
    maya: [[0, S(2), 'listen', 'citizen'], [S(2), S(5), 'listen', 'omar'], [S(5), S(7), 'talk', 'citizen'], [S(7), S(8), 'listen', 'official'], [S(8), S(11), 'listen', 'omar'], [S(11), S(13), 'listen', 'official'], [S(13), D.T, 'type']],
    omar: [[0, S(2), 'listen', 'citizen'], [S(2), S(5), 'talk', 'maya'], [S(5), S(8), 'listen', 'official'], [S(8), S(11), 'talk', 'maya'], [S(11), D.T, 'listen', 'official']],
    official: [[0, S(7), 'listen', 'citizen'], [S(7), S(8), 'paper'], [S(8), S(11), 'listen', 'omar'], [S(11), S(13), 'talk', 'maya'], [S(13), D.T, 'paper']],
    citizen: [[0, S(5), 'text'], [S(5), S(7), 'listen', 'maya'], [S(7), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(5), 'folder', 'Case 2048', 'neutral'],
      [S(5), S(7), 'bell', 'Text threat reported', 'safe'],
      [S(7), S(13), 'key', 'IT finding · Stolen password', 'alert', 'login'],
      [S(13), D.T, 'shield', 'Protect every account', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Threatening text to applicant'],
    [S(5), E(5), 'Do not reply · Reported'],
    [S(7), E(7), 'IT finding · Stolen password'],
    [S(13), E(13), 'Approve only your own sign-in'],
  ],
  screens: [
    [S(0), S(2), phone('Text message · Unknown', row('From', '+971 50 000 0147', 'no') + row('Message', 'We have your Case 2048 papers.', 'no') + note('Tell the Authority to pay now.', 'no'))],
    [S(5), S(7), win('Counter report · Case 2048', row('Reply or link', 'Do not reply or open', 'ok') + row('Report', 'Sent via approved route', 'ok') + row('Follow-up', 'Official channel only', 'ok'), 'good')],
    [S(7), S(8), win('IT finding · Initial entry', row('Entry method', 'Staff account password', 'no') + row('Break-in', 'None — valid sign-in', 'warn') + note('Attack began with a stolen password.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(2), S(5), 'Multi-extortion: pressure on the people affected', 'made/own_mobile+made/own_chat+made/own_warning_beacon', [
      ['Pressure on both institution and applicants', S(2), 'v-coral'],
      ['Extortionists target government and services', S(3), 'v-amber'],
    ]),
    hero(S(8), S(11), 'Most attacks start with an identity', 'made/own_key+made/id_badge', [
      ['79% of ransomware starts with identity', S(9), 'v-coral'],
      ['73% of victims had leaked credentials', S(10), 'v-amber'],
    ]),
    hero(S(11), S(13), 'Never share a code or a password', 'made/own_lock+made/own_mobile', [
      ['Strong MFA must cover every account', S(11), 'v-teal'],
      ['97% of credential victims had MFA gaps', S(12), 'v-amber'],
    ]),
    hero(S(13), D.T, 'Approve only the sign-in you started', 'made/own_shield+made/own_bell', [
      ['Never share a password or sign-in code', S(13), 'v-coral'],
      ['Report any pressuring message at once', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
