// The guest nobody invited.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '5.2',
  actors: { official: 'desk', maya: 'beside', omar: 'deskGuest' },
  shots: [[0, 'pair'], [S(1), 'display'], [S(3), 'desk'], [S(4), 'pair'], [S(14), 'desk'], [S(15), 'display'], [S(16), 'pair']],
  actions: {
    official: [[0, S(3), 'read'], [S(3), S(4), 'talk', 'maya'], [S(4), S(14), 'read'], [S(14), S(15), 'talk', 'maya'], [S(15), D.T, 'type']],
    maya: [[0, S(3), 'listen', 'official'], [S(3), D.T, 'listen', 'official']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), D.T, 'listen', 'official']],
  },
  displays: {
    desk: [
      [0, S(1), 'computer', 'Case 2048 · Video call', 'neutral'],
      [S(1), S(14), 'megaphone', 'AI notetaker joined', 'alert'],
      [S(14), D.T, 'shield', 'Notetaker removed', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048 · Video call'],
    [S(1), E(1), 'AI notetaker joined'],
    [S(3), E(3), 'Discussion paused'],
    [S(14), E(14), 'Notetaker removed'],
  ],
  screens: [
    [S(1), S(3), win('Case 2048 · Video call', row('Participants', 'Hamad, Shaima, Omar, Partner') + row('Just joined', 'AI Notetaker (Uninvited)', 'no') + row('Recording', 'Active · Auto-joined', 'no') + note('Joined via partner calendar invite.', 'no'), 'alert')],
    [S(14), S(15), win('Case 2048 · Video call', row('AI Notetaker', 'Removed from call', 'ok') + row('Case talk', 'Paused until removed', 'ok') + row('Report', 'Sent via approved route', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(9), 'Unknown notetaker', 'made/headset+computer+wifi', [
      ['Processed in third-party cloud', S(5), 'v-coral'],
      ['Durable, searchable transcripts', S(8), 'v-amber'],
    ]),
    hero(S(9), S(11), 'Review the notes', 'file-text+zoom', [
      ['May invent words or swap speakers', S(9), 'v-amber'],
      ['Unreviewed errors become the record', S(10), 'v-coral'],
    ]),
    hero(S(11), S(13), 'Voice is personal data', 'megaphone+made/id_badge', [
      ['Voice analysis without consent', S(12), 'v-coral'],
    ]),
    hero(S(15), D.T, 'Approved tool, told participants', 'shield+tick+bell', [
      ['Store reviewed notes in approved place', S(16), 'v-teal'],
      ['Unknown bot? Pause and report', S(17), 'v-amber'],
    ]),
  ],
}));
