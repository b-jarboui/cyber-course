// A name under every decision.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, btn } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '5.3',
  actors: { maya: 'counter', omar: 'colleague', official: 'signer' },
  file: [[0, S(1), 1, 1], [S(15), E(15), 1, 0]],
  signing: true,
  habits: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(6), 'file'], [S(7), 'file'], [S(8), 'counter'], [S(11), 'habits'], [S(15), 'file']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(3), 'talk', 'official'], [S(3), S(6), 'read'], [S(6), S(7), 'file'], [S(7), S(15), 'listen', 'official'], [S(15), D.T, 'file']],
    omar: [[0, S(7), 'listen', 'maya'], [S(7), D.T, 'listen', 'official']],
    official: [[0, S(7), 'listen', 'maya'], [S(7), E(7), 'sign'], [S(8), S(15), 'talk', 'maya'], [S(15), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'folder', 'Case 2048', 'neutral'],
      [S(1), S(7), 'file-text', 'AI draft · Refusal', 'alert'],
      [S(7), S(15), 'tick', 'Approved and signed', 'safe'],
      [S(15), D.T, 'folder', 'Next case', 'neutral'],
    ],
  },
  plates: [
    [S(1), E(1), 'AI draft · Refusal'],
    [S(6), E(6), 'Supporting document found'],
    [S(7), E(7), 'Signed by Hamad'],
    [S(15), E(15), 'Next case'],
  ],
  screens: [
    [S(1), S(3), win('AI draft · Refusal', row('Case', 'Case 2048 · Late request') + row('Draft decision', 'Refused (AI suggested)', 'no') + row('Decided by', 'No named staff member', 'no') + btn('Send reply', 'off'), 'alert')],
    [S(6), S(8), win('Case 2048 · Final decision', row('Supporting file', 'Found in another folder', 'ok') + row('Decision owner', 'Hamad · Approved & signed', 'ok') + row('Record note', 'AI draft · Checked by Shaima', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(6), 'AI suggests, a person decides', 'computer+made/rubber_stamp', [
      ['Human oversight on key decisions', S(4), 'v-teal'],
      ['Governance, monitoring, accountability', S(5), 'v-navy'],
    ]),
    hero(S(8), S(11), 'Every decision has a named owner', 'made/id_badge+made/register_book', [
      ['Owner, review and approved location', S(8), 'v-teal'],
      ['Record use and limit AI reach', S(10), 'v-navy'],
    ]),
    hero(S(11), S(14), 'Say that AI helped', 'shield+file-text+tick', [
      ['Check level, channel and retention', S(11), 'v-teal'],
      ['Approved AI only; check every draft', S(12), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Stop, verify, report', 'shield+made/register_book+bell', [
      ['Verify through a known official channel', S(14), 'v-teal'],
      ['People remain in charge', S(15), 'v-teal'],
    ]),
  ],
}));
