// The helper inside the browser.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '5.2',
  actors: { maya: 'counter', omar: 'colleague', official: 'director' },
  enter: { official: S(12) },
  shots: [[0, 'counter'], [S(1), 'staff'], [S(2), 'counterDisplay'], [S(3), 'her'], [S(11), 'counter'], [S(12), 'gathering'], [S(13), 'counterDisplay'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(1), 'read'], [S(1), S(2), 'listen', 'omar'], [S(2), S(11), 'read'], [S(11), S(12), 'talk', 'omar'], [S(12), D.T, 'listen', 'official']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(2), 'talk', 'maya'], [S(2), S(12), 'listen', 'maya'], [S(12), D.T, 'listen', 'official']],
    official: [[S(12), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(3), 'puzzle', 'New browser assistant', 'neutral'],
      [S(3), S(12), 'link', 'Read all websites', 'alert'],
      [S(12), D.T, 'shield', 'Extensions under review', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Shared counter laptop'],
    [S(3), E(3), 'Read all websites'],
    [S(11), E(11), 'Permission declined'],
    [S(12), E(12), 'Extensions under review'],
  ],
  screens: [
    [S(2), S(4), win('Browser extension · Permissions', row('Side panel', 'Active on case system', 'warn') + row('Website data', 'Read and change all sites', 'no') + row('Browsing history', 'See every web address', 'no') + note('Unapproved extension on shared laptop.', 'no'), 'alert')],
    [S(11), S(13), win('Extensions · Shared laptop', row('Permission prompt', 'Declined · Not allowed', 'ok') + row('AI assistant', 'Stopped', 'ok') + row('IT review', 'Reported via approved route', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(6), 'Browser extension', 'computer+puzzle', [
      ['Reads every page and AI answer', S(4), 'v-coral'],
      ['Look-alike AI extensions steal chats', S(5), 'v-amber'],
    ]),
    hero(S(6), S(11), 'Read all websites?', 'link+zoom+bell', [
      ['A store badge is not proof of safety', S(7), 'v-amber'],
      ['Updates can change what it does', S(8), 'v-coral'],
    ]),
    hero(S(13), S(15), 'Approved list only', 'made/register_book+shield', [
      ['Audit every extension permission', S(13), 'v-teal'],
      ['Decline read-all-websites requests', S(14), 'v-amber'],
    ]),
    hero(S(15), D.T, 'Ask, then install', 'shield+tools+bell', [
      ['Approved? What it sees? Where data goes?', S(15), 'v-teal'],
      ['Unknown icon? Stop and report', S(16), 'v-amber'],
    ]),
  ],
}));
