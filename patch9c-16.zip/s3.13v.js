// A news story about us, from nowhere
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["omar", "lena", "official"];
export default chapterHall((S, E, D) => ({
  lesson: "3.3",
  actors: { omar: 'desk', lena: 'beside', official: 'deskGuest' },
  shots: [[0,'pair'], [S(1),'display'], [S(2),'pair'], [S(6),'display'], [S(9),'desk'], [S(13),'pair'], [S(14),'desk'], [S(15),'pair']],
  actions: { omar: [[0,S(4),'read'], [S(4),S(6),'type'], [S(6),S(9),'read'], [S(9),E(9),'type'], [S(10),S(14),'listen','lena'], [S(14),E(14),'type'], [S(15),D.T,'listen','official']], lena: [[0,S(10),'listen','omar'], [S(10),S(13),'talk','omar'], [S(13),D.T,'listen','official']], official: [[0,S(2),'listen','omar'], [S(2),S(4),'talk','omar'], [S(4),S(15),'listen','omar'], [S(15),D.T,'talk','omar']] },
  setupProps: evidence({
    surfaces: { desk: [[0,S(4),'article','Unconfirmed data leak'], [S(6),S(9),'draft','Article and draft reply']] },
    pointAt: [[S(2),E(2),'official','desk']], inserts: [[S(1),E(1),'desk'], [S(7),E(7),'desk']],
  }),
  displays: { desk: [[S(4),S(6),'computer','No official report','neutral'], [S(9),S(14),'file','Draft deleted','safe'], [S(14),D.T,'bell','Report sent','safe']] },
  plates: [[S(1),E(1),'Unconfirmed data leak'], [S(2),E(2),'No author or date'], [S(7),E(7),'Unverified figure'], [S(14),E(14),'Save the link and time']],
  screens: [
    [S(1), S(3), q => win('daily-wire-news.example', reveal([
      row('Headline', 'Unconfirmed data leak', 'no'),
      row('Author', 'None listed', 'no'),
      row('Date & sources', 'Missing', 'no'),
      note('Looks like news — no author or date.', 'no'),
    ], q), 'alert')],
    [S(6), S(8), q => win('AI draft reply', reveal([
      row('Tone', 'Confident public reply', 'warn'),
      row('Affected count', 'Unverified figure', 'no'),
      note('Never publish unverified AI figures.', 'no'),
    ], q), 'alert')],
    [S(13), S(15), q => win('Report sent', reveal([
      row('Staff chat', 'No reply · Not forwarded', 'ok'),
      row('Saved details', 'Link and time seen', 'ok'),
      row('Draft reply', 'Deleted', 'ok'),
    ], q), 'good')],
  ],
  pages: [
    hero(S(3), S(4), "Who published it, and when?", "made/laptop+calendar", [
      ["No author or date", S(3), "v-amber"],
    ]),
    hero(S(4), S(6), "Compare with official sources", "computer+made/register_book", [
      ["No official report", S(4), "v-navy"],
    ]),
    hero(S(8), S(10), "Check AI output before using it", "made/laptop+file-text", [
      ["Unverified figure", S(8), "v-amber"],
      ["Draft deleted", S(9), "v-teal"],
    ]),
  ],
}));
