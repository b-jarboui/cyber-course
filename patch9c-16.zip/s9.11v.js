// Learn, correct, improve.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'priya', 'lena', 'official', 'admin'];
export default chapterHall((S, E, D) => ({
  lesson: '9.3',
  actors: { official: 'director', maya: 'counter', omar: 'colleague', priya: 'team', lena: 'teamEnd', admin: 'desk' },
  file: [[0, S(14), 0, 0], [S(14), E(14), 0, 1]],
  shots: [[0, 'gathering'], [S(2), 'staff'], [S(5), 'gathering'], [S(8), 'desk'], [S(11), 'gathering'], [S(14), 'counterDisplay'], [S(15), 'counter']],
  actions: {
    official: [[0, S(5), 'paper'], [S(5), S(11), 'talk', 'maya'], [S(11), D.T, 'paper']],
    maya: [[0, S(14), 'listen', 'official'], [S(14), S(15), 'type'], [S(15), D.T, 'file']],
    omar: [[0, S(5), 'listen', 'official'], [S(5), S(8), 'paper'], [S(8), D.T, 'listen', 'official']],
    priya: [[0, S(8), 'listen', 'official'], [S(8), S(11), 'paper'], [S(11), D.T, 'listen', 'official']],
    lena: [[0, S(11), 'listen', 'official'], [S(11), S(14), 'talk', 'maya'], [S(14), D.T, 'listen', 'maya']],
    admin: [[0, S(8), 'read'], [S(8), D.T, 'type']],
  },
  displays: {
    counter: [
      [0, S(8), 'clock', 'Post-incident review · 2048', 'neutral'],
      [S(8), S(14), 'tools', '4 corrective actions assigned', 'safe'],
      [S(14), D.T, 'tick', 'Case 2048 · Clean system', 'safe'],
    ],
    desk: [
      [0, S(8), 'zoom', 'Root cause · Old access setting', 'alert'],
      [S(8), D.T, 'shield', 'Controls updated · Verified', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'One week later · Review meeting'],
    [S(4), E(4), 'Root cause · Broad old setting'],
    [S(8), E(8), 'Four corrective actions'],
    [S(14), E(14), 'Case 2048 completed safely'],
  ],
  screens: [
    [S(1), S(2), win('Post-incident review · Case 2048', row('Services', 'Restored and working', 'ok') + row('Review focus', 'Find causes & fix gaps', 'hi') + row('Goal', 'Stronger controls next time', 'ok'))],
  ],
  pages: [
    hero(S(2), S(5), 'What happened? Why? What changes?', 'made/own_whiteboard+made/own_incident_binder', [
      ['Rebuild timeline from logs, evidence and notes', S(3), 'v-navy'],
      ['Found stolen account plus old broad access', S(4), 'v-amber'],
    ]),
    hero(S(5), S(11), 'Fix the cause, not only the damage', 'made/own_tools+made/own_setting', [
      ['Find system gaps, not someone to blame', S(6), 'v-teal'],
      ['Cut excess access, fix cloud, test backups', S(8), 'v-navy'],
      ['Limit AI agents; set owner, deadline, check', S(9), 'v-teal'],
    ]),
    hero(S(11), D.T, 'Report · Respond · Recover · Improve', 'made/own_policy_binder+made/own_shield', [
      ['Review plans and reports after every incident', S(11), 'v-navy'],
      ['Each lesson strengthens the next defence', S(13), 'v-teal'],
      ['Result: a safer, more resilient institution', S(15), 'v-teal'],
    ]),
  ],
}));
