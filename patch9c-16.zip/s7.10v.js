// The update from a trusted supplier.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.3',
  actors: { official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'gathering'], [S(1), 'counter'], [S(2), 'staff'], [S(3), 'her'], [S(11), 'gathering'], [S(12), 'counterDisplay'], [S(13), 'staff']],
  actions: {
    official: [[0, S(3), 'paper'], [S(3), S(11), 'listen', 'omar'], [S(11), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'omar']],
    maya: [[0, S(2), 'listen', 'official'], [S(2), S(3), 'talk', 'omar'], [S(3), S(12), 'listen', 'omar'], [S(12), S(13), 'read'], [S(13), D.T, 'listen', 'omar']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), S(11), 'talk', 'maya'], [S(11), S(13), 'listen', 'official'], [S(13), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(12), 'setting', 'Supplier update notice', 'neutral'],
      [S(12), D.T, 'tick', 'Verified by IT · Case 2048 open', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Supplier update notice'],
    [S(11), E(11), 'IT checks via contract contact'],
    [S(12), E(12), 'Verified update · Case 2048 open'],
    [S(14), E(14), 'Trust is not verification'],
  ],
  screens: [
    [S(1), S(3), win('Supplier update notice', row('From', 'updates@casesys-vendor.example', 'warn') + row('System', 'Case system · New version ready', 'hi') + note('Do not install until IT verifies it.', 'warn'))],
  ],
  pages: [
    hero(S(3), S(8), 'Supply chain', 'made/supplier_truck+made/parcel', [
      ['Harm arrives through a trusted update', S(4), 'v-coral'],
      ['Poisoned code spreads across hundreds of packages', S(6), 'v-amber'],
    ]),
    hero(S(8), S(11), 'Trusted does not mean safe', 'made/own_link+made/own_warning_beacon', [
      ['One supplier incident can hit thousands', S(8), 'v-amber'],
      ['Third parties featured in 48% of breaches', S(9), 'v-coral'],
    ]),
    hero(S(11), S(13), 'IT verifies the supplier', 'made/register_book+made/own_tick', [
      ['Staff do not install supplier updates directly', S(11), 'v-teal'],
      ['IT confirms via contract and deploys safely', S(12), 'v-navy'],
    ]),
    hero(S(13), D.T, 'Report anything odd', 'made/own_setting+made/own_bell', [
      ['Odd behaviour or new permission? Warning sign', S(13), 'v-amber'],
      ['Stop and report; let IT check with supplier', S(15), 'v-teal'],
    ]),
  ],
}));
