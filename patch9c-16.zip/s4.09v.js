// One account, many cloud doors.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.2',
  actors: { official: 'desk', maya: 'beside', omar: 'aisle' },
  habits: true,
  walks: { omar: [[S(9), E(9), 'deskGuest']] },
  shots: [[0, 'pair'], [S(1), 'display'], [S(3), 'pair'], [S(9), 'desk'], [S(10), 'pair'], [S(12), 'display'], [S(13), 'habits']],
  actions: {
    official: [[0, S(9), 'read'], [S(9), S(10), 'listen', 'maya'], [S(10), S(12), 'type'], [S(12), D.T, 'talk', 'maya']],
    maya: [[0, S(9), 'listen', 'official'], [S(9), E(9), 'talk', 'omar'], [S(10), D.T, 'listen', 'official']],
    omar: [[S(10), E(10), 'talk', 'maya'], [S(11), D.T, 'listen', 'official']],
  },
  displays: {
    desk: [[0, S(10), 'bell', 'Outside cloud sign-in', 'alert'], [S(10), S(12), 'bell', 'Report sent', 'safe'], [S(12), D.T, 'shield', 'Account contained', 'safe']],
  },
  plates: [[S(0), E(0), 'Security alert'], [S(1), E(1), 'Email, files and contacts'], [S(10), E(10), 'Omar never travelled'], [S(12), E(12), 'Account contained']],
  screens: [
    [S(0), S(2), q => win('Security alert', reveal([
      row('Account', 'omar@sadeed.gov.example', 'warn'),
      row('Sign-in location', 'Outside the country', 'no'),
      row('Accessed', 'Email, files, staff directory', 'no'),
      note('Valid credentials used from abroad.', 'no'),
    ], q), 'alert')],
  ],
  pages: [
    hero(S(2), S(4), 'A valid sign-in can still be hostile', 'made/id_badge+made/padlock_open', [
      ['Valid identity information misused', S(2), 'v-amber'],
    ]),
    hero(S(4), S(9), 'One identity, many cloud services', 'mail+folder+wifi', [
      ['Email, files and contacts', S(5), 'v-amber'],
      ['Often involves no malware', S(7), 'v-coral'],
    ]),
    hero(S(10), S(12), 'Report unfamiliar activity immediately', 'bell+mobile', [
      ['Do not use the affected account', S(11), 'v-amber'],
    ]),
    hero(S(12), S(13), 'The authorized team contains the incident', 'shield+lock', [
      ['Disable, end sessions, revoke tokens', S(12), 'v-teal'],
    ]),
  ],
}));
