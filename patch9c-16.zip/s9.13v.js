// Faster triage, faster response.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['priya', 'lena', 'analyst'];
export default chapterHall((S, E, D) => ({
  lesson: '9.4',
  actors: { priya: 'desk', lena: 'beside', analyst: 'deskGuest' },
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'pair'], [S(6), 'display'], [S(10), 'pair'], [S(14), 'desk'], [S(15), 'pair']],
  actions: {
    priya: [[0, S(6), 'read'], [S(6), S(10), 'type'], [S(10), S(14), 'read'], [S(14), S(15), 'talk', 'lena'], [S(15), D.T, 'type']],
    lena: [[0, S(6), 'listen', 'priya'], [S(6), S(10), 'paper'], [S(10), S(14), 'listen', 'priya'], [S(14), D.T, 'talk', 'priya']],
    analyst: [[0, S(10), 'listen', 'priya'], [S(10), D.T, 'paper']],
  },
  displays: {
    desk: [
      [0, S(6), 'bell', '3 amber alerts · AI grouped', 'alert'],
      [S(6), S(14), 'zoom', 'Threat intel · Pattern match', 'alert'],
      [S(14), D.T, 'tick', 'Containment · Approved by lead', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Three alerts · Incident triage'],
    [S(6), E(6), 'Threat intelligence match'],
    [S(10), E(10), 'Approved automated playbooks'],
    [S(14), E(14), 'Team lead approves containment'],
  ],
  screens: [
    [S(0), S(2), win('Alert triage · 3 open', row('Alert 1', 'Routine test · Likely harmless', 'ok') + row('Alert 2', 'Odd login · Needs review', 'warn') + row('Alert 3', 'Public service at risk', 'no'), 'alert')],
  ],
  pages: [
    hero(S(2), S(6), 'AI adds context, people set priority', 'made/control_desk+made/own_file', [
      ['Triage puts public-service risks first', S(2), 'v-navy'],
      ['AI groups signals and summarises evidence', S(3), 'v-teal'],
      ['About 1 in 3 entities use AI to investigate', S(5), 'v-amber'],
    ]),
    hero(S(6), S(10), 'Threat intelligence strengthens the picture', 'made/own_shield+made/own_megaphone', [
      ['Matches alerts against trusted threat data', S(6), 'v-teal'],
      ['National platforms share alerts and indicators', S(7), 'v-navy'],
      ['AI shortens time from flaw to exploitation', S(9), 'v-coral'],
    ]),
    hero(S(10), D.T, 'Automate within approved limits', 'made/robot_arm+made/own_policy_binder', [
      ['Approved workflows act at machine speed', S(10), 'v-teal'],
      ['AI never invents its own authority', S(12), 'v-coral'],
      ['Service-impacting steps need human approval', S(13), 'v-navy'],
    ]),
  ],
}));
