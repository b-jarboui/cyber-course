// When the screens go dark, the service goes on.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '8.3',
  actors: { maya: 'counter', omar: 'desk', official: 'director', citizen: 'visitor' },
  file: [[0, D.T, 1, 1]],
  landline: 'desk',
  shots: [[0, 'counterDisplay'], [S(1), 'counter'], [S(2), 'file'], [S(3), 'hall'], [S(5), 'desk'], [S(7), 'gathering'], [S(9), 'staff'], [S(12), 'counter'], [S(13), 'gathering']],
  actions: {
    maya: [[0, S(1), 'listen', 'citizen'], [S(1), S(3), 'sign'], [S(3), S(7), 'file'], [S(7), S(12), 'listen', 'official'], [S(12), S(13), 'sign'], [S(13), D.T, 'listen', 'official']],
    omar: [[0, S(3), 'paper'], [S(3), S(5), 'talk', 'maya'], [S(5), S(7), 'extension'], [S(7), D.T, 'paper']],
    official: [[0, S(7), 'paper'], [S(7), S(12), 'talk', 'maya'], [S(12), D.T, 'paper']],
    citizen: [[0, S(3), 'listen', 'maya'], [S(3), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, D.T, 'computer', 'Exercise · Screens switched off', 'neutral'],
    ],
    desk: [
      [0, D.T, 'computer', 'Exercise · Screens switched off', 'neutral'],
    ],
  },
  plates: [
    [S(0), E(0), 'Continuity exercise · Screens off'],
    [S(1), E(1), 'Approved paper form · Case 2048'],
    [S(5), E(5), 'Printed contact list · Desk phone'],
    [S(12), E(12), 'Lesson logged · More paper forms'],
  ],
  screens: [
    [S(1), S(3), win('Paper form · Continuity exercise', row('Case file', 'Case 2048', 'ok') + row('Time recorded', '09:15 · Hall counter', 'ok') + row('Reference', 'MAN-2048-01', 'ok') + note('Ready to enter when IT returns.', ''), 'good')],
    [S(12), S(13), win('Exercise review · Notes', row('Gap found', 'Paper forms ran short', 'warn') + row('Plan update', 'Keep larger drawer stock', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(7), 'Paper forms and printed contact lists', 'made/paper_tray+made/own_desk_phone', [
      ['Manual forms keep service moving when IT stops', S(3), 'v-teal'],
      ['Keep plans and contact lists offline on paper', S(6), 'v-navy'],
    ]),
    hero(S(7), S(9), 'Use only the approved alternative channels', 'made/own_policy_binder+made/own_warning_beacon', [
      ['Criminals send fake help during outages', S(7), 'v-coral'],
      ['Use only channels listed in the printed plan', S(8), 'v-teal'],
    ]),
    hero(S(9), S(12), 'One team coordinates the recovery', 'made/own_whiteboard+made/own_incident_binder', [
      ['Incident, service, IT and comms work as one', S(9), 'v-navy'],
      ['Clear escalation and national notification', S(10), 'v-teal'],
      ['Sixth Gulf Cyber Exercise practised joint work', S(11), 'v-navy'],
    ]),
    hero(S(13), D.T, 'Practise before the real day', 'made/own_clock+made/own_signed_document', [
      ['Know where paper forms and contact lists are', S(13), 'v-teal'],
      ['Follow the coordinating team; join exercises', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
