// Locked, and copied too.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, mail } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '8.1',
  actors: { maya: 'counter', omar: 'colleague', official: 'director', citizen: 'door' },
  enter: { citizen: S(12) },
  file: [[0, D.T, 1, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(3), 'staff'], [S(7), 'gathering'], [S(9), 'her'], [S(12), 'door'], [(S(12) + E(12)) / 2, 'counter'], [S(13), 'her']],
  actions: {
    maya: [[0, S(3), 'read'], [S(3), S(9), 'listen', 'omar'], [S(9), S(10), 'read'], [S(10), S(12), 'type'], [S(12), S(13), 'extension'], [S(13), D.T, 'read']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(8), 'talk', 'maya'], [S(8), D.T, 'listen', 'maya']],
    official: [[0, S(8), 'paper'], [S(8), S(9), 'talk', 'maya'], [S(9), D.T, 'paper']],
    citizen: [[S(12), E(12), 'call']],
  },
  displays: {
    counter: [
      [0, S(1), 'mail', 'General mailbox · New email', 'neutral', 'inbox'],
      [S(1), S(10), 'mail', 'Threat to publish files', 'alert', 'inbox'],
      [S(10), D.T, 'bell', 'Reported · Kept as evidence', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'General mailbox · New email'],
    [S(2), E(2), 'Threat to publish files'],
    [S(10), E(10), 'Reported · Kept as evidence'],
    [S(12), E(12), 'Official channel only'],
  ],
  screens: [
    [S(1), S(3), win('General mailbox', mail('Unknown Sender', 'extort@outside-mail.example', 'Case 2048 files copied', 'We copied your files. Pay or we publish them.'), 'alert')],
    [S(12), S(13), phone('Desk call · Applicant', row('Caller asks', 'Status of Case 2048', 'wait') + row('Incident details', 'Not confirmed', 'ok') + row('Next step', 'Official channel contact', 'ok'))],
  ],
  pages: [
    hero(S(3), S(7), 'Double extortion: lock and threaten to publish', 'made/ransom_laptop+made/own_mail', [
      ['Lock files and threaten to release data', S(3), 'v-coral'],
      ['Some criminals skip encryption and only extort', S(4), 'v-amber'],
      ['Data theft attempted in 80% of incidents', S(6), 'v-coral'],
    ]),
    hero(S(7), S(9), 'A backup does not undo the theft', 'made/own_backup_drive+made/case_folder', [
      ['Backups restore files, not confidentiality', S(7), 'v-amber'],
      ['Personal data theft puts applicants at risk', S(8), 'v-coral'],
    ]),
    hero(S(9), S(12), 'Do not reply, negotiate or forward', 'made/own_mail+made/own_incident_binder', [
      ['Keep the message untouched as evidence', S(10), 'v-navy'],
      ['Authorised team decides all response steps', S(11), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Report through the approved route', 'made/own_bell+made/own_desk_phone', [
      ['Never reply, negotiate or share threats', S(13), 'v-coral'],
      ['Confirm nothing; use official channels only', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
