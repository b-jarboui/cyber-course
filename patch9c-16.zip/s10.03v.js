// Measured, reviewed, improved.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '10.1',
  actors: { omar: 'desk', maya: 'beside' },
  shots: [[0, 'pair'], [S(1), 'display'], [S(4), 'desk'], [S(9), 'pair'], [S(12), 'display'], [S(14), 'pair']],
  actions: {
    omar: [[0, S(1), 'talk', 'maya'], [S(1), S(4), 'read'], [S(4), S(12), 'type'], [S(12), S(14), 'read'], [S(14), D.T, 'talk', 'maya']],
    maya: [[0, S(14), 'listen', 'omar'], [S(14), D.T, 'paper']],
  },
  displays: {
    desk: [
      [0, S(4), 'computer', 'Monthly security dashboard', 'neutral'],
      [S(4), S(12), 'shield', 'Six functions · Govern at centre', 'neutral'],
      [S(12), D.T, 'tick', 'Reported message counted', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Monthly security dashboard'],
    [S(14), E(14), 'Last month report counted'],
  ],
  screens: [
    [S(0), S(1), win('Monthly security dashboard', row('Updates on time', '96% installed', 'ok') + row('Staff reports', '14 suspicious messages', 'hi') + row('Open gaps', '3 under review', 'warn'))],
    [S(14), E(14), win('Monthly security dashboard', row('Last month reports', '14 logged · Honest count', 'ok') + row('Shaima report', 'Suspicious message · Counted', 'ok') + note('Every report helps improve controls.'), 'good')],
  ],
  pages: [
    hero(S(1), S(4), 'Measure, review, improve', 'made/own_tablet+made/own_setting', [
      ['Governance checks that controls work', S(2), 'v-navy'],
      ['Track update speed and staff reports', S(3), 'v-teal'],
    ]),
    hero(S(4), S(12), 'Six functions, governance at the centre', 'made/own_whiteboard+made/own_shield', [
      ['Govern, Identify, Protect, Detect, Respond, Recover', S(6), 'v-navy'],
      ['Review risk results to adjust strategy', S(9), 'v-teal'],
      ['NIST CSF 2.0 & ISO 27001: keep improving', S(10), 'v-navy'],
    ]),
    hero(S(12), S(14), 'Report every event, even without harm', 'made/own_bell+made/own_file', [
      ['Dashboard numbers only help if honest', S(12), 'v-amber'],
      ['Report suspicious events via approved route', S(13), 'v-teal'],
    ]),
  ],
}));
