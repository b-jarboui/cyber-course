// Allowed to open, not to take.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '7.3',
  actors: { maya: 'counter', omar: 'colleague', official: 'director' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(2), 'counterDisplay'], [S(3), 'her'], [S(4), 'staff'], [S(8), 'counter'], [S(10), 'gathering'], [S(11), 'counterDisplay'], [S(12), 'staff'], [S(17), 'gathering']],
  actions: {
    maya: [[0, S(2), 'type'], [S(2), S(4), 'read'], [S(4), S(8), 'listen', 'omar'], [S(8), S(10), 'talk', 'official'], [S(10), S(11), 'listen', 'official'], [S(11), S(12), 'read'], [S(12), S(17), 'listen', 'omar'], [S(17), D.T, 'listen', 'official']],
    omar: [[0, S(4), 'listen', 'maya'], [S(4), S(8), 'talk', 'maya'], [S(8), S(11), 'listen', 'official'], [S(11), S(12), 'point'], [S(12), S(17), 'talk', 'maya'], [S(17), D.T, 'listen', 'official']],
    official: [[0, S(10), 'listen', 'maya'], [S(10), S(11), 'talk', 'maya'], [S(11), S(17), 'listen', 'omar'], [S(17), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'mail', 'Case 2048 · Summary draft', 'neutral', 'inbox'],
      [S(2), S(11), 'mail', 'Warning: Outside recipient', 'alert', 'inbox'],
      [S(11), S(17), 'file', 'Alert: Night bulk copy', 'alert'],
      [S(17), D.T, 'shield', 'Exports logged · Remote only', 'safe'],
    ],
  },
  plates: [
    [S(2), E(2), 'Warning: Outside recipient'],
    [S(8), E(8), 'No applicant data in free AI'],
    [S(11), E(11), 'Alert: Night bulk copy'],
    [S(17), E(17), 'Approved remote channel only'],
  ],
  screens: [
    [S(1), S(3), q => win('New email · Case 2048', reveal([row('To', 'tariq.h@outside-mail.example', 'no'), row('Subject', 'Case 2048 summary', 'warn'), note('Warning: Outside the Authority.', 'no')], q), 'alert')],
    [S(11), S(12), win('Security alert · Bulk export', row('Time', '02:14 · Night', 'warn') + row('Account', 'Staff account · Case system', 'warn') + row('Activity', 'Large applicant list copied out', 'no'), 'alert')],
  ],
  pages: [
    hero(S(4), S(6), 'Insider threats', 'made/id_badge+made/case_folder', [
      ['Harm from people who already have access', S(4), 'v-amber'],
      ['Covers both intentional and accidental acts', S(5), 'v-navy'],
    ]),
    hero(S(6), S(11), 'Honest mistakes', 'made/own_mail+made/own_warning_beacon', [
      ['Mistyped address or unapproved free AI tool', S(6), 'v-coral'],
      ['Approved AI on work account only', S(10), 'v-teal'],
    ]),
    hero(S(12), S(17), 'Unauthorized data extraction', 'made/usb_stick+made/filing_cabinet', [
      ['Allowed to open is not allowed to take', S(12), 'v-coral'],
      ['Personal drives or paid insiders leak data', S(15), 'v-amber'],
    ]),
    hero(S(17), D.T, 'Report early', 'made/register_book+made/own_bell', [
      ['Assigned cases, logged exports, approved remote', S(17), 'v-teal'],
      ['Mistake or bribe? Refuse and report early', S(18), 'v-navy'],
    ]),
  ],
}));
