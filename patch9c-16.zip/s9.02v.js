// When an account is no longer yours.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note, btn } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '9.1',
  actors: { omar: 'desk', maya: 'beside' },
  landline: 'desk',
  handsets: {
    omar: [
      [0, S(11), 'lock'],
      [S(11), S(12), 'mobile'],
      [S(12), D.T, 'bell'],
    ],
  },
  shots: [[0, 'pair'], [S(1), 'desk'], [S(3), 'pair'], [S(7), 'display'], [S(10), 'desk'], [S(12), 'pair'], [S(14), 'desk']],
  actions: {
    omar: [[0, S(3), 'text'], [S(3), S(7), 'read'], [S(7), S(11), 'text'], [S(11), S(12), 'extension'], [S(12), S(14), 'text'], [S(14), D.T, 'extension']],
    maya: [[0, S(12), 'listen', 'omar'], [S(12), S(14), 'talk', 'omar'], [S(14), D.T, 'listen', 'omar']],
  },
  displays: {
    desk: [
      [0, S(11), 'lock', 'Sign-in approval · Not started', 'alert', 'login'],
      [S(11), S(14), 'mobile', 'Caller asks for sign-in code', 'alert'],
      [S(14), D.T, 'bell', 'Reported · Known number', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Unexpected approval request'],
    [S(11), E(11), 'Caller asks for code'],
    [S(12), E(12), 'Request declined · Call ended'],
    [S(14), E(14), 'Service desk · Known number'],
  ],
  screens: [
    [S(0), S(2), phone('Sign-in approval', row('Account', 'omar@sadeed.gov.example', 'warn') + row('Action', 'Approve sign-in?', 'warn') + note('Omar did not try to sign in.', 'no') + btn('Deny', 'no'))],
    [S(11), S(12), win('Desk phone · Incoming call', row('Caller', 'Claims to be from IT', 'no') + row('Asks for', 'Sign-in code on screen', 'no') + row('Your code', '•••••• (For you alone)', 'warn') + note('Real IT never asks for your code.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(3), S(7), 'A request you did not start is a warning', 'made/own_mobile+made/own_lock', [
      ['Stolen credentials in 39% of breaches', S(4), 'v-coral'],
      ['Watch for odd-hour sign-ins or resets', S(5), 'v-amber'],
    ]),
    hero(S(7), S(10), 'Strong sign-in and active sessions', 'made/own_key+made/own_shield', [
      ['Phishing-resistant MFA blocks over 99%', S(7), 'v-teal'],
      ['1 in 3 stolen logins include a live session', S(9), 'v-coral'],
    ]),
    hero(S(12), S(14), 'Never share a code or password', 'made/own_desk_phone+made/own_warning_beacon', [
      ['Voice phishing is the #2 route into entities', S(12), 'v-coral'],
      ['Real IT never asks for codes or passwords', S(13), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Report on the known number', 'made/own_desk_phone+made/own_bell', [
      ['Report both the request and the call', S(14), 'v-teal'],
      ['Over a third of stolen logins trade in 1 day', S(15), 'v-amber'],
    ]),
  ],
}));
