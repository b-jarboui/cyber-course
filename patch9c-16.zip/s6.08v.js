// Is it the model we approved?
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '6.3',
  actors: { official: 'counter', omar: 'colleague', maya: 'director' },
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(5), 'staff'], [S(6), 'counter'], [S(10), 'counterDisplay'], [S(11), 'her'], [S(15), 'counter']],
  actions: {
    official: [[0, S(5), 'read'], [S(5), S(6), 'listen', 'omar'], [S(6), S(10), 'talk', 'omar'], [S(10), D.T, 'read']],
    omar: [[0, S(5), 'listen', 'official'], [S(5), S(10), 'paper'], [S(10), D.T, 'listen', 'official']],
    maya: [[0, S(5), 'listen', 'official'], [S(5), S(6), 'listen', 'omar'], [S(6), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(5), 'mail', 'Provider model update', 'neutral'],
      [S(5), S(10), 'key', 'Shared login · Two users', 'alert'],
      [S(10), D.T, 'key', 'Personal accounts requested', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Provider model update'],
    [S(5), E(5), 'Two colleagues · One login'],
    [S(10), E(10), 'Separate work accounts requested'],
    [S(14), E(14), 'Sample data only for testing'],
  ],
  screens: [
    [S(0), S(2), q => win('Provider update notice', reveal([
      row('From', 'updates@ai-provider.example'),
      row('Release', 'Model v4.2 available', 'warn'),
      row('Integrity check', 'Unverified · Not tested', 'warn'),
      note('How do we know nobody changed it?', 'warn'),
    ], q))],
    [S(5), S(6), win('Assistant accounts', row('Shared login', 'team-ai@sadeed.gov.example', 'no') + row('Active users', '2 staff · 1 licence', 'no') + note('Shared login hides who is asking.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(2), S(5), 'Known source, recorded version, approved change', 'made/register_book+made/rubber_stamp', [
      ['Model integrity: unchanged and verified', S(2), 'v-teal'],
      ['Check signatures and test before use', S(3), 'v-navy'],
    ]),
    hero(S(6), S(11), 'One person, one account', 'made/id_badge+made/own_key', [
      ['Mass queries can copy a model without break-in', S(6), 'v-amber'],
      ['Shared logins hide who is asking', S(10), 'v-coral'],
    ]),
    hero(S(11), S(14), 'Unapproved tool, information out of our control', 'made/laptop+made/padlock_open', [
      ['Unsanctioned AI drives data breaches', S(12), 'v-coral'],
      ['60% of AI incidents compromised data', S(13), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Protect data and logins', 'made/safe+made/own_bell', [
      ['Mask sensitive data; test with sample data', S(14), 'v-teal'],
      ['Odd update or login request? Stop and report', S(15), 'v-amber'],
    ]),
  ],
}));
