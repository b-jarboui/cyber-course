// Files that change, data that leaves.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '9.1',
  actors: { omar: 'desk', maya: 'counter' },
  file: [[0, D.T, 1, 1]],
  landline: true,
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(7), 'counterDisplay'], [S(8), 'her'], [S(12), 'desk'], [S(14), 'counter'], [S(15), 'her']],
  actions: {
    omar: [[0, S(1), 'type'], [S(1), S(12), 'read'], [S(12), D.T, 'listen', 'maya']],
    maya: [[0, S(7), 'type'], [S(7), S(14), 'read'], [S(14), D.T, 'extension']],
  },
  displays: {
    desk: [
      [0, S(1), 'folder', 'Case 2048 · Shared folder', 'neutral'],
      [S(1), S(12), 'lock', 'Files locked · Names changed', 'alert'],
      [S(12), D.T, 'shield', 'Hands off · Left powered on', 'safe'],
    ],
    counter: [
      [0, S(7), 'folder', 'Cloud records · Case 2048', 'neutral'],
      [S(7), S(14), 'zoom', 'Alert · Overnight download', 'alert'],
      [S(14), D.T, 'bell', 'Both signs reported', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Files locked · Names changed'],
    [S(7), E(7), 'Overnight bulk download'],
    [S(12), E(12), 'Hands off · Keep powered on'],
    [S(14), E(14), 'Both signs reported'],
  ],
  screens: [
    [S(1), S(2), win('Shared folder · Case 2048', row('Case2048_01.locked', 'Will not open', 'no') + row('Case2048_02.locked', 'Will not open', 'no') + row('ID_scan.locked', 'Will not open', 'no') + note('File names changed unexpectedly.', 'no'), 'alert')],
    [S(7), S(8), win('Cloud records · Alert', row('Activity', 'Bulk download · 3,420 records', 'no') + row('Time', '02:40 · Overnight', 'no') + row('Status', 'Outside working hours', 'warn'), 'alert')],
    [S(14), S(15), win('Incident report · Sent', row('Sign 1', 'Locked files · Case 2048 folder', 'warn') + row('Sign 2', 'Overnight download · Cloud records', 'warn') + row('Route', 'Approved service desk', 'ok') + note('Waiting for response team instructions.', ''), 'good')],
  ],
  pages: [
    hero(S(2), S(7), "Files won't open · names changed", 'made/ransom_laptop+made/own_folder', [
      ['Ransomware locks files or switches tools off', S(2), 'v-coral'],
      ['Attackers steal data to threaten publication', S(4), 'v-amber'],
      ['58% growth in ransomware groups in the UAE', S(6), 'v-coral'],
    ]),
    hero(S(8), S(12), 'Unusual data leaving', 'made/server_rack+made/own_warning_beacon', [
      ['Large off-hour downloads signal misuse', S(8), 'v-coral'],
      ['Watch for odd links, settings or new users', S(10), 'v-amber'],
      ['Destructive cloud attacks rose by 87%', S(11), 'v-coral'],
    ]),
    hero(S(12), S(14), "Don't fix, delete or pay. Report.", 'made/laptop+made/own_incident_binder', [
      ['Stop working; do not rename, copy or delete', S(12), 'v-coral'],
      ['Leave the device on to keep memory evidence', S(13), 'v-teal'],
    ]),
    hero(S(15), D.T, 'Only the response team decides', 'made/own_bell+made/own_shield', [
      ['Report every warning sign through the route', S(15), 'v-teal'],
      ['Wait for authorized team instructions', (S(15) + E(15)) / 2, 'v-navy'],
    ]),
  ],
}));
