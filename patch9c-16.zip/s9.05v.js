// One report, the right route.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['helpdesk', 'official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '9.2',
  actors: { helpdesk: 'desk', official: 'beside', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 1, 1]],
  landline: 'desk',
  shots: [[0, 'pair'], [S(1), 'display'], [S(2), 'counter'], [S(5), 'file'], [S(8), 'pair'], [S(11), 'desk'], [S(12), 'gathering'], [S(15), 'her']],
  actions: {
    helpdesk: [[0, S(5), 'type'], [S(5), S(11), 'read'], [S(11), D.T, 'type']],
    official: [[0, S(11), 'listen', 'helpdesk'], [S(11), S(15), 'extension'], [S(15), D.T, 'listen', 'maya']],
    maya: [[0, S(5), 'read'], [S(5), S(8), 'paper'], [S(8), S(15), 'file'], [S(15), D.T, 'paper']],
    omar: [[0, S(8), 'listen', 'maya'], [S(8), D.T, 'listen', 'official']],
  },
  displays: {
    desk: [
      [0, S(1), 'file', '3 hall reports received', 'neutral'],
      [S(1), S(11), 'folder', 'Linked into 1 incident ticket', 'alert'],
      [S(11), D.T, 'shield', 'Escalated to response team', 'safe'],
    ],
    counter: [
      [0, S(5), 'file', 'Official report form · 2048', 'neutral'],
      [S(5), D.T, 'tick', 'Times and facts recorded', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Three reports · One ticket'],
    [S(5), E(5), 'Official report form · Case 2048'],
    [S(11), E(11), 'Manager joins · Team leads'],
    [S(14), E(14), 'Internal route only'],
  ],
  screens: [
    [S(0), S(2), win('Service desk · Ticket #904', row('Report 1 · 08:25', 'Shaima · Night sign-in alert', 'warn') + row('Report 2 · 09:10', 'Omar · Unexpected approval', 'warn') + row('Report 3 · 10:45', 'Locked files & cloud download', 'no') + note('Linked into 1 possible incident.', 'warn'), 'alert')],
    [S(11), S(12), win('Escalation · Ticket #904', row('Technical lead', 'Incident response team', 'ok') + row('Management', 'Informed on call', 'hi') + row('Hall staff', 'Follow team instructions', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(5), 'Report early, even if unsure', 'made/own_bell+made/own_clock', [
      ['Small signs together reveal one incident', S(2), 'v-amber'],
      ['A false alarm costs minutes; silence costs more', S(3), 'v-teal'],
    ]),
    hero(S(5), S(8), 'What · When · Where · Who', 'made/own_incident_binder+made/case_folder', [
      ['Use the known number and official form', S(6), 'v-teal'],
      ['No group chats or applicant discussions', S(7), 'v-coral'],
    ]),
    hero(S(8), S(11), 'Escalate by severity and role', 'made/signpost+made/own_policy_binder', [
      ['Response plans set escalation and severity', S(9), 'v-teal'],
      ['Service desk alerts IR team and management', S(10), 'v-navy'],
    ]),
    hero(S(12), D.T, 'National reporting: the designated team', 'made/own_shield+made/own_desk_phone', [
      ['National bodies receive official entity reports', S(12), 'v-navy'],
      ['Staff report inside; designated team notifies', S(14), 'v-teal'],
    ]),
  ],
}));
