// The portal that will not load, and the attack that aims to destroy.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '8.2',
  actors: { maya: 'counter', omar: 'colleague', official: 'director', citizen: 'visitor' },
  handsets: { official: [[S(1), S(10), 'bell']] },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'counterDisplay'], [S(1), 'gathering'], [S(2), 'staff'], [S(7), 'hall'], [S(10), 'counter'], [S(11), 'her'], [S(12), 'staff'], [S(13), 'counter']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(10), 'listen', 'omar'], [S(10), S(11), 'sign'], [S(11), S(12), 'talk', 'citizen'], [S(12), D.T, 'listen', 'omar']],
    omar: [[0, S(2), 'listen', 'official'], [S(2), S(5), 'talk', 'maya'], [S(5), S(7), 'listen', 'official'], [S(7), S(10), 'talk', 'maya'], [S(10), S(12), 'listen', 'maya'], [S(12), D.T, 'talk', 'maya']],
    official: [[0, S(1), 'listen', 'maya'], [S(1), S(5), 'text'], [S(5), S(7), 'talk', 'maya'], [S(7), S(10), 'text'], [S(10), D.T, 'listen', 'maya']],
    citizen: [[0, S(11), 'listen', 'maya'], [S(11), S(12), 'listen', 'maya'], [S(12), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(10), 'wifi', 'Public portal · Loading error', 'alert'],
      [S(10), D.T, 'file', 'Paper backup form · Case 2048', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Public portal · Loading error'],
    [S(1), E(1), 'Official IT notice · DDoS attack'],
    [S(10), E(10), 'Approved paper backup form'],
    [S(11), E(11), 'Share official notice only'],
  ],
  screens: [
    [S(0), S(1), win('portal.sadeed.gov.example', row('Status', 'Service unavailable', 'no') + row('Applicants', 'Page will not load', 'no') + note('Public portal is not responding.', 'warn'), 'alert')],
    [S(1), S(2), win('Official IT notice', row('From', 'IT Security Operations', 'hi') + row('Affected', 'Public portal', 'warn') + row('Cause', 'DDoS traffic flood', 'no') + note('Share only official updates.', 'warn'), 'alert')],
    [S(10), S(11), win('Approved paper backup form', row('Case file', 'Case 2048', 'ok') + row('Method', 'Recorded by hand', 'ok') + row('Status', 'Service continues safely', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(7), 'DDoS: flooding a service until it stops', 'made/traffic_light+made/server_rack', [
      ['47.1 million DDoS attacks blocked in 2025', S(3), 'v-amber'],
      ['Blocks access; sometimes hides another attack', S(5), 'v-coral'],
    ]),
    hero(S(7), S(10), 'Destructive attacks aim to erase or damage', 'made/control_desk+made/power_pylon+made/water_tower', [
      ['Aim to destroy systems, not demand money', S(7), 'v-coral'],
      ['Control devices in water and energy targeted', S(8), 'v-amber'],
    ]),
    hero(S(11), S(13), 'Share only official updates', 'made/own_megaphone+made/own_signed_document', [
      ['Do not guess who is behind an attack', S(11), 'v-navy'],
      ['Never post incidents or rumours online', S(12), 'v-coral'],
    ]),
    hero(S(13), D.T, 'Use the approved backup procedure', 'made/paper_tray+made/own_bell', [
      ['Report the outage through the approved route', S(13), 'v-teal'],
      ['Switch to approved backup forms and updates', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
