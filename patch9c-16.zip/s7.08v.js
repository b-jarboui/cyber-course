// One click on Allow.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, btn, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.2',
  actors: { maya: 'counter', omar: 'aisle' },
  walks: { omar: [[S(3), E(3), 'colleague']] },
  file: [[0, E(0), 0, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(3), 'hall'], [S(4), 'staff'], [S(10), 'her'], [S(13), 'counter'], [S(14), 'counterDisplay'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(3), 'read'], [S(3), S(4), 'talk', 'omar'], [S(4), S(13), 'listen', 'omar'], [S(13), S(14), 'extension'], [S(14), D.T, 'type']],
    omar: [[0, S(3), 'listen', 'maya'], [S(4), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'file', 'Case 2048 · Notes', 'neutral'],
      [S(1), S(13), 'puzzle', 'Allow: read all files & mail?', 'alert'],
      [S(13), D.T, 'tick', 'Cancelled · IT asked', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Free note-taking add-on'],
    [S(2), E(2), 'Asks for all files and mail'],
    [S(13), E(13), 'Pressed Cancel · IT asked'],
    [S(15), E(15), 'Unknown app? Tell IT at once'],
  ],
  screens: [
    [S(1), S(3), q => win('Permission request', reveal([row('Free add-on', 'AutoNotes · Outside party', 'warn'), row('Read all your files', 'Requested', 'no'), row('Read all your mail', 'Requested', 'no'), btn('Allow', 'no') + ' ' + btn('Cancel', 'ok')], q), 'alert')],
    [S(13), S(14), win('Permission request · Cancelled', row('AutoNotes', 'Access denied · Cancelled', 'ok') + row('IT Service Desk', 'Asked for approved note tool', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(7), 'Connected application', 'made/own_link+made/id_badge', [
      ['Outside service linked to your account', S(4), 'v-navy'],
      ['Allow grants a token without your password', S(5), 'v-amber'],
    ]),
    hero(S(7), S(10), 'Read the permission screen', 'made/own_zoom+made/own_mail+made/own_folder', [
      ['Stolen app tokens hit over 700 organisations', S(7), 'v-coral'],
      ['Abuse looks like normal trusted traffic', S(9), 'v-amber'],
    ]),
    hero(S(10), S(13), 'No passwords in notes', 'made/own_file+made/own_key', [
      ['Attackers search exported notes for secrets', S(10), 'v-coral'],
      ['Review integrations and rotate tokens', S(11), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Approved applications only', 'made/rubber_stamp+made/own_bell', [
      ['Named owner, least access, regular IT review', S(14), 'v-teal'],
      ['Pressed Allow? Report so IT revokes access', S(15), 'v-amber'],
    ]),
  ],
}));
