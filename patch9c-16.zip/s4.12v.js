// Trusted yesterday, checked today.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.3',
  actors: { maya: 'desk', omar: 'beside' },
  handsets: { maya: [[S(12), S(13), 'shield']] },
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(4), 'pair'], [S(12), 'display'], [S(13), 'desk'], [S(14), 'pair']],
  actions: {
    maya: [[0, S(1), 'type'], [S(1), S(12), 'read'], [S(12), S(13), 'text'], [S(13), D.T, 'type']],
    omar: [[0, S(13), 'listen', 'maya'], [S(13), D.T, 'talk', 'maya']],
  },
  displays: {
    desk: [[0, S(1), 'folder', 'Case 2048', 'neutral'], [S(1), S(12), 'lock', 'Verify identity again', 'alert', 'login'], [S(12), D.T, 'tick', 'Case 2048 · Limited access', 'safe']],
  },
  plates: [[S(0), E(0), 'Meeting-room laptop'], [S(1), E(1), 'Different device and context'], [S(2), E(2), 'Verify identity again'], [S(12), E(12), 'Case 2048 · Limited access']],
  screens: [
    [S(1), S(3), win('Verify identity again', row('Device', 'Meeting-room laptop', 'warn') + row('Context', 'Different from counter', 'warn') + row('Action', 'Extra verification required', 'wait'), 'alert')],
    [S(12), S(13), win('Case 2048 · Limited access', row('Additional check', 'Completed', 'ok') + row('Scope', 'Case 2048 only', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(5), 'Never trust automatically', 'shield+lock', [
      ['Zero Trust principle', S(4), 'v-teal'],
    ]),
    hero(S(5), S(6), 'Verify every access request', 'made/id_badge+tick', [
      ['No automatic inside trust', S(5), 'v-teal'],
    ]),
    hero(S(6), S(10), 'Check identity, device and context', 'made/id_badge+made/laptop+clock', [
      ['Unhealthy device may be denied', S(6), 'v-amber'],
      ['Scoped to the approved task', S(8), 'v-teal'],
    ]),
    hero(S(10), S(12), 'Limit access and monitor continuously', 'computer+zoom+shield', [
      ['Session risk can change', S(10), 'v-amber'],
      ['Re-verify, restrict or end session', S(11), 'v-teal'],
    ]),
  ],
}));
