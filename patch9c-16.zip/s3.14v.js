// One clear voice in a noisy week
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["maya", "citizen", "official", "omar", "priya", "lena"];
export default chapterHall((S, E, D) => ({
  lesson: "3.3",
  actors: { maya: 'counter', citizen: 'signer', official: 'director', omar: 'colleague', priya: 'team', lena: 'teamEnd' },
  enter: { official: S(7), priya: S(7), lena: S(7) },
  file: [[0,S(1),0,0], [S(15),E(15),0,1]],
  shots: [[0,'counter'], [S(1),'gathering'], [S(5),'staff'], [S(6),'counter'], [S(7),'gathering'], [S(10),'staff'], [S(13),'gathering'], [S(15),'file']],
  actions: { maya: [[0,S(6),'read'], [S(6),S(7),'listen','citizen'], [S(7),S(15),'listen','official'], [S(15),D.T,'file']], citizen: [[0,S(6),'listen','maya'], [S(6),S(7),'listen','maya'], [S(7),D.T,'listen','official']], official: [[S(7),D.T,'talk','maya']], omar: [[0,S(7),'listen','maya'], [S(7),D.T,'listen','official']], priya: [[S(7),D.T,'listen','official']], lena: [[S(7),D.T,'listen','official']] },
  setupProps: evidence({
    surfaces: { noticeBoard: [[0,D.T,'notice','Official correction']], handout: [[S(6),D.T,'notice','Official correction']] },
    handoff: [S(6),E(6),'maya','citizen'],
    inserts: [[S(1),E(1),'noticeBoard']],
  }),
  displays: { counter: [[0,S(15),'file-text','Official correction','safe'], [S(15),D.T,'folder','Next case','neutral']] },
  plates: [[S(0),E(0),'Official correction'], [S(6),E(6),'Case 2048'], [S(7),E(7),'Hamad · Manager'], [S(15),E(15),'Next case']],
  screens: [
    [S(0), S(2), q => win('sadeed.gov.example', reveal([
      row('Processing fee', 'No new fee', 'ok'),
      row('Refund service', 'Open as normal', 'ok'),
      row('Video & letter', 'Confirmed fake', 'no'),
      note('Official notice from the Authority.'),
    ], q), 'good')],
  ],
  pages: [
    hero(S(5), S(6), "Official channels only", "computer+file-text", [
      ["Official correction", S(5), "v-teal"],
    ]),
    hero(S(10), S(13), "Pause and verify before you act or share", "mobile+made/register_book", [
      ["Check the original", S(11), "v-teal"],
      ["Follow the approvals", S(12), "v-teal"],
    ]),
    hero(S(13), S(15), "Report early through the approved route", "mobile+made/case_folder", [
      ["Report even if unsure", S(13), "v-teal"],
      ["Authorized teams review", S(14), "v-teal"],
    ]),
  ],
}));
