// Three channels, one story.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note, mail, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['admin', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.2',
  actors: { admin: 'desk', omar: 'beside' },
  handsets: { admin: [[S(1),S(2),'chat'], [S(2),S(10),'mobile']] },
  shots: [[0,'desk'], [S(1),'pair'], [S(2),'desk'], [S(6),'pair'], [S(10),'desk'], [S(11),'display'], [S(12),'desk'], [S(14),'pair']],
  actions: {
    admin: [[0,S(1),'read'], [S(1),S(2),'text'], [S(2),S(10),'call'], [S(10),S(11),'read'], [S(11),E(12),'call'], [S(14),D.T,'type']],
    omar: [[0,D.T,'listen','admin']],
  },
  displays: { desk: [[0,S(10),'mail','Supplier tender','neutral','inbox'], [S(10),S(14),'file-text','Supplier record','safe'], [S(14),D.T,'bell','Three contacts reported','safe']] },
  plates: [[S(0),E(0),'Supplier tender'], [S(1),E(1),'Same tender by text'], [S(2),E(2),'Deadline by phone'], [S(6),E(6),'Job title and conference'], [S(14),E(14),'Three contacts reported']],
  screens: [
    [S(0), S(1), win('Inbox', mail('Tender Desk', 'bids@supplier-tender.example', 'Urgent: Tender documents', 'Please send the tender pack before 4 pm.'), 'alert')],
    [S(1), S(3), q => phone('Same story · New channels', reveal([
      row('Text', 'Send tender files today', 'warn'),
      row('Call · +971 50 000 0391', 'Before the deadline', 'no'),
      note('Three channels, same urgent push.', 'no'),
    ], q))],
    [S(10), S(11), win('Supplier record', row('Procurement system', 'Official contact', 'ok') + row('Stored phone', '+971 50 000 0219', 'ok') + note('Verify on the number already on file.'), 'good')],
  ],
  pages: [
    hero(S(3), S(4), 'Agreement across channels is not proof', 'mail+chat+mobile', [
      ['One tender request', S(3), 'v-amber'],
    ]),
    hero(S(4), S(6), 'Email, text, call: one attack', 'mobile+mail+chat', [
      ['Same deadline', S(4), 'v-amber'],
    ]),
    hero(S(7), S(10), 'Public details can be used against you', 'made/id_badge+calendar', [
      ['Job title and conference', S(7), 'v-amber'],
    ]),
    hero(S(11), S(13), 'Verify on the number you already hold', 'made/register_book+mobile', [
      ['Supplier record', S(11), 'v-teal'],
      ['No tender request', S(12), 'v-teal'],
    ]),
  ],
}));
