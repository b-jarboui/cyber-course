// Chapter 2-10 scenes: shared building, optional per-scene rooms ('meeting','office','ops','home','taxi'),
// real office props, cast library, camera and bilingual hero pages.
import { THREE, C, V, mat, metal, frosted, mesh, rbox, box, cyl, sph, group, bar, plant, chair, officeChair, laptop, monitor, standingFolders, folder, canvasTex, ramp } from './kit.js';
import { cached, createPerson, loadMotion } from './people.js';
import { desk, workplace, typing } from './sets.js';
import { SHOTS } from './story.js';
import { frameShots, quietScreens } from './astra.js';
import { restoreTeachingTable } from './v1-set.js';
import { createBoard } from './board.js';
import { concept, readyPages, seekPages, loadPicture } from './library-pages.js';
import { AR, tr, trTemplate } from './i18n.js';
import { iconSrc } from './own-art.js';
import './pages-l2.js';

// A place gives the actor's feet and facing direction. The work desk is Omar's usual desk.
const hallPlaces = {
  inspect: [-2.68, -.10, 1.5], signer: [-1.38, -.15, -1.55], counterEnd: [-1.38, -1.12, 1.5],
  counter: [-2.82, -.42, 1.55], colleague: [-3.22, .27, 2.18], visitor: [-1.28, -.14, -1.67],
  deskGuest: [1.83, -2.08, 1.93],
  desk: [3.2, -2.5, -1.45], beside: [3.05, -1.12, -2.69] /* was 2.76,-1.68: inside the desk top (Bassem 2026-11-22) */, aisle: [1.44, -.98, 2.45],
  door: [1.48, -3.78, .24], office: [1.05, -3.07, 2.57], exit: [.48, -.44, 1.55],
  director: [-3.25, -1.55, .95] /* was -3.52,-.88: straight behind Shaima in the camera's line, they looked merged (Gemini 2026-11-23) */, team: [-1.38, .67, -1.96], teamEnd: [-.57, -.59, -1.22],
};
const hallShots = { ...SHOTS,
  hall: { x: -1.85, y: 1.15, z: -.25, w: 2.65, e: .48, f: .44 },
  desk: { x: 2.9, y: 1.03, z: -2.4, w: 2.05, e: .48, f: .47 },
  finance: { x: 2.72, y: 1.55, z: -1.68, w: 2.05, e: .42, f: .48 },
  counterDisplay: { x: -2.45, y: 1.48, z: -.65, w: 1.85, e: .44, f: .48 },
  pair: { x: 2.62, y: 1.14, z: -2.06, w: 2.68, e: .5, f: .47 },
  display: { x: 2.68, y: 1.25, z: -2.35, w: 1.85, e: .48, f: .48 },
  file: { x: -2.22, y: 1.35, z: -.12, w: 2.05, e: .55, f: .48 },
  poster: { x: -1.92, y: 1.32, z: -.05, w: 1.35, e: .55, f: .48 },
  door: { x: 1.32, y: 1.19, z: -3.4, w: 2.8, e: .48, f: .47 },
  gathering: { x: -2.18, y: 1.22, z: -.32, w: 2.35, e: .46, f: .44 },
  habits: { x: -3.95, y: 1.45, z: -.55, w: 2.85, e: .38, f: .48 },
};

const active = (rows, t) => rows?.find(([a,z]) => a <= t && t < z);
const female = role => role === 'maya' || role === 'finance' || role === 'priya' || role === 'lena' || role === 'comms';
const seated = role => (female(role) ? 'f' : 'm') + '_sit_table_idle_neutral_01';
const IDLE_M = ['m_idle_neutral_01', 'm_idle_waiting_01', 'm_idle_look_around_01', 'm_idle_neutral_02', 'm_idle_waiting_02'];
const IDLE_F = ['f_idle_neutral_01', 'f_idle_waiting_01', 'f_idle_look_around_01', 'f_idle_neutral_02', 'f_idle_waiting_02'];
const LISTEN_M = ['m_idle_neutral_01', 'm_gestic_listen_accept_01', 'm_idle_waiting_01', 'm_idle_neutral_02', 'm_idle_look_around_01'];
const LISTEN_F = ['f_idle_neutral_01', 'f_gestic_listen_accept_01', 'f_idle_waiting_01', 'f_idle_neutral_02', 'f_idle_look_around_01'];
const SEATED_M = ['m_sit_table_idle_neutral_01', 'm_sit_table_gestic_thoughtful'];
const TALK_M = ['m_gestic_talk_neutral_01'];
const TALK_F = ['f_gestic_talk_neutral_01', 'f_gestic_talk_self-assured_01'];
function clipAt(role, idx, sat, beat, t) {
  const action = beat?.[2], f = female(role);
  const pool = sat ? (!f && !['type', 'call', 'text', 'dial', 'paper', 'tablet', 'usb', 'idCard'].includes(action) ? SEATED_M : [seated(role)])
    : action === 'talk' ? (f ? TALK_F : TALK_M)
    : action === 'listen' ? (f ? LISTEN_F : LISTEN_M)
    : (f ? IDLE_F : IDLE_M);
  const span = 6.5 + (idx % 4) * 1.1, phase = idx * 2.3;
  const u = action === 'talk' && beat ? Math.max(0, t - beat[0]) : t + phase;
  const slot = Math.floor(u / span), localT = u - slot * span;
  const name = pool[(slot + idx) % pool.length];
  const prevName = slot > 0 ? pool[(slot - 1 + idx) % pool.length] : name;
  return { name, time: localT, prevName, prevTime: span + localT, blend: slot > 0 && localT < 0.45 && prevName !== name ? localT / 0.45 : 1 };
}

export const hero = (a, z, title, art, lines) => ({ a, z, scene: 'hero', cues: { title, art, lines } });

function putInk(parent, w, h, x, y, z, tex) {
  const ink = new THREE.Mesh(new THREE.PlaneGeometry(w,h), new THREE.MeshBasicMaterial({map:tex, toneMapped:false}));
  ink.position.set(x,y,z); parent.add(ink);
  return ink;
}
const swatch = { alert:'#b8503c', safe:'#28746e', neutral:'#34466a' };
// In-world screens carry the message being discussed. Use the same short label on the plate.
function displayTexture(icon, label, tone, type) {
  return canvasTex(640,360,(g,w,h) => {
    const colour = swatch[tone] || swatch.neutral;
    g.fillStyle = '#faf7ef'; g.fillRect(0,0,w,h);
    g.fillStyle = colour; g.fillRect(0,0,w,41);
    g.fillStyle = '#fff'; for (const x of [19,37,55]) { g.beginPath(); g.arc(AR?w-x:x,21,4,0,Math.PI*2); g.fill(); }
    g.drawImage(icon, AR?456:20,64,158,158);
    g.direction = AR?'rtl':'ltr'; g.textAlign = AR?'right':'left'; g.fillStyle = '#26305a';
    g.font='bold 34px "Segoe UI",Arial,sans-serif'; g.fillText(tr(label),AR?446:194,126,420);
    const left=AR?44:194;
    g.fillStyle='#bbc7ca'; g.fillRect(left,153,388,8); g.fillRect(left,176,278,8);
    if(type==='login') {
      g.strokeStyle=colour; g.lineWidth=4;
      for(const y of [218,275]) { g.strokeRect(left,y,300,34); g.fillStyle='#b2bfca'; g.fillRect(left+18,y+14,144,6); }
    } else if(type==='inbox') {
      for(let i=0;i<4;i++){g.fillStyle=i%2?'#cbd7dc':'#e2e8e6';g.fillRect(22,214+i*32,596,24);}
    } else {
      g.fillStyle=colour; g.fillRect(left,225,230,54); g.fillStyle='#fff'; g.fillRect(left+22,249,146,7);
    }
  });
}
const icons = new Map(), tables = new Map();
function iconImage(name) { return cached(icons, name, () => readIcon(name)); }
async function readIcon(name) {
  const image = new Image(), src = iconSrc(name);
  await loadPicture(image, new URL('./assets/2d/'+src+(src.startsWith('made/')?'.webp':'.png'),import.meta.url));
  return image;
}

function paymentPoster(scene) {
  const g=group(scene,-2.04,1.055,-.05); g.rotation.y=.85;
  mesh(rbox(.46,.025,.24),C.navy,0,.013,0,g);
  mesh(rbox(.44,.50,.026),C.paper,0,.25,0,g);
  // Two non-scannable printed motifs. The raised corner casts a separate shadow.
  function code(seed) {
    return canvasTex(168,168,ctx=>{
      ctx.fillStyle='#fff'; ctx.fillRect(0,0,168,168); ctx.fillStyle='#253457';
      for(let y=1;y<20;y++) for(let x=1;x<20;x++) if((x*11+y*7+x*y+seed)%9<4)ctx.fillRect(x*8,y*8,8,8);
      for(const [x,y] of [[8,8],[112,8],[8,112]]) {ctx.fillStyle='#253457';ctx.fillRect(x,y,48,48);ctx.fillStyle='#fff';ctx.fillRect(x+8,y+8,32,32);ctx.fillStyle='#253457';ctx.fillRect(x+16,y+16,16,16);}
    });
  }
  putInk(g,.31,.31,0,.26,.014,code(1));
  const sticker=group(g,.017,.27,.018);sticker.rotation.z=-.075;
  mesh(rbox(.295,.295,.006,.002),C.paper,0,0,0,sticker);
  putInk(sticker,.282,.282,0,0,.004,code(4));
  const curl=mesh(rbox(.069,.055,.004,.001),'#e1d5b6',.113,.124,.022,sticker);
  curl.rotation.x=.67;
}
async function habitsBoard(parent, x=-4.96, y=1.99, z=-.58, rotY=Math.PI/2) {
  // real office objects (check the file, protect access, use the computer, report by phone) instead of symbols
  const images=await Promise.all(['made/own_file','made/own_badge_reader','made/own_computer','made/own_desk_phone'].map(async n=>{ const im=new Image(); im.src=new URL('./assets/2d/'+n+'.webp',import.meta.url).href; await im.decode(); return im; }));
  const g=group(parent,x,y,z); g.rotation.y=rotY;
  mesh(rbox(2.0,.53,.05),C.navy,0,0,0,g);
  const texture=canvasTex(1000,250,ctx=>{
    ctx.fillStyle='#fffdf8';ctx.fillRect(0,0,1000,250);
    const origin=i=>(AR?4-i:i)*194+26;
    ctx.fillStyle='#315866';
    for(const dx of [45,92]) ctx.fillRect(origin(0)+dx,73,27,92);
    images.forEach((img,i)=>ctx.drawImage(img,origin(i+1),38,164,164));
  });
  putInk(g,1.94,.47,0,0,.027,texture);
  return g;
}
function mobile(scene) {
  const p=group(scene);
  mesh(rbox(.082,.158,.013,.007),C.dark,0,0,0,p);
  mesh(rbox(.086,.162,.008,.006),C.metalD,0,0,-.001,p);
  mesh(rbox(.024,.028,.004,.002),'#1d212b',-.018,.048,-.008,p);
  p.userData.screen=putInk(p,.070,.135,0,.002,.0075,null);
  p.userData.screen.material.color.set('#adcbd5');
  return p;
}

// ---------- real office props (RC-4a) ----------
function wallWhiteboard(parent, x, y, z, rotY=0, w=2.0, h=1.02, cfg=null) {
  const g=group(parent,x,y,z); g.rotation.y=rotY;
  mesh(rbox(w+.08,h+.08,.045,.012),C.metal,0,0,0,g);
  mesh(rbox(w+.04,.045,.09,.008),C.metalD,0,-h/2-.04,.035,g);
  mesh(rbox(.11,.028,.045,.006),C.navy,-.35,-h/2-.008,.045,g);
  mesh(cyl(.009,.009,.12,12),C.teal,.15,-h/2-.008,.045,g).rotation.z=Math.PI/2;
  mesh(cyl(.009,.009,.12,12),C.coral,.34,-h/2-.008,.045,g).rotation.z=Math.PI/2;
  const title=typeof cfg==='object'&&cfg?.title ? cfg.title : 'Case 2048 · Notes';
  const items=typeof cfg==='object'&&Array.isArray(cfg?.items)&&cfg.items.length
    ? cfg.items : ['Verify through known channel', 'Follow approved procedure', 'Report early'];
  const tex=canvasTex(1024,512,(ctx,cw,ch)=>{
    ctx.fillStyle='#fdfcf8'; ctx.fillRect(0,0,cw,ch);
    ctx.fillStyle='#e8edf2';
    for(let gx=40;gx<cw;gx+=48) for(let gy=96;gy<ch-28;gy+=48) ctx.fillRect(gx,gy,3,3);
    ctx.fillStyle='#2f4b6e'; ctx.fillRect(0,0,cw,74);
    ctx.direction=AR?'rtl':'ltr'; ctx.textAlign=AR?'right':'left';
    ctx.fillStyle='#ffffff'; ctx.font='bold 36px "Segoe UI",Arial,sans-serif';
    ctx.fillText(tr(title),AR?cw-34:34,49,cw-68);
    const cols=['#2f7477','#333f6b','#c6543b','#d78c22'];
    items.slice(0,4).forEach((line,i)=>{
      const ry=116+i*88, bx=AR?cw-82:36;
      ctx.fillStyle=cols[i%cols.length]; ctx.fillRect(bx,ry-28,44,44);
      ctx.fillStyle='#eef2f5'; ctx.fillRect(AR?42:98,ry-28,cw-140,48);
      ctx.fillStyle='#26305a'; ctx.font='600 30px "Segoe UI",Arial,sans-serif';
      ctx.fillText(tr(line),AR?cw-114:116,ry+5,cw-176);
    });
  });
  putInk(g,w,h,0,0,.025,tex);
  return g;
}
function wallClock(parent, x, y, z, rotY=0) {
  const g=group(parent,x,y,z); g.rotation.y=rotY;
  mesh(cyl(.22,.22,.04,32),C.navy,0,0,0,g).rotation.x=Math.PI/2;
  const face=canvasTex(256,256,ctx=>{
    ctx.fillStyle='#fffdf8'; ctx.beginPath(); ctx.arc(128,128,120,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle='#333f6b'; ctx.lineWidth=6;
    for(let i=0;i<12;i++){ const a=i/12*Math.PI*2; ctx.beginPath(); ctx.moveTo(128+Math.cos(a)*92,128+Math.sin(a)*92); ctx.lineTo(128+Math.cos(a)*108,128+Math.sin(a)*108); ctx.stroke(); }
    ctx.lineCap='round';
    ctx.lineWidth=9; ctx.beginPath(); ctx.moveTo(128,128); ctx.lineTo(128,62); ctx.stroke();
    ctx.lineWidth=6; ctx.strokeStyle='#2f7477'; ctx.beginPath(); ctx.moveTo(128,128); ctx.lineTo(182,110); ctx.stroke();
    ctx.fillStyle='#333f6b'; ctx.beginPath(); ctx.arc(128,128,8,0,Math.PI*2); ctx.fill();
  });
  putInk(g,.38,.38,0,0,.022,face);
  return g;
}
function usbDrive(parent) {
  const g=group(parent);
  mesh(rbox(.028,.014,.068,.004),C.navy,0,0,0,g);
  mesh(rbox(.029,.015,.014,.003),C.teal,0,0,-.022,g);
  mesh(rbox(.018,.008,.024,.001),C.metal,0,0,.044,g);
  mesh(box(.004,.009,.004),C.dark,-.004,0,.047,g);
  mesh(box(.004,.009,.004),C.dark,.004,0,.047,g);
  return g;
}
function officeIdCard(parent) {
  const g=group(parent);
  mesh(rbox(.108,.070,.004,.002),C.paper,0,0,0,g);
  const tex=canvasTex(260,168,ctx=>{
    ctx.fillStyle='#fffdf8'; ctx.fillRect(0,0,260,168);
    ctx.fillStyle='#2f7477'; ctx.fillRect(0,0,260,34);
    ctx.fillStyle='#ffffff'; ctx.font='bold 16px "Segoe UI",Arial,sans-serif'; ctx.fillText('ID CARD',16,23);
    ctx.fillStyle='#cfd9e2'; ctx.fillRect(16,48,66,84);
    ctx.fillStyle='#6c7c94'; ctx.beginPath(); ctx.arc(49,76,14,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(49,122,24,Math.PI,0); ctx.fill();
    ctx.fillStyle='#333f6b'; ctx.fillRect(98,56,136,12);
    ctx.fillStyle='#8c9bb0'; ctx.fillRect(98,80,104,9); ctx.fillRect(98,100,122,9);
    ctx.fillStyle='#d8b068'; ctx.fillRect(98,122,28,20);
  });
  putInk(g,.102,.064,0,0,.0026,tex);
  const back=putInk(g,.102,.064,0,0,-.0026,tex); back.rotation.y=Math.PI;
  return g;
}
function officeTablet(parent, title='Monthly security dashboard') {
  const g=group(parent);
  mesh(rbox(.285,.202,.012,.006),C.dark,0,0,0,g);
  const tex=canvasTex(512,356,ctx=>{
    ctx.fillStyle='#f8f5ee'; ctx.fillRect(0,0,512,356);
    ctx.fillStyle='#2f4269'; ctx.fillRect(0,0,512,50);
    ctx.direction=AR?'rtl':'ltr'; ctx.textAlign=AR?'right':'left';
    ctx.fillStyle='#fff'; ctx.font='bold 22px "Segoe UI",Arial,sans-serif';
    ctx.fillText(tr(title),AR?490:22,33,468);
    const tiles=[['#2f7477',22,74,224,116],['#333f6b',266,74,224,116],['#d78c22',22,210,224,120],['#2f7477',266,210,224,120]];
    tiles.forEach(([col,x,y,w,h],i)=>{
      ctx.fillStyle='#ffffff'; ctx.fillRect(x,y,w,h);
      ctx.fillStyle=col; ctx.fillRect(x,y,w,18);
      ctx.fillStyle='#d5dde3'; ctx.fillRect(x+16,y+38,w-32,14);
      ctx.fillStyle=col; ctx.fillRect(x+16,y+66,(w-32)*(i===2?.45:.78),18);
      ctx.fillStyle='#b8c4ce'; ctx.fillRect(x+16,y+96,w-64,10);
    });
  });
  putInk(g,.258,.178,0,0,.007,tex);
  return g;
}
function deskTabletStand(parent, deskGroup, title) {
  const pos=deskGroup.localToWorld(V(-.48,.78,.08));
  const g=group(parent,pos.x,pos.y,pos.z);
  g.rotation.y=deskGroup.rotation.y+Math.PI-.28;
  mesh(rbox(.16,.012,.13,.005),C.metal,0,.006,0,g);
  const prop=mesh(rbox(.045,.14,.014,.005),C.metalD,0,.07,-.02,g); prop.rotation.x=-.32;
  const tab=officeTablet(g,title); tab.position.set(0,.12,.012); tab.rotation.x=-.34;
  return g;
}
function networkCable(parent, lap, unplugAt=null) {
  if(!lap) return null;
  const port=lap.localToWorld(V(-.235,.014,-.03));
  const outDir=lap.localToWorld(V(-1,.014,-.03)).sub(lap.localToWorld(V(0,.014,-.03))).normalize();
  const backDir=lap.localToWorld(V(-.235,.014,-1)).sub(port).normalize();
  const plug=group(parent);
  mesh(rbox(.022,.016,.038,.003),'#d8e2e8',0,0,0,plug);
  mesh(rbox(.014,.012,.014,.002),C.teal,0,0,-.024,plug);
  const pMid=port.clone().addScaledVector(outDir,.22).addScaledVector(backDir,.18);
  const pEdge=port.clone().addScaledVector(outDir,.28).addScaledVector(backDir,.44);
  const pDrop=pEdge.clone().setY(Math.max(.02,port.y-.68));
  const pluggedStart=port.clone().addScaledVector(outDir,.012);
  const unpluggedStart=port.clone().addScaledVector(outDir,.17).addScaledVector(backDir,.06);
  const cableMat=mat('#2c6d8e',{roughness:.55});
  const makeCurve=start=>new THREE.CatmullRomCurve3([start,start.clone().addScaledVector(outDir,.08).addScaledVector(backDir,.04),pMid,pEdge,pDrop]);
  const geoPlugged=new THREE.TubeGeometry(makeCurve(pluggedStart),28,.0065,8,false);
  const geoUnplugged=new THREE.TubeGeometry(makeCurve(unpluggedStart),28,.0065,8,false);
  const cord=mesh(geoPlugged,cableMat,0,0,0,parent);
  const yaw=Math.atan2(outDir.x,outDir.z);
  plug.rotation.y=yaw+Math.PI;
  return t=>{
    const k=unplugAt!==null ? ramp(t,unplugAt,unplugAt+.65) : 0;
    plug.position.copy(pluggedStart).lerp(unpluggedStart,k);
    plug.rotation.y=yaw+Math.PI+k*.35;
    cord.geometry=k>.5 ? geoUnplugged : geoPlugged;
  };
}

function deskPhone(scene) {
  const dock=group(scene,-2.38,1.055,.52); dock.rotation.y=-.65;
  mesh(rbox(.21,.037,.17,.012),C.dark,0,.023,0,dock);
  for(const x of [-.022,.009,.04]) for(const z of [-.038,-.01,.018,.046])
    mesh(rbox(.022,.005,.018,.003),C.metal, x,.044,z,dock);
  const receiver=group(scene);
  mesh(rbox(.035,.16,.023,.012),C.navy,0,0,0,receiver);
  for(const y of [-.073,.073]) mesh(rbox(.06,.047,.042,.013),C.dark,0,y,.012,receiver);
  return {dock,receiver};
}
function restReceiver(phone) {
  const {dock,receiver}=phone;
  receiver.position.copy(dock.localToWorld(V(-.074,.059,0)));
  receiver.rotation.set(Math.PI/2,dock.rotation.y,0,'YXZ');
}

// ---------- optional room sets (Phase B1) ----------
function makeFloorTex(base, grout, wood=false) {
  const t=canvasTex(512,512,(g,w)=>{
    g.fillStyle=base; g.fillRect(0,0,w,w);
    if(wood) {
      for(let i=0;i<16;i++){
        g.fillStyle=i%2?'rgba(95,62,32,.07)':'rgba(255,245,230,.05)';
        g.fillRect(0,i*32,w,31);
        g.fillStyle=grout; g.fillRect(0,i*32,w,2);
        const sx=((i*137)%420)+40; g.fillRect(sx,i*32,2,32);
      }
    } else {
      g.strokeStyle=grout; g.lineWidth=3;
      for(let i=0;i<=4;i++){ g.beginPath(); g.moveTo(i*128,0); g.lineTo(i*128,w); g.moveTo(0,i*128); g.lineTo(w,i*128); g.stroke(); }
    }
  });
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(2.4,2.4);
  return t;
}
function buildRoomShell(parent, { x0, x1, z0, z1, h=3.0, wallCol=C.wall, floorCol=C.floor, groutCol=C.grout, trimCol=C.teal, woodFloor=false }) {
  const W=x1-x0, D=z1-z0, cx=(x0+x1)/2, cz=(z0+z1)/2, T=.26;
  const gnd=mesh(new THREE.PlaneGeometry(80,80),mat(C.sky,{roughness:1}),0,-.35,0,parent); gnd.rotation.x=-Math.PI/2; gnd.castShadow=false;
  mesh(box(W+.4,.28,D+.4),C.wallTop,cx,-.14,cz,parent);
  mesh(box(W+.7,.05,D+.7),C.metal,cx,-.31,cz,parent);
  const fl=mesh(new THREE.PlaneGeometry(W,D),new THREE.MeshStandardMaterial({map:makeFloorTex(floorCol,groutCol,woodFloor),roughness:.72}),cx,.004,cz,parent);
  fl.rotation.x=-Math.PI/2; fl.castShadow=false;
  const wallM=mat(wallCol,{roughness:.9}), capM=mat(C.wallTop,{roughness:.9});
  // Back wall (-Z) and left wall (-X), open on +X and +Z for cutaway camera.
  mesh(box(W+T,h,T),wallM,cx-T/2,h/2,z0-T/2,parent);
  mesh(box(W+T,.025,T),capM,cx-T/2,h+.012,z0-T/2,parent).castShadow=false;
  mesh(box(T,h,D),wallM,x0-T/2,h/2,cz,parent);
  mesh(box(T,.025,D),capM,x0-T/2,h+.012,cz,parent).castShadow=false;
  if(trimCol){
    mesh(box(W-.2,.22,.02),trimCol,cx,h-.42,z0+.012,parent);
    mesh(box(.02,.22,D-.2),trimCol,x0+.012,h-.42,cz,parent);
  }
  mesh(box(W,.12,.03),C.sandD,cx,.06,z0+.015,parent);
  mesh(box(.03,.12,D),C.sandD,x0+.015,.06,cz,parent);
}
function addOfficeDoor(parent, x, z, rotY=Math.PI/2, glassPane=true) {
  const g=group(parent,x,0,z); g.rotation.y=rotY;
  mesh(rbox(1.06,2.30,.08,.012),C.navy,0,1.15,0,g);
  mesh(rbox(.94,2.20,.05,.01),mat('#e6d9c3',{roughness:.72}),0,1.10,.02,g);
  if(glassPane) mesh(box(.42,1.15,.058),frosted('#cfe0da',.68),0,1.42,.022,g).castShadow=false;
  mesh(rbox(.13,.025,.04,.008),metal(),.34,1.02,.06,g);
  return g;
}
function addBookshelf(parent, x, z, rotY=0) {
  const g=group(parent,x,0,z); g.rotation.y=rotY;
  const W=1.32, H=1.92, D=.40;
  mesh(rbox(W,H,.04,.01),C.navy,0,H/2,-D/2+.02,g);
  for(const s of [-1,1]) mesh(rbox(.05,H,D,.01),C.navy,s*(W/2-.025),H/2,0,g);
  for(const y of [.08,.56,1.04,1.52,1.90]) mesh(rbox(W-.04,.04,D,.008),mat('#ece4d6',{roughness:.7}),0,y,0,g);
  const cols=[C.teal,C.navyL,C.sand,C.powder,C.plum,C.sandD];
  for(const sy of [.58,1.06,1.54]) {
    for(let i=0;i<7;i++) {
      const bh=.26+(i%3)*.045;
      mesh(rbox(.065,bh,.26,.006),cols[(i+Math.round(sy*3))%cols.length],-.48+i*.15,sy+bh/2+.01,.02,g);
    }
  }
  return g;
}

async function buildMeetingSet(parent, c) {
  buildRoomShell(parent, { x0: -2.95, x1: 3.45, z0: -2.45, z1: 2.95 });
  addOfficeDoor(parent, -2.92, 1.35, Math.PI/2, true);
  wallWhiteboard(parent, -.15, 1.56, -2.41, 0, 2.05, 1.0, c.whiteboard);
  wallClock(parent, 1.85, 2.04, -2.41, 0);
  if(c.habits) await habitsBoard(parent, -.15, 2.34, -2.40, 0);
  plant(parent, -2.45, 0, -1.95, .74, C.sand, .95);
  plant(parent, 2.75, 0, -1.95, .72, '#fbf7ef', .9);
  // Conference table centered at (0, 0, .25): 2.45 x 1.12 m, top at y = .78 m.
  const table=group(parent, 0, 0, .25);
  mesh(rbox(2.46,.06,1.12,.025),mat('#f2eadb',{roughness:.58}),0,.75,0,table);
  mesh(box(2.22,.08,.88),C.navy,0,.69,0,table);
  for(const sx of [-1.06,1.06]) for(const sz of [-.42,.42])
    mesh(rbox(.065,.72,.065,.018),C.metalD,sx,.36,sz,table);
  // 6 seats around table, generous >=0.80 m spacing, faces toward camera (+1,e,+1).
  const places={
    seat1: [-.82, -.58, .14], seat2: [0, -.58, 0], seat3: [.82, -.58, -.14],
    head: [-1.50, .25, Math.PI/2], seat4: [-.58, 1.08, 2.48], seat5: [.48, 1.08, -2.68],
    board: [-1.58, -1.52, .62], presenter: [-1.58, -1.52, .62], door: [-2.18, 1.35, 1.35],
    // Safe aliases for hall place names
    desk: [0, -.58, 0], beside: [-.82, -.58, .14], deskGuest: [.82, -.58, -.14],
    director: [-1.50, .25, Math.PI/2], counter: [-.82, -.58, .14], colleague: [.82, -.58, -.14],
    team: [-.58, 1.08, 2.48], teamEnd: [.48, 1.08, -2.68],
  };
  for(const [x,z,r] of [places.seat1,places.seat2,places.seat3,places.head,places.seat4,places.seat5])
    officeChair(parent, x-Math.sin(r)*.06, z-Math.cos(r)*.06, r);
  // Virtual desk anchor for seat2 so work.desk.localToWorld works cleanly for landline & deskPaper.
  const deskAnchor=group(parent, 0, 0, .10); deskAnchor.rotation.y=Math.PI;
  const lap=laptop(parent, 0, .78, -.06, Math.PI, 1.05);
  const work={ desk: deskAnchor, laptop: lap, f: V(0,0,1), keyL: V(.12,.875,-.12), keyR: V(-.12,.875,-.12) };
  const rec=folder(parent, .78, .782, .18, .86); rec.rotation.y=-.22; rec.visible=!!c.file;
  const needPhone=c.landline || Object.values(c.actions||{}).some(rows=>rows.some(x=>x[2]==='extension'));
  let ll=null;
  if(needPhone) { ll=deskPhone(parent); ll.dock.position.copy(deskAnchor.localToWorld(V(.47,.78,-.07))); ll.dock.rotation.y=Math.PI; }
  const setShots={
    wide: { x: -.32, y: 1.24, z: -.22, w: 3.35, e: .40, f: .48 },
    hall: { x: -.32, y: 1.24, z: -.22, w: 3.35, e: .40, f: .48 },
    gathering: { x: -.32, y: 1.24, z: -.22, w: 3.25, e: .40, f: .48 },
    table: { x: -.08, y: 1.04, z: -.12, w: 2.30, e: .42, f: .45 },
    pair: { x: -.08, y: 1.04, z: -.12, w: 2.30, e: .42, f: .45 },
    desk: { x: 0, y: 1.02, z: -.22, w: 1.90, e: .40, f: .45 },
    her: { x: 0, y: 1.02, z: -.22, w: 1.90, e: .40, f: .45 },
    counter: { x: -.15, y: 1.04, z: -.15, w: 2.15, e: .42, f: .45 },
    display: { x: 0, y: 1.00, z: -.12, w: 1.72, e: .42, f: .46 },
    counterDisplay: { x: 0, y: 1.00, z: -.12, w: 1.72, e: .42, f: .46 },
    board: { x: -.82, y: 1.38, z: -1.18, w: 2.65, e: .34, f: .48 },
    staff: { x: -.82, y: 1.38, z: -1.18, w: 2.65, e: .34, f: .48 },
    file: { x: .20, y: 1.02, z: .02, w: 1.98, e: .44, f: .45 },
    habits: { x: -.15, y: 1.36, z: -.55, w: 2.90, e: .36, f: .47 },
    door: { x: -1.65, y: 1.24, z: .85, w: 2.35, e: .40, f: .47 },
  };
  return {
    places, shots: setShots, work, counterLaptop: lap, record: rec, landline: ll,
    seated: new Set(['seat1','seat2','seat3','seat4','seat5','head','desk','beside','deskGuest','director','team','teamEnd','counter','colleague']),
    devices: { desk: lap.userData.screen, counter: lap.userData.screen },
    pointTarget: V(-.15, 1.56, -2.35),
  };
}

function buildOfficeSet(parent, c) {
  buildRoomShell(parent, { x0: -2.75, x1: 2.85, z0: -2.25, z1: 2.55 });
  addOfficeDoor(parent, -2.72, 1.35, Math.PI/2, true);
  addBookshelf(parent, -1.65, -1.96, 0);
  // Frosted office window on back wall right side.
  mesh(box(1.45,1.22,.05),frosted('#d4e3dc',.76),1.15,1.66,-2.22,parent).castShadow=false;
  for(const x of [.43,1.15,1.87]) mesh(box(.045,1.24,.08),metal(),x,1.66,-2.22,parent);
  for(const y of [1.05,2.27]) mesh(box(1.48,.045,.08),metal(),1.15,y,-2.22,parent);
  wallClock(parent, -.22, 2.02, -2.22, 0);
  plant(parent, 2.20, 0, -1.72, .76, C.sand, .95);
  // Desk oriented toward (+1, e, +1) camera so seated face is front 3/4 visible.
  const seatPos=[-.25, -1.15, .55];   // was z -.55: the seat sat inside the office table top (body check, 2.11v)
  const work=workplace(parent, ...seatPos);
  const rec=folder(parent, 0, 0, 0, .86);
  rec.position.copy(work.desk.localToWorld(V(-.52,.782,-.14)));
  rec.rotation.y=work.desk.rotation.y;
  rec.visible=!!c.file;
  const needPhone=c.landline || Object.values(c.actions||{}).some(rows=>rows.some(x=>x[2]==='extension'));
  let ll=null;
  if(needPhone) { ll=deskPhone(parent); ll.dock.position.copy(work.desk.localToWorld(V(.47,.78,-.07))); ll.dock.rotation.y=work.desk.rotation.y; }
  if(c.tablet) deskTabletStand(parent, work.desk, typeof c.tablet==='object'?c.tablet.title:'Monthly security dashboard');
  const places={
    desk: seatPos, beside: [-1.38, .22, 1.02], aisle: [-1.85, 1.05, 1.15],
    door: [-2.08, 1.35, 1.32], office: [-1.38, .22, 1.02], deskGuest: [1.32, -.15, -1.05],
    director: [-1.38, .22, 1.02], counter: seatPos, colleague: [-1.38, .22, 1.02],
  };
  const setShots={
    desk: { x: -.08, y: 1.06, z: -.18, w: 1.98, e: .40, f: .45 },
    her: { x: -.08, y: 1.06, z: -.18, w: 1.98, e: .40, f: .45 },
    counter: { x: -.08, y: 1.06, z: -.18, w: 1.98, e: .40, f: .45 },
    display: { x: .04, y: 1.04, z: -.08, w: 1.76, e: .42, f: .46 },
    counterDisplay: { x: .04, y: 1.04, z: -.08, w: 1.76, e: .42, f: .46 },
    pair: { x: -.45, y: 1.24, z: -.08, w: 2.55, e: .40, f: .47 },
    finance: { x: -.45, y: 1.24, z: -.08, w: 2.55, e: .40, f: .47 },
    staff: { x: -.45, y: 1.24, z: -.08, w: 2.55, e: .40, f: .47 },
    gathering: { x: -.40, y: 1.24, z: -.05, w: 2.68, e: .40, f: .47 },
    hall: { x: -.35, y: 1.24, z: .0, w: 2.85, e: .42, f: .47 },
    wide: { x: -.35, y: 1.24, z: .0, w: 2.85, e: .42, f: .47 },
    door: { x: -1.42, y: 1.26, z: .75, w: 2.35, e: .40, f: .47 },
    file: { x: -.05, y: 1.04, z: -.05, w: 1.88, e: .44, f: .45 },
  };
  return {
    places, shots: setShots, work, counterLaptop: work.laptop, record: rec, landline: ll,
    seated: new Set(['desk','counter']),
    devices: { desk: work.laptop.userData.screen, counter: work.laptop.userData.screen },
    pointTarget: work.laptop.position.clone().add(V(0,.22,0)),
  };
}

function buildOpsSet(parent, c) {
  buildRoomShell(parent, { x0: -3.15, x1: 3.45, z0: -2.45, z1: 2.65, wallCol: '#eceff3', floorCol: '#e1e5ea', groutCol: '#cfd5de', trimCol: C.navy });
  addOfficeDoor(parent, -3.12, 1.35, Math.PI/2, true);
  // Wall badge reader by operations room door.
  mesh(rbox(.04,.18,.12,.01),C.dark,-3.08,1.32,.68,parent);
  mesh(sph(.014),new THREE.MeshBasicMaterial({color:'#4fd084'}),-3.055,1.38,.68,parent).castShadow=false;
  // Large wall operations display facing camera (+Z).
  const wallBoard=group(parent, -.05, 1.78, -2.38);
  mesh(rbox(2.58,1.16,.06,.018),C.dark,0,0,0,wallBoard);
  const wallTex=canvasTex(960,420,(ctx,w,h)=>{
    ctx.fillStyle='#1d2638'; ctx.fillRect(0,0,w,h);
    ctx.fillStyle='#2f7477'; ctx.fillRect(0,0,w,54);
    ctx.fillStyle='#ffffff'; ctx.font='bold 26px "Segoe UI",Arial,sans-serif'; ctx.fillText('SOC · LIVE MONITORING',28,36);
    const cols=['#4f8a55','#e9a23b','#c6543b','#4f8a55'];
    for(let i=0;i<4;i++){
      const x=26+i*230;
      ctx.fillStyle='#27334b'; ctx.fillRect(x,78,210,145);
      ctx.fillStyle=cols[i]; ctx.fillRect(x,78,210,16);
      ctx.fillStyle='#9eb2c9'; ctx.fillRect(x+16,112,130,10); ctx.fillRect(x+16,136,165,10);
      ctx.fillStyle=cols[i]; ctx.fillRect(x+16,172,110+i*14,22);
    }
    ctx.fillStyle='#27334b'; ctx.fillRect(26,248,w-52,146);
    ctx.strokeStyle='#5bc0be'; ctx.lineWidth=4; ctx.beginPath();
    for(let x=0;x<28;x++){ const px=44+x*32, py=354-Math.abs(Math.sin(x*.55)*48+(x===16||x===17?44:0)); if(!x)ctx.moveTo(px,py); else ctx.lineTo(px,py); }
    ctx.stroke();
  });
  const wallScreen=putInk(wallBoard, 2.46, 1.04, 0, 0, .034, wallTex);
  // Long operations console desk (3.3 m wide, z in [-0.15, +0.67], top at y=0.78).
  const consoleDesk=group(parent, 0, 0, .26);
  mesh(rbox(3.30,.06,.84,.02),mat('#ece7dc',{roughness:.58}),0,.75,0,consoleDesk);
  mesh(box(3.04,.46,.04),C.navyD,0,.48,.32,consoleDesk);
  for(const sx of [-1.52,0,1.52]) for(const sz of [-.34,.34])
    mesh(rbox(.06,.72,.06,.016),C.metalD,sx,.36,sz,consoleDesk);
  // 4 low-profile alert monitors along front edge (top at y=1.12 -> strictly below seated faces!).
  const monColors=['#2f7477','#e9a23b','#c6543b','#3f8d90'];
  const monScreens=[];
  [-1.26,-.44,.44,1.26].forEach((mx,mi)=>{
    const m=group(parent, mx, .78, .50); m.rotation.y=Math.PI+(mx<0?-.14:.14);
    mesh(rbox(.20,.016,.14,.006),C.metalD,0,.008,0,m);
    mesh(rbox(.04,.12,.025,.006),C.metalD,0,.07,-.01,m);
    mesh(rbox(.52,.29,.028,.01),C.dark,0,.22,0,m);
    const mt=canvasTex(320,180,ctx=>{
      ctx.fillStyle='#1d2738'; ctx.fillRect(0,0,320,180);
      ctx.fillStyle=monColors[mi]; ctx.fillRect(0,0,320,26);
      for(let r=0;r<4;r++){ ctx.fillStyle=r===1&&mi===2?'#c6543b':'#32425e'; ctx.fillRect(14,38+r*32,292,22); }
    });
    monScreens.push(putInk(m,.48,.25,0,.22,.016,mt));
  });
  // 3 analyst seats facing +Z (front 3/4 toward camera, clear of monitors!).
  const places={
    seat1: [-.96, -.44, .12], desk: [0, -.44, 0], seat2: [0, -.44, 0], seat3: [.96, -.44, -.12],
    analyst1: [-.96, -.44, .12], analyst2: [.96, -.44, -.12],
    director: [-1.62, -1.45, .62], lead: [-1.62, -1.45, .62],
    beside: [1.52, -1.35, -.52], counter: [1.52, -1.35, -.52],
    deskGuest: [2.22, -.62, -.92], colleague: [2.22, -.62, -.92],
    signer: [-1.92, -.10, 1.25], team: [-1.92, -.10, 1.25],
    door: [-2.35, 1.35, 1.32],
  };
  for(const [x,z,r] of [places.seat1,places.desk,places.seat3])
    officeChair(parent, x-Math.sin(r)*.06, z-Math.cos(r)*.06, r);
  const deskAnchor=group(parent, 0, 0, .24); deskAnchor.rotation.y=Math.PI;
  const lap=laptop(parent, 0, .78, .08, Math.PI, 1.02);
  const work={ desk: deskAnchor, laptop: lap, f: V(0,0,1), keyL: V(.12,.875,.02), keyR: V(-.12,.875,.02) };
  const workstations={
    desk: work, seat2: work,
    seat1: { keyL: V(-.79,.875,.00), keyR: V(-1.03,.875,.02), laptop: lap },
    seat3: { keyL: V(1.03,.875,.02), keyR: V(.79,.875,.00), laptop: lap },
  };
  const rec=folder(parent, -1.38, .782, .05, .85); rec.rotation.y=.25; rec.visible=!!c.file;
  const needPhone=c.landline || Object.values(c.actions||{}).some(rows=>rows.some(x=>x[2]==='extension'));
  let ll=null;
  if(needPhone) { ll=deskPhone(parent); ll.dock.position.set(-.48,.78,.14); ll.dock.rotation.y=Math.PI; }
  const setShots={
    gathering: { x: -.05, y: 1.38, z: -.68, w: 3.35, e: .38, f: .48 },
    hall: { x: -.05, y: 1.38, z: -.68, w: 3.35, e: .38, f: .48 },
    wide: { x: -.05, y: 1.38, z: -.68, w: 3.35, e: .38, f: .48 },
    pair: { x: .52, y: 1.20, z: -.48, w: 2.58, e: .38, f: .47 },
    staff: { x: -.58, y: 1.36, z: -.72, w: 2.85, e: .36, f: .48 },
    desk: { x: 0, y: 1.06, z: -.18, w: 2.02, e: .40, f: .45 },
    her: { x: 0, y: 1.06, z: -.18, w: 2.02, e: .40, f: .45 },
    counter: { x: -.05, y: 1.38, z: -.68, w: 3.15, e: .38, f: .48 },
    display: { x: -.05, y: 1.38, z: -1.15, w: 2.35, e: .34, f: .46 },
    counterDisplay: { x: -.05, y: 1.38, z: -1.15, w: 2.35, e: .34, f: .46 },
    file: { x: -1.12, y: 1.32, z: -.12, w: 2.48, e: .38, f: .48 },
  };
  return {
    places, shots: setShots, work, workstations, counterLaptop: lap, wallDisplay: wallScreen, record: rec, landline: ll,
    seated: new Set(['desk','seat1','seat2','seat3','analyst1','analyst2']),
    devices: { desk: lap.userData.screen, counter: wallScreen },
    pointTarget: V(-.05, 1.72, -2.30),
  };
}

function buildHomeSet(parent, c) {
  buildRoomShell(parent, { x0: -2.45, x1: 2.65, z0: -2.10, z1: 2.40, h: 2.95, wallCol: '#f0e6d6', floorCol: '#c9a67d', groutCol: '#b08b62', trimCol: null, woodFloor: true });
  // Evening window with twilight sky and curtains on back wall.
  const win=group(parent, .55, 1.66, -2.06);
  mesh(rbox(1.54,1.24,.08,.012),'#8f7254',0,0,0,win);
  const nightSky=canvasTex(256,200,ctx=>{
    const gr=ctx.createLinearGradient(0,0,0,200);
    gr.addColorStop(0,'#1e2c48'); gr.addColorStop(.65,'#35486e'); gr.addColorStop(1,'#6d6580');
    ctx.fillStyle=gr; ctx.fillRect(0,0,256,200);
    ctx.fillStyle='#ffe8a8'; ctx.beginPath(); ctx.arc(198,46,12,0,Math.PI*2); ctx.fill();
  });
  putInk(win, 1.40, 1.10, 0, 0, .042, nightSky);
  for(const sx of [-.86,.86]) mesh(rbox(.28,1.52,.07,.02),mat('#e6ddd0',{roughness:.92}),sx,-.06,.05,win);
  mesh(box(2.05,.04,.04),'#7a624a',0,.70,.05,win);
  // Warm framed artwork on left wall + home bookcase.
  const art=group(parent, -2.41, 1.66, -.15); art.rotation.y=Math.PI/2;
  mesh(rbox(.86,.64,.04,.01),'#8f7254',0,0,0,art);
  const artTex=canvasTex(256,192,ctx=>{
    ctx.fillStyle='#f6efe3'; ctx.fillRect(0,0,256,192);
    ctx.fillStyle='#d8a878'; ctx.beginPath(); ctx.arc(165,78,34,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#5c7b7d'; ctx.fillRect(24,118,208,52);
    ctx.fillStyle='#3d556a'; ctx.fillRect(24,142,208,28);
  });
  putInk(art,.76,.54,0,0,.022,artTex);
  addBookshelf(parent, -1.55, -1.82, 0);
  plant(parent, 1.98, 0, -1.52, .76, '#b86d4b', .95);
  // Home desk facing camera front-3/4 + warm glowing desk lamp + coffee mug.
  const seatPos=[-.15, -.42, .52];
  const f=V(Math.sin(seatPos[2]),0,Math.cos(seatPos[2]));
  const dx=seatPos[0]+f.x*.66, dz=seatPos[1]+f.z*.66;
  const hd=group(parent, dx, 0, dz); hd.rotation.y=seatPos[2]+Math.PI;
  mesh(rbox(1.62,.055,.82,.02),mat('#cfa97e',{roughness:.62}),0,.752,0,hd);
  for(const sx of [-.72,.72]) for(const sz of [-.34,.34]) mesh(rbox(.05,.72,.05,.012),C.dark,sx,.36,sz,hd);
  officeChair(parent, seatPos[0]-f.x*.06, seatPos[1]-f.z*.06, seatPos[2]);
  const lap=laptop(parent, seatPos[0]+f.x*.52, .78, seatPos[1]+f.z*.52, seatPos[2]+Math.PI, 1.05);
  // Warm home desk lamp on desk corner.
  const lampPos=hd.localToWorld(V(-.56,.78,-.16));
  const lamp=group(parent, lampPos.x, lampPos.y, lampPos.z);
  mesh(cyl(.085,.095,.025,20),C.dark,0,.013,0,lamp);
  bar(V(0,.02,0),V(-.04,.32,-.02),.01,mat('#b69258',{roughness:.35,metalness:.5}),lamp);
  bar(V(-.04,.32,-.02),V(.06,.42,.04),.01,mat('#b69258',{roughness:.35,metalness:.5}),lamp);
  const shade=mesh(cyl(.055,.11,.13,20),mat('#e6c88a',{roughness:.6}),.08,.38,.05,lamp); shade.rotation.z=-.38;
  mesh(sph(.038),new THREE.MeshBasicMaterial({color:'#fff2c8'}),.08,.33,.05,lamp).castShadow=false;
  const glow=new THREE.PointLight('#ffdca0',1.8,5.2); glow.position.set(lampPos.x+.08,lampPos.y+.34,lampPos.z+.06); parent.add(glow);
  // Ceramic mug on desk.
  const mugPos=hd.localToWorld(V(.46,.78,.04));
  mesh(cyl(.038,.034,.09,18),mat('#3f8d90',{roughness:.35}),mugPos.x,mugPos.y+.045,mugPos.z,parent);
  const work={ desk: hd, laptop: lap, f, keyL: V(seatPos[0]+f.x*.46+f.z*.12,.875,seatPos[1]+f.z*.46-f.x*.12), keyR: V(seatPos[0]+f.x*.46-f.z*.12,.875,seatPos[1]+f.z*.46+f.x*.12) };
  const rec=folder(parent, 0, 0, 0, .85); rec.position.copy(hd.localToWorld(V(.45,.782,-.14))); rec.rotation.y=hd.rotation.y; rec.visible=!!c.file;
  const places={ desk: seatPos, counter: seatPos, beside: [1.18, -.28, -.42], door: [-1.75, 1.25, 1.1] };
  const setShots={
    desk: { x: .0, y: 1.06, z: -.08, w: 2.08, e: .40, f: .45 },
    her: { x: .0, y: 1.06, z: -.08, w: 2.08, e: .40, f: .45 },
    hall: { x: -.05, y: 1.08, z: -.05, w: 2.35, e: .42, f: .45 },
    wide: { x: -.05, y: 1.08, z: -.05, w: 2.35, e: .42, f: .45 },
    display: { x: .06, y: 1.02, z: -.02, w: 1.76, e: .42, f: .46 },
    pair: { x: .0, y: 1.08, z: -.08, w: 2.15, e: .40, f: .45 },
  };
  return {
    places, shots: setShots, work, counterLaptop: lap, record: rec, landline: null,
    seated: new Set(['desk','counter']),
    devices: { desk: lap.userData.screen, counter: lap.userData.screen },
    pointTarget: lap.position.clone().add(V(0,.2,0)),
  };
}

function buildTaxiSet(parent) {
  // Evening street kerb: pavement in foreground (+Z), kerb at z=-0.42, asphalt road behind (-Z) so taxi is right behind the actor, never blocking them!
  const gnd=mesh(new THREE.PlaneGeometry(80,80),mat('#5a606c',{roughness:1}),0,-.38,0,parent); gnd.rotation.x=-Math.PI/2; gnd.castShadow=false;
  // Sidewalk / pavement slab (y = 0, z in [-0.42, +3.4]).
  const paveTex=makeFloorTex('#d9d2c5','#beb6a7',false);
  mesh(box(9.6,.24,3.8),C.wallTop,0,-.12,1.48,parent);
  const pv=mesh(new THREE.PlaneGeometry(9.6,3.8),new THREE.MeshStandardMaterial({map:paveTex,roughness:.85}),0,.004,1.48,parent);
  pv.rotation.x=-Math.PI/2; pv.castShadow=false;
  // Bevelled kerbstone along z = -0.42.
  mesh(rbox(9.6,.14,.18,.025),mat('#c5beb0',{roughness:.8}),0,-.045,-.42,parent);
  // Asphalt road (y = -0.12, z in [-5.2, -0.42]).
  const road=mesh(box(11.0,.16,4.8),mat('#454a54',{roughness:.92}),0,-.20,-2.82,parent); road.castShadow=false;
  // Yellow kerb-side no-parking line & dashed centre lane markers.
  mesh(box(9.6,.008,.07),mat('#d6a23b',{roughness:.7}),0,-.116,-.60,parent).castShadow=false;
  for(const lx of [-3.2,-1.4,.4,2.2,4.0]) mesh(box(1.0,.008,.08),mat('#e6e2d8',{roughness:.75}),lx,-.116,-2.95,parent).castShadow=false;
  // Subtle evening building wall & planter across far side of road for depth.
  mesh(box(11.0,2.8,.30),mat('#cfc6b8',{roughness:.92}),0,1.28,-5.10,parent);
  for(const wx of [-2.4,.2,2.6]) mesh(box(.95,1.05,.04),new THREE.MeshBasicMaterial({color:'#f2dfb6'}),wx,1.55,-4.94,parent).castShadow=false;
  plant(parent, -2.55, 0, .55, .74, '#b8b0a2', .95);
  // Warm evening street lamp on pavement left of Omar.
  const pole=group(parent, -1.78, 0, .05);
  mesh(cyl(.09,.12,.16,16),C.dark,0,.08,0,pole);
  mesh(cyl(.045,.065,3.15,16),C.dark,0,1.65,0,pole);
  bar(V(0,3.15,0),V(.55,3.22,-.25),.03,mat(C.dark),pole);
  mesh(rbox(.32,.08,.18,.02),C.dark,.62,3.22,-.28,pole);
  mesh(rbox(.26,.04,.13,.01),new THREE.MeshBasicMaterial({color:'#fff1c4'}),.62,3.17,-.28,pole).castShadow=false;
  const streetGlow=new THREE.PointLight('#ffdfa2',2.2,9.0); streetGlow.position.set(-.95,3.05,-.15); parent.add(streetGlow);
  // Taxi parked neatly along kerb at (-0.65, -0.12, -1.42), nose pointing +X (clean own geometry!).
  const taxi=group(parent, -.65, -.12, -1.42); taxi.rotation.y=Math.PI/2;
  const bodyM=mat('#ede9de',{roughness:.42,metalness:.12}), roofM=mat('#e4a42c',{roughness:.45,metalness:.1});
  const glassM=mat('#2f394c',{roughness:.18,metalness:.35}), tireM=mat('#22262e',{roughness:.88});
  // Lower chassis + bumpers
  mesh(rbox(1.74,.52,4.05,.09),bodyM,0,.52,0,taxi);
  mesh(rbox(1.78,.14,.22,.04),C.dark,0,.32,1.98,taxi);
  mesh(rbox(1.78,.14,.22,.04),C.dark,0,.32,-1.98,taxi);
  // Amber taxi stripe along both sides
  for(const sx of [-.875,.875]) mesh(box(.02,.10,3.60),roofM,sx,.52,0,taxi);
  // Cabin & amber-yellow roof
  mesh(rbox(1.56,.54,2.15,.08),roofM,0,1.02,-.12,taxi);
  // Windscreen, rear glass & side windows
  mesh(rbox(1.42,.42,.05,.02),glassM,0,1.02,.96,taxi).rotation.x=-.35;
  mesh(rbox(1.42,.40,.05,.02),glassM,0,1.02,-1.18,taxi).rotation.x=.32;
  for(const sx of [-.785,.785]) mesh(box(.03,.38,1.72),glassM,sx,1.02,-.12,taxi);
  // Glowing TAXI roof sign
  const signBox=group(taxi, 0, 1.37, -.08);
  mesh(rbox(.56,.18,.22,.03),C.dark,0,0,0,signBox);
  const taxiTex=canvasTex(256,84,ctx=>{
    ctx.fillStyle='#ffeb99'; ctx.fillRect(0,0,256,84);
    ctx.fillStyle='#1f2633'; ctx.font='900 54px "Segoe UI",Arial,sans-serif'; ctx.textAlign='center'; ctx.fillText('TAXI',128,62);
  });
  putInk(signBox,.50,.14,0,0,.114,taxiTex);
  const backSign=putInk(signBox,.50,.14,0,0,-.114,taxiTex); backSign.rotation.y=Math.PI;
  // 4 wheels with hubcaps
  for(const sx of [-.84,.84]) for(const sz of [-1.24,1.24]){
    const w=mesh(cyl(.31,.31,.22,22),tireM,sx,.31,sz,taxi); w.rotation.z=Math.PI/2;
    const h=mesh(cyl(.16,.16,.24,16),C.metal,sx,.31,sz,taxi); h.rotation.z=Math.PI/2;
  }
  // Headlights & taillights
  for(const sx of [-.62,.62]){
    mesh(rbox(.30,.14,.05,.02),new THREE.MeshBasicMaterial({color:'#fff4c9'}),sx,.58,2.02,taxi).castShadow=false;
    mesh(rbox(.30,.14,.05,.02),new THREE.MeshBasicMaterial({color:'#d94a3c'}),sx,.58,-2.02,taxi).castShadow=false;
  }
  const places={ kerb: [.55, .36, .62], door: [.55, .36, .62], desk: [.55, .36, .62], beside: [1.52, .52, .25] };
  const setShots={
    kerb: { x: .12, y: 1.12, z: -.22, w: 2.65, e: .38, f: .44 },
    door: { x: .12, y: 1.12, z: -.22, w: 2.65, e: .38, f: .44 },
    wide: { x: .12, y: 1.12, z: -.22, w: 2.65, e: .38, f: .44 },
    hall: { x: .12, y: 1.12, z: -.22, w: 2.65, e: .38, f: .44 },
    pair: { x: .12, y: 1.12, z: -.22, w: 2.65, e: .38, f: .44 },
    close: { x: .42, y: 1.26, z: .14, w: 1.92, e: .36, f: .44 },
    display: { x: .42, y: 1.26, z: .14, w: 1.92, e: .36, f: .44 },
    desk: { x: .42, y: 1.26, z: .14, w: 1.92, e: .36, f: .44 },
  };
  return {
    places, shots: setShots, work: null, counterLaptop: null, record: null, landline: null,
    seated: new Set(), devices: {}, pointTarget: V(-.65, 1.0, -1.42),
  };
}

function applySetLighting(stage, setName) {
  const L=stage.lights; if(!L) return;
  if(setName==='home') {
    stage.scene.background.set('#d5d0c7');
    L.hemi.color.set('#dce0ec'); L.hemi.groundColor.set('#c4b29c'); L.hemi.intensity=.86;
    L.sun.color.set('#ffdcb0'); L.sun.intensity=.76;
    L.fill.color.set('#9ab0d8'); L.fill.intensity=.24;
  } else if(setName==='taxi') {
    stage.scene.background.set('#bcc4d2');
    L.hemi.color.set('#b8c6e0'); L.hemi.groundColor.set('#7a7d8a'); L.hemi.intensity=.82;
    L.sun.color.set('#d8e2f5'); L.sun.intensity=.70;
    L.fill.color.set('#ffd9a0'); L.fill.intensity=.32;
  } else {
    stage.scene.background.set(C.sky);
    L.hemi.color.set('#ffffff'); L.hemi.groundColor.set('#e8e2d6'); L.hemi.intensity=1.18;
    L.sun.color.set('#fff6e8'); L.sun.intensity=1.45;
    L.fill.color.set('#eef3ff'); L.fill.intensity=.28;
  }
}

function collectObstacles(root) {
  root.updateMatrixWorld(true);
  const blocks=[], tables=[];
  root.traverse(o=>{
    if(!o.isMesh||o.isSkinnedMesh||!o.geometry) return;
    if(!o.geometry.boundingBox) o.geometry.computeBoundingBox();
    const bb=o.geometry.boundingBox.clone().applyMatrix4(o.matrixWorld);
    const dx=bb.max.x-bb.min.x, dy=bb.max.y-bb.min.y, dz=bb.max.z-bb.min.z;
    if(dy<.12 && bb.max.y>.6 && bb.max.y<1.2 && dx>.35 && dz>.35 && dx<6 && dz<6)
      { blocks.push([bb.min.x-.32,bb.max.x+.32,bb.min.z-.32,bb.max.z+.32]); tables.push(blocks.at(-1)); }
    else if(dy>=.4 && bb.min.y<1.2 && bb.max.y<2.2 && ((dx<.2 && dz>.5 && dz<6) || (dz<.2 && dx>.5 && dx<6)))
      blocks.push([bb.min.x-.35,bb.max.x+.35,bb.min.z-.35,bb.max.z+.35]);
    else if(o.geometry.type==='CylinderGeometry' && bb.min.y<.15 && dy>=.25 && dy<=.75 && dx>=.3 && dx<=.85 && dz>=.3 && dz<=.85)
      blocks.push([bb.min.x-.35,bb.max.x+.35,bb.min.z-.35,bb.max.z+.35]);
  });
  return { blocks, tables };
}

export function chapterHall(describe) {
  return async ({stage,scene,b,createCounter,S,E,D,ui,slot})=>{
    const c=describe(S,E,D), roles=Object.keys(c.actors);
    const setTimeline=Array.isArray(c.set) ? c.set : [[0, D.T+1, c.set || 'hall']];
    const setAt=t=>active(setTimeline,t)?.[2] || setTimeline[0][2];
    const usedSets=[...new Set(setTimeline.map(x=>x[2]))];
    const primarySet=setTimeline[0][2];
    const hasMoodSet=usedSets.some(s=>s==='home'||s==='taxi');

    const motions=new Set(roles.flatMap(r=>female(r)?[...IDLE_F,...LISTEN_F,seated(r)]:[...IDLE_M,...LISTEN_M,...SEATED_M]));
    for(const [role,rows] of Object.entries(c.actions||{})) for(const [, , action] of rows) {
      if(action==='talk') (female(role)?TALK_F:TALK_M).forEach(m=>motions.add(m));
    }
    await loadMotion([...motions]);

    // Build each required set into its own group; default 'hall' keeps today's hall unchanged.
    const setData={}, setGroups={}, propUpdaters=[];
    const needHallPhone=c.landline || Object.values(c.actions||{}).some(rows=>rows.some(x=>x[2]==='extension'));
    for(const name of usedSets) {
      const g=group(scene); setGroups[name]=g;
      if(name==='hall') {
        createCounter(g,false);
        if (slot) {
          const table = await cached(tables, 'hall', async () => {
            const root = new THREE.Group();
            await restoreTeachingTable(root);
            return root;
          });
          g.add(table.clone(true));
        } else await restoreTeachingTable(g);
        const counterLaptop=laptop(g,-2.34,1.055,-.52,-1.37,1.17);
        const work=workplace(g,...hallPlaces.desk);
        const rec=folder(g,c.signing ? -2.05 : -2.22,1.057,.12,.88); rec.rotation.y=-Math.PI/2; rec.visible=!!c.file;
        if(c.poster) paymentPoster(g);
        if(c.habits) await habitsBoard(g);
        if(c.whiteboard) wallWhiteboard(g,-4.93,1.62,-.55,Math.PI/2,1.62,.96,c.whiteboard);
        let ll=null;
        if(needHallPhone) {
          ll=deskPhone(g);
          const inHall=r=>{ const a=c.actorSets?.[r]; return !a || (Array.isArray(a)?a.includes('hall'):a==='hall'); };
          const deskExt=c.landline==='desk' || Object.entries(c.actions||{}).some(([r,rows])=>{
            if(!inHall(r)) return false;
            const pl=typeof c.actors[r]==='string'?c.actors[r]:c.actors[r]?.hall;
            return (pl==='desk'||pl==='beside') && rows.some(x=>x[2]==='extension');
          });
          if(deskExt) { ll.dock.position.copy(work.desk.localToWorld(V(.47,.78,-.07))); ll.dock.rotation.y=work.desk.rotation.y; }
        }
        if(c.tablet && typeof c.tablet==='object' && c.tablet.on==='desk') deskTabletStand(g,work.desk,c.tablet.title);
        setData.hall={
          places: hallPlaces, shots: hallShots, work, counterLaptop, record: rec, landline: ll,
          seated: new Set(['desk']),
          devices: { counter: counterLaptop.userData.screen, desk: work.laptop.userData.screen },
          pointTarget: V(-1.95,1.39,-.14),
        };
      } else if(name==='meeting') setData.meeting=await buildMeetingSet(g,c);
      else if(name==='office') setData.office=buildOfficeSet(g,c);
      else if(name==='ops') setData.ops=buildOpsSet(g,c);
      else if(name==='home') setData.home=buildHomeSet(g,c);
      else if(name==='taxi') setData.taxi=buildTaxiSet(g,c);
    }
    if(b?.group && !usedSets.includes('hall')) b.group.visible=false;

    // Optional real network cable prop (e.g. 9.06v unplugging Ethernet while leaving laptop on).
    if(c.cable) {
      const cfg=typeof c.cable==='object' ? c.cable : { device:'desk' };
      for(const name of usedSets) {
        const sd=setData[name], lap=cfg.device==='counter'?sd.counterLaptop:sd.work?.laptop;
        if(lap) { const up=networkCable(setGroups[name],lap,cfg.unplugAt ?? null); if(up) propUpdaters.push(up); }
      }
    }

    const inkPen=mesh(rbox(.012,.012,.15,.005),C.navy,-2.15,1.09,.06,scene);
    inkPen.visible=false;

    // In-world screen displays (or screenOff for continuity exercises like 8.13v).
    const states=[];
    if(c.screenOff) {
      const offMat=mat('#1d222b',{roughness:.22,metalness:.1});
      for(const name of usedSets) {
        const sd=setData[name];
        for(const scr of Object.values(sd.devices||{})) if(scr) scr.material=offMat;
      }
    } else {
      for(const [device,rows] of Object.entries(c.displays||{})) {
        const screens=usedSets.map(n=>setData[n].devices?.[device]).filter(Boolean);
        if(!screens.length) continue;
        const idles=screens.map(s=>s.material.clone());
        const views=await Promise.all(rows.map(async ([a,z,icon,label,tone,type])=>{
          const map=displayTexture(await iconImage(icon),label,tone,type);
          return [a,z,new THREE.MeshBasicMaterial({map,toneMapped:false})];
        }));
        states.push(t=>{
          const m=active(views,t)?.[2];
          screens.forEach((s,i)=>{ s.material=m||idles[i]; });
        });
      }
    }

    const actors={}, phones={}, sheets={}, usbs={}, tablets={}, idCards={};
    for(const role of roles) {
      actors[role]=createPerson(role,scene,slot?.cast,slot?.people);
      if (slot) await slot.yieldFrame();
      const actions=c.actions?.[role]||[];
      if(actions.some(x=>['call','text','photo','dial'].includes(x[2]))) phones[role]=mobile(scene);
      if(actions.some(x=>x[2]==='paper')) {
        const page=group(scene);
        mesh(rbox(.22,.003,.29,.001),C.paper,0,0,0,page);
        for(let i=0;i<6;i++) mesh(rbox(i? .16:.11,.001,.005,.0004),i?C.metalD:C.teal,-.01,.0025,-.10+i*.029,page);
        sheets[role]=page;
      }
      if(actions.some(x=>x[2]==='usb')) usbs[role]=usbDrive(scene);
      if(actions.some(x=>x[2]==='tablet')) tablets[role]=officeTablet(scene,typeof c.tablet==='object'?c.tablet.title:'Sadeed briefing');
      if(actions.some(x=>x[2]==='idCard')) idCards[role]=officeIdCard(scene);
    }
    for(const [role,rows] of Object.entries(c.handsets||{})) {
      if(!phones[role]) continue;
      const screen=phones[role].userData.screen, idle=screen.material;
      const views=await Promise.all(rows.map(async ([a,z,name])=>{
        const image=await iconImage(name);
        const texture=canvasTex(136,264,ctx=>{
          ctx.fillStyle='#f5f3ea';ctx.fillRect(0,0,136,264);
          ctx.fillStyle='#315866';ctx.fillRect(0,0,136,26);
          ctx.drawImage(image,7,48,122,122);
          ctx.fillStyle='#93b6b4';ctx.fillRect(18,184,100,8);ctx.fillRect(18,204,72,6);
        });
        return [a,z,new THREE.MeshBasicMaterial({map:texture,toneMapped:false})];
      }));
      states.push(t=>{screen.material=active(views,t)?.[2]||idle;});
    }

    const primary=setData[primarySet];
    const beforeProps=new Set(scene.children);
    const updateProps = c.setupProps && await c.setupProps({
      stage, scene, actors, devices: primary.devices, phones, sheets,
      work: primary.work, counterLaptop: primary.counterLaptop || setData.hall?.counterLaptop, landline: primary.landline, record: primary.record,
      /* a readable close-up is on screen: top-down inserts would show only the counter top behind it (Gemini 2026-11-23, 3.01v) */
      screenAt: t => !!c.screens?.some(([a,z]) => a <= t && t < z),
    });
    if(usedSets.length>1) {
      for(const ch of [...scene.children]) if(!beforeProps.has(ch)) setGroups[primarySet].attach(ch);
    }

    const deskRest=primary.work?.laptop.position.clone() || V(0,0,0);
    const bankCard=c.bankCard && group(scene);
    if(bankCard) {
      mesh(rbox(.086,.055,.003,.002),C.teal,0,0,0,bankCard);
      mesh(rbox(.081,.01,.001,.0004),C.navy,0,.013,.002,bankCard);
      for(const x of [-.022,-.005,.012])mesh(rbox(.01,.003,.001,.0004),C.paper,x,-.005,.002,bankCard);
    }
    const host = slot?.dom || document;
    const head=host.getElementById('head'), kicker=host.getElementById('kicker');
    kicker.textContent=trTemplate('Lesson {lesson} · Version 4',{lesson:c.lesson});
    const plate=document.createElement('span');
    plate.style.cssText='display:inline-block;padding:3px 9px;margin-top:5px;border-radius:6px;color:#fff;background:#315866;font-size:clamp(15px,2.7vw,18px);font-weight:700';
    head.append(plate);
    const B=createBoard(D.T, host.getElementById('stage'));
    for(let i=0;i<c.pages.length;i++){
      const p=c.pages[i]; if(c.pages[i-1]?.z!==p.a) B.open(p.a);
      concept(B,p.a,p.z,p);
      if(p.z<D.T && c.pages[i+1]?.a!==p.z) B.close(p.z);
    }
    // The longer bilingual headings get their own bounded region above the illustration.
    for(const page of B.libraryCanvas.children) {
      const h=page.querySelector('.v-heading');
      Object.assign(h.style,{fontSize:AR?'26px':'27px',lineHeight:AR?'1.29':'1.13',height:'122px',maxHeight:'122px'});
      page.querySelector('.v-art').style.top='177px';
      const cards=[...page.querySelectorAll('.v-card')];
      if(cards.length) {
        const stack=document.createElement('div');
        const startTop=Math.min(...cards.map(n=>parseFloat(n.style.top)||386))+24;
        stack.style.cssText=`position:absolute;left:24px;top:${startTop}px;width:312px;display:flex;flex-direction:column;gap:8px;z-index:2`;
        page.append(stack);
        for(const line of cards) {
          Object.assign(line.style,{position:'relative',left:'auto',top:'auto',width:'100%',whiteSpace:'normal',display:'flex',alignItems:'center',lineHeight:'1.2',minHeight:'56px',height:'auto',padding:'8px 12px'});
          stack.append(line);
        }
      }
    }
    B.end(); await readyPages(B);

    // Per-set obstacle maps for clean walking without passing through furniture, glass, plants or people.
    const setObstacles={};
    for(const name of usedSets) {
      const ob=collectObstacles(setGroups[name]);
      if(name==='hall' && b?.group) {
        const bo=collectObstacles(b.group);
        ob.blocks.push(...bo.blocks); ob.tables.push(...bo.tables);
      }
      setObstacles[name]=ob;
    }
    const inRect=(p,[x0,x1,z0,z1])=>p[0]>x0&&p[0]<x1&&p[1]>z0&&p[1]<z1;
    const crosses=(p,q,b)=>{
      const [x0,x1,z0,z1]=b, L=Math.hypot(q[0]-p[0],q[1]-p[1]);
      const steps=Math.max(40,Math.ceil(L/.08)), pIn=inRect(p,b), qIn=inRect(q,b);
      for(let i=1;i<steps;i++){ const f=i/steps, x=p[0]+(q[0]-p[0])*f, z=p[1]+(q[1]-p[1])*f;
        if((pIn && f*L<.45)||(qIn && (1-f)*L<.45)) continue;
        if(x>x0+.2&&x<x1-.2&&z>z0+.2&&z<z1-.2) return true; }
      return false;
    };
    const clear=(p,q,list)=>!list.some(b=>crosses(p,q,b));
    const inside=(p,list)=>list.some(b=>inRect(p,b));
    function route(p,q,list,tables){
      if(clear(p,q,list)) return [p,q];
      const d=(u,v)=>Math.hypot(u[0]-v[0],u[1]-v[1]);
      const corners=list.flatMap(([x0,x1,z0,z1])=>[[x0,z0],[x0,z1],[x1,z0],[x1,z1]]).filter(cn=>!inside(cn,list)&&d(p,cn)>.15&&d(cn,q)>.15);
      let best=null, bl=1e9;
      for(const cn of corners) if(clear(p,cn,list)&&clear(cn,q,list)&&d(p,cn)+d(cn,q)<bl){ best=[p,cn,q]; bl=d(p,cn)+d(cn,q); }
      if(!best) for(const c1 of corners) for(const c2 of corners) if(c1!==c2&&clear(p,c1,list)&&clear(c1,c2,list)&&clear(c2,q,list)){
        const l=d(p,c1)+d(c1,c2)+d(c2,q); if(l<bl){ best=[p,c1,c2,q]; bl=l; } }
      if(best) return best;
      return list!==tables ? route(p,q,tables,tables) : [p,q];
    }
    const basePlace=(role,sName)=>{
      const spec=c.actors[role];
      return typeof spec==='string' ? spec : (spec[sName] || Object.values(spec)[0]);
    };
    const roleAllowedIn=(role,sName)=>{
      const allow=c.actorSets?.[role];
      if(!allow) return true;
      return Array.isArray(allow) ? allow.includes(sName) : allow===sName;
    };
    const actorPlaceAt=(role,t,sName)=>{
      let pl=basePlace(role,sName);
      for(const [a,z,to] of c.walks?.[role]||[]){
        if(setAt((a+z)/2)!==sName) continue;
        if(t<a) break; if(t>=z){pl=to;continue;} return null;
      }
      return pl;
    };
    const walkRoutes=new Map();
    for(const role of roles) {
      const fromBySet={};
      (c.walks?.[role]||[]).forEach(([a,z,to],wi)=>{
        const tm=(a+z)/2, sName=setAt(tm), sd=setData[sName], pl=sd.places, ob=setObstacles[sName];
        const from=fromBySet[sName] || basePlace(role,sName);
        if(!pl[from]||!pl[to]) return;
        const [x0,z0]=pl[from], [x1,z1]=pl[to];
        const p=[x0,z0], q=[x1,z1], all=[...ob.blocks];
        for(const other of roles) {
          if(other===role || !roleAllowedIn(other,sName)) continue;
          if(c.leave?.[other]!==undefined && tm>=c.leave[other]) continue;
          if(c.enter?.[other]!==undefined && tm<c.enter[other]) continue;
          const opl=actorPlaceAt(other,tm,sName); if(!opl || !pl[opl]) continue;
          const [ox,oz]=pl[opl];
          if(Math.hypot(ox-x0,oz-z0)<.55 || Math.hypot(ox-x1,oz-z1)<.55) continue;
          all.push([ox-.55,ox+.55,oz-.55,oz+.55]);
        }
        walkRoutes.set(`${role}:${wi}`,route(p,q,all,ob.tables));
        fromBySet[sName]=to;
      });
    }
    const beatW=(t,a,z,fade=.42)=>{
      const f=Math.min(fade,Math.max(.05,(z-a)*.45));
      const inK=a<=.01 ? 1 : ramp(t,a,a+f);
      const outK=z>=D.T-.05 ? 1 : 1-ramp(t,z-f,z);
      return inK*outK;
    };
    const frames=c.shots.map(([a,name],i)=>{
      const sName=setAt(a+.01), sd=setData[sName];
      const shot=sd.shots[name] || sd.shots.wide || sd.shots.desk || hallShots[name] || hallShots.hall;
      return i ? {t0:a-.02,t1:a,...shot} : shot;
    });

    return t=>{
      const curSetName=setAt(t), curSet=setData[curSetName], places=curSet.places;
      for(const name of usedSets) setGroups[name].visible=(name===curSetName);
      if(b?.group) b.group.visible=(curSetName==='hall');
      if(hasMoodSet) applySetLighting(stage,curSetName);

      // c.screens (optional): readable close-ups of the message being discussed (screens.js beats), as in Chapter 1 (audit 2026-11-22).
      B.tl.time(t,false); seekPages(B,t); if(c.screens) ui.play(t,c.screens); else quietScreens(ui,t);
      stage.conceptPage=c.pages.some(({a,z})=>t>=a && t<z);
      stage.focus=null; stage.outage=0;
      const label=active(c.plates,t)?.[2];
      plate.style.display=label?'inline-block':'none';
      const plateText=label ? tr(label) : '';
      if(plate.textContent!==plateText) plate.textContent=plateText;
      states.forEach(update=>update(t));
      propUpdaters.forEach(update=>update(t));

      const landline=curSet.landline, work=curSet.work, counterLaptop=curSet.counterLaptop, record=curSet.record;
      if(landline) restReceiver(landline);
      if(bankCard) bankCard.visible=false;
      if(c.carryLaptop && work) work.laptop.position.copy(deskRest);
      let open=0;
      for(const [a,z,from,to] of c.file||[]) if(t>=a) open=from+(to-from)*ramp(t,a,z);
      if(record) {
        record.userData.open(open*(Math.PI/2.5));
        if(open>=.99) record.userData.cover.position.y=.008;
      }
      inkPen.visible=false;

      for(const role of roles) {
        const idx=roles.indexOf(role), person=actors[role], beat=active(c.actions?.[role],t), action=beat?.[2];
        let place=basePlace(role,curSetName), walking=false;
        person.reset(); person.idle(t,idx+1);
        const walks=c.walks?.[role]||[];
        for(let wi=0;wi<walks.length;wi++){
          const [a,z,to]=walks[wi];
          if(setAt((a+z)/2)!==curSetName) continue;
          if(t<a) break;
          if(t>=z){place=to;continue;}
          const pFrom=places[place], pTo=places[to];
          if(pFrom && pTo) {
            const [x0,z0,r0]=pFrom, [x1,z1,r1]=pTo;
            const pts=walkRoutes.get(`${role}:${wi}`)||[[x0,z0],[x1,z1]];
            person.goPath(t,a,z,pts,r0,r1);
            walking=true;
          }
          break;
        }
        const sat=curSet.seated.has(place) && !walking;
        if(!walking && places[place]){
          person.at(...places[place]);
          const cur=clipAt(role,idx,sat,beat,t);
          const beatAge=beat && beat[0]>.01 ? t-beat[0] : 1;
          if(beatAge<.45) {
            const prevBeat=active(c.actions?.[role],beat[0]-.02);
            const prev=clipAt(role,idx,sat,prevBeat,beat[0]-.02);
            if(prev.name!==cur.name) person.playBlend(prev.name,prev.time+beatAge,cur.name,cur.time,beatAge/.45,true);
            else if(cur.blend<1) person.playBlend(cur.prevName,cur.prevTime,cur.name,cur.time,cur.blend,true);
            else person.play(cur.name,cur.time,true);
          } else if(cur.blend<1) person.playBlend(cur.prevName,cur.prevTime,cur.name,cur.time,cur.blend,true);
          else person.play(cur.name,cur.time,true);
        }
        person.g.visible=roleAllowedIn(role,curSetName)
          && !(c.leave?.[role]!==undefined && t>=c.leave[role])
          && !(c.enter?.[role]!==undefined && t<c.enter[role]);
        if(phones[role]) phones[role].visible=false;
        if(sheets[role]) sheets[role].visible=false;
        if(usbs[role]) usbs[role].visible=false;
        if(tablets[role]) tablets[role].visible=false;
        if(idCards[role]) idCards[role].visible=false;
        if(!person.g.visible)continue;

        if(c.carryLaptop?.[0]===role && work && t<c.carryLaptop[2]) {
          const [,a,z]=c.carryLaptop, k=ramp(t,a,z);
          const hand=person.g.localToWorld(V(0,101,28));
          work.laptop.position.copy(hand).lerp(deskRest,k);
          for(const [side,x] of [['L',.20],['R',-.20]]) person.reach(side,work.laptop.localToWorld(V(x,.012,.04)),1-k);
        }
        if(bankCard && role===c.bankCard[0] && t>=c.bankCard[1] && t<c.bankCard[2]) {
          const bw=beatW(t,c.bankCard[1],c.bankCard[2],.4);
          bankCard.visible=bw>.04; bankCard.position.copy(person.g.localToWorld(V(15,132-16*(1-bw),25)));
          bankCard.rotation.set(-.35,person.g.rotation.y+Math.PI,-.12,'YXZ');
          person.reach('L',bankCard.localToWorld(V(.035,-.018,0)),bw,V(.6,-1,-.35));person.look(bankCard.position,bw);
        }
        const lap=place==='counter'?(counterLaptop||work?.laptop):(work?.laptop||counterLaptop);
        const w=beat ? beatW(t,beat[0],beat[1],.42) : 0;
        if(action==='read'||action==='type'||action==='handsOff'){
          const lookObj=(curSetName==='ops' && !sat && curSet.wallDisplay) ? curSet.wallDisplay : lap?.userData?.screen;
          if(lookObj) person.look(lookObj.getWorldPosition(V(0,0,0)),w);
          if(action==='type' && lap) {
            person.bend=.06*w+.014*w*Math.sin(t*2.1+idx);
            const ws=curSet.workstations?.[place] || (place==='desk'||place==='seat2' ? work : null);
            if(sat && ws) typing(person,ws,t,w);
            else if(!sat) for(const [side,x] of [['L',-.09],['R',.09]]) {
              const dy=.008*Math.sin(t*(side==='R'?7.1:6.3)+(side==='R'?0:2.1));
              person.reach(side,lap.localToWorld(V(x,.035+dy,.06)),w,V(side==='L'?.65:-.65,-1,-.45),{profile:'typing',time:t});
            }
          } else {
            person.bend=(action==='handsOff'?.01:.03)*w+.01*w*Math.sin(t*1.3+idx);
          }
        } else if(action==='extension' && landline){
          person.flush();
          const headAt=person.b.Bip01_Head.getWorldPosition(V(0,0,0)), yaw=person.g.rotation.y;
          const phone=landline.receiver, restPos=phone.position.clone(), restY=phone.rotation.y;
          const earPos=headAt.clone().add(V(-.14*Math.cos(yaw),-.035+.008*Math.sin(t*1.8+idx),.14*Math.sin(yaw)));
          const dyaw=Math.atan2(Math.sin(yaw-Math.PI/2-restY),Math.cos(yaw-Math.PI/2-restY));
          phone.position.copy(restPos).lerp(earPos,w);
          phone.rotation.set(Math.PI/2*(1-w),restY+dyaw*w,-.12*w,'YXZ');
          person.reach('R',phone.position,w,V(-.65,-.95,-.35));
        } else if(action==='call'||action==='text'||action==='photo'||action==='dial'){
          person.flush();
          const phone=phones[role], yaw=person.g.rotation.y;
          const headAt=person.b.Bip01_Head.getWorldPosition(V(0,0,0));
          const ear=action==='call', x=ear?-.135:-.10, z=ear ? .035 : .29;
          const lift=-.16*(1-w)+.007*Math.sin(t*1.9+idx)*w;
          phone.position.copy(headAt).add(V(x*Math.cos(yaw)+z*Math.sin(yaw),(ear?-.015:-.25)+lift,-x*Math.sin(yaw)+z*Math.cos(yaw)));
          phone.rotation.set(ear?0:-.36,yaw+(ear?-Math.PI/2:Math.PI),ear ? .13 : 0,'YXZ');
          phone.visible=w>.04;
          person.reach('R',phone.localToWorld(V(.027,-.038,-.01)),w,V(-.6,-.95,-.3));
          if(!ear)person.look(action==='photo'?V(-1.93,1.35,-.05):phone.position,w);
          if(action==='text'||action==='dial') {
            const tap=.008*Math.sin(t*6.8+idx);
            person.reach('L',phone.localToWorld(V(-.02,tap,.014)),.86*w,V(.6,-.95,-.3));
          }
        } else if(action==='paper'){
          const sheet=sheets[role], yaw=person.g.rotation.y;
          sheet.visible=w>.04;
          sheet.position.copy(person.g.localToWorld(V(0,(sat?100:117)-12*(1-w),29)));
          sheet.rotation.set(-.64+.035*Math.sin(t*1.4+idx)*w,yaw,0,'YXZ');
          person.grasp('L',sheet,V(.102,0,.05),V(-1,0,0),w);
          person.grasp('R',sheet,V(-.102,0,.08),V(1,0,0),w);person.look(sheet.position,w);
        } else if(action==='usb' && usbs[role]){
          const u=usbs[role], yaw=person.g.rotation.y;
          u.visible=w>.04;
          u.position.copy(person.g.localToWorld(V(-14,(sat?98:116)-10*(1-w),38)));
          u.rotation.set(.12,yaw-.25,.08,'YXZ');
          person.reach('R',u.position.clone().add(V(0,-.01,0)),w,V(-.6,-.95,-.3));
          if(beat?.[3] && actors[beat[3]]) {
            const tp=actorPlaceAt(beat[3],t,curSetName);
            if(tp && places[tp]) person.look(V(places[tp][0],curSet.seated.has(tp)?1.18:1.5,places[tp][1]),.9*w);
          } else person.look(u.position,w);
        } else if(action==='tablet' && tablets[role]){
          const tab=tablets[role], yaw=person.g.rotation.y;
          tab.visible=w>.04;
          tab.position.copy(person.g.localToWorld(V(0,(sat?102:118)-12*(1-w),33)));
          tab.rotation.set(-.42+.03*Math.sin(t*1.4+idx)*w,yaw+Math.PI,0,'YXZ');
          person.reach('L',tab.localToWorld(V(-.13,-.02,0)),w,V(.6,-1,-.3));
          person.reach('R',tab.localToWorld(V(.13,-.02,0)),w,V(-.6,-1,-.3));
          person.look(tab.position,w);
        } else if(action==='idCard' && idCards[role]){
          const card=idCards[role], yaw=person.g.rotation.y;
          card.visible=w>.04;
          card.position.copy(person.g.localToWorld(V(-12,(sat?102:118)-10*(1-w),36)));
          card.rotation.set(-.22,yaw+Math.PI,.05,'YXZ');
          person.reach('R',card.localToWorld(V(.045,-.018,0)),w,V(-.6,-.95,-.3));
          if(beat?.[3] && actors[beat[3]]) {
            const tp=actorPlaceAt(beat[3],t,curSetName);
            if(tp && places[tp]) person.look(V(places[tp][0],curSet.seated.has(tp)?1.18:1.5,places[tp][1]),.9*w);
          } else person.look(card.position,w);
        } else if(['point','present','check','sign','file'].includes(action)){
          const target=(record ? record.position.clone() : V(0,1.0,0)).add(V(action==='sign' ? .15 : -.13,.04,0));
          if(curSetName==='hall') {
            if(action==='check') target.set(-2.13,1.39,.055);
            if(action==='point'||action==='present') target.set(-1.95,1.39,-.14);
          } else if(action==='point'||action==='present') {
            target.copy(curSet.pointTarget || target);
          }
          const gestEnd=(action==='point'||action==='present') ? Math.min(beat[1],beat[0]+2.6) : beat[1];
          const rw=beatW(t,beat[0],gestEnd,.4);
          if(action==='sign'){
            target.x+=.065*Math.sin((t-beat[0])*5);inkPen.visible=rw>.15;
            inkPen.rotation.set(.88,0,.22);inkPen.position.copy(target);inkPen.position.y+=.045;
          }
          person.look(target,w);
          if(rw>0) person.reach('R',target,.98*rw,V(-.65,-1,-.35));
        } else if(beat?.[3] && actors[beat[3]] && roleAllowedIn(beat[3],curSetName)){
          const targetPlace=actorPlaceAt(beat[3],t,curSetName) || basePlace(beat[3],curSetName);
          if(targetPlace && places[targetPlace]) {
            const [x,z]=places[targetPlace]; person.look(V(x,curSet.seated.has(targetPlace)?1.16:1.5,z),.92*w);
          }
        }
      }
      frameShots(stage,t,frames);
      updateProps?.(t);
    };
  };
}
