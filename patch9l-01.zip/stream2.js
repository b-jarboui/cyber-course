import { AR, tr } from './i18n.js';
import { THREE, createStage, createBuilding, createCounter } from './kit.js';
import { cached, loadCast } from './people.js';
import { createScreens, CSS } from './screens.js';
import { dressHall } from './made.js';

const arabicCues = {
  "2.01v": {"timing":[[0,8.46],[10.06,17.03],[18.28,23.43],[25.1,34.5],[36.14,47.45],[48.62,56.97],[58.27,66.18],[67.61,82.01],[82.71,89.06],[90.08,93.88],[94.84,99.67],[100.59,108.95],[109.93,113.86],[114.95,121.37],[122.07,127.58]],"T":128.22},
  "2.02v": {"timing":[[0,6.28],[7.57,12.19],[13.53,17.96],[19.31,26.04],[27.27,34.92],[36,43.4],[44.86,47.28],[48.46,52.15],[53.52,57.44],[58.98,63.89],[65.47,75.6],[76.85,83.64],[84.73,99.51],[100.83,103.94],[104.96,112.32]],"T":113.82},
  "2.03v": {"timing":[[0,5.16],[6.78,14.87],[16.5,22.99],[24.59,30.74],[32.37,42.64],[44.18,49.8],[51.09,56.88],[58.5,65.75],[67.1,70.31],[71.54,77.06],[78.51,84.89],[85.86,88.8],[90.08,100.92],[102.02,107.66],[108.6,116.06]],"T":117.65}
};

export async function mount({ DATA, order, label, continuePlaying }) {
  const $ = id => document.getElementById(id), pilot = window.__streamScene;
  const ac = new (window.AudioContext || window.webkitAudioContext)();
  const stage = createStage($('stage')), building = createBuilding(stage.scene);
  const target = new THREE.WebGLRenderTarget(8, 8);
  const scenes = new Map(), recordings = new Map();
  const tags = ['head','panel','screen','chips','cap'];
  const templates = tags.map(id => $(id).cloneNode(true));
  for (const id of [...tags, 'fade']) $(id).style.display = 'none';
  const style = document.createElement('style'); style.textContent = CSS; document.head.append(style);
  const wide = () => innerWidth > innerHeight * 1.1;
  const clamp = (x, max) => Math.max(0, Math.min(max, Number(x) || 0));
  const fmt = x => Math.floor(x / 60) + ':' + String(Math.floor(x % 60)).padStart(2,'0');
  const next = s => order[order.indexOf(s.id) + 1];
  let current, voice, queued, offset = 0, generation = 0, switching = false;
  let routed = '', lastSave = 0, lastDraw = -Infinity, dirty = true, failed = false, dragging = false, leaving = false;
  const now = () => ac.currentTime;
  const position = () => voice ? clamp(now() - voice.origin, current.audio.duration) : offset;
  const warn = e => { $('status').textContent = tr('Audio unavailable · Check your connection and press Play to retry'); console.error(e); };
  const resize = () => { document.body.classList.toggle('wide', wide()); dirty = true; };
  addEventListener('resize', resize); resize();
  const cabinet = dressHall(stage.scene).then(() => { dirty = true; });
  cabinet.catch(console.warn);

  function audio(id) {
    return cached(recordings, id, async () => {
      const r = await fetch('audio/' + (AR ? 'ar/' : '') + id + '.mp3');
      if (!r.ok) throw Error('Narration ' + id + ' HTTP ' + r.status);
      return ac.decodeAudioData(await r.arrayBuffer());
    });
  }
  function prepare(id, cast) {
    return cached(scenes, id + '/' + cast, async () => {
      const [mod, buffer] = await Promise.all([import('./s' + id + '.js').then(async m => {
        await loadCast(m.cast, cast); return m;
      }), audio(id)]);
      const D = AR ? {...DATA[id],...arabicCues[id]} : {...DATA[id], ...DATA[id].contexts?.[cast]};
      const host = document.createElement('div'), dom = host.attachShadow({mode:'open'});
      host.style.cssText = 'position:absolute;inset:0;pointer-events:none;opacity:0';
      host.inert = true; $('stage').after(host);
      try {
        const body = document.createElement('body'), view = document.createElement('div');
        body.classList.toggle('wide', wide()); body.style.background = 'transparent';
        view.id = 'view'; view.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;aspect-ratio:auto;transform:none;background:transparent';
        const base = document.createElement('div'); base.id = 'stage';
        view.append(base, ...templates.map(el => el.cloneNode(true))); body.append(view); dom.append(body);
        for (const el of document.querySelectorAll('style,link[href$="player-ar.css"]')) dom.insertBefore(el.cloneNode(true),body);
        const slot = {id,cast,D,host,dom,body,base,people:[],root:new THREE.Group(),audio:buffer,slide:0};
        slot.yieldFrame = () => new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve,0)));
        const cue = (i,k) => D.timing[Math.min(i,D.timing.length-1)][k];
        slot.update = await mod.default({stage,scene:slot.root,b:building,createCounter,slot,D,T:D.T,
          S:i=>cue(i,0), E:i=>cue(i,1), ui:createScreens(dom.getElementById('screen'))});
        if (!dom.getElementById('vl-library-style')) dom.insertBefore($('vl-library-style').cloneNode(true),body);
        dom.getElementById('title').textContent = D.title;
        dom.getElementById('kicker').textContent = label(id);
        await stage.renderer.compileAsync(slot.root, stage.camera, stage.scene);
        const old = current, previousTarget = stage.renderer.getRenderTarget();
        old?.root.removeFromParent(); stage.scene.add(slot.root);
        try {
          pose(slot, 0); stage.renderer.setRenderTarget(target); stage.render();
        } finally {
          stage.renderer.setRenderTarget(previousTarget); slot.root.removeFromParent();
          if (old) { stage.scene.add(old.root); pose(old,position(),false); }
        }
        return slot;
      } catch (e) { host.remove(); throw e; }
    });
  }
  function pose(s, x, smooth = false) {
    const t = Math.min(x, Math.max(0,s.D.T - 0.0001));
    s.body.classList.toggle('wide',wide()); s.update(t); s.people.forEach(p => p.flush());
    const page = s.body.classList.contains('vl-2d-active') ? 1 : 0;
    s.slide = smooth ? s.slide + (page-s.slide)*0.1 : page;
    const canvas = stage.renderer.domElement, w = canvas.clientWidth, h = canvas.clientHeight;
    if (wide() && s.slide > .002) stage.camera.setViewOffset(w,h,(AR?-1:1)*h*.5625*s.slide/2,0,w,h);
    else stage.camera.clearViewOffset();
    const i = s.D.timing.findLastIndex(row => t >= row[0] - .05);
    const text = s.D.phrases ? s.D.phrases.find(p=>t>=p[0] && t<p[1])?.[2] :
      i >= 0 && t < s.D.timing[i][1]+.3 ? s.D.sentences[i] : '';
    const cap = s.dom.getElementById('cap'), caption = (text || '').replace(/Sadeed|Sadid/g,'Sadeed');
    if (cap.textContent !== caption) cap.textContent = caption;
  }
  function save(push = false) {
    if (!current) return;
    const place = {id:current.id,t:Math.round(position()*100)/100,context:current.cast};
    window.__live = place;
    try { localStorage.setItem('chapter1-place',JSON.stringify(place)); } catch {}
    history[push ? 'pushState' : 'replaceState'](null,'','#'+place.id+'-'+place.t+'-'+place.context); routed=location.href;
  }
  function stopNode(v, when = now()) { if (v) { try { v.node.stop(when); } catch {} } }
  function source(s, x, at) {
    const node = ac.createBufferSource(); node.buffer = s.audio; node.connect(ac.destination);
    node.onended = () => node.disconnect(); node.start(at,x);
    return {node,origin:at-x,end:at-x+s.audio.duration};
  }
  function invalidate() {
    generation++; stopNode(queued?.v); queued = null; switching = false;
  }
  function pause() {
    invalidate(); offset = current ? position() : 0; stopNode(voice); voice = null;
    dirty = true; if (current) save();
  }
  function draw() {
    const x = position(); pose(current,x,!!voice); stage.render();
    $('time').textContent = fmt(x)+' / '+fmt(current.audio.duration); $('seek').value = x;
    $('seek').setAttribute('aria-valuetext',$('time').textContent);
    $('play').textContent = tr(voice ? 'Pause' : 'Play');
    $('play').setAttribute('aria-label',$('play').textContent);
    dirty = false;
  }
  function show(s, x, v, historyMode) {
    const old = current;
    if (old && old !== s) {
      const canvas = stage.renderer.domElement, still = document.createElement('canvas');
      still.width = canvas.width; still.height = canvas.height; still.style.cssText = 'width:100%;height:100%';
      still.getContext('2d').drawImage(canvas,0,0); old.base.replaceChildren(still);
      old.host.inert = true; old.host.style.zIndex = '2'; old.root.removeFromParent();
      const fade = old.host.animate([{opacity:1},{opacity:0}],{duration:150});
      fade.onfinish = () => { if (current !== old && old.fade === fade) {
        old.host.style.opacity = '0'; old.host.style.zIndex = ''; old.base.replaceChildren();
      } }; old.fade = fade;
    }
    current = s; offset = x; voice = v; failed = false; s.fade?.cancel();
    s.base.replaceChildren(); s.host.style.zIndex = '1'; s.host.style.opacity = '1'; s.host.inert = false;
    if (!s.root.parent) stage.scene.add(s.root);
    $('seek').max = s.audio.duration; $('scene').value = s.id; $('ctx').value = s.cast;
    $('status').textContent = label(s.id); window.__people = s.people;
    window.__scene = {T:s.D.T,set(t){pause(); offset=clamp(t,s.D.T); draw();}};
    draw(); save(historyMode === 'push');
    performance.mark('stream-frame-'+s.id);
  }
  function legacy(id, x, cast, play, mode) {
    leaving = true;
    const target = id+'-'+Math.round(x*100)/100+'-'+cast;
    try {sessionStorage.setItem('chapter1-navigation',JSON.stringify({target,play,at:Date.now()}));} catch {}
    if (mode !== 'none') history.pushState(null,'','#'+target);
    location.reload();
  }
  async function go(id, x, cast, mode = 'push', automatic = false) {
    if (!id || !order.includes(id)) return;
    if (!pilot(id)) { legacy(id,x,cast,!!voice,mode); return; }
    if (!automatic) { invalidate(); switching = true; }
    const token = generation, from = current;
    try {
      const s = await prepare(id,cast);
      if (token !== generation || from !== current) return;
      x = clamp(x,s.audio.duration);
      if (automatic) {
        if (!voice || switching || queued) return;
        const boundary = voice.end, at = Math.max(boundary,now());
        queued = {s,x,at,v:source(s,x,at),mode};
        performance.mark('stream-schedule-'+s.id,{detail:{boundary,at}});
      } else {
        switching = false; const at = now(), v = voice ? source(s,x,at) : null;
        if (mode === 'push') save();
        stopNode(voice,at); show(s,x,v,mode); warm();
      }
    } catch (e) { if (token === generation) { switching=false; failed=true; warn(e); } }
  }
  function warm() {
    const id = next(current);
    if (!pilot(id) || window.__recordingPreload) return;
    if (voice) void go(id,0,current.cast,'push',true);
    else prepare(id,current.cast).catch(e => console.warn('Next scene',e));
  }
  async function play() {
    invalidate(); const token = generation;
    try {
      await ac.resume(); if (token !== generation || document.hidden) return;
      if (offset >= current.audio.duration) {
        const id = next(current);
        if (!pilot(id)) { legacy(id,0,current.cast,true,'push'); return; }
        const s = await prepare(id,current.cast); if(token !== generation) return;
        show(s,0,null,'push');
      }
      if (pilot(next(current)) && current.audio.duration-offset < 2) await prepare(next(current),current.cast);
      if (token !== generation || document.hidden) return;
      voice = source(current,offset,now()); failed=false; dirty=true; warm();
    } catch (e) { warn(e); }
  }
  function frame(stamp) {
    if (queued && now() >= queued.at) {
      const q = queued; queued=null; generation++; show(q.s,q.x,q.v,q.mode); warm();
    } else if (voice && now() >= voice.end && !switching && !queued) {
      const id = next(current);
      if (!pilot(id)) { legacy(id,0,current.cast,true,'push'); return; }
      if (failed) { pause(); warn(Error('Next scene unavailable')); }
    }
    if (current && (dirty || voice && stamp-lastDraw >= (matchMedia('(pointer:coarse)').matches?1000/30:1000/60))) {
      draw(); lastDraw=stamp;
    }
    if (voice && !switching && stamp-lastSave >= 1000) { save(); lastSave=stamp; }
    requestAnimationFrame(frame);
  }
  const button = (id,text,arText,delta) => {
    const b=document.createElement('button'); b.id=id; b.textContent=delta<0?'◀':'▶';
    b.setAttribute('aria-label',AR?arText:text); b.title=b.getAttribute('aria-label');
    $('options').insertBefore(b,delta<0?$('scene'):$('ctx'));
    b.onclick=()=>go(order[order.indexOf(current.id)+delta],0,current.cast);
  };
  const init = window.__live;
  const first = await prepare(init.id,init.context);
  show(first,clamp(init.t,first.audio.duration),null,'replace'); window.__stage = stage;
  $('wait').style.display='none';
  for (const id of ['seek','play','back','fwd','scene','ctx','full']) $(id).disabled=false;
  button('prevScene','Previous scene','المشهد السابق',-1); button('nextScene','Next scene','المشهد التالي',1);
  $('scene').onchange=e=>go(e.target.value,0,current.cast);
  $('ctx').onchange=e=>go(current.id,position(),e.target.value);
  $('play').onclick=()=>voice?pause():play();
  function seek(x) { const resume=!!voice; pause(); offset=clamp(x,current.audio.duration); draw(); save(); if(resume) void play(); }
  $('back').onclick=()=>seek(position()-5); $('fwd').onclick=()=>seek(position()+5);
  let resumeDrag=false;
  $('seek').oninput=e=>{if(!dragging){resumeDrag=!!voice;pause();dragging=true;}offset=+e.target.value;draw();};
  $('seek').onchange=$('seek').onblur=$('seek').onpointercancel=()=>{if(dragging){dragging=false;save();if(resumeDrag)void play();}};
  const root=document.documentElement, full=root.requestFullscreen || root.webkitRequestFullscreen;
  if (!full) $('full').hidden=true;
  $('full').onclick=async()=>{try{if(document.fullscreenElement||document.webkitFullscreenElement)
    await (document.exitFullscreen||document.webkitExitFullscreen).call(document);else await full.call(root);}catch(e){console.warn(e);}};
  function route() {
    if (routed === location.href) return; routed = location.href;
    const m=/^#(\d+\.\d\dv)(?:-(\d+(?:\.\d+)?))?(?:-(arab|gulf))?$/.exec(location.hash);
    if(m && order.includes(m[1])) void go(m[1],Number(m[2]||0),m[3]||'arab','none');
  }
  addEventListener('popstate',route); addEventListener('hashchange',route);
  addEventListener('keydown',e=>{if(e.altKey||e.ctrlKey||e.metaKey||/^(INPUT|SELECT|BUTTON|TEXTAREA)$/.test(e.target.tagName))return;
    if(e.code==='Space'){e.preventDefault();$('play').click();}
    if(e.code==='ArrowLeft'||e.code==='ArrowRight'){e.preventDefault();$((e.code==='ArrowLeft')!==AR?'back':'fwd').click();}});
  document.addEventListener('visibilitychange',()=>{if(document.hidden && !leaving)pause();else dirty=true;});
  addEventListener('pagehide',()=>{if(!leaving)pause();}); window.__stop=pause;
  warm(); requestAnimationFrame(frame); if(continuePlaying && !document.hidden) void play();
}
