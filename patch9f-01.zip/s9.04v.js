// When the assistant follows the wrong instructions.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '9.1',
  actors: { maya: 'counter', citizen: 'visitor' },
  file: [[0, D.T, 1, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(3), 'counter'], [S(7), 'her'], [S(11), 'counterDisplay'], [S(13), 'her'], [S(14), 'counter'], [S(15), 'her']],
  actions: {
    maya: [[0, S(1), 'type'], [S(1), S(13), 'read'], [S(13), S(14), 'extension'], [S(14), S(15), 'talk', 'citizen'], [S(15), D.T, 'read']],
    citizen: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'computer', 'AI summary · Case 2048', 'neutral'],
      [S(1), S(11), 'mail', 'AI proposes outside send', 'alert'],
      [S(11), S(13), 'shield', 'Action stopped · Screenshot kept', 'safe'],
      [S(13), D.T, 'bell', 'AI incident reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'AI summary · Case 2048'],
    [S(1), E(1), 'Unasked outside send'],
    [S(11), E(11), 'Stopped · Screenshot saved'],
    [S(14), E(14), 'Short review before moving on'],
  ],
  screens: [
    [S(1), S(3), win('AI agent · Case 2048 summary', row('Recommendation', 'Approve immediately', 'warn') + row('Proposed send', 'Whole file → external address', 'no') + row('Destination', 'drop@outside-mail.example', 'no') + note('Neither action was requested.', 'no'), 'alert')],
    [S(13), S(14), win('AI incident report', row('Proposed action', 'Approve & send file outside', 'warn') + row('Action taken', 'Stopped · Not approved', 'ok') + row('Evidence', 'Screenshot & time recorded', 'ok') + row('Route', 'Approved security route', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(7), 'Hidden instructions can hide in documents', 'made/own_file+made/robot_arm', [
      ['Hidden prompts in files can steer AI tools', S(3), 'v-coral'],
      ['AI cannot reliably split rules from data', S(5), 'v-amber'],
    ]),
    hero(S(7), S(11), "Odd action → stop, don't approve", 'made/robot_arm+made/own_warning_beacon', [
      ['Watch for odd scope, access, speed or sends', S(7), 'v-amber'],
      ['Limit agent powers; keep people in control', S(9), 'v-teal'],
      ['13% of entities reported an AI breach', S(10), 'v-coral'],
    ]),
    hero(S(11), S(13), 'Stop, record, do not test the agent', 'made/own_computer+made/own_incident_binder', [
      ['Do not approve or send the proposed action', S(11), 'v-coral'],
      ['Do not probe the agent with new prompts', S(12), 'v-amber'],
    ]),
    hero(S(15), D.T, 'Report strange AI behavior like any incident', 'made/own_bell+made/robot_arm', [
      ['Record what the agent proposed and when', S(15), 'v-navy'],
      ['Report through the approved security route', (S(15) + E(15)) / 2, 'v-teal'],
    ]),
  ],
}));
