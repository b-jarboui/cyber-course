export default {
 "0.cast2": {
  "title": "Cast check",
  "texts": [],
  "sentences": [
   "Cast check."
  ],
  "timing": [
   [
    0.5,
    1.5
   ]
  ],
  "T": 3
 },
 "0.face": {
  "title": "Faces",
  "texts": [],
  "sentences": [
   "Faces."
  ],
  "timing": [
   [
    0.5,
    1.5
   ]
  ],
  "T": 3
 },
 "0.cast": {
  "title": "Cast check",
  "texts": [],
  "sentences": [
   "Cast check."
  ],
  "timing": [
   [
    0.5,
    1.5
   ]
  ],
  "T": 3
 },
 "1.01": {
  "title": "A service starts with trust",
  "texts": [
   "Cybersecurity in the Age of Artificial Intelligence",
   "Sadeed Service Authority",
   "Protect people. Protect public services."
  ],
  "sentences": [
   "Someone has submitted an application.",
   "They are waiting for a decision that matters to them.",
   "At the Sadeed Service Authority, Shaima opens the record and begins her work.",
   "For the applicant, this is a public service.",
   "For Shaima, it is a responsibility.",
   "Behind both are information, identities, software, suppliers, and decisions that need protection.",
   "Cybersecurity helps keep that service trustworthy and working.",
   "Sadeed and everyone you meet in this course are fictional.",
   "The situations reflect decisions that real public-sector staff may face.",
   "We will follow those decisions from the service counter into the systems behind it, including the growing role of artificial intelligence.",
   "Start with the person waiting for the service.",
   "That is who this protection is for."
  ],
  "timing": [
   [
    0.76,
    2.9
   ],
   [
    3.28,
    6.4
   ],
   [
    6.78,
    11.7
   ],
   [
    12.08,
    15.08
   ],
   [
    15.46,
    18.1
   ],
   [
    18.48,
    25.18
   ],
   [
    25.56,
    29.62
   ],
   [
    30,
    33.65
   ],
   [
    34.03,
    39.26
   ],
   [
    39.64,
    47.8
   ],
   [
    48.18,
    51.37
   ],
   [
    51.75,
    53.84
   ]
  ],
  "T": 55.22
 },
 "1.02": {
  "title": "What are we protecting?",
  "texts": [
   "Information assets",
   "Digital identities",
   "Critical dependencies"
  ],
  "sentences": [
   "What needs protection?",
   "An information asset is something valuable to the institution’s work.",
   "It can include an applicant's record, an employee file, a device, an application, or the systems that process and store information.",
   "Digital identities also matter.",
   "A person, a device, an application, or an AI agent may have an identity that a system uses when deciding whether to allow access.",
   "These services depend on other services.",
   "Identity checks, payment processing, communications, and electricity may be provided elsewhere.",
   "Some dependencies support critical infrastructure: systems whose disruption can seriously affect society.",
   "Sadeed does not operate every system in this model.",
   "It still needs to understand what it relies on.",
   "Protecting the counter means understanding the information, access, and infrastructure beneath it."
  ],
  "timing": [
   [
    0.76,
    2.63
   ],
   [
    3.01,
    7.71
   ],
   [
    8.09,
    16.66
   ],
   [
    17.04,
    19.37
   ],
   [
    19.75,
    29.09
   ],
   [
    29.47,
    31.97
   ],
   [
    32.35,
    39.38
   ],
   [
    39.76,
    46.34
   ],
   [
    46.72,
    49.98
   ],
   [
    50.36,
    53.26
   ],
   [
    53.64,
    59.81
   ]
  ],
  "T": 61.19
 },
 "1.03": {
  "title": "Three promises",
  "texts": [
   "Confidentiality — authorized access",
   "Integrity — protected from improper change",
   "Availability — usable when needed"
  ],
  "sentences": [
   "Cybersecurity protects three connected qualities.",
   "Confidentiality means information is available only to people and systems authorized to access it.",
   "An applicant’s private details should not become visible simply because someone has a link.",
   "Integrity means protecting information from unauthorized or improper change or destruction.",
   "A decision, payment detail, or supporting record must not be silently altered.",
   "Legitimate changes need appropriate control and accountability.",
   "Availability means authorized people and systems can use information and services when they need them.",
   "These qualities work together.",
   "A private record is not useful if the service cannot retrieve it.",
   "A service that is always online can still cause harm if its information is wrong.",
   "Even a public announcement needs integrity and availability.",
   "Ask three questions: who may see it, who may change it, and can the right people use it when needed?"
  ],
  "timing": [
   [
    0.76,
    4.62
   ],
   [
    5,
    11.91
   ],
   [
    12.29,
    17.93
   ],
   [
    18.31,
    24.45
   ],
   [
    24.83,
    30.33
   ],
   [
    30.71,
    35.49
   ],
   [
    35.87,
    42.47
   ],
   [
    42.85,
    44.72
   ],
   [
    45.1,
    49.47
   ],
   [
    49.85,
    55.27
   ],
   [
    55.65,
    59.49
   ],
   [
    59.87,
    66.88
   ]
  ],
  "T": 68.26
 },
 "1.04": {
  "title": "Six different words",
  "texts": [
   "Threat — potential cause of harm",
   "Vulnerability — a weakness",
   "Risk — likelihood and potential impact",
   "Incident — security compromised or threatened",
   "An alert needs assessment"
  ],
  "sentences": [
   "These words describe different things.",
   "A threat is a potential cause of harm.",
   "An unauthorized person seeking confidential information is one example.",
   "A vulnerability is a weakness that could allow harm.",
   "Here, a confidential folder has been shared too broadly.",
   "Risk considers how likely harmful circumstances are and how serious their consequences could be.",
   "The sensitivity of the records, the exposure, and existing protections all affect that judgment.",
   "An incident occurs when security is compromised, or threatened in a way that requires a response.",
   "In this example, evidence shows that an unauthorized person accessed the folder.",
   "An event is simply something that happened.",
   "An alert draws attention to something that needs assessment; it is not automatically proof of an incident.",
   "You do not have to settle the classification yourself.",
   "Report a reasonable concern through the approved route."
  ],
  "timing": [
   [
    0.76,
    3.16
   ],
   [
    3.54,
    5.89
   ],
   [
    6.27,
    11.12
   ],
   [
    11.5,
    15.22
   ],
   [
    15.6,
    19.18
   ],
   [
    19.56,
    25.3
   ],
   [
    25.68,
    32.47
   ],
   [
    32.85,
    39.16
   ],
   [
    39.54,
    44.99
   ],
   [
    45.37,
    47.99
   ],
   [
    48.37,
    55.04
   ],
   [
    55.42,
    58.42
   ],
   [
    58.8,
    62.26
   ]
  ],
  "T": 63.64
 },
 "1.05": {
  "title": "Where weaknesses live",
  "texts": [
   "People",
   "Technology",
   "Organization",
   "Make the safer action practical"
  ],
  "sentences": [
   "Weaknesses can appear in people’s decisions, in technology, and in the way an organization works.",
   "A person under pressure may accept an unusual request without checking it.",
   "A device may contain an unresolved software weakness.",
   "A process may leave nobody clearly responsible for approving a sensitive change.",
   "These weaknesses can reinforce each other.",
   "A warning is less useful when staff cannot understand it.",
   "A policy is less effective when the approved process is difficult to find or too slow to use.",
   "Effective protection combines training, usable processes, maintained technology, clear responsibilities, and enough support to act safely.",
   "Staff should follow the approved process and raise concerns.",
   "Managers should make that process workable.",
   "When something goes wrong, examine the conditions and controls as well as the individual action."
  ],
  "timing": [
   [
    0.76,
    7.05
   ],
   [
    7.43,
    12.85
   ],
   [
    13.23,
    17.12
   ],
   [
    17.5,
    23.55
   ],
   [
    23.93,
    26.64
   ],
   [
    27.02,
    31.15
   ],
   [
    31.53,
    37.75
   ],
   [
    38.13,
    48.21
   ],
   [
    48.59,
    52.55
   ],
   [
    52.93,
    55.88
   ],
   [
    56.26,
    62.31
   ]
  ],
  "T": 63.69
 },
 "1.06": {
  "title": "Protection has owners and layers",
  "texts": [
   "Clear ownership",
   "Defense in depth",
   "Prevent • Detect • Respond • Recover"
  ],
  "sentences": [
   "Cybersecurity is a shared institutional responsibility, with different duties for different roles.",
   "Leaders set direction, assign accountability, and provide resources.",
   "Service and information owners make decisions about their risks and requirements.",
   "Security and technology teams operate and improve protections.",
   "Privacy, procurement, and other functions contribute their expertise.",
   "Staff use approved tools, protect access and information, follow procedures, and report concerns promptly.",
   "Governance connects these responsibilities through policy, oversight, and decisions about risk.",
   "Defense in depth combines several protections.",
   "Access controls, maintained software, restricted connections, monitoring, and recovery capabilities address different ways harm can occur.",
   "A failure in one control should not leave the institution relying on nothing else.",
   "No single product or person can guarantee safety.",
   "The protections need clear owners, regular review, and practice working together."
  ],
  "timing": [
   [
    0.76,
    7.46
   ],
   [
    7.84,
    12.86
   ],
   [
    13.24,
    18.26
   ],
   [
    18.64,
    23.3
   ],
   [
    23.68,
    28.77
   ],
   [
    29.15,
    36.93
   ],
   [
    37.31,
    43.6
   ],
   [
    43.98,
    47.58
   ],
   [
    47.96,
    57.49
   ],
   [
    57.87,
    63.58
   ],
   [
    63.96,
    67.39
   ],
   [
    67.77,
    73.39
   ]
  ],
  "T": 74.77
 },
 "1.07": {
  "title": "Different actors, overlapping motives",
  "texts": [
   "Profit",
   "Intelligence",
   "Political disruption",
   "Motives and methods can overlap"
  ],
  "sentences": [
   "Public institutions face different kinds of hostile activity.",
   "Cybercriminals seek profit through fraud, stolen information, extortion, and other crimes.",
   "Organized networks may divide the work among different specialists.",
   "State-sponsored activity may seek sensitive information, strategic advantage, or disruption.",
   "Cyberespionage can remain hidden because the objective may be to collect information while systems continue operating.",
   "Hacktivists and other politically motivated actors may seek attention, disruption, or exposure of information.",
   "These categories overlap.",
   "A claimed political motive does not prove who is responsible, and similar methods can be used by very different actors.",
   "Employees should recognize suspicious activity and its possible impact.",
   "Identifying the actor is specialist work.",
   "For the institution, the practical question remains: which services and information could be harmed, and how do we protect them?"
  ],
  "timing": [
   [
    0.76,
    4.91
   ],
   [
    5.29,
    12.2
   ],
   [
    12.58,
    17
   ],
   [
    17.38,
    23.91
   ],
   [
    24.29,
    32.07
   ],
   [
    32.45,
    39.91
   ],
   [
    40.29,
    42.21
   ],
   [
    42.59,
    50.44
   ],
   [
    50.82,
    55.91
   ],
   [
    56.29,
    59.31
   ],
   [
    59.69,
    67.61
   ]
  ],
  "T": 68.99
 },
 "1.08": {
  "title": "Locked, copied, destroyed",
  "texts": [
   "Encryption can deny access",
   "Stolen data can enable extortion",
   "Destruction can prevent recovery",
   "Report. Follow the response plan."
  ],
  "sentences": [
   "Ransomware can make files or systems unusable, often through encryption, while criminals demand payment.",
   "An extortion incident may also involve stolen information.",
   "Criminals can threaten to publish it or use it to pressure the institution and the people affected.",
   "Data theft can occur with or without encryption.",
   "Destructive attacks aim to damage or erase information and systems.",
   "A demand for money does not guarantee that recovery is possible, and a working backup does not undo a disclosure.",
   "These examples show different kinds of harm.",
   "An incident may combine several of them.",
   "If you see a ransom demand, unexpected loss of access, or signs that information has been stolen, report it immediately through the approved route.",
   "Follow the response plan.",
   "Decisions about containment, recovery, external communication, and extortion demands belong to the authorized response structure."
  ],
  "timing": [
   [
    0.76,
    8.44
   ],
   [
    8.82,
    12.68
   ],
   [
    13.06,
    19.04
   ],
   [
    19.42,
    22.32
   ],
   [
    22.7,
    27.6
   ],
   [
    27.98,
    35.16
   ],
   [
    35.54,
    38.28
   ],
   [
    38.66,
    40.94
   ],
   [
    41.32,
    50.37
   ],
   [
    50.75,
    52.62
   ],
   [
    53,
    61.86
   ]
  ],
  "T": 63.24
 },
 "1.09": {
  "title": "A trusted account can be misused",
  "texts": [
   "A familiar account is not enough",
   "Verify unusual instructions",
   "Protect credentials and sessions"
  ],
  "sentences": [
   "An attacker may misuse an identity instead of visibly damaging a system.",
   "Identity theft involves using someone’s identity without authorization.",
   "Credential compromise can give an unauthorized person access to an account or help them impersonate its holder.",
   "A compromised account may send messages that appear to come from a trusted colleague or supplier.",
   "Here, Rania sees a request to change payment information.",
   "The account looks familiar.",
   "The instruction still needs the required verification and approval.",
   "Financial fraud may depend on one apparently small change: a payment destination, an administrative record, or an authorization.",
   "Protecting an account includes its passwords and other authenticators, its recovery process, and its signed-in sessions.",
   "When a request is unusual or sensitive, verify both who is asking and whether the action is permitted."
  ],
  "timing": [
   [
    0.76,
    6.11
   ],
   [
    6.49,
    11.84
   ],
   [
    12.22,
    18.77
   ],
   [
    19.15,
    24.98
   ],
   [
    25.36,
    29.15
   ],
   [
    29.53,
    31.4
   ],
   [
    31.78,
    36.22
   ],
   [
    36.6,
    45.48
   ],
   [
    45.86,
    53.95
   ],
   [
    54.33,
    61.48
   ]
  ],
  "T": 62.86
 },
 "1.10": {
  "title": "The weakness in the software",
  "texts": [
   "Software can contain vulnerabilities",
   "Apply approved updates",
   "Zero-day exploitation",
   "Keep other protections active"
  ],
  "sentences": [
   "Software can contain weaknesses in its design, code, or configuration.",
   "Suppliers and security teams identify many vulnerabilities and provide fixes or other protective measures.",
   "Delaying an approved update can leave a known weakness exposed.",
   "Zero-day exploitation takes advantage of a flaw before a security fix is available.",
   "The weakness may initially be unknown to the supplier or to defenders.",
   "This is one reason security cannot rely entirely on patching.",
   "Restricted access, monitoring, secure configuration, and response readiness also matter.",
   "Staff should use approved software, allow required updates, and report problems that prevent them from completing.",
   "Technical teams assess the risk and manage deployment safely, especially where an update could affect a critical service.",
   "Do not attempt an unofficial repair from an unexpected message or website.",
   "Use the institution’s established support process."
  ],
  "timing": [
   [
    0.76,
    5.87
   ],
   [
    6.25,
    14
   ],
   [
    14.38,
    18.53
   ],
   [
    18.91,
    25.03
   ],
   [
    25.41,
    30.14
   ],
   [
    30.52,
    34.94
   ],
   [
    35.32,
    41.85
   ],
   [
    42.23,
    48.76
   ],
   [
    49.14,
    56.65
   ],
   [
    57.03,
    61.95
   ],
   [
    62.33,
    65.91
   ]
  ],
  "T": 67.29
 },
 "1.11": {
  "title": "Trust arrives through other people",
  "texts": [
   "Supplier access needs controls",
   "Insider harm may be deliberate or accidental",
   "Access is limited to an authorized purpose"
  ],
  "sentences": [
   "Institutions rely on suppliers, contractors, software, and connected services.",
   "If one of those is compromised, the consequences may reach the institution through an update, a dependency, a service connection, or authorized access.",
   "This is a supply-chain risk.",
   "Trust in a supplier still needs defined responsibilities, appropriate access, monitoring, and review.",
   "Harm can also arise from inside the institution’s boundary.",
   "Someone may deliberately misuse legitimate access.",
   "An employee may also cause harm unintentionally, for example by sharing information with the wrong audience.",
   "These situations require different investigations, but both show why access should fit an authorized purpose.",
   "Report suspicious behavior or an accidental exposure through the approved route.",
   "Describe what you observed.",
   "Avoid unsupported accusations.",
   "Authorized teams need the facts to protect information and assess what happened."
  ],
  "timing": [
   [
    0.76,
    6.9
   ],
   [
    7.28,
    17.84
   ],
   [
    18.22,
    20.12
   ],
   [
    20.5,
    27.17
   ],
   [
    27.55,
    31.34
   ],
   [
    31.72,
    35.1
   ],
   [
    35.48,
    42.34
   ],
   [
    42.72,
    50.09
   ],
   [
    50.47,
    55.44
   ],
   [
    55.82,
    57.69
   ],
   [
    58.07,
    60.42
   ],
   [
    60.8,
    65.77
   ]
  ],
  "T": 67.15
 },
 "1.12": {
  "title": "When a digital problem becomes a public problem",
  "texts": [
   "Services depend on other services",
   "Digital disruption has human consequences",
   "Prepare safe alternatives"
  ],
  "sentences": [
   "A digital incident can become a public-service problem very quickly.",
   "If an identity service is unavailable, an applicant may be unable to complete an application.",
   "If a payment service is disrupted, money may not reach its intended recipient on time.",
   "A problem in a shared provider can affect several institutions at once.",
   "Attacks against essential services can have operational, financial, and societal consequences.",
   "Some can also affect safety.",
   "The impact depends on the service, its dependencies, the duration of disruption, and the alternatives available.",
   "That is why institutions identify critical services, prepare continuity arrangements, and test recovery.",
   "Staff contribute by protecting their part of the process, reporting early, and following approved alternative procedures.",
   "Return to the applicant at the counter.",
   "A system’s availability, integrity, and confidentiality all affect the service they receive."
  ],
  "timing": [
   [
    0.76,
    4.96
   ],
   [
    5.34,
    11.92
   ],
   [
    12.3,
    17.7
   ],
   [
    18.08,
    22.9
   ],
   [
    23.28,
    29.78
   ],
   [
    30.16,
    32.03
   ],
   [
    32.41,
    39.39
   ],
   [
    39.77,
    46.92
   ],
   [
    47.3,
    55.53
   ],
   [
    55.91,
    58.21
   ],
   [
    58.59,
    65
   ]
  ],
  "T": 66.38
 },
 "1.13": {
  "title": "AI makes deception more convincing",
  "texts": [
   "Personalized does not prove authentic",
   "AI can improve convincing deception",
   "Verify the request through a known route"
  ],
  "sentences": [
   "Artificial intelligence can help an attacker make sense of public information about an institution, its staff, and its activities.",
   "That can support reconnaissance: gathering information to understand possible targets.",
   "AI can also help identify relevant people and generate messages that fit their work, language, and circumstances.",
   "A phishing message may be polished, specific, and free of obvious mistakes.",
   "It may refer to a real project or imitate a familiar style.",
   "Those details can make a request feel credible.",
   "They do not establish who sent it or whether it is authorized.",
   "Here, Shaima recognizes the subject of the message.",
   "She still checks the unusual request through an established route.",
   "You do not need to prove that AI wrote a message before treating it cautiously.",
   "Focus on the requested action, the information involved, and the evidence of authority."
  ],
  "timing": [
   [
    0.76,
    9.16
   ],
   [
    9.54,
    14.94
   ],
   [
    15.32,
    22.95
   ],
   [
    23.33,
    28.54
   ],
   [
    28.92,
    33.58
   ],
   [
    33.96,
    37.13
   ],
   [
    37.51,
    41.09
   ],
   [
    41.47,
    45.02
   ],
   [
    45.4,
    49.43
   ],
   [
    49.81,
    54.47
   ],
   [
    54.85,
    60.08
   ]
  ],
  "T": 61.46
 },
 "1.14": {
  "title": "AI increases operational speed",
  "texts": [
   "AI can accelerate parts of cyber operations",
   "Human-directed • Supervised • More autonomous",
   "Capability and reliability vary"
  ],
  "sentences": [
   "AI can also assist more technical parts of hostile activity.",
   "It can help analyze software weaknesses, support attempts to exploit them, and generate or modify malicious code.",
   "Automation can help coordinate repeated tasks and increase the speed or scale of an operation.",
   "In a semi-autonomous process, people still direct or approve important parts of the work.",
   "A more autonomous system can select and carry out more actions within the goals and capabilities delegated to it.",
   "These capabilities vary.",
   "Generated code can fail, conclusions can be wrong, and human operators often remain important.",
   "Claims that an attack was fully autonomous need evidence.",
   "For defenders, the practical implication is pressure to maintain protections and respond promptly.",
   "Restrict unnecessary access, keep approved systems maintained, and escalate concerns.",
   "Do not assume that either a dramatic claim or a reassuring label tells the whole story."
  ],
  "timing": [
   [
    0.76,
    4.98
   ],
   [
    5.36,
    12.58
   ],
   [
    12.96,
    19.3
   ],
   [
    19.68,
    25.97
   ],
   [
    26.35,
    33.45
   ],
   [
    33.83,
    35.61
   ],
   [
    35.99,
    42.45
   ],
   [
    42.83,
    46.67
   ],
   [
    47.05,
    53.87
   ],
   [
    54.25,
    60.75
   ],
   [
    61.13,
    66.31
   ]
  ],
  "T": 67.69
 },
 "1.15": {
  "title": "AI can help the defenders",
  "texts": [
   "AI can connect observations",
   "An alert is a lead",
   "Check evidence and consequences",
   "Keep oversight and control"
  ],
  "sentences": [
   "AI can help defenders work with large amounts of security information.",
   "It can connect observations across accounts, devices, cloud services, and applications, and highlight patterns that deserve attention.",
   "It can also help summarize an incident or suggest priorities for review.",
   "But a convincing explanation is not the same as verified evidence.",
   "AI may mistake normal behavior for a threat, miss an important event, or produce an incorrect analysis.",
   "Poorly controlled automation can also interrupt legitimate work or take actions beyond what was intended.",
   "Here, Omar checks the underlying observations before approving a significant response.",
   "Effective defensive use needs suitable information, evaluation, monitoring, clear permissions, and human oversight.",
   "Your role remains important.",
   "An early report from a person who notices something unusual can provide context that automated monitoring does not have."
  ],
  "timing": [
   [
    0.76,
    5.3
   ],
   [
    5.68,
    14.25
   ],
   [
    14.63,
    18.81
   ],
   [
    19.19,
    24.13
   ],
   [
    24.51,
    31.64
   ],
   [
    32.02,
    38.43
   ],
   [
    38.81,
    45.03
   ],
   [
    45.41,
    53.71
   ],
   [
    54.09,
    55.96
   ],
   [
    56.34,
    64.07
   ]
  ],
  "T": 65.45
 },
 "1.16": {
  "title": "The first decision",
  "texts": [],
  "sentences": [
   "Shaima receives an urgent request to use a new AI service with applicant records.",
   "The message claims that the director has approved it.",
   "The request looks professional and refers to real work.",
   "Think about what matters here.",
   "The information may be sensitive.",
   "The tool’s approval and permitted use have not been established.",
   "The message’s claim of authority has not been independently verified.",
   "What should Shaima do?",
   "Upload immediately, reply to confirm, or verify through approved channels?",
   "Shaima should verify through approved channels.",
   "That means checking the request independently, establishing that the tool and the proposed use are permitted, and reporting the unusual request through the known security reporting route.",
   "The records remain in the approved environment while those checks happen.",
   "Cybersecurity protects confidentiality, integrity, and availability so that public services remain trustworthy.",
   "AI can change the speed and appearance of a threat.",
   "Clear responsibilities, layered protection, careful verification, and early reporting remain essential.",
   "In the next chapter, we follow a convincing request across email, websites, telephone calls, and workplace messages."
  ],
  "timing": [
   [
    0.76,
    6.59
   ],
   [
    6.97,
    9.83
   ],
   [
    10.21,
    13.88
   ],
   [
    14.26,
    16.13
   ],
   [
    16.51,
    19.1
   ],
   [
    19.48,
    23.7
   ],
   [
    24.08,
    28.54
   ],
   [
    28.92,
    30.79
   ],
   [
    31.17,
    37.07
   ],
   [
    37.45,
    40.83
   ],
   [
    41.21,
    52.03
   ],
   [
    52.41,
    56.35
   ],
   [
    56.73,
    64.84
   ],
   [
    65.22,
    68.53
   ],
   [
    68.91,
    76.04
   ],
   [
    76.42,
    84.48
   ]
  ],
  "T": 85.86
 },
 "1.04s": {
  "title": "Threat, vulnerability, risk",
  "texts": [],
  "sentences": [
   "These words describe different things.",
   "A threat is a potential cause of harm.",
   "An unauthorized person seeking confidential information is one example.",
   "A vulnerability is a weakness that could allow harm.",
   "Here, a confidential folder has been shared too broadly.",
   "Risk considers how likely harmful circumstances are and how serious their consequences could be.",
   "The sensitivity of the records, the exposure, and existing protections all affect that judgment.",
   "The folder is open to 340 people, but nobody has misused it yet. Is this a threat, a vulnerability, or an incident?",
   "It is a vulnerability. The weakness is there, even though no harm has happened yet."
  ],
  "timing": [
   [
    0.8,
    3.2
   ],
   [
    4.2,
    6.55
   ],
   [
    7.05,
    11.9
   ],
   [
    13.4,
    17.12
   ],
   [
    18.02,
    21.6
   ],
   [
    23.1,
    28.83
   ],
   [
    29.73,
    36.52
   ],
   [
    38.12,
    46.98
   ],
   [
    50.48,
    55.54
   ]
  ],
  "T": 56.74
 },
 "1.04v": {
  "title": "Threat, vulnerability, risk",
  "texts": [],
  "sentences": [
   "At the fictional Sadeed Service Authority, Shaima is working on this applicant’s record.",
   "She notices the sharing setting.",
   "Only five caseworkers are permitted to use this record.",
   "The setting gives all 340 staff accounts access.",
   "That excessive permission is a vulnerability: a weakness that could allow harm.",
   "A threat is a potential cause of harm.",
   "Here, someone could deliberately misuse access, or a colleague could accidentally share private details.",
   "A threat can come from inside the authority.",
   "Risk considers how likely a harmful event is, and how serious its consequences could be; weaknesses make harm more likely.",
   "Broad permissions create more opportunities for someone outside the case team to see the record.",
   "The record contains identity and contact details.",
   "Disclosure could expose the applicant to fraud or unwanted contact.",
   "These possible consequences matter when judging risk.",
   "Shaima reports the sharing problem through Sadeed’s approved reporting route.",
   "She describes the setting she found, without accusing anyone.",
   "She does not need proof of misuse before reporting.",
   "Excessive access is a weakness, and it may also be an incident if someone used it without authorization.",
   "The responsible team assesses what happened and what response is needed.",
   "Omar receives her report and starts checking the permissions.",
   "Receiving a report does not mean the problem is fixed.",
   "If access is restricted to the five permitted caseworkers, that reduces opportunities for unauthorized access.",
   "It does not make the record less sensitive, undo any earlier exposure, or remove the need to assess what happened."
  ],
  "timing": [
   [
    0.8,
    5.858
   ],
   [
    6.178,
    8.626
   ],
   [
    8.946,
    12.904
   ],
   [
    13.224,
    18.072
   ],
   [
    18.392,
    24.328
   ],
   [
    24.648,
    27.979
   ],
   [
    28.299,
    35.266
   ],
   [
    35.586,
    39.445
   ],
   [
    39.765,
    47.565
   ],
   [
    47.885,
    53.874
   ],
   [
    54.194,
    58.582
   ],
   [
    58.902,
    64.024
   ],
   [
    64.344,
    68.836
   ],
   [
    69.156,
    74.434
   ],
   [
    74.754,
    80.327
   ],
   [
    80.647,
    85.072
   ],
   [
    85.392,
    92.038
   ],
   [
    92.358,
    96.703
   ],
   [
    97.023,
    100.659
   ],
   [
    100.979,
    104.546
   ],
   [
    104.866,
    112.451
   ],
   [
    112.771,
    120.569
   ]
  ],
  "T": 121.89
 },
 "1.01v": {
  "title": "A service starts with trust",
  "texts": [],
  "sentences": [
   "Someone has submitted an application.",
   "They are waiting for a decision that matters to them.",
   "At Sadeed Service Authority, Shaima opens Case 2048 and begins her work.",
   "Sadeed and everyone you meet in this course are fictional.",
   "Cybersecurity helps keep public services trustworthy and working.",
   "An information asset is something valuable to the institution’s work.",
   "Case 2048 is one example.",
   "Assets also include employee files, devices, applications, and the systems that process and store information.",
   "Each supports work that people rely on.",
   "A digital identity represents a person, device, application, or AI agent—software that carries out tasks on its own—in a digital system.",
   "Authentication checks that someone can prove control of the sign-in method linked to that identity; it does not prove they are its rightful owner.",
   "Authorization is a separate decision: even a checked identity needs permission to open Case 2048.",
   "The service that verifies the applicant’s identity has stopped responding.",
   "The applicant’s case has to wait.",
   "Public services rely on other services, called dependencies.",
   "Sadeed relies on identity checks, payment processing, communications and electricity.",
   "Some are provided by other organizations.",
   "Sadeed does not operate every system, but still needs to understand what it relies on.",
   "Some dependencies support critical infrastructure: essential assets, systems and services whose disruption could seriously affect society.",
   "Electricity, for example, supports many essential services at once.",
   "Confidentiality means preventing information from being disclosed to people or systems that are not authorized to receive it.",
   "Case 2048 contains private identity and contact details.",
   "Having a link does not give someone permission to see them.",
   "Sending them to the wrong person would break confidentiality.",
   "The service that verifies the applicant’s identity is working again.",
   "Shaima finds a wrong decision in Case 2048 and checks the approved decision before correcting it.",
   "Integrity means protecting information from unauthorized or improper change or destruction.",
   "An unapproved change from Approved to Refused could give this applicant a wrong decision.",
   "Legitimate corrections need the right checks and a record of who changed what.",
   "Shaima saves the checked correction.",
   "Availability means authorized people and systems can use information and services when they need them.",
   "Earlier, Shaima had access to Case 2048, but the applicant’s identity could not be verified.",
   "That dependency delayed the service.",
   "Even a public announcement needs integrity and availability.",
   "The public needs the correct opening hours, available when they need them.",
   "These protections work together.",
   "A private record is not useful if the service cannot retrieve it.",
   "A service that is always online can still cause harm if its information is wrong."
  ],
  "timing": [
   [
    1.0,
    3.131
   ],
   [
    3.451,
    6.729
   ],
   [
    7.049,
    13.487
   ],
   [
    13.807,
    18.687
   ],
   [
    19.007,
    25.063
   ],
   [
    25.383,
    31.071
   ],
   [
    31.391,
    34.412
   ],
   [
    34.732,
    42.346
   ],
   [
    42.666,
    46.53
   ],
   [
    46.85,
    57.338
   ],
   [
    57.658,
    65.53
   ],
   [
    65.85,
    73.242
   ],
   [
    73.562,
    77.841
   ],
   [
    78.161,
    80.995
   ],
   [
    81.314,
    86.247
   ],
   [
    86.567,
    92.53
   ],
   [
    92.85,
    95.457
   ],
   [
    95.777,
    101.706
   ],
   [
    102.026,
    111.316
   ],
   [
    111.636,
    116.896
   ],
   [
    117.216,
    124.861
   ],
   [
    125.181,
    130.288
   ],
   [
    130.608,
    133.87
   ],
   [
    134.19,
    138.635
   ],
   [
    138.955,
    144.285
   ],
   [
    144.605,
    151.622
   ],
   [
    151.942,
    158.089
   ],
   [
    158.409,
    163.944
   ],
   [
    164.264,
    169.299
   ],
   [
    169.619,
    172.716
   ],
   [
    173.036,
    180.33
   ],
   [
    180.65,
    188.223
   ],
   [
    188.543,
    192.583
   ],
   [
    192.903,
    198.252
   ],
   [
    198.572,
    204.073
   ],
   [
    204.393,
    207.458
   ],
   [
    207.778,
    212.547
   ],
   [
    212.867,
    218.525
   ]
  ],
  "T": 221.12
 },
 "1.05v": {
  "title": "Where weaknesses live",
  "texts": [],
  "sentences": [
   "Weaknesses can appear in people’s decisions, in technology, and in the way an organization works.",
   "A person under pressure may accept an unusual request without checking it.",
   "A device may contain an unresolved software weakness.",
   "A process may leave nobody clearly responsible for approving a sensitive change.",
   "These weaknesses can reinforce each other.",
   "A warning is less useful when staff cannot understand it.",
   "A policy is less effective when the approved process is difficult to find or too slow to use.",
   "Effective protection needs several things together: clear training, practical processes, maintained technology, named responsibilities, and enough support to act safely.",
   "Staff should follow the approved process and raise concerns.",
   "Managers should make that process workable.",
   "When something goes wrong, examine the conditions and controls as well as the individual action."
  ],
  "timing": [
   [
    0.76,
    7.05
   ],
   [
    7.43,
    12.85
   ],
   [
    13.23,
    17.12
   ],
   [
    17.5,
    23.55
   ],
   [
    23.93,
    26.64
   ],
   [
    27.02,
    31.15
   ],
   [
    31.53,
    37.75
   ],
   [
    38.13,
    49.79
   ],
   [
    50.11,
    54.07
   ],
   [
    54.39,
    57.34
   ],
   [
    57.66,
    63.71
   ]
  ],
  "T": 65.03
 },
 "1.06v": {
  "title": "Protection has owners and layers",
  "texts": [],
  "sentences": [
   "Cybersecurity is a shared institutional responsibility, with different duties for different roles.",
   "Leaders set direction, assign accountability, and provide resources.",
   "Service and information owners make decisions about their risks and requirements.",
   "Security and technology teams operate and improve protections.",
   "Privacy, procurement, and other functions contribute their expertise.",
   "Staff use approved tools, protect access and information, follow procedures, and report concerns promptly.",
   "Governance is how the institution sets policy, assigns responsibility, oversees the work, and makes decisions about risk.",
   "Defense in depth combines several layers of protection.",
   "Access controls, maintained software, restricted connections, monitoring, and recovery capabilities address different ways harm can occur.",
   "A failure in one control should not leave the institution relying on nothing else.",
   "No single product or person can guarantee safety.",
   "The protections need clear owners, regular review, and practice working together."
  ],
  "timing": [
   [
    0.76,
    7.365
   ],
   [
    7.685,
    12.764
   ],
   [
    13.084,
    18.153
   ],
   [
    18.473,
    23.218
   ],
   [
    23.537,
    28.664
   ],
   [
    28.984,
    36.821
   ],
   [
    37.141,
    45.81
   ],
   [
    46.13,
    49.85
   ],
   [
    50.17,
    59.686
   ],
   [
    60.006,
    65.726
   ],
   [
    66.046,
    69.486
   ],
   [
    69.806,
    75.522
   ]
  ],
  "T": 76.84
 },
 "1.07v": {
  "title": "Different actors, overlapping motives",
  "texts": [],
  "sentences": [
   "Public institutions face different kinds of hostile activity.",
   "Cybercriminals seek profit through fraud, stolen information, extortion, and other crimes.",
   "Organized networks may divide the work among different specialists.",
   "State-sponsored activity may seek sensitive information, strategic advantage, or disruption.",
   "Espionage may remain hidden, because the objective is to collect information while systems continue operating.",
   "Hacktivists and other politically motivated actors may seek attention, disruption, or exposure of information.",
   "These categories overlap.",
   "A claimed political motive does not prove who is responsible, and similar methods can be used by very different actors.",
   "Employees should recognize suspicious activity and its possible impact.",
   "Identifying who is responsible, called attribution, is specialist work.",
   "For the institution, the practical question remains: which services and information could be harmed, and how do we protect them?"
  ],
  "timing": [
   [
    0.76,
    4.91
   ],
   [
    5.29,
    12.2
   ],
   [
    12.58,
    17.0
   ],
   [
    17.38,
    23.91
   ],
   [
    24.29,
    31.39
   ],
   [
    32.45,
    39.91
   ],
   [
    40.29,
    42.21
   ],
   [
    42.59,
    50.44
   ],
   [
    50.82,
    55.91
   ],
   [
    56.29,
    61.59
   ],
   [
    61.91,
    69.83
   ]
  ],
  "T": 71.15
 },
 "1.08v": {
  "title": "Locked, copied, destroyed",
  "texts": [],
  "sentences": [
   "Ransomware can make files or systems unusable, often by encrypting them—scrambling them so they cannot be opened—while criminals demand payment.",
   "An extortion incident may also involve stolen information.",
   "Criminals can threaten to publish it or use it to pressure the institution and the people affected.",
   "Data theft can occur with or without encryption.",
   "Destructive attacks aim to damage or erase information and systems.",
   "Paying does not guarantee recovery, and restoring from a backup does not undo the theft or disclosure of information.",
   "These examples show different kinds of harm.",
   "An incident may combine several of them.",
   "If you see a ransom demand, unexpected loss of access, or signs that information has been stolen, report it immediately through the approved route.",
   "Follow the response plan.",
   "The authorized incident response team coordinates containment and recovery; decisions on external communication and any extortion demand involve leadership and the other responsible authorities under the response plan."
  ],
  "timing": [
   [
    0.76,
    10.904
   ],
   [
    11.224,
    15.15
   ],
   [
    15.47,
    21.509
   ],
   [
    21.829,
    24.814
   ],
   [
    25.134,
    30.073
   ],
   [
    30.393,
    38.337
   ],
   [
    38.657,
    41.4
   ],
   [
    41.72,
    43.995
   ],
   [
    44.315,
    53.38
   ],
   [
    53.7,
    55.438
   ],
   [
    55.758,
    69.766
   ]
  ],
  "T": 71.22
 },
 "1.09v": {
  "title": "A trusted account can be misused",
  "texts": [],
  "sentences": [
   "An attacker may misuse an identity instead of visibly damaging a system.",
   "Identity theft or misuse means obtaining or using another person's identity information without authorization.",
   "Stolen or exposed sign-in details can give an unauthorized person access to an account or help them impersonate its holder.",
   "A compromised account may send messages that appear to come from a trusted colleague or supplier.",
   "Here, Rania sees a request to change payment information.",
   "The account looks familiar.",
   "The instruction still needs the required verification and approval.",
   "Financial fraud may depend on one apparently small change: a payment destination, an administrative record, or an authorization.",
   "Protecting an account includes its password and other sign-in methods, its recovery process, and its active sessions—the devices where it is already signed in.",
   "When a request is unusual or sensitive, verify both who is asking and whether the action is permitted."
  ],
  "timing": [
   [
    0.76,
    6.045
   ],
   [
    6.365,
    14.181
   ],
   [
    14.501,
    22.133
   ],
   [
    22.453,
    28.299
   ],
   [
    28.619,
    32.423
   ],
   [
    32.743,
    34.508
   ],
   [
    34.828,
    39.359
   ],
   [
    39.679,
    48.581
   ],
   [
    48.901,
    58.741
   ],
   [
    59.061,
    66.324
   ]
  ],
  "T": 67.64
 },
 "1.10v": {
  "title": "The weakness in the software",
  "texts": [],
  "sentences": [
   "Software can contain weaknesses in its design, code, or configuration.",
   "Suppliers and security teams identify many vulnerabilities and provide fixes or other protective measures.",
   "Delaying an approved update can leave a known weakness exposed.",
   "A zero-day attack exploits a flaw that was previously unknown, before the supplier has had a chance to prepare a fix.",
   "At that point, an effective security fix may not yet be available.",
   "This is one reason security cannot rely entirely on software updates and fixes.",
   "Limiting access, monitoring systems, using secure settings, and being ready to respond also matter.",
   "Staff should use approved software, follow the institution's update process, never install updates offered by unexpected messages or websites, and report any update that fails.",
   "Technical teams assess the risk and manage deployment safely, especially where an update could affect a critical service.",
   "Do not attempt an unofficial repair from an unexpected message or website.",
   "Use the institution’s established support process."
  ],
  "timing": [
   [
    0.76,
    5.807
   ],
   [
    6.127,
    13.933
   ],
   [
    14.253,
    18.462
   ],
   [
    18.782,
    26.27
   ],
   [
    26.59,
    31.477
   ],
   [
    31.797,
    37.629
   ],
   [
    37.949,
    44.951
   ],
   [
    45.271,
    56.767
   ],
   [
    57.087,
    64.597
   ],
   [
    64.917,
    69.828
   ],
   [
    70.148,
    73.839
   ]
  ],
  "T": 75.16
 },
 "1.11v": {
  "title": "Trust arrives through other people",
  "texts": [],
  "sentences": [
   "Institutions rely on suppliers, contractors, software, and connected services.",
   "If one of those is compromised, the consequences may reach the institution through an update, a dependency, a service connection, or authorized access.",
   "This is a supply-chain risk.",
   "Trust in a supplier still needs defined responsibilities, appropriate access, monitoring, and review.",
   "Harm can also begin inside the institution.",
   "Someone may deliberately misuse legitimate access.",
   "An employee may also cause harm unintentionally, for example by sharing information with the wrong audience.",
   "These situations require different investigations, but both show why access should fit an authorized purpose.",
   "Report suspicious behavior or an accidental exposure through the approved route.",
   "Describe what you observed.",
   "Avoid unsupported accusations.",
   "Authorized teams need the facts to protect information and assess what happened."
  ],
  "timing": [
   [
    0.76,
    6.9
   ],
   [
    7.28,
    17.84
   ],
   [
    18.22,
    20.12
   ],
   [
    20.5,
    27.17
   ],
   [
    27.55,
    30.41
   ],
   [
    31.72,
    35.1
   ],
   [
    35.48,
    42.34
   ],
   [
    42.72,
    50.09
   ],
   [
    50.47,
    55.44
   ],
   [
    55.82,
    57.69
   ],
   [
    58.07,
    60.42
   ],
   [
    60.8,
    65.77
   ]
  ],
  "T": 67.15
 },
 "1.12v": {
  "title": "When a digital problem becomes a public problem",
  "texts": [],
  "sentences": [
   "A digital incident can become a public-service problem very quickly.",
   "If an identity service is unavailable, an applicant may be unable to complete an application.",
   "If a payment service is disrupted, money may not reach its intended recipient on time.",
   "A problem in a shared provider can affect several institutions at once.",
   "Attacks against essential services can have operational, financial, and societal consequences.",
   "Some can also affect safety.",
   "The impact depends on the service, its dependencies, the duration of disruption, and the alternatives available.",
   "That is why institutions identify critical services, prepare safe ways to keep essential work going, and test recovery.",
   "Staff contribute by protecting their part of the process, reporting early, and following approved alternative procedures.",
   "Return to the applicant at the counter.",
   "A system’s availability, integrity, and confidentiality all affect the service they receive."
  ],
  "timing": [
   [
    0.76,
    4.96
   ],
   [
    5.34,
    11.92
   ],
   [
    12.3,
    17.7
   ],
   [
    18.08,
    22.9
   ],
   [
    23.28,
    29.78
   ],
   [
    30.16,
    32.03
   ],
   [
    32.41,
    39.39
   ],
   [
    39.77,
    48.24
   ],
   [
    48.56,
    56.79
   ],
   [
    57.11,
    59.41
   ],
   [
    59.73,
    66.14
   ]
  ],
  "T": 67.46
 },
 "1.13v": {
  "title": "AI makes deception more convincing",
  "texts": [],
  "sentences": [
   "An attacker can use AI tools to analyze public information about an institution, its staff, and its activities.",
   "This information gathering is called reconnaissance: it helps an attacker understand possible targets.",
   "AI can also help identify relevant people and generate messages that fit their work, language, and circumstances.",
   "A phishing message—a deceptive message designed to trick you into acting—may be polished, specific, and free of obvious mistakes.",
   "It may refer to a real project or imitate a familiar style.",
   "Those details can make a request feel credible.",
   "They do not establish who sent it or whether it is authorized.",
   "Here, Shaima recognizes the subject of the message.",
   "She still checks the unusual request through an established route.",
   "You do not need to prove that AI wrote a message before treating it cautiously.",
   "Focus on the requested action, the information involved, and the evidence of authority."
  ],
  "timing": [
   [
    0.76,
    8.678
   ],
   [
    8.998,
    15.538
   ],
   [
    15.857,
    23.475
   ],
   [
    23.795,
    32.459
   ],
   [
    32.779,
    37.425
   ],
   [
    37.745,
    40.921
   ],
   [
    41.241,
    44.839
   ],
   [
    45.159,
    48.703
   ],
   [
    49.023,
    53.034
   ],
   [
    53.354,
    58.045
   ],
   [
    58.365,
    63.678
   ]
  ],
  "T": 65.0
 },
 "1.14v": {
  "title": "AI increases operational speed",
  "texts": [],
  "sentences": [
   "AI can also assist more technical parts of hostile activity.",
   "It can help analyze software weaknesses, support attempts to exploit them, and generate or modify malicious code.",
   "Automation can help coordinate repeated tasks and increase the speed or scale of an operation.",
   "In a semi-autonomous process, people may set goals, direct the work, or approve selected actions; the level of human oversight varies.",
   "A more autonomous system is allowed to choose and carry out more actions, within the limits, access and goals given to it.",
   "These capabilities vary.",
   "Generated code can fail, conclusions can be wrong, and human operators often remain important.",
   "Claims that an attack was fully autonomous need evidence.",
   "For defenders, the practical implication is pressure to maintain protections and respond promptly.",
   "Restrict unnecessary access, keep approved systems maintained, and escalate concerns.",
   "Do not assume that either a dramatic claim or a reassuring label tells the whole story."
  ],
  "timing": [
   [
    0.76,
    4.908
   ],
   [
    5.228,
    12.514
   ],
   [
    12.834,
    19.23
   ],
   [
    19.55,
    29.102
   ],
   [
    29.422,
    37.794
   ],
   [
    38.114,
    39.96
   ],
   [
    40.28,
    46.757
   ],
   [
    47.077,
    50.942
   ],
   [
    51.262,
    58.044
   ],
   [
    58.364,
    64.876
   ],
   [
    65.196,
    70.491
   ]
  ],
  "T": 71.81
 },
 "1.15v": {
  "title": "AI can help the defenders",
  "texts": [],
  "sentences": [
   "AI can help defenders work with large amounts of security information.",
   "It can connect observations from accounts, devices, cloud services and applications, then highlight patterns that need attention.",
   "It can also help summarize an incident or suggest priorities for review.",
   "But a convincing explanation is not the same as verified evidence.",
   "AI may mistake normal behavior for a threat, miss an important event, or produce an incorrect analysis.",
   "Poorly controlled automation can also interrupt legitimate work or take actions beyond what was intended.",
   "Here, Omar checks the underlying observations before approving a significant response.",
   "Effective defensive use needs suitable information, evaluation, monitoring, clear permissions, and human oversight.",
   "Your role remains important.",
   "An early report from a person who notices something unusual can provide context that automated monitoring does not have."
  ],
  "timing": [
   [
    0.76,
    5.3
   ],
   [
    5.68,
    13.72
   ],
   [
    14.63,
    18.81
   ],
   [
    19.19,
    24.13
   ],
   [
    24.51,
    31.64
   ],
   [
    32.02,
    38.43
   ],
   [
    38.81,
    45.03
   ],
   [
    45.41,
    53.71
   ],
   [
    54.09,
    55.96
   ],
   [
    56.34,
    64.07
   ]
  ],
  "T": 65.45
 },
 "1.16v": {
  "title": "The first decision",
  "texts": [],
  "sentences": [
   "Shaima receives an urgent request to use a new AI service with applicant records.",
   "The message claims that the director has approved it.",
   "The request looks professional and refers to real work.",
   "Think about what matters here.",
   "The information may be sensitive.",
   "The tool’s approval and permitted use have not been established.",
   "The message's claim that the director approved the request has not been independently verified.",
   "What should Shaima do?",
   "Upload immediately, reply to confirm, or verify through approved channels?",
   "Shaima should verify through approved channels.",
   "That means checking the director's approval independently, confirming that the tool is approved and that its use is permitted, and reporting the unusual request through the approved reporting route.",
   "The records remain in the approved environment while those checks happen.",
   "Cybersecurity protects confidentiality, integrity, and availability so that public services remain trustworthy.",
   "AI can change the speed and appearance of a threat.",
   "Clear responsibilities, layered protection, careful verification, and early reporting remain essential.",
   "In the next chapter, we follow a convincing request across email, websites, telephone calls, and workplace messages."
  ],
  "timing": [
   [
    0.76,
    6.493
   ],
   [
    6.873,
    9.699
   ],
   [
    10.079,
    13.773
   ],
   [
    14.153,
    15.993
   ],
   [
    16.373,
    19.003
   ],
   [
    19.383,
    23.617
   ],
   [
    23.997,
    29.709
   ],
   [
    30.089,
    31.706
   ],
   [
    32.086,
    38.225
   ],
   [
    38.605,
    42.01
   ],
   [
    42.39,
    53.382
   ],
   [
    53.762,
    57.781
   ],
   [
    58.161,
    66.291
   ],
   [
    66.671,
    70.003
   ],
   [
    70.383,
    77.455
   ],
   [
    77.835,
    86.045
   ]
  ],
  "T": 87.42
 },
 "2.01v": {
  "title": "A message that knows your name",
  "texts": [],
  "sentences": [
   "It is morning in the hall of Sadeed Services Authority, and Shaima opens her email at the counter.",
   "One message mentions case file 2048 and uses the applicant's name.",
   "It asks her to open a link to see updated documents before noon.",
   "Phishing emails pretend to come from someone you trust, to make you click, open a file, or share information.",
   "In 2025, phishing and spoofing together were the most reported type of cybercrime in national crime reports in the United States.",
   "Spear phishing targets one person or a small group, using real details from their work.",
   "Artificial intelligence can now write such messages quickly, in fluent language, tailored to the reader.",
   "The European Union's cybersecurity agency cited reports that, by early 2025, AI-supported phishing made up more than 80 percent of observed social engineering worldwide, meaning tricks that manipulate people.",
   "So fluent language and a familiar case number no longer prove that a message is genuine.",
   "Shaima does not click the link, and she does not reply.",
   "She finds the applicant's phone number in the case file, recorded at the counter.",
   "Omar reminds her to verify through a known contact or an official channel, never through details in the message itself.",
   "The applicant confirms that they sent no email.",
   "Shaima reports the email through the approved route, so the responsible team can warn others.",
   "One message reported early can protect the whole organisation."
  ],
  "timing": [
   [
    0.76,
    6.472
   ],
   [
    6.852,
    11.892
   ],
   [
    12.272,
    16.664
   ],
   [
    17.044,
    23.788
   ],
   [
    24.168,
    33.096
   ],
   [
    33.476,
    39.332
   ],
   [
    39.712,
    46.96
   ],
   [
    47.34,
    61.044
   ],
   [
    61.424,
    67.256
   ],
   [
    67.636,
    71.02
   ],
   [
    71.4,
    76.032
   ],
   [
    76.412,
    84.308
   ],
   [
    84.688,
    87.688
   ],
   [
    88.067,
    93.587
   ],
   [
    93.967,
    98.335
   ]
  ],
  "T": 99.71
 },
 "2.02v": {
  "title": "A sign-in page that only looks right",
  "texts": [],
  "sentences": [
   "Shortly afterwards, Omar receives an email at his desk in the hall.",
   "It warns that his mailbox will be suspended today unless he signs in.",
   "The link opens a page that looks exactly like the Authority's sign-in page.",
   "Fake sign-in pages are built to collect credentials: your username and your password.",
   "Their web address often differs from the real one by a single letter, a dash, or a different ending.",
   "Gulf cybersecurity centres have warned about messages that lead to copies of government portals.",
   "Omar does not sign in through the link.",
   "He closes the page and types the official address himself.",
   "The real portal shows no warning about his mailbox.",
   "Shaima asks why one password matters so much.",
   "With stolen credentials, criminals can enter a real mailbox, read its messages, and send emails from a trusted colleague's real account.",
   "This is called business email compromise, and it often leads to requests for money or information.",
   "In 2025, reports to the United States' national cybercrime centre linked business email compromise to more than 3 billion US dollars in losses.",
   "Omar reports the email through the approved route.",
   "If you have already entered your password on such a page, report it immediately, because the responsible team must act quickly."
  ],
  "timing": [
   [
    0.76,
    5.176
   ],
   [
    5.556,
    9.636
   ],
   [
    10.016,
    14.504
   ],
   [
    14.884,
    20.62
   ],
   [
    21.0,
    27.072
   ],
   [
    27.452,
    33.308
   ],
   [
    33.688,
    35.92
   ],
   [
    36.3,
    40.452
   ],
   [
    40.832,
    44.264
   ],
   [
    44.644,
    47.884
   ],
   [
    48.264,
    56.904
   ],
   [
    57.284,
    63.236
   ],
   [
    63.615,
    74.344
   ],
   [
    74.723,
    77.555
   ],
   [
    77.935,
    85.447
   ]
  ],
  "T": 86.83
 },
 "2.03v": {
  "title": "A file that hides a link",
  "texts": [],
  "sentences": [
   "Late in the morning, Khalid, the procurement officer, opens his email.",
   "A message that appears to come from a supplier carries an attached document called updated price list.",
   "Inside the document there is no price list, only a button that says open shared folder.",
   "Criminals often hide links inside ordinary documents, so the file itself looks harmless.",
   "In 2025, one security research report found that malicious emails used links four times more often than attachments.",
   "The same report found such links placed inside files and documents.",
   "Behind the link there may be a fake sign-in page, or a download that installs malware.",
   "Khalid notices that this supplier usually sends price lists through the procurement system, not by email.",
   "He does not press the button, and he does not open the file again.",
   "Omar reminds him that a known name on the message does not prove who sent it.",
   "Khalid calls the supplier on the number already recorded in the supplier's file, not the number in the email.",
   "The supplier has sent nothing today.",
   "Gulf cybersecurity centres advise staff not to open files from unknown or unverified senders, and to check web addresses before visiting them.",
   "Khalid reports the email through the approved route, says that he opened the file, and does not forward it.",
   "If you have already opened a link or a file like this, say so in your report, so the responsible team can check your device."
  ],
  "timing": [
   [
    0.76,
    5.488
   ],
   [
    5.868,
    11.964
   ],
   [
    12.344,
    18.512
   ],
   [
    18.892,
    25.06
   ],
   [
    25.44,
    33.648
   ],
   [
    34.028,
    38.756
   ],
   [
    39.136,
    44.536
   ],
   [
    44.916,
    51.42
   ],
   [
    51.8,
    55.328
   ],
   [
    55.708,
    60.1
   ],
   [
    60.48,
    66.648
   ],
   [
    67.028,
    69.284
   ],
   [
    69.663,
    79.023
   ],
   [
    79.403,
    85.355
   ],
   [
    85.735,
    93.055
   ]
  ],
  "T": 94.44
 },
 "2.04v": {
  "title": "A sticker on the poster, an advert at the top",
  "texts": [],
  "sentences": [
   "At midday, the applicant for case file 2048 returns to the counter to pay a fee.",
   "He points at the payment poster and asks whether he should scan its quick response code.",
   "Shaima looks closely and sees a sticker with lifted edges, placed over the printed code.",
   "A code stuck on top of another, or with peeling corners, is a sign that it may have been replaced.",
   "Dubai's electronic security centre advises that codes in government service centres be printed into the material, not added as stickers.",
   "Shaima asks the applicant not to scan it, and gives him the official payment address on a printed slip.",
   "Then she photographs the sticker and reports it through the approved route.",
   "The same trick also arrives by email, where a code hides a link that some security tools cannot read.",
   "In January 2026, the United States' federal police warned that such codes move the victim from a work computer to a phone, away from work email security checks.",
   "Meanwhile, Omar searches the web for the payment portal.",
   "The first result is a paid advertisement, and its address differs from the official one by one letter.",
   "The same agency warned in 2025 that criminals buy search adverts that copy government service websites to steal credentials and redirect payments.",
   "Omar does not click the advert.",
   "He opens the portal from the official address saved by the Authority, or types it himself.",
   "If you have already scanned a code or clicked an advert and entered details, report it immediately through the approved route."
  ],
  "timing": [
   [
    0.76,
    7.24
   ],
   [
    7.62,
    12.42
   ],
   [
    12.8,
    18.536
   ],
   [
    18.916,
    24.892
   ],
   [
    25.272,
    33.648
   ],
   [
    34.028,
    40.7
   ],
   [
    41.08,
    45.472
   ],
   [
    45.852,
    51.708
   ],
   [
    52.088,
    63.128
   ],
   [
    63.508,
    67.108
   ],
   [
    67.488,
    73.872
   ],
   [
    74.252,
    84.116
   ],
   [
    84.496,
    86.368
   ],
   [
    86.747,
    92.363
   ],
   [
    92.743,
    99.751
   ]
  ],
  "T": 101.13
 },
 "2.05v": {
  "title": "When the second code is not enough",
  "texts": [],
  "sentences": [
   "In the afternoon, Shaima receives an email inviting her to review a shared report on case file 2048.",
   "The link opens a sign-in page that asks for her password, then for the verification code on her phone.",
   "Many people believe that this second step makes any sign-in page safe.",
   "Multi-factor authentication does stop many attacks, and it remains essential.",
   "But some fake pages sit between you and the real service, and pass on everything you enter.",
   "When the sign-in succeeds, criminals can capture the session token, the digital proof that you are already signed in.",
   "With that token, they can use the account without the password or the code, while the session stays valid.",
   "In March 2026, security researchers described one such phishing service, since disrupted, that reached more than 500,000 organisations a month, including government bodies.",
   "Another trick asks you to type a code into a genuine sign-in page, which approves a sign-in the criminal started on their own device.",
   "Researchers have seen this trick used against government bodies, including in the Middle East.",
   "Shaima stops: she did not expect any report, and she did not type this address herself.",
   "Sign in only from the official address you typed or saved, and enter a code only for a sign-in that you started yourself.",
   "Never give a verification code to anyone, even a caller who says they work for a bank or the Authority.",
   "If you have already signed in through such a page, changing your password alone may not end the criminal's access.",
   "Report it immediately through the approved route, so the responsible team can end active sessions and check the account."
  ],
  "timing": [
   [
    0.76,
    8.44
   ],
   [
    8.82,
    14.748
   ],
   [
    15.128,
    19.952
   ],
   [
    20.332,
    25.828
   ],
   [
    26.208,
    31.944
   ],
   [
    32.324,
    39.26
   ],
   [
    39.64,
    45.856
   ],
   [
    46.236,
    58.788
   ],
   [
    59.168,
    67.352
   ],
   [
    67.732,
    73.18
   ],
   [
    73.56,
    79.824
   ],
   [
    80.204,
    87.956
   ],
   [
    88.335,
    94.647
   ],
   [
    95.027,
    98.027
   ],
   [
    98.407,
    106.135
   ]
  ],
  "T": 107.52
 },
 "2.06v": {
  "title": "Pressure from the hall",
  "texts": [],
  "sentences": [
   "A new week begins in the hall of Sadeed Services Authority.",
   "A well-dressed visitor comes to Shaima's counter and speaks with confidence.",
   "He says a senior official's office sent him to collect the full documents of case file 2048.",
   "He adds that the official is waiting, and that any delay will be her responsibility.",
   "This is social engineering: manipulating people, rather than systems, to obtain information, money or access.",
   "It uses our good qualities: respect for seniors, wish to help, and fear of making a mistake.",
   "Two levers appear together here: claimed authority and artificial urgency.",
   "The UAE Cyber Security Council lists urgency among the main warning signs of fraud.",
   "Qatar's cyber security agency has warned of messages that impersonate government bodies.",
   "In a 2026 analysis of breaches, a human action, such as a mistake or being tricked, was involved in 62 percent of them.",
   "Shaima stays polite, and keeps the file closed.",
   "She calls her manager, Hamad, on the extension listed in the internal directory, not on a number the visitor offers.",
   "Hamad knows of no such request, and the visitor leaves before anyone else arrives.",
   "Only a verified request is acted on; a fraudulent one often disappears when checked.",
   "Shaima records the time and description, and reports the visit through the approved route."
  ],
  "timing": [
   [
    0.76,
    4.384
   ],
   [
    4.764,
    9.42
   ],
   [
    9.8,
    16.904
   ],
   [
    17.284,
    22.42
   ],
   [
    22.8,
    30.648
   ],
   [
    31.028,
    37.772
   ],
   [
    38.152,
    43.312
   ],
   [
    43.692,
    49.38
   ],
   [
    49.76,
    55.472
   ],
   [
    55.852,
    64.564
   ],
   [
    64.944,
    68.328
   ],
   [
    68.708,
    76.364
   ],
   [
    76.743,
    82.6
   ],
   [
    82.979,
    89.507
   ],
   [
    89.887,
    94.975
   ]
  ],
  "T": 96.35
 },
 "2.07v": {
  "title": "A text, then a call",
  "texts": [],
  "sentences": [
   "Late in the morning, Noura, the finance officer, receives a text message on her phone.",
   "It says her salary account has been suspended, and gives a link to restore it.",
   "Phishing by text message has grown fast: one industry group counted a 40 percent rise between the first and second quarters of 2026.",
   "Bahrain's national cybersecurity centre reminds the public that government agencies never ask for personal or banking details by text message.",
   "Noura does not open the link.",
   "A few minutes later, her phone rings.",
   "A calm voice says he is from her bank, and that he can stop the suspension if she reads him the code just sent to her phone.",
   "This is voice phishing: a phone call designed to make you act or reveal information.",
   "The United States' federal police have warned that criminals pose as bank staff on the phone to obtain one-time passcodes.",
   "A code sent to your phone is a key to your account, and nobody genuine will ask you to read it out.",
   "Noura says she will call the bank herself, and ends the call.",
   "She calls the number printed on her bank card, and learns that her account is working normally.",
   "The UAE Cyber Security Council advises: do not reply and do not click; report the message, then block the sender and delete it.",
   "Because the message targeted her salary and her work phone number, Noura also reports it through the approved route at the Authority.",
   "If you have already shared a code or banking details, contact your bank through its official number and report it immediately."
  ],
  "timing": [
   [
    0.76,
    6.328
   ],
   [
    6.708,
    11.316
   ],
   [
    11.696,
    21.152
   ],
   [
    21.532,
    30.508
   ],
   [
    30.888,
    32.88
   ],
   [
    33.26,
    35.876
   ],
   [
    36.256,
    43.336
   ],
   [
    43.716,
    48.924
   ],
   [
    49.304,
    56.456
   ],
   [
    56.836,
    62.62
   ],
   [
    63.0,
    66.744
   ],
   [
    67.124,
    72.212
   ],
   [
    72.591,
    81.424
   ],
   [
    81.803,
    89.171
   ],
   [
    89.551,
    96.391
   ]
  ],
  "T": 97.77
 },
 "2.08v": {
  "title": "The help desk that came from outside",
  "texts": [],
  "sentences": [
   "Early in the afternoon, Omar's inbox suddenly fills with dozens of unwanted emails.",
   "Minutes later, a chat message arrives in the work chat application, from an account called Help Desk.",
   "The sender offers to stop the flood, if Omar approves a remote session on his laptop.",
   "A sudden flood of emails can be used on purpose, to cause stress and make a fake helper seem welcome.",
   "In 2026, security researchers described criminals contacting staff through work chat applications from outside accounts, posing as the help desk.",
   "Once a user approves remote access, the criminal can control the device and move deeper into the organisation's systems.",
   "A joint advisory by several international agencies in July 2025 described a criminal group that impersonates IT and help desk staff to gain credentials and install remote access tools.",
   "The same group also works the other way, calling help desks while pretending to be employees, to get passwords reset.",
   "Fake technical support also targets the public: in 2025, it was the third-largest source of reported losses in the United States' national cybercrime report.",
   "Omar notices that the chat account is marked as external.",
   "He does not approve the session, and he closes the chat.",
   "He calls the Authority's help desk on the number in the internal directory.",
   "The real help desk did not contact him, and asks him to report the chat through the approved route.",
   "Real support starts from a request you made, or from a contact you can confirm through a known channel.",
   "If you have already approved a remote session, turn off Wi-Fi or unplug the network cable, and report it immediately."
  ],
  "timing": [
   [
    0.76,
    6.592
   ],
   [
    6.972,
    13.212
   ],
   [
    13.592,
    19.208
   ],
   [
    19.588,
    25.516
   ],
   [
    25.896,
    35.832
   ],
   [
    36.212,
    44.276
   ],
   [
    44.656,
    58.096
   ],
   [
    58.476,
    65.508
   ],
   [
    65.888,
    76.544
   ],
   [
    76.924,
    80.668
   ],
   [
    81.048,
    84.528
   ],
   [
    84.908,
    89.012
   ],
   [
    89.391,
    95.175
   ],
   [
    95.555,
    101.195
   ],
   [
    101.575,
    108.751
   ]
  ],
  "T": 110.13
 },
 "2.09v": {
  "title": "Three channels, one story",
  "texts": [],
  "sentences": [
   "In the middle of the afternoon, Khalid receives an email about a supplier tender he is handling.",
   "A few minutes later, a text message on his phone says the same thing.",
   "Then a caller asks him to share the tender documents today, before a deadline.",
   "When the same story arrives through several channels, it can feel confirmed.",
   "But all three may come from the same criminals: this is a multichannel attack.",
   "An international anti-phishing group reported that in the second quarter of 2026, criminals reached victims through email, phone, messaging services and social media.",
   "The caller also knows Khalid's job title, his team, and a conference he attended.",
   "All of these details were public, on websites and social media.",
   "Europol reported in 2026 that criminals use generative artificial intelligence to build highly targeted phishing and social engineering.",
   "The United States' federal police warned that such tools remove the spelling and grammar errors that once revealed fraud.",
   "Khalid tells the caller he will respond through the official channel, and ends the call.",
   "He calls the supplier on the number stored in the procurement system.",
   "The supplier made no such request.",
   "Think about what you share publicly about your role, and keep work details to what your job requires.",
   "Khalid reports all three contacts together through the approved route, so the responsible team sees the full picture."
  ],
  "timing": [
   [
    0.76,
    6.28
   ],
   [
    6.66,
    11.028
   ],
   [
    11.408,
    15.608
   ],
   [
    15.988,
    21.052
   ],
   [
    21.432,
    26.64
   ],
   [
    27.02,
    38.012
   ],
   [
    38.392,
    43.384
   ],
   [
    43.764,
    48.396
   ],
   [
    48.776,
    57.968
   ],
   [
    58.348,
    65.26
   ],
   [
    65.64,
    70.632
   ],
   [
    71.012,
    74.54
   ],
   [
    74.919,
    77.391
   ],
   [
    77.771,
    83.675
   ],
   [
    84.055,
    91.519
   ]
  ],
  "T": 92.9
 },
 "2.10v": {
  "title": "A fix you should never run",
  "texts": [],
  "sentences": [
   "Late in the afternoon, Shaima searches the web for a blank form she needs for case file 2048.",
   "The page she opens shows a familiar box that asks her to confirm she is human.",
   "But then it gives her steps: open a system window on her computer, paste some text, and run it.",
   "This trick is known as ClickFix: fake troubleshooting or verification steps that make you run a harmful command yourself.",
   "The text has usually been copied in secret, and it can install malware that steals information.",
   "In August 2025, security researchers reported campaigns of this kind targeting thousands of devices around the world every day.",
   "Because you run the command yourself, it can get past automated security tools.",
   "The lure may also look like a document error, a page that will not load, or a security warning.",
   "In 2025, a public-sector security centre in the United States traced two such campaigns to ransomware incidents, one affecting a public-sector body.",
   "A real human check keeps you in the browser, and never asks you to open a system tool or paste a command.",
   "Shaima closes the page without following the steps.",
   "Omar finds the form in the Authority's internal document library, the official source for its forms.",
   "Shaima reports the page through the approved route, so the responsible team can block it for everyone.",
   "If you pasted something but did not run it, do not run it; close the window and report it.",
   "If you already ran it, turn off Wi-Fi or unplug the network cable, and report it immediately through the approved route."
  ],
  "timing": [
   [
    0.76,
    7.528
   ],
   [
    7.908,
    12.66
   ],
   [
    13.04,
    18.728
   ],
   [
    19.108,
    26.74
   ],
   [
    27.12,
    32.928
   ],
   [
    33.308,
    42.236
   ],
   [
    42.616,
    47.656
   ],
   [
    48.036,
    53.964
   ],
   [
    54.344,
    65.0
   ],
   [
    65.38,
    71.668
   ],
   [
    72.048,
    76.08
   ],
   [
    76.46,
    82.844
   ],
   [
    83.224,
    89.224
   ],
   [
    89.603,
    95.483
   ],
   [
    95.863,
    103.063
   ]
  ],
  "T": 104.44
 },
 "2.11v": {
  "title": "The manager's voice, but not the manager",
  "texts": [],
  "sentences": [
   "A new morning begins in the hall of Sadeed Services Authority.",
   "Noura, the finance officer, receives a voice message on her phone from an unknown number.",
   "The voice sounds exactly like her manager, Hamad.",
   "It says he is in a meeting, and asks her to continue on a private messaging application to settle an urgent, confidential payment.",
   "Artificial intelligence can now copy a real person's voice and face with high accuracy; this is called a deepfake.",
   "The UAE Cyber Security Council has warned that deepfakes can cause organisations significant financial losses, because they imitate voices and faces.",
   "In 2025, the United States' federal police warned that criminals were sending AI-generated voice messages that pretended to come from senior government officials.",
   "The criminals quickly asked targets to move to another messaging application, then requested codes, personal documents, or money transfers.",
   "A request to leave official channels is itself a warning sign.",
   "So is a request for secrecy, which stops you from asking a colleague.",
   "Noura does not reply, and does not move to the other application.",
   "She calls Hamad on his extension in the internal directory, and then walks to his office.",
   "Hamad has sent no message, and he has requested no payment.",
   "Whatever the voice, the face or the rank, verify the person through a number or channel you already know.",
   "Hamad thanks her, and Noura reports the message through the approved route, keeping it as evidence."
  ],
  "timing": [
   [
    0.76,
    4.53
   ],
   [
    4.91,
    10.5
   ],
   [
    10.88,
    14.22
   ],
   [
    14.6,
    22.26
   ],
   [
    22.64,
    30.56
   ],
   [
    30.94,
    41.28
   ],
   [
    41.66,
    51.69
   ],
   [
    52.07,
    60.85
   ],
   [
    61.23,
    65.55
   ],
   [
    65.93,
    70.25
   ],
   [
    70.63,
    75.12
   ],
   [
    75.5,
    80.92
   ],
   [
    81.3,
    85.21
   ],
   [
    85.59,
    92.41
   ],
   [
    92.79,
    98.62
   ]
  ],
  "T": 100.0
 },
 "2.12v": {
  "title": "New bank details from a trusted supplier",
  "texts": [],
  "sentences": [
   "Late in the morning, Khalid brings his laptop to Noura's desk.",
   "An email from Saeed, a supplier the Authority has used for years, says his company has changed banks.",
   "It asks that this month's payment go to a new account.",
   "The message arrives inside a real earlier conversation about the same invoice.",
   "This may be supplier impersonation, one of the most common forms of business email compromise.",
   "The UK's national cybersecurity centre explains that such emails may copy text from an existing conversation, so the victim believes the correspondence is genuine.",
   "The email may come from a look-alike address, or from the supplier's real mailbox after criminals have broken into it.",
   "The United States' federal police warn that criminals can read billing emails, so their request arrives just when a real payment is expected.",
   "So the right name, the right thread and the right invoice number do not prove that the request is real.",
   "Noura puts the payment on hold, and does not reply to the email.",
   "She calls Saeed on the number stored in the supplier record, not the number in the email.",
   "Saeed is surprised: his bank has not changed, and he did not send that message.",
   "His mailbox may have been compromised, so Noura advises him to alert his own technical team.",
   "Any change to a supplier's bank details must be confirmed through a known contact, and approved, before it is saved or paid.",
   "Noura and Khalid report the email together through the approved route.",
   "If a payment has already been sent, report it at once and contact the bank through its official number, because every hour counts."
  ],
  "timing": [
   [
    0.76,
    4.744
   ],
   [
    5.124,
    11.58
   ],
   [
    11.96,
    15.368
   ],
   [
    15.748,
    21.316
   ],
   [
    21.696,
    27.408
   ],
   [
    27.788,
    37.7
   ],
   [
    38.08,
    45.208
   ],
   [
    45.588,
    54.396
   ],
   [
    54.776,
    61.328
   ],
   [
    61.708,
    65.524
   ],
   [
    65.904,
    70.752
   ],
   [
    71.132,
    76.652
   ],
   [
    77.031,
    82.888
   ],
   [
    83.267,
    91.091
   ],
   [
    91.471,
    95.671
   ],
   [
    96.051,
    104.379
   ]
  ],
  "T": 105.76
 },
 "2.13v": {
  "title": "An invoice nobody ordered, a record nobody asked to change",
  "texts": [],
  "sentences": [
   "In the afternoon, an invoice for a training workshop reaches Noura by email.",
   "It says that Hamad has approved it, and that it must be paid today.",
   "An international anti-phishing group reported in 2026 that one leading fraud group sends fake invoices for coaching services, with a forged email thread involving a senior executive.",
   "Noura asks Khalid to check the procurement system.",
   "There is no purchase order, no contract, and no record of this supplier.",
   "An invoice is paid because it matches an approved purchase, not because it looks official or urgent.",
   "Hamad, reached on his internal extension, confirms that he approved nothing.",
   "At the same time, Shaima receives an email asking her to change the bank account for the approved refund in case file 2048.",
   "Changing payment details in a record is a quiet way to redirect money that is due to someone else.",
   "The United States' federal police have warned that criminals who gain access to an account change deposit details to redirect future payments.",
   "Shaima makes no change, and calls the applicant on the number recorded in the paper file.",
   "The applicant did not ask for any change.",
   "Any change to bank details, contact details or access settings in an administrative record must be verified and authorised before it is made.",
   "If you receive a notice of a change you did not make, such as a new sign-in method on your account, report it immediately.",
   "Noura, Khalid and Shaima report both requests through the approved route, so the responsible team can see they arrived together."
  ],
  "timing": [
   [
    0.76,
    5.68
   ],
   [
    6.06,
    10.116
   ],
   [
    10.496,
    22.88
   ],
   [
    23.26,
    26.524
   ],
   [
    26.904,
    31.848
   ],
   [
    32.228,
    38.564
   ],
   [
    38.944,
    44.056
   ],
   [
    44.436,
    52.812
   ],
   [
    53.192,
    59.336
   ],
   [
    59.716,
    68.02
   ],
   [
    68.4,
    73.824
   ],
   [
    74.204,
    77.372
   ],
   [
    77.751,
    87.279
   ],
   [
    87.659,
    94.307
   ],
   [
    94.687,
    102.367
   ]
  ],
  "T": 103.75
 },
 "2.14v": {
  "title": "Case 2048 closes safely",
  "texts": [],
  "sentences": [
   "At the end of the week, the applicant returns to Shaima's counter for the last time.",
   "Case file 2048 is complete, and the approved refund goes to the account verified under the Authority's procedure.",
   "Hamad gathers the team in the hall.",
   "This week, the Authority received fake emails, a fake sign-in page, a replaced QR code, a fake fix, texts, calls, a fake help desk, a cloned voice, and false payment requests.",
   "The tools were different, but the pattern was the same: trust, pressure, and a request to act fast.",
   "No requested payment was made and no requested information was shared, because each person followed a few simple habits.",
   "First, pause when a message pushes urgency, authority or secrecy.",
   "Second, verify through a contact or channel you already know, never through details in the message.",
   "Third, never share a password or verification code, and never approve a sign-in or remote session that you did not start.",
   "Fourth, reach services through the official address, and change payment details or records only after verification and approval.",
   "Fifth, report early through the approved route, even if you are not sure.",
   "If you made a mistake, stay calm and report it at once; the sooner the team knows, the sooner it can help.",
   "If money was sent, the bank must also be contacted immediately through its official number.",
   "The authorized teams then decide on investigation, recovery, and any notice to the people affected.",
   "Shaima closes the file, knowing that alert staff, clear procedures and security tools protect the Authority together."
  ],
  "timing": [
   [
    0.76,
    5.224
   ],
   [
    5.604,
    13.908
   ],
   [
    14.288,
    16.976
   ],
   [
    17.356,
    30.364
   ],
   [
    30.744,
    37.8
   ],
   [
    38.18,
    45.884
   ],
   [
    46.264,
    51.928
   ],
   [
    52.308,
    58.692
   ],
   [
    59.072,
    66.584
   ],
   [
    66.964,
    75.628
   ],
   [
    76.008,
    80.472
   ],
   [
    80.852,
    87.668
   ],
   [
    88.047,
    94.047
   ],
   [
    94.427,
    101.363
   ],
   [
    101.743,
    110.215
   ]
  ],
  "T": 111.6
 },
 "3.01v": {
  "title": "Two recordings, one voice",
  "texts": [],
  "sentences": [
   "A new week begins in the hall of the Sadeed Services Authority.",
   "Before the counters open, Hamad gathers the team at Shaima's counter.",
   "He plays two short recordings of his own voice, each greeting the team.",
   "One is real, and the other was produced by the authorized security team for this training.",
   "Shaima listens twice and cannot tell them apart, and Omar guesses wrong.",
   "This is voice cloning: AI software learns a person's voice and produces new speech that sounds like them.",
   "INTERPOL reported in 2026 that tools sold to criminals can clone a voice from only a few seconds of genuine audio.",
   "A speech at a public event, a video online, or a voicemail can be enough.",
   "The UAE Cybersecurity Council warns that these tools can copy real people's voices with high accuracy.",
   "So a familiar voice no longer proves who is speaking.",
   "Criminals use cloned voices to make a request sound trusted and urgent.",
   "The voice may sound perfect, so check the request, not the voice.",
   "If a call or voice message asks you to pay, share information, or change a record, pause.",
   "Verify it through a number or channel you already know, never through details in the message.",
   "If something feels wrong, report it early through the approved route.",
   "Hamad stops the recording and says, \"From today, we trust the process, not the voice.\""
  ],
  "timing": [
   [
    0.76,
    4.48
   ],
   [
    4.86,
    9.588
   ],
   [
    9.968,
    14.216
   ],
   [
    14.596,
    19.924
   ],
   [
    20.304,
    25.464
   ],
   [
    25.844,
    32.876
   ],
   [
    33.256,
    41.656
   ],
   [
    42.036,
    47.388
   ],
   [
    47.768,
    54.416
   ],
   [
    54.796,
    58.228
   ],
   [
    58.608,
    63.408
   ],
   [
    63.788,
    68.492
   ],
   [
    68.871,
    75.328
   ],
   [
    75.707,
    81.107
   ],
   [
    81.487,
    85.423
   ],
   [
    85.803,
    92.451
   ]
  ],
  "T": 93.83
 },
 "3.02v": {
  "title": "A voice message that wants a reply elsewhere",
  "texts": [],
  "sentences": [
   "Later that morning, Omar finds a voice message on his work phone.",
   "The voice sounds like a senior official from a partner government entity.",
   "It mentions case file 2048 and asks Omar to continue the conversation on a private messaging app.",
   "Minutes later, a live call comes in, and the same voice answers his questions without pause.",
   "The caller asks for a copy of the applicant's passport, today, and quietly.",
   "The FBI warned in 2025 that criminals send AI-generated voice messages that pretend to come from senior officials.",
   "They build trust first, then ask to move the conversation to another messaging app.",
   "Then they ask for verification codes, copies of passports, or money transfers.",
   "Calls are used too: one security company tracked a 442 percent rise in voice phishing, or scam calls, from the first to the second half of 2024.",
   "A live call can sound natural, but signs include fear, urgency, small delays, or an unnatural rhythm.",
   "Omar does not reply on the private app, and he sends nothing.",
   "He ends the call politely and finds the partner entity's number in the official directory.",
   "The official's office confirms that no one called and nothing was requested.",
   "Personal data in a case file is shared only through approved channels, never because a voice asks.",
   "Omar keeps the voice message and the call details, and reports them through the approved route."
  ],
  "timing": [
   [
    0.76,
    4.6
   ],
   [
    4.98,
    8.892
   ],
   [
    9.272,
    16.76
   ],
   [
    17.14,
    23.236
   ],
   [
    23.616,
    28.584
   ],
   [
    28.964,
    36.812
   ],
   [
    37.192,
    42.832
   ],
   [
    43.212,
    48.516
   ],
   [
    48.896,
    59.744
   ],
   [
    60.124,
    67.948
   ],
   [
    68.328,
    71.856
   ],
   [
    72.236,
    77.3
   ],
   [
    77.68,
    82.311
   ],
   [
    82.691,
    89.387
   ],
   [
    89.767,
    95.071
   ]
  ],
  "T": 96.45
 },
 "3.03v": {
  "title": "The right voice, the right answers",
  "texts": [],
  "sentences": [
   "In the afternoon, Shaima takes a call on the Authority's service line.",
   "The caller sounds exactly like the applicant from case file 2048.",
   "He gives his full name, his date of birth, and his file number without hesitation.",
   "Then he asks her to change the mobile number on his file, because his old phone was lost.",
   "A familiar voice and correct answers can feel like proof, but they are not.",
   "In 2025, the head of a major AI company warned banks that AI has defeated voiceprint checks, which identify callers by their voice.",
   "Personal details can also be stolen in data breaches.",
   "A 2025 industry report found that, in the fraud calls it studied, fraudsters passed security questions 53 percent of the time.",
   "The same report found a faked caller number in more than 16 percent of confirmed fraud cases.",
   "Changing a contact number can let a criminal receive the applicant's verification codes and messages.",
   "Shaima follows the procedure and tells the caller that this change cannot be made by phone.",
   "She offers the official route: an appointment at the counter with his identity document, or the official digital service.",
   "The caller becomes impatient and ends the call.",
   "Shaima then calls the applicant on the number already verified in his file, and he says he never called.",
   "She notes the call in the file and reports it through the approved route.",
   "A voice, a name, and the right answers are not enough to change a record."
  ],
  "timing": [
   [
    0.76,
    4.672
   ],
   [
    5.052,
    10.332
   ],
   [
    10.712,
    15.8
   ],
   [
    16.18,
    21.364
   ],
   [
    21.744,
    26.616
   ],
   [
    26.996,
    36.044
   ],
   [
    36.424,
    40.0
   ],
   [
    40.38,
    49.068
   ],
   [
    49.448,
    55.616
   ],
   [
    55.996,
    61.972
   ],
   [
    62.352,
    67.896
   ],
   [
    68.276,
    75.524
   ],
   [
    75.903,
    78.784
   ],
   [
    79.163,
    85.787
   ],
   [
    86.167,
    90.079
   ],
   [
    90.459,
    95.067
   ]
  ],
  "T": 96.45
 },
 "3.04v": {
  "title": "The director's voice, the finance rules",
  "texts": [],
  "sentences": [
   "Near the end of the day, Rania's phone rings in the finance office.",
   "The voice sounds like the Authority's Director General, calm and familiar.",
   "He says a confidential agreement must be paid before the banks close today.",
   "He asks her not to discuss it with anyone, because he is in a meeting.",
   "Authority, urgency and secrecy arrive together in one call.",
   "The UAE Cybersecurity Council warns that imitating voices and faces can cause organisations large financial losses.",
   "Joint guidance from United States security agencies warns that AI-faked voices and videos are used to impersonate leaders and financial officers.",
   "Rania does not argue, and she does not act on the call.",
   "She ends it politely and calls the Director General's office on the number in the official directory.",
   "His office confirms that he made no call and requested no payment.",
   "Even a real senior voice cannot replace the payment procedure and its approvals.",
   "Rania reports the call through the approved route, and Hamad thanks her.",
   "This lesson leaves three habits for any spoken request.",
   "First, pause when a voice brings urgency, authority or secrecy.",
   "Second, verify through a number or channel you already know, and follow the normal approvals.",
   "Third, report early through the approved route, even when the voice sounded real."
  ],
  "timing": [
   [
    0.76,
    4.912
   ],
   [
    5.292,
    9.852
   ],
   [
    10.232,
    14.696
   ],
   [
    15.076,
    18.82
   ],
   [
    19.2,
    23.688
   ],
   [
    24.068,
    32.588
   ],
   [
    32.968,
    42.04
   ],
   [
    42.42,
    45.9
   ],
   [
    46.28,
    52.04
   ],
   [
    52.42,
    56.644
   ],
   [
    57.024,
    62.424
   ],
   [
    62.804,
    67.268
   ],
   [
    67.647,
    72.328
   ],
   [
    72.707,
    78.395
   ],
   [
    78.775,
    84.655
   ],
   [
    85.035,
    90.483
   ]
  ],
  "T": 91.86
 },
 "3.05v": {
  "title": "A photo of a moment that never happened",
  "texts": [],
  "sentences": [
   "The next morning, Lena arrives in the Sadeed hall looking worried.",
   "On her phone is a photo, shared in a public group, of Shaima at her counter taking an envelope from a visitor.",
   "A short video shows the same moment, with Shaima's face and uniform.",
   "Shaima never took that envelope, and the moment in the photo never happened.",
   "This is a deepfake: AI creates or changes images, video or audio so realistically that it is hard to tell what is real.",
   "A Saudi awareness campaign for the Year of AI 2026 puts it simply: seeing someone in a video is not proof that it happened.",
   "Many views and reshares do not make content true either.",
   "The UK government estimates that eight million deepfakes were shared in 2025, up from half a million in 2023.",
   "Our eyes are not a reliable test.",
   "In a 2025 study of two thousand people, only one in a thousand correctly identified every real and fake image and video.",
   "Fake videos were harder to spot than fake photos, yet most people still felt confident.",
   "Omar wants to reply in the group and defend Shaima, but Lena stops him.",
   "They do not forward it, comment on it, or post it again, because sharing spreads the harm.",
   "Kuwait's National Cyber Security Center advises checking the source and authenticity of content before sharing it.",
   "Lena saves the link and the time she saw it, and Shaima reports it through the approved route.",
   "The authorized teams will decide on the response, and Shaima opens her counter as usual."
  ],
  "timing": [
   [
    0.76,
    4.792
   ],
   [
    5.172,
    12.516
   ],
   [
    12.896,
    17.984
   ],
   [
    18.364,
    22.756
   ],
   [
    23.136,
    32.544
   ],
   [
    32.924,
    41.924
   ],
   [
    42.304,
    46.384
   ],
   [
    46.764,
    54.948
   ],
   [
    55.328,
    57.68
   ],
   [
    58.06,
    67.06
   ],
   [
    67.44,
    73.584
   ],
   [
    73.964,
    78.62
   ],
   [
    78.999,
    84.808
   ],
   [
    85.187,
    93.203
   ],
   [
    93.583,
    99.151
   ],
   [
    99.531,
    105.579
   ]
  ],
  "T": 106.96
 },
 "3.06v": {
  "title": "A face that belongs to two people",
  "texts": [],
  "sentences": [
   "Later that day, a new application arrives at Shaima's counter through the online service.",
   "The applicant uploaded his own photo, and it looks clear and ordinary.",
   "AI can now swap one face for another in a photo or a video.",
   "Software can also morph two faces into one photo that looks like both people.",
   "The United States standards institute, NIST, warned in 2025 that a morphed photo can let two people use one passport.",
   "The risk is highest when people submit their own photos, and much lower when the photo is taken under trusted conditions.",
   "Criminals also build synthetic identities by combining AI-generated images with stolen or invented personal data.",
   "A United States financial-crime authority reported in 2024 that such identities have been used to open accounts.",
   "An industry report released in late 2025 found that deepfakes were behind one in five attempts to cheat biometric checks, such as face scans.",
   "When the applicant comes to the counter, Shaima follows the procedure and takes a new photo with the counter camera.",
   "She checks his original identity document in person, not a copy on a phone screen.",
   "Omar notices that the uploaded photo and the new photo do not quite match.",
   "They do not accuse the applicant, because a mismatch can have an innocent reason.",
   "Shaima pauses the application and refers it for review through the approved route.",
   "Trained reviewers decide, because even good detection software needs a human investigation."
  ],
  "timing": [
   [
    0.76,
    6.496
   ],
   [
    6.876,
    11.316
   ],
   [
    11.696,
    16.208
   ],
   [
    16.588,
    22.108
   ],
   [
    22.488,
    30.864
   ],
   [
    31.244,
    38.588
   ],
   [
    38.968,
    46.6
   ],
   [
    46.98,
    54.204
   ],
   [
    54.584,
    63.488
   ],
   [
    63.868,
    70.324
   ],
   [
    70.704,
    75.72
   ],
   [
    76.1,
    81.428
   ],
   [
    81.808,
    86.463
   ],
   [
    86.843,
    91.787
   ],
   [
    92.167,
    98.575
   ]
  ],
  "T": 99.96
 },
 "3.07v": {
  "title": "Everyone on the call looked real",
  "texts": [],
  "sentences": [
   "On Wednesday morning, Rania receives an invitation to an urgent video meeting.",
   "On the screen she sees Hamad, a senior finance manager, and a supplier she knows.",
   "Their faces move, and their voices sound right.",
   "They ask her to process a confidential transfer before the end of the day.",
   "AI can now impersonate people in live video calls, not only in recordings.",
   "In a case reported in 2024, a finance employee joined a video call in which every other participant was a deepfake.",
   "He had doubted the first email, but the call convinced him, and he made fifteen transfers.",
   "Royal Oman Police has warned that criminals use deepfakes to pose as government employees in video calls.",
   "Fake faces have also appeared in job interviews, according to a 2026 alert by eleven governments.",
   "Warning signs can include urgency, secrecy, small delays, or a face that moves unnaturally.",
   "But a good fake may show no signs at all, so the check must happen outside the call.",
   "Rania says she will follow the normal procedure and leaves the call.",
   "She calls Hamad on the number in the official directory.",
   "Hamad is in the hall downstairs, and he was never in that meeting.",
   "Rania keeps the invitation and reports it through the approved route.",
   "A face on a screen is not an approval; payments follow the written procedure, every time."
  ],
  "timing": [
   [
    0.76,
    5.92
   ],
   [
    6.3,
    11.84
   ],
   [
    12.22,
    15.58
   ],
   [
    15.96,
    20.4
   ],
   [
    20.78,
    26.44
   ],
   [
    26.82,
    34.74
   ],
   [
    35.12,
    40.81
   ],
   [
    41.19,
    48.15
   ],
   [
    48.53,
    55.9
   ],
   [
    56.28,
    63.74
   ],
   [
    64.12,
    68.85
   ],
   [
    69.23,
    73.17
   ],
   [
    73.55,
    76.72
   ],
   [
    77.1,
    80.99
   ],
   [
    81.37,
    85.47
   ],
   [
    85.85,
    91.49
   ]
  ],
  "T": 92.87
 },
 "3.08v": {
  "title": "A perfect document, a photo that proves nothing",
  "texts": [],
  "sentences": [
   "On Thursday, a visitor brings Omar an application for a compensation payment.",
   "He attaches an identity document and a photo of his shop damaged in a storm.",
   "Both look clean, sharp and complete.",
   "The FBI warned that criminals use AI to create fake identity documents and fake official credentials.",
   "A 2025 industry report found that national identity cards were the most commonly faked document.",
   "AI can also produce a photo, a recording or a report of something that never happened.",
   "Courts are facing the same problem, and in 2025 a United States judicial committee described deepfake evidence as hard to detect.",
   "So a document is checked against the official record, not judged by how it looks.",
   "Shaima checks the identity number in the official records system, and the name does not match.",
   "United States guidance lists such mismatches between documents and records as a red flag.",
   "The storm photo cannot be confirmed either, so Omar asks for the inspection report from the official channel.",
   "Neither of them accuses the visitor, and neither tries to investigate alone.",
   "Omar explains calmly that the application needs further review.",
   "Shaima keeps the submitted files unchanged and refers the case through the approved route.",
   "The authorized teams decide what happens next.",
   "A convincing document or photo is a reason to check, never a reason to skip the check."
  ],
  "timing": [
   [
    0.76,
    6.136
   ],
   [
    6.516,
    11.652
   ],
   [
    12.032,
    14.648
   ],
   [
    15.028,
    22.276
   ],
   [
    22.656,
    29.28
   ],
   [
    29.66,
    35.06
   ],
   [
    35.44,
    44.224
   ],
   [
    44.604,
    49.692
   ],
   [
    50.072,
    55.736
   ],
   [
    56.116,
    62.188
   ],
   [
    62.568,
    69.216
   ],
   [
    69.596,
    74.636
   ],
   [
    75.016,
    78.856
   ],
   [
    79.235,
    84.899
   ],
   [
    85.279,
    88.663
   ],
   [
    89.043,
    95.067
   ]
  ],
  "T": 96.45
 },
 "3.09v": {
  "title": "When a tool says \"maybe\"",
  "texts": [],
  "sentences": [
   "On Thursday afternoon, the security team calls Shaima and Lena about the fake counter video.",
   "A detection tool has checked the video, and its answer is only \"possibly manipulated\".",
   "The UK National Cyber Security Centre notes that tools for spotting synthetic content can be unreliable.",
   "A UK government report in 2026 described deepfake detection technology as still at an early stage.",
   "Even when software works well, NIST says that a flagged image still needs a human investigation.",
   "So the team does not rely on the tool alone; it goes back to the original source.",
   "The hall's own camera footage for the time in the video shows Shaima serving applicants, with no envelope and no such visitor.",
   "This is source verification: checking a claim against trusted original sources, not only judging how it looks.",
   "Some files now carry tamper-evident digital records of where they came from and how they were edited.",
   "Security agencies from several countries said in 2025 that these records help, but do not solve the problem alone.",
   "Saudi Arabia's National Cybersecurity Authority offers a service that checks whether a link or file is dangerous, but not whether a video is real.",
   "Staff use only the tools and channels that the Authority has approved.",
   "Hamad closes the lesson with three habits for images and video.",
   "First, pause: a realistic picture or a live face is not proof.",
   "Second, verify against the original source, the official record, or a contact you already know.",
   "Third, do not share doubtful content, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    6.352
   ],
   [
    6.732,
    12.708
   ],
   [
    13.088,
    19.904
   ],
   [
    20.284,
    28.3
   ],
   [
    28.68,
    35.208
   ],
   [
    35.588,
    40.676
   ],
   [
    41.056,
    49.768
   ],
   [
    50.148,
    57.588
   ],
   [
    57.968,
    64.64
   ],
   [
    65.02,
    72.772
   ],
   [
    73.152,
    82.032
   ],
   [
    82.412,
    86.324
   ],
   [
    86.704,
    91.504
   ],
   [
    91.883,
    97.307
   ],
   [
    97.687,
    104.191
   ],
   [
    104.571,
    109.851
   ]
  ],
  "T": 111.23
 },
 "3.10v": {
  "title": "A rumour reaches the hall",
  "texts": [],
  "sentences": [
   "On Sunday morning, the Sadeed hall is unusually crowded.",
   "An applicant shows Shaima a message on his phone.",
   "It says the Authority will stop accepting refund applications tomorrow.",
   "His cousin forwarded it, trying to help.",
   "Shaima knows of no such decision.",
   "False information shared by mistake is called misinformation.",
   "False information created or spread on purpose to deceive is called disinformation.",
   "One message can start as disinformation, then spread as misinformation when honest people pass it on.",
   "UK government guidance from 2025 notes that AI content and automated accounts can spread false stories quickly and at scale.",
   "The World Economic Forum's 2026 report ranks misinformation and disinformation among the top short-term global risks.",
   "Shaima does not guess, and she does not repeat the rumour.",
   "She checks the Authority's official website and the internal staff notices.",
   "There is no announcement, so she tells the applicant calmly that the service continues as normal.",
   "She points him to the official website for any future updates.",
   "Omar notices more people in the queue holding the same message.",
   "Shaima reports the rumour through the approved route, so the communications team can respond early."
  ],
  "timing": [
   [
    0.76,
    4.672
   ],
   [
    5.052,
    8.148
   ],
   [
    8.528,
    13.04
   ],
   [
    13.42,
    15.7
   ],
   [
    16.08,
    18.768
   ],
   [
    19.148,
    23.468
   ],
   [
    23.848,
    29.392
   ],
   [
    29.772,
    36.324
   ],
   [
    36.704,
    46.112
   ],
   [
    46.492,
    54.844
   ],
   [
    55.224,
    59.112
   ],
   [
    59.492,
    63.716
   ],
   [
    64.096,
    69.808
   ],
   [
    70.187,
    73.955
   ],
   [
    74.335,
    78.415
   ],
   [
    78.795,
    84.459
   ]
  ],
  "T": 85.84
 },
 "3.11v": {
  "title": "The Director General announces a fee he never set",
  "texts": [],
  "sentences": [
   "By noon, a new message is spreading among applicants.",
   "It contains a short video of the Authority's Director General.",
   "In the video, he says that refunds now require a small processing fee, paid through a link below.",
   "The link opens a website with the Authority's colours, logo and layout.",
   "The UAE Cybersecurity Council has warned that fabricated videos of government officials can be used to mislead the public and create false crises.",
   "In 2026, the FBI reported a deepfake video of one of its own leaders that sent viewers to a fake complaint website.",
   "That fake site even gave visitors a reference number, so it felt official.",
   "Royal Oman Police has warned that copies of official portals can appear at the top of search results and collect bank details and verification codes.",
   "A real face, a familiar logo and an official tone do not prove that an announcement is genuine.",
   "Shaima does not open the link.",
   "She types the Authority's official website address herself and finds no fee and no announcement.",
   "Omar tells the applicants calmly that the Authority charges no such fee and that they should not pay or enter any details.",
   "One applicant has already paid, so Shaima advises him to contact his bank at once through its official number.",
   "She saves the video, the link and the time, without forwarding them.",
   "Then she reports the fake announcement through the approved route.",
   "Official news about our services comes only through the Authority's official channels."
  ],
  "timing": [
   [
    0.76,
    4.53
   ],
   [
    4.91,
    8.82
   ],
   [
    9.2,
    15.63
   ],
   [
    16.01,
    20.67
   ],
   [
    21.05,
    30.31
   ],
   [
    30.69,
    38.99
   ],
   [
    39.37,
    43.93
   ],
   [
    44.31,
    53.0
   ],
   [
    53.38,
    60.46
   ],
   [
    60.84,
    62.81
   ],
   [
    63.19,
    69.77
   ],
   [
    70.15,
    78.24
   ],
   [
    78.62,
    85.34
   ],
   [
    85.72,
    90.4
   ],
   [
    90.78,
    94.19
   ],
   [
    94.57,
    99.85
   ]
  ],
  "T": 101.23
 },
 "3.12v": {
  "title": "A letter on our letterhead that we never sent",
  "texts": [],
  "sentences": [
   "On Monday, a worried citizen brings Lena a letter at the enquiries desk.",
   "It carries the Authority's logo, a stamp, a signature and a reference number.",
   "It says he owes an unpaid penalty and must pay within forty-eight hours.",
   "The day after the letter arrived, a caller claiming to be from the Authority had phoned him and told him to keep the matter private.",
   "Criminals often pretend to be government bodies, because people trust them and fear ignoring them.",
   "The FBI reported nearly sixty-one thousand complaints from January 2025 to July 2026 about criminals posing as police or government officials.",
   "Reported losses were more than one point six billion dollars.",
   "The scammers used real names and faked real phone numbers, and they told victims to keep the call secret.",
   "AI makes forged letters, stamps and reports look more convincing, and digital document forgeries rose sharply in 2024, according to an industry report.",
   "In the UAE, Federal Decree-Law No. 34 of 2021 covers the forgery of electronic documents and the creation of fake websites and accounts.",
   "Lena does not judge the letter by its appearance.",
   "She searches the reference number in the Authority's case system, and it does not exist.",
   "She tells the citizen not to pay, not to call the number in the letter, and to contact his bank through its official number if he shared any details.",
   "With his consent, she keeps a copy of the letter and notes the caller's number.",
   "Then she reports the impersonation through the approved route.",
   "A document from the Authority should be confirmed in our own records, through our own channels."
  ],
  "timing": [
   [
    0.76,
    6.04
   ],
   [
    6.42,
    11.58
   ],
   [
    11.96,
    17.024
   ],
   [
    17.404,
    24.724
   ],
   [
    25.104,
    30.816
   ],
   [
    31.196,
    42.884
   ],
   [
    43.264,
    47.104
   ],
   [
    47.484,
    54.18
   ],
   [
    54.56,
    65.072
   ],
   [
    65.452,
    75.772
   ],
   [
    76.152,
    79.104
   ],
   [
    79.484,
    84.452
   ],
   [
    84.832,
    93.303
   ],
   [
    93.683,
    98.531
   ],
   [
    98.911,
    102.439
   ],
   [
    102.819,
    108.675
   ]
  ],
  "T": 110.05
 },
 "3.13v": {
  "title": "A news story about us, from nowhere",
  "texts": [],
  "sentences": [
   "On Tuesday, Omar finds an article shared in a staff chat group.",
   "It claims that applicants' personal data leaked from the Sadeed Services Authority.",
   "The website looks like a news outlet, but it has no author, no date, and no other source.",
   "Bahrain's National Cyber Security Center advises asking who posted the content, checking its date, and comparing at least three sources.",
   "Omar finds no report of the leak from the Authority or from any official source.",
   "Even so, he cannot know alone whether a data breach happened, so that judgment belongs to the authorized teams.",
   "Omar had drafted a public reply in the approved AI tool, without case data.",
   "The draft sounds confident, but it states a number of affected applicants that no one has confirmed.",
   "Bahrain's 2026 awareness campaign reminds staff to check AI output for errors and manipulation before using or sharing it.",
   "Omar deletes the draft, because only the authorized team speaks to the public for the Authority.",
   "An unverified story, or a careless reply, can damage public trust in an institution.",
   "The UAE Cybersecurity Council describes public awareness as the first line of defence that helps protect the reputation of official institutions.",
   "Yet a 2025 study found that only one person in five would report a suspected deepfake.",
   "Omar does not forward the article, and he does not reply in the chat group.",
   "He reports it through the approved route, with the link and the time he saw it.",
   "Hamad nods: checking the source protects the facts, and reporting early protects public trust."
  ],
  "timing": [
   [
    0.76,
    5.056
   ],
   [
    5.436,
    9.924
   ],
   [
    10.304,
    16.184
   ],
   [
    16.564,
    25.324
   ],
   [
    25.704,
    30.816
   ],
   [
    31.196,
    38.612
   ],
   [
    38.992,
    44.32
   ],
   [
    44.7,
    50.652
   ],
   [
    51.032,
    60.68
   ],
   [
    61.06,
    66.748
   ],
   [
    67.128,
    73.32
   ],
   [
    73.7,
    83.276
   ],
   [
    83.656,
    90.376
   ],
   [
    90.755,
    95.075
   ],
   [
    95.455,
    99.607
   ],
   [
    99.987,
    106.323
   ]
  ],
  "T": 107.7
 },
 "3.14v": {
  "title": "One clear voice in a noisy week",
  "texts": [],
  "sentences": [
   "On Thursday, the Authority publishes an official notice on its website and channels.",
   "It states clearly that there is no new fee, the service continues, and the video and letter were fake.",
   "The notice was quick because staff reported early, so the team saw the pattern and assessed its impact.",
   "UK government guidance from 2025 describes the same path: recognise the false story, warn early, assess the impact, communicate, and track the results.",
   "In the UAE, Federal Decree-Law No. 34 of 2021 sets penalties for spreading false news, with higher penalties during crises.",
   "So staff never add their own posts or guesses; the authorized team speaks for the Authority.",
   "At her counter, Shaima hands the applicant from case file 2048 a printed copy of the official notice.",
   "Then Hamad gathers the team in the hall.",
   "This week brought cloned voices, a fake video call, forged documents, false announcements and a fake news story.",
   "First, a voice, a face, a document or a logo is not proof on its own.",
   "Second, pause when content brings urgency, authority, secrecy or strong emotion.",
   "Third, verify through a contact you already know, the original source or the official record, never through details in the message.",
   "Fourth, never pay, change a record or share data because of a call, a video or a document alone; follow the procedure and its approvals.",
   "Fifth, do not forward doubtful content, and report it early through the approved route, even if you are not sure.",
   "The authorized teams then decide on investigation, public communication and any notice to the people affected.",
   "Shaima opens the next file, knowing that in an age of convincing fakes, careful checking keeps public trust real."
  ],
  "timing": [
   [
    0.76,
    6.45
   ],
   [
    6.83,
    13.62
   ],
   [
    14.0,
    19.86
   ],
   [
    20.24,
    31.66
   ],
   [
    32.04,
    42.12
   ],
   [
    42.5,
    48.26
   ],
   [
    48.64,
    55.84
   ],
   [
    56.22,
    59.27
   ],
   [
    59.65,
    67.4
   ],
   [
    67.78,
    73.56
   ],
   [
    73.94,
    80.78
   ],
   [
    81.16,
    89.8
   ],
   [
    90.18,
    100.12
   ],
   [
    100.5,
    107.51
   ],
   [
    107.89,
    115.19
   ],
   [
    115.57,
    123.01
   ]
  ],
  "T": 124.39
 },
 "4.01v": {
  "title": "One password, two doors",
  "texts": [],
  "sentences": [
   "On Monday morning, Shaima signs in at her counter to open case file 2048.",
   "Her username says who she claims to be; her password and her second check help prove it.",
   "That proof is called authentication.",
   "Your digital identity is your account, your permissions, and the record of what you do with them.",
   "The UAE Cyber Security Council calls digital identity one of the most valuable assets that people and organizations own.",
   "If it is stolen, the harm can include fraud, financial loss and damage to reputation.",
   "Beside her, Omar admits that he uses the same password at work and on a shopping site.",
   "If that site leaks it, criminals will try it on his work account too.",
   "A major threat report for 2025 found that over 97 percent of identity attacks were password attacks, mostly mass guessing.",
   "So a password must be long, used for one account only, and hard to guess.",
   "A phrase of several unrelated words is longer, and easier to remember, than a short word full of symbols.",
   "United States standards guidance from 2025 favors length, and systems that block known leaked passwords, over forced changes on a fixed schedule.",
   "A password manager approved by the Authority can create and store a different password for every account.",
   "Never share your password with anyone, not even a colleague or a caller who says they are from IT.",
   "If you think someone else knows your password, change it through the official channel and report it at once through the approved route.",
   "That same morning, Omar changes his work password and stores it in the approved password manager."
  ],
  "timing": [
   [
    0.76,
    6.544
   ],
   [
    6.924,
    12.492
   ],
   [
    12.872,
    15.584
   ],
   [
    15.964,
    21.508
   ],
   [
    21.888,
    29.88
   ],
   [
    30.26,
    36.044
   ],
   [
    36.424,
    42.16
   ],
   [
    42.54,
    46.308
   ],
   [
    46.688,
    55.496
   ],
   [
    55.876,
    60.724
   ],
   [
    61.104,
    68.784
   ],
   [
    69.164,
    79.004
   ],
   [
    79.383,
    85.767
   ],
   [
    86.147,
    91.979
   ],
   [
    92.359,
    99.223
   ],
   [
    99.603,
    105.771
   ]
  ],
  "T": 107.15
 },
 "4.02v": {
  "title": "A second check that resists trickery",
  "texts": [],
  "sentences": [
   "Later that morning, Omar's phone receives a code to finish his sign-in.",
   "This second check is multi-factor authentication.",
   "It asks for something you know, like a password, and something you have or are, like a phone or a fingerprint.",
   "The UAE Cyber Security Council said in 2026 that it can prevent more than 99 percent of identity-based attacks.",
   "But not every second check is equally strong.",
   "The United States cybersecurity agency rates text-message codes as the weakest form.",
   "A code can be typed into a fake page, or a criminal can trick someone into reading it out.",
   "So a verification code is for you alone; no colleague, helpdesk or official ever needs it.",
   "At her laptop, Shaima signs in with a passkey and her fingerprint.",
   "A passkey has no secret for her to type, and it works only with the genuine site it was made for.",
   "That is why it is called phishing-resistant: a fake page cannot collect it.",
   "In 2026, the UK National Cyber Security Centre advised people to choose passkeys first for their online accounts, wherever they are offered.",
   "An industry study from 2025 also found passkey sign-ins succeeded far more often than other methods, and much faster.",
   "Use the strongest sign-in method the Authority provides, and set it up only through the official IT channel.",
   "If anyone asks you for a code, refuse, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    5.22
   ],
   [
    5.6,
    8.89
   ],
   [
    9.27,
    14.86
   ],
   [
    15.24,
    23.83
   ],
   [
    24.21,
    27.38
   ],
   [
    27.76,
    33.9
   ],
   [
    34.28,
    39.7
   ],
   [
    40.08,
    46.22
   ],
   [
    46.6,
    50.85
   ],
   [
    51.23,
    57.61
   ],
   [
    57.99,
    63.03
   ],
   [
    63.41,
    73.03
   ],
   [
    73.41,
    81.76
   ],
   [
    82.14,
    89.32
   ],
   [
    89.7,
    94.62
   ]
  ],
  "T": 96.0
 },
 "4.03v": {
  "title": "Ten requests he never made",
  "texts": [],
  "sentences": [
   "On Monday afternoon, Omar's phone lights up with a sign-in approval request.",
   "He is not signing in to anything.",
   "A second request comes, then a third, then many more.",
   "An approval request you did not start means someone else may already have your password.",
   "Criminals send request after request, hoping you will tap approve just to make it stop.",
   "This is called authentication fatigue.",
   "Sometimes a caller adds pressure, posing as IT support and asking you to accept the request.",
   "A joint FBI and CISA advisory in July 2025 described one criminal group using exactly these tricks against large organizations.",
   "One wrong tap can open the account to them.",
   "Some systems ask you to type a number shown on the sign-in screen, which makes approving by mistake much harder.",
   "Phishing-resistant methods such as passkeys remove this risk further.",
   "Omar does not approve; he chooses deny on every request.",
   "Then he calls the IT service desk on the number in the staff directory, not a number from any message.",
   "The authorized team resets his password and checks his account for any other activity.",
   "If a request appears that you did not start, never approve it, and report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    5.968
   ],
   [
    6.348,
    8.724
   ],
   [
    9.104,
    13.136
   ],
   [
    13.516,
    18.58
   ],
   [
    18.96,
    25.128
   ],
   [
    25.508,
    27.884
   ],
   [
    28.264,
    35.008
   ],
   [
    35.388,
    46.284
   ],
   [
    46.664,
    49.448
   ],
   [
    49.828,
    56.38
   ],
   [
    56.76,
    61.392
   ],
   [
    61.772,
    66.212
   ],
   [
    66.591,
    72.448
   ],
   [
    72.827,
    78.323
   ],
   [
    78.703,
    85.135
   ]
  ],
  "T": 86.52
 },
 "4.04v": {
  "title": "A new phone, the same person?",
  "texts": [],
  "sentences": [
   "On Tuesday morning, the applicant from case file 2048 returns to Shaima's counter.",
   "She lost her phone and cannot receive her sign-in codes.",
   "She asks Shaima to put a new mobile number on her file.",
   "Account recovery is a real need, but it is also a back door into an account.",
   "Whoever controls the phone number or the reset can take over the whole digital identity.",
   "So Shaima follows the procedure and checks the original identity document against the official record.",
   "A name, a date of birth or a file number is not enough, because criminals can find these details.",
   "United States standards guidance does not accept security questions for this reason, and its 2025 update keeps that rule.",
   "The same care protects staff accounts inside the Authority.",
   "In 2025, the UK National Cyber Security Centre urged organizations to review how their helpdesks check staff before resetting passwords.",
   "A call back on the number already on file, never a number the caller gives, is one step in the full recovery check.",
   "If you lose your own work phone or security key, report it at once through the approved route.",
   "Recover your account only through the official IT channel.",
   "The identity matches, and Shaima updates the number with her supervisor's approval, as the procedure requires.",
   "This lesson's habits: one strong password per account, the strongest sign-in method offered, no shared codes, no unexpected approvals, and recovery only through the procedure."
  ],
  "timing": [
   [
    0.76,
    6.952
   ],
   [
    7.332,
    10.836
   ],
   [
    11.216,
    14.576
   ],
   [
    14.956,
    20.068
   ],
   [
    20.448,
    26.304
   ],
   [
    26.684,
    33.068
   ],
   [
    33.448,
    39.544
   ],
   [
    39.924,
    47.724
   ],
   [
    48.104,
    51.872
   ],
   [
    52.252,
    61.492
   ],
   [
    61.872,
    68.976
   ],
   [
    69.356,
    74.924
   ],
   [
    75.303,
    79.047
   ],
   [
    79.427,
    86.915
   ],
   [
    87.295,
    98.911
   ]
  ],
  "T": 100.29
 },
 "4.05v": {
  "title": "Old passwords, new attempts",
  "texts": [],
  "sentences": [
   "On Wednesday morning, Hamad gathers the counter team in the hall.",
   "Overnight, the IT security team saw thousands of failed sign-in attempts on staff accounts.",
   "Some attempts used passwords leaked from other websites.",
   "Criminals try leaked usernames and passwords on other sites and services, hoping they were reused; this is called credential stuffing.",
   "Other attempts tried one common password against many accounts, quietly, to avoid lockouts; this is called password spraying.",
   "Omar is relieved that he changed his reused password on Monday.",
   "Passwords are also stolen directly, by malware that copies saved passwords from an infected device.",
   "In May 2025, Europol reported that one such malware had infected about 394,000 computers in two months.",
   "A major breach report in 2026 found credential abuse at some stage in 39 percent of the breaches it studied.",
   "With a working password, a criminal can take over an account and act as its owner.",
   "That is why a unique password and a strong second check matter together.",
   "Never use a work password on any other site.",
   "Sign in to work systems only on devices approved by the Authority.",
   "If you see a sign-in alert you do not recognize, or your account is locked without reason, report it through the approved route.",
   "The authorized team decides on resets, blocks and further investigation."
  ],
  "timing": [
   [
    0.76,
    5.08
   ],
   [
    5.46,
    11.748
   ],
   [
    12.128,
    15.944
   ],
   [
    16.324,
    25.036
   ],
   [
    25.416,
    34.44
   ],
   [
    34.82,
    38.852
   ],
   [
    39.232,
    45.88
   ],
   [
    46.26,
    55.86
   ],
   [
    56.24,
    64.4
   ],
   [
    64.78,
    70.324
   ],
   [
    70.704,
    75.168
   ],
   [
    75.548,
    78.716
   ],
   [
    79.096,
    83.535
   ],
   [
    83.915,
    91.427
   ],
   [
    91.807,
    97.111
   ]
  ],
  "T": 98.49
 },
 "4.06v": {
  "title": "The real page behind a fake one",
  "texts": [],
  "sentences": [
   "On Wednesday afternoon, Rania in finance receives an email about a shared payment file.",
   "The link opens a sign-in page that looks exactly like the Authority's.",
   "Some fake pages sit between you and the real site and pass everything along as you type.",
   "This is called an adversary-in-the-middle attack.",
   "Your password and your code reach the real site, and you are signed in as usual.",
   "But the criminal also captures the session token, the digital pass that keeps you signed in.",
   "With that token, he can use your account without your password or your code.",
   "In March 2026, Europol announced action against one such phishing service, which had reached nearly 100,000 organizations, including public institutions.",
   "In 2025, Microsoft also described a campaign against governments, including in the Middle East, where victims signed in on a genuine page at an attacker's request.",
   "So a familiar page, or even a genuine one, is not proof that a sign-in request is safe.",
   "Passkeys help against fake pages, because they work only with the real site's address.",
   "Rania does not sign in from the link; she types the address she already knows.",
   "There is no shared payment file waiting for her.",
   "She reports the email through the approved route, without forwarding it to colleagues.",
   "If you have already entered your details on a doubtful page, report it at once, because changing your password alone may not end the criminal's session.",
   "The authorized team can end all active sessions and check the account."
  ],
  "timing": [
   [
    0.76,
    6.808
   ],
   [
    7.188,
    11.7
   ],
   [
    12.08,
    18.152
   ],
   [
    18.532,
    21.244
   ],
   [
    21.624,
    27.264
   ],
   [
    27.644,
    33.14
   ],
   [
    33.52,
    37.96
   ],
   [
    38.34,
    49.476
   ],
   [
    49.856,
    60.824
   ],
   [
    61.204,
    67.54
   ],
   [
    67.92,
    73.056
   ],
   [
    73.436,
    78.548
   ],
   [
    78.927,
    81.543
   ],
   [
    81.923,
    86.651
   ],
   [
    87.031,
    95.647
   ],
   [
    96.027,
    100.635
   ]
  ],
  "T": 102.02
 },
 "4.07v": {
  "title": "The application asks for more",
  "texts": [],
  "sentences": [
   "On Thursday morning, Lena in procurement opens a link described as a revised supplier document.",
   "A page asks her to sign in, and then an application asks for permission to read her files, messages and contacts.",
   "The sign-in may be genuine, but the request for access may still be malicious.",
   "An application can ask you to authorize it without asking for your password directly.",
   "If you approve, it may receive a token that lets it use the permitted data and services.",
   "So signing in successfully does not mean that every request for access is safe.",
   "In September 2025, the United States Federal Bureau of Investigation warned that criminals posing as technical support had persuaded staff to connect malicious applications to business systems.",
   "The same warning described attackers abusing authorization tokens taken from a trusted external integration.",
   "Before approving, read the application name, the organization behind it and every permission requested.",
   "A document viewer does not need broad access to your messages, contacts or all your files.",
   "Do not approve an unfamiliar application because a caller, message or document tells you to do so.",
   "Lena closes the request and checks the supplier document through the Authority's approved procurement channel.",
   "The procurement record contains no revised document and no request to install or authorize an application.",
   "She reports the link and the permission screen through the approved route.",
   "If you approved such a request by mistake, report it immediately; removing the application yourself may not cancel every token or reveal what it accessed.",
   "The authorized team can revoke the application's access, end affected sessions and examine the account."
  ],
  "timing": [
   [
    0.76,
    7.144
   ],
   [
    7.524,
    14.532
   ],
   [
    14.912,
    20.48
   ],
   [
    20.86,
    26.116
   ],
   [
    26.496,
    32.184
   ],
   [
    32.564,
    38.156
   ],
   [
    38.536,
    51.112
   ],
   [
    51.492,
    58.26
   ],
   [
    58.64,
    65.624
   ],
   [
    66.004,
    72.46
   ],
   [
    72.84,
    78.792
   ],
   [
    79.172,
    85.868
   ],
   [
    86.248,
    93.328
   ],
   [
    93.707,
    97.715
   ],
   [
    98.095,
    108.391
   ],
   [
    108.771,
    115.275
   ]
  ],
  "T": 116.66
 },
 "4.08v": {
  "title": "The new phone that was not his",
  "texts": [],
  "sentences": [
   "On Thursday afternoon, the Sadeed IT service desk receives an urgent call from someone claiming to be Omar.",
   "The caller says his phone is broken and asks for a password reset and a new phone to be registered immediately.",
   "He knows Omar's full name, department and staff number.",
   "But information about a person is not proof that the caller is that person.",
   "Criminals impersonate staff and pressure helpdesks to bypass the normal recovery procedure.",
   "If they succeed, they can change the password and register a device they control.",
   "That device may then receive approval requests or act as a trusted way back into the account.",
   "A joint warning updated in July 2025 described criminals impersonating staff to helpdesks, forcing fraudulent resets and enrolling their own devices.",
   "The helpdesk officer does not use the phone number supplied by the caller.",
   "She follows the approved recovery procedure and calls Omar on the number already held in the official staff record.",
   "Omar answers from the hall and confirms that he made no request and that his phone is working.",
   "The officer refuses the reset, blocks the enrollment request and reports the attempted impersonation.",
   "Staff must never ask a colleague to bypass the identity check, even when the work seems urgent.",
   "If your account shows a device you do not recognize, do not remove it and continue as normal; report it immediately through the approved route.",
   "The authorized team can revoke the device, end active sessions, reset affected credentials and investigate what happened."
  ],
  "timing": [
   [
    0.76,
    7.36
   ],
   [
    7.74,
    14.508
   ],
   [
    14.888,
    18.584
   ],
   [
    18.964,
    23.716
   ],
   [
    24.096,
    30.288
   ],
   [
    30.668,
    35.756
   ],
   [
    36.136,
    42.544
   ],
   [
    42.924,
    53.532
   ],
   [
    53.912,
    58.28
   ],
   [
    58.66,
    65.452
   ],
   [
    65.832,
    71.376
   ],
   [
    71.756,
    78.164
   ],
   [
    78.543,
    84.76
   ],
   [
    85.139,
    93.539
   ],
   [
    93.919,
    101.647
   ]
  ],
  "T": 103.03
 },
 "4.09v": {
  "title": "One account, many cloud doors",
  "texts": [],
  "sentences": [
   "Early on Sunday morning, Hamad receives a security alert about activity in Omar's cloud account.",
   "A sign-in from outside the country was followed by access to email, files and the staff directory.",
   "The system accepted it because the attacker used valid identity information, obtained in a way not yet known.",
   "A valid sign-in does not always mean that the real account owner is present.",
   "One compromised identity can open several connected cloud services.",
   "The attacker may read messages, search files, gather contacts and send convincing requests in the employee's name.",
   "A 2026 threat report found that misuse of valid accounts caused 35 percent of the cloud incidents it examined.",
   "The same report found that 82 percent of the detections involved no malware.",
   "This means that an attack may look like ordinary work performed through an ordinary account.",
   "Shaima asks Omar whether he opened the files or signed in while traveling.",
   "Omar confirms that he did neither, and the team reports the alert immediately through the approved route.",
   "They do not reply to messages from the affected account or warn colleagues through that account.",
   "The authorized team disables the account temporarily, ends its active sessions, revokes suspicious tokens and checks what was accessed.",
   "The habits from this lesson are clear: do not reuse passwords, do not sign in from unexpected links, do not authorize unfamiliar applications, and do not accept unverified recovery or device requests.",
   "If an account behaves in a way you do not recognize, stop, verify through a known official channel and report early, even if the sign-in appears valid."
  ],
  "timing": [
   [
    0.76,
    7.528
   ],
   [
    7.908,
    14.484
   ],
   [
    14.864,
    21.608
   ],
   [
    21.988,
    27.172
   ],
   [
    27.552,
    32.328
   ],
   [
    32.708,
    40.124
   ],
   [
    40.504,
    48.808
   ],
   [
    49.188,
    54.42
   ],
   [
    54.8,
    59.984
   ],
   [
    60.364,
    65.188
   ],
   [
    65.568,
    71.808
   ],
   [
    72.188,
    77.18
   ],
   [
    77.559,
    86.415
   ],
   [
    86.795,
    100.235
   ],
   [
    100.615,
    110.047
   ]
  ],
  "T": 111.43
 },
 "4.10v": {
  "title": "Signed in does not mean allowed",
  "texts": [],
  "sentences": [
   "Later that Sunday morning, Shaima signs in at her counter and opens case file 2048.",
   "Her authentication tells the system that the person signing in is Shaima.",
   "But when she selects a finance panel, the system does not let her open it.",
   "Nothing has gone wrong; authentication and authorization answer two different questions.",
   "Authentication asks: who are you?",
   "Authorization asks: what are you allowed to see or do?",
   "A valid account should not automatically provide access to every file, system or administrative function.",
   "Saudi Arabia's Essential Cybersecurity Controls require access rights to follow need-to-know, need-to-use, least privilege and segregation of duties.",
   "Least privilege gives each user only the access their work needs; segregation of duties splits sensitive steps among different people.",
   "If Shaima's account were ever compromised, those limits would also restrict what an attacker could reach through it.",
   "Staff should never borrow a colleague's account because their own account lacks permission.",
   "They should never share an account to make a task faster.",
   "Shaima needs information from finance, so she sends the request through the approved workflow instead of trying to bypass the restriction.",
   "The finance officer sees only the information required for that part of case 2048 and returns the approved result.",
   "If your work genuinely requires additional access, request it through the official approval route; do not work around the control."
  ],
  "timing": [
   [
    0.76,
    6.688
   ],
   [
    7.068,
    12.54
   ],
   [
    12.92,
    17.36
   ],
   [
    17.74,
    23.284
   ],
   [
    23.664,
    26.304
   ],
   [
    26.684,
    30.74
   ],
   [
    31.12,
    38.368
   ],
   [
    38.748,
    49.212
   ],
   [
    49.592,
    58.808
   ],
   [
    59.188,
    65.908
   ],
   [
    66.288,
    71.04
   ],
   [
    71.42,
    74.66
   ],
   [
    75.04,
    83.007
   ],
   [
    83.387,
    91.307
   ],
   [
    91.687,
    99.463
   ]
  ],
  "T": 100.84
 },
 "4.11v": {
  "title": "The role, the case and the master key",
  "texts": [],
  "sentences": [
   "On Sunday afternoon, Hamad reviews who needs access to case file 2048.",
   "Shaima needs the case details because she is the caseworker assigned to the file.",
   "Rania needs only the payment fields required for the finance check.",
   "The system can assign these permissions according to each person's job role.",
   "This is role-based access control.",
   "A system can also check details of each request, such as the employee's department, the case classification, the approved device, or the place and time of access.",
   "This is attribute-based access control, and it can narrow access when the context changes.",
   "An administrator has broader powers and may be able to create accounts, change permissions or alter security settings.",
   "These privileged powers are like a master key, so they must not be used for ordinary email, browsing or daily office work.",
   "Saudi Arabia's Essential Cybersecurity Controls require privileged access to be restricted and managed, with identities and access rights reviewed periodically.",
   "A privileged account should belong to one accountable person, use strong authentication and be active only when the approved task requires it.",
   "Shared administrator accounts weaken accountability because the record may not show who performed an action.",
   "Hamad approves Shaima's case access and Rania's limited finance access, but he does not give either of them administrator privileges.",
   "If your role changes, or access is no longer needed, the permissions must be reviewed and removed through the approved process.",
   "Never keep extra access for convenience, and report any permission that appears broader than your work requires."
  ],
  "timing": [
   [
    0.76,
    6.328
   ],
   [
    6.708,
    11.844
   ],
   [
    12.224,
    16.304
   ],
   [
    16.684,
    20.668
   ],
   [
    21.048,
    23.688
   ],
   [
    24.068,
    34.268
   ],
   [
    34.648,
    40.336
   ],
   [
    40.716,
    48.444
   ],
   [
    48.824,
    57.008
   ],
   [
    57.388,
    67.756
   ],
   [
    68.136,
    76.824
   ],
   [
    77.204,
    83.996
   ],
   [
    84.376,
    93.016
   ],
   [
    93.395,
    101.363
   ],
   [
    101.743,
    109.111
   ]
  ],
  "T": 110.49
 },
 "4.12v": {
  "title": "Trusted yesterday, checked today",
  "texts": [],
  "sentences": [
   "On Monday morning, Shaima tries to open case file 2048 from a laptop in a meeting room.",
   "The system pauses because the device and access context differ from those at her usual counter.",
   "It asks Shaima to verify her identity again before continuing.",
   "This is not a judgment that Shaima cannot be trusted.",
   "It applies a Zero Trust principle: do not grant trust automatically because a person, device or connection is already inside the Authority.",
   "Each request is assessed using the identity, the device, the service and the context, usually without a new sign-in.",
   "An approved user on an unhealthy or unknown device may still be denied access.",
   "A familiar device may also face an additional check when the location, time or activity is unusual.",
   "Access is then limited to the information and actions required for the approved task.",
   "In June 2025, NIST published nineteen example implementations showing how organizations can apply a Zero Trust architecture.",
   "Zero Trust also requires continuous monitoring, because a safe session can become risky after it begins.",
   "If the risk changes, the system can request another verification, restrict an action or end the session.",
   "Shaima completes the additional check, and the system gives her only the access required for case 2048.",
   "Staff should not try another device, borrow an account or bypass a warning when access is blocked.",
   "If legitimate work is blocked, contact the official IT service desk and let the authorized team examine the identity, device and access request."
  ],
  "timing": [
   [
    0.76,
    7.336
   ],
   [
    7.716,
    13.14
   ],
   [
    13.52,
    18.152
   ],
   [
    18.532,
    21.964
   ],
   [
    22.344,
    31.608
   ],
   [
    31.988,
    40.316
   ],
   [
    40.696,
    46.48
   ],
   [
    46.86,
    54.876
   ],
   [
    55.256,
    60.872
   ],
   [
    61.252,
    70.444
   ],
   [
    70.824,
    77.952
   ],
   [
    78.332,
    85.244
   ],
   [
    85.624,
    93.159
   ],
   [
    93.539,
    99.827
   ],
   [
    100.207,
    110.359
   ]
  ],
  "T": 111.74
 },
 "4.13v": {
  "title": "Access that should have ended",
  "texts": [],
  "sentences": [
   "On Tuesday morning, Lena and Hamad review the external access list for a procurement project.",
   "One consultant's contract ended last month, but the account is still active.",
   "The account was legitimate when the consultant needed it, but that does not make the access permanent.",
   "Every identity has a lifecycle: it is created for a purpose, its access may change, and it must be removed when the need ends.",
   "That applies to employees, contractors, suppliers and other third parties.",
   "Saudi Arabia's Essential Cybersecurity Controls require identities and access rights to be reviewed periodically and include cybersecurity requirements for external parties.",
   "The risk is significant: the 2026 Data Breach Investigations Report found third parties involved in 48 percent of breaches, up from 30 percent.",
   "An external account should therefore have a named owner, a defined business purpose, only the access it needs and a clear end date.",
   "Temporary access should not quietly become permanent access.",
   "The same rule applies when an employee changes teams or responsibilities.",
   "New access may be required, but access from the old role may need to be removed.",
   "When a person leaves the Authority or an external contract ends, access should be withdrawn through the approved process without unnecessary delay.",
   "Lena verifies the contract end date in the official procurement record instead of relying on an email or a phone call.",
   "Hamad sends the expired account through the approved removal process and asks for the remaining contractor access to be reviewed.",
   "If you notice access that no longer matches someone's work, do not ignore it or remove it informally; report it through the approved route so the record and the access can be corrected together."
  ],
  "timing": [
   [
    0.76,
    6.784
   ],
   [
    7.164,
    12.108
   ],
   [
    12.488,
    18.224
   ],
   [
    18.604,
    27.772
   ],
   [
    28.152,
    33.288
   ],
   [
    33.668,
    44.636
   ],
   [
    45.016,
    55.384
   ],
   [
    55.764,
    64.14
   ],
   [
    64.52,
    68.84
   ],
   [
    69.22,
    74.068
   ],
   [
    74.448,
    80.064
   ],
   [
    80.444,
    89.444
   ],
   [
    89.823,
    97.311
   ],
   [
    97.691,
    105.611
   ],
   [
    105.991,
    117.031
   ]
  ],
  "T": 118.41
 },
 "4.14v": {
  "title": "Every identity, human or automated",
  "texts": [],
  "sentences": [
   "On Wednesday afternoon, Shaima completes case file 2048 and returns the approved result to the applicant.",
   "Behind the counter, Hamad reviews the identities that helped process the case.",
   "They include staff accounts, a finance application and an AI agent, a program that acts with some independence to sort non-sensitive requests for review.",
   "Automated applications and AI agents need governed identities just as people do.",
   "Each one should have its own identity, a defined owner and a clear business purpose.",
   "It should receive only the data, tools and actions required for its approved task.",
   "An AI agent that sorts requests does not need permission to approve payments, change identities or grant access.",
   "Its actions should be recorded and monitored, and important decisions should remain under the required human approval.",
   "In December 2025, the OWASP guidance for agentic applications named identity and privilege abuse as a leading security risk.",
   "In February 2026, NIST published a concept paper on identity and authorization for AI agents.",
   "When an application or agent changes purpose, its access must be reviewed; when it is retired, its identity and credentials must be removed.",
   "The chapter's first habit is to protect your accounts with the strongest sign-in the Authority provides, and a unique password wherever one is used.",
   "The second is to reject unexpected approvals, codes, recovery requests, devices and application permissions.",
   "The third is to give people, contractors, applications and AI agents only the access they need, for only as long as they need it.",
   "If an identity, device or request behaves unexpectedly, stop, verify through a known official channel and report early through the approved route.",
   "Shaima opens the next case, knowing that secure public service depends on verifying every identity and limiting every path to information and action."
  ],
  "timing": [
   [
    0.76,
    7.864
   ],
   [
    8.244,
    13.212
   ],
   [
    13.592,
    23.624
   ],
   [
    24.004,
    30.412
   ],
   [
    30.792,
    35.808
   ],
   [
    36.188,
    41.636
   ],
   [
    42.016,
    49.456
   ],
   [
    49.836,
    56.988
   ],
   [
    57.368,
    66.776
   ],
   [
    67.156,
    75.004
   ],
   [
    75.384,
    84.888
   ],
   [
    85.268,
    93.716
   ],
   [
    94.096,
    101.871
   ],
   [
    102.251,
    110.675
   ],
   [
    111.055,
    120.943
   ],
   [
    121.323,
    131.571
   ]
  ],
  "T": 132.95
 },
 "5.01v": {
  "title": "Read the label first",
  "texts": [],
  "sentences": [
   "On Thursday morning, the hall at the Sadeed Services Authority is busy, and Shaima opens a new case at the counter.",
   "Omar comes to her desk with a request from a colleague in another office, who wants the summary of case file 2048.",
   "Before she answers, Shaima looks at the sensitivity level written on the document.",
   "Every item of information the Authority holds has a sensitivity level.",
   "The level shows how much harm a disclosure could cause, and who may see the information.",
   "Saudi Arabia's national data classification policy, issued in 2020, uses four levels: top secret, secret, restricted and public.",
   "In May 2026, Qatar's National Cyber Security Agency described the same order of work: list the data, classify it, then protect it.",
   "A level is set when information is created or received, and mixed information takes the highest level it contains.",
   "The summary holds the applicant's name, identity number, address and phone number, which are personal data.",
   "UAE law, issued in 2021, defines personal data as any data that identifies a person, directly or indirectly, such as a name, voice, image, identification number or location.",
   "The summary also mentions the applicant's health condition, and information about health, family or ethnic origin, religion or a criminal record is sensitive personal data.",
   "Employee records, such as salary and personnel files, need the same care, and each set of records has an owner in the Authority.",
   "Confidential institutional information, such as internal plans and system details, is protected even when no person is named.",
   "Shaima sees that the summary is restricted, and that Omar's colleague has no part in the case, so the need to know is not met.",
   "She does not send it, and she asks Omar to pass the request to the owner of the record, who decides.",
   "If a level is missing or unclear, ask the owner before you share anything.",
   "If something was shared by mistake, report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    7.912
   ],
   [
    8.292,
    15.276
   ],
   [
    15.656,
    20.792
   ],
   [
    21.172,
    25.948
   ],
   [
    26.328,
    31.656
   ],
   [
    32.036,
    42.14
   ],
   [
    42.52,
    52.288
   ],
   [
    52.668,
    59.748
   ],
   [
    60.128,
    66.464
   ],
   [
    66.844,
    80.98
   ],
   [
    81.36,
    91.68
   ],
   [
    92.06,
    100.076
   ],
   [
    100.456,
    109.12
   ],
   [
    109.499,
    117.467
   ],
   [
    117.847,
    124.375
   ],
   [
    124.755,
    129.675
   ],
   [
    130.055,
    134.423
   ]
  ],
  "T": 135.8
 },
 "5.02v": {
  "title": "Send it safely, or not at all",
  "texts": [],
  "sentences": [
   "Later the same morning, a call comes to Shaima's desk from someone who says he works in a partner office.",
   "The caller asks her to email the supporting documents of case file 2048 to a personal mailbox, because the official system is slow.",
   "His voice is calm and sure, and he says the matter is urgent.",
   "Shaima remembers that confidentiality means only people who are allowed may see the information.",
   "Confidentiality must hold while information is stored, and also while it is on the move.",
   "In September 2025, the UAE Cyber Security Council issued a national policy on the security of data exchange.",
   "It covers classification and handling of data, access control, encryption and prevention of data leakage.",
   "Encryption makes information unreadable to anyone who intercepts it, and the UAE personal data law lists it among the protective measures.",
   "A personal mailbox is outside the Authority's controls: no approved encryption, no Authority record, and no way for the Authority to take the message back.",
   "In June 2025, Europol, the European police agency, reported that stolen data is traded and reused like a commodity, and that social engineering is a particularly common way to obtain it.",
   "In April 2026, the FBI's internet crime report described scammers using fake profiles, cloned voices, identity documents and videos, and advised people to take a beat and resist pressure to act fast.",
   "A familiar voice or a confident tone is not proof of identity.",
   "Shaima sends nothing, ends the call politely, and phones the partner office on the number in the official directory.",
   "The office confirms that nobody there made the request.",
   "When information must be exchanged, check its level, confirm the recipient needs it, use the approved channel, and share only what is required.",
   "Report any unusual request for information through the approved route, so the security team can warn others."
  ],
  "timing": [
   [
    0.76,
    6.544
   ],
   [
    6.924,
    16.332
   ],
   [
    16.712,
    21.032
   ],
   [
    21.412,
    27.724
   ],
   [
    28.104,
    33.408
   ],
   [
    33.788,
    42.14
   ],
   [
    42.52,
    49.624
   ],
   [
    50.004,
    59.244
   ],
   [
    59.624,
    69.848
   ],
   [
    70.228,
    83.092
   ],
   [
    83.472,
    97.272
   ],
   [
    97.652,
    102.02
   ],
   [
    102.4,
    109.216
   ],
   [
    109.595,
    113.003
   ],
   [
    113.383,
    122.095
   ],
   [
    122.475,
    129.123
   ]
  ],
  "T": 130.5
 },
 "5.03v": {
  "title": "Open to anyone, kept too long",
  "texts": [],
  "sentences": [
   "On Thursday afternoon, Hamad stops at Omar's desk with a list of case files whose sharing settings he is checking.",
   "Omar had shared the working papers of case file 2048 with a contractor, through a link that anyone can open.",
   "The contractor finished two days ago, but the link still works.",
   "Information needs protection for its whole life: while it is stored, while it is shared, and when it is no longer needed.",
   "Saudi Arabia's Essential Cybersecurity Controls, updated in 2024, use four colour markings to show who may receive shared material.",
   "Amber material may be shared only inside the entity, with those who must act on it, and green material must never go to public platforms.",
   "A link that anyone can open ignores these limits, because the owner no longer knows who has it.",
   "In 2025, Verizon's breach report found that third-party involvement in breaches had doubled in one year, from fifteen to thirty percent.",
   "A summary of the same report adds that forty-six percent of compromised systems holding company credentials were devices the organisation did not manage.",
   "Omar changes the folder so that only named people can open it, with the lowest level of access they need, and he removes the contractor.",
   "Files of the Authority stay in approved locations, never on personal phones, personal drives or private mailboxes.",
   "Hamad explains retention: each type of record has a period set by the Authority's rules and the law, and it is kept for that period, longer only under a legal hold.",
   "In September 2025, the United States standards institute NIST published new guidance on media sanitization.",
   "It asks each organisation to run a media sanitization program, and to choose the method of erasing or destroying media by the sensitivity of the information.",
   "An old laptop from the counter waits in a cupboard, and Hamad sends it through the approved disposal route, because deleting files is not always enough.",
   "If you find a folder, device or document open to people who should not see it, close it if you are allowed to, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    7.48
   ],
   [
    7.86,
    15.156
   ],
   [
    15.536,
    19.52
   ],
   [
    19.9,
    27.532
   ],
   [
    27.912,
    37.416
   ],
   [
    37.796,
    46.484
   ],
   [
    46.864,
    52.6
   ],
   [
    52.98,
    62.196
   ],
   [
    62.576,
    72.632
   ],
   [
    73.012,
    81.916
   ],
   [
    82.296,
    90.792
   ],
   [
    91.172,
    101.54
   ],
   [
    101.919,
    109.888
   ],
   [
    110.267,
    120.371
   ],
   [
    120.751,
    130.231
   ],
   [
    130.611,
    139.443
   ]
  ],
  "T": 140.82
 },
 "5.04v": {
  "title": "Sent to the wrong place",
  "texts": [],
  "sentences": [
   "At the end of Thursday, Shaima prepares a list of pending cases for the finance office.",
   "She types the first letters of the name, the mail program completes the address, and she presses send.",
   "Seconds later, she sees that the address belongs to an outside organisation with a similar name.",
   "The list holds the names, identity numbers and case status of applicants.",
   "Leakage means information leaves the Authority's control, and unauthorized disclosure means someone with no right to it can see it.",
   "It does not need an attacker, because a wrong recipient, an open link or a document left on the printer is enough.",
   "In 2025, an industry breach report found a human element in about sixty percent of breaches, including errors and social engineering.",
   "In the same year, a major technology company reported that attackers sought to steal data in eighty percent of the incidents it investigated.",
   "Saudi Arabia's data protection regulation defines a personal data breach as any incident that leads to disclosure, destruction or unauthorized access, whether intentional or accidental.",
   "The UAE personal data law, in force since January 2022, applies outside government and requires prompt breach reporting, and anyone processing data for the responsible body must tell it immediately.",
   "Whatever law applies, the Authority must learn of an incident quickly, and the response team, not the staff member, decides how serious it is.",
   "Shaima stops, and she does not hide the email, delete it quietly or try to fix it alone.",
   "She reports at once through the approved route, saying what was sent, to whom and when, and she contacts the recipient only if the response team asks her to.",
   "The Authority's privacy principles are simple: collect only what is needed, use it only for its stated purpose, and give access by duty.",
   "Keep information only as long as required, and then dispose of it safely.",
   "Bahrain's 2022 order on protective measures asks for the same, with access limited to each employee's duties and retention and disposal under control.",
   "The habit for every member of staff is to check the level, share through approved channels with named people, keep only what is required, and report any leak at once."
  ],
  "timing": [
   [
    0.76,
    5.968
   ],
   [
    6.348,
    12.78
   ],
   [
    13.16,
    19.448
   ],
   [
    19.828,
    24.796
   ],
   [
    25.176,
    33.0
   ],
   [
    33.38,
    40.34
   ],
   [
    40.72,
    49.888
   ],
   [
    50.268,
    59.316
   ],
   [
    59.696,
    71.552
   ],
   [
    71.932,
    85.684
   ],
   [
    86.064,
    95.328
   ],
   [
    95.708,
    101.9
   ],
   [
    102.279,
    111.784
   ],
   [
    112.163,
    121.139
   ],
   [
    121.519,
    126.439
   ],
   [
    126.819,
    136.731
   ],
   [
    137.111,
    146.927
   ]
  ],
  "T": 148.31
 },
 "5.05v": {
  "title": "The helper nobody approved",
  "texts": [],
  "sentences": [
   "On the next working morning, Shaima notices Omar typing fast on his phone at the counter, with a pile of applicant letters beside him.",
   "He has opened a free AI chat app that he found on his own, and he is about to paste in the summary of case file 2048 so that it will write a reply letter for him.",
   "The app is not on the Authority's approved list, and the Authority has never reviewed how it stores or uses what it receives.",
   "Using generative AI tools that the institution has not approved, often through a personal account, is shadow AI.",
   "In July 2025, an annual breach study found that sixty-three percent of the breached organisations it examined had no AI governance policy or were still developing one, and one in five reported a breach linked to unapproved AI.",
   "Organisations with high levels of unapproved AI paid, on average, about USD 670,000 more per breach than those with little or none.",
   "In January 2026, a cloud security report found that forty-seven percent of generative AI users were using personal AI apps.",
   "Everything typed or pasted into an unapproved tool is sent to a service outside the Authority's control, and the Authority cannot take it back.",
   "Omar's draft holds the applicant's name, identity number and health condition, which are personal data, and partly sensitive personal data.",
   "In October 2025, a study of browser activity in companies found that seventy-seven percent of AI users pasted data into prompts, and eighty-two percent of those pastes came from personal accounts outside company control.",
   "The January 2026 report also found that incidents of staff sending sensitive data to AI apps had doubled in a year, to an average of two hundred and twenty-three a month in each organisation.",
   "In August 2026, the UAE Cyber Security Council advised the public never to give financial data, identity documents or health records to an AI service, and warned that some AI tools found through online searches may be designed to collect personal data.",
   "Saudi Arabia's data and AI authority tells government employees to use generative AI only where they can identify the risks and reduce them.",
   "Shaima asks Omar to stop before he pastes anything, and he closes the app with no case information entered.",
   "Case details, names, identity numbers and internal documents stay out of any AI tool the Authority has not approved.",
   "If you are unsure whether a tool is approved, ask the security team through a known official channel.",
   "If you have already pasted information into an unapproved tool, report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.944
   ],
   [
    9.324,
    19.188
   ],
   [
    19.568,
    27.296
   ],
   [
    27.676,
    35.14
   ],
   [
    35.52,
    50.424
   ],
   [
    50.804,
    61.124
   ],
   [
    61.504,
    70.6
   ],
   [
    70.98,
    80.22
   ],
   [
    80.6,
    89.408
   ],
   [
    89.788,
    104.524
   ],
   [
    104.904,
    117.408
   ],
   [
    117.788,
    134.18
   ],
   [
    134.56,
    144.28
   ],
   [
    144.659,
    151.547
   ],
   [
    151.927,
    160.351
   ],
   [
    160.731,
    166.659
   ],
   [
    167.039,
    173.327
   ]
  ],
  "T": 174.71
 },
 "5.06v": {
  "title": "One click, a whole file gone",
  "texts": [],
  "sentences": [
   "That afternoon, a long medical report arrives for case file 2048, written partly in a language Shaima reads slowly.",
   "Omar leans over with his laptop and shows her a website he found through a search.",
   "The site promises to translate and summarise any file for free, and all it asks is that you upload the document.",
   "Shaima reads the first page of the report: the applicant's full name, identity number, diagnoses and prescriptions.",
   "Health information is sensitive personal data, and the applicant gave it to the Authority only so that case file 2048 could be assessed.",
   "Uploading a file sends a complete copy to a service outside the Authority's control, and the Authority cannot call it back.",
   "In October 2025, a study of browser activity in companies found that about forty percent of the files uploaded to generative AI tools contained personal or payment card data.",
   "In August 2026, the UAE Cyber Security Council advised the public never to give financial data, identity documents or health records to an AI service.",
   "The council also warned that some AI tools found through online searches may be designed to collect personal data without the user knowing.",
   "For documents of their own, it suggests removing names and identity numbers first, but the files of the Authority follow a stricter rule.",
   "They go only into tools the Authority has approved, and only in the way its rules allow.",
   "Saudi Arabia's guidance for government employees takes the same direction, and warns against putting state data into outside commercial AI tools that no one has reviewed.",
   "Shaima does not upload the report, and she tells Omar that a fast answer is not worth a copy of a patient's record sitting on an unknown site.",
   "She asks, through the approved route, for the report to be translated with a tool or a translator that the Authority has approved.",
   "Before you upload any file to an AI service, ask three things: is the tool approved, may this file leave the Authority, and does the task really need the whole file.",
   "If a file has already gone to an unapproved service, do not upload more, and do not try to fix it alone.",
   "Report at once through the approved route, and say which file, which service and when."
  ],
  "timing": [
   [
    0.76,
    9.544
   ],
   [
    9.924,
    14.748
   ],
   [
    15.128,
    22.832
   ],
   [
    23.212,
    30.796
   ],
   [
    31.176,
    40.704
   ],
   [
    41.084,
    49.292
   ],
   [
    49.672,
    61.408
   ],
   [
    61.788,
    72.924
   ],
   [
    73.304,
    81.176
   ],
   [
    81.556,
    90.244
   ],
   [
    90.624,
    96.192
   ],
   [
    96.572,
    106.796
   ],
   [
    107.175,
    116.296
   ],
   [
    116.675,
    124.427
   ],
   [
    124.807,
    136.303
   ],
   [
    136.683,
    142.779
   ],
   [
    143.159,
    148.679
   ]
  ],
  "T": 150.06
 },
 "5.07v": {
  "title": "The guest nobody invited",
  "texts": [],
  "sentences": [
   "Hamad holds a short review of case file 2048 in the small meeting room, with Shaima and Omar present and a colleague from a partner office on the screen.",
   "A minute after the start, a new name appears in the participant list: an AI notetaker.",
   "Nobody in the room invited it, because it joined by itself through the partner colleague's calendar invitation, and it is already recording.",
   "Hamad pauses the discussion and asks everyone to stop talking about the case.",
   "An AI notetaker records the voices, turns them into a written transcript, and writes a summary with follow-up tasks.",
   "The processing and storage usually happen in cloud services run by an outside company, which is a third party that the Authority does not control.",
   "Depending on the provider's terms, it may keep the data, analyse it, or use it to train its own AI models.",
   "In February 2026, a law firm warned that stores of meeting audio and transcripts are attractive targets for attackers, and that tools staff add on their own bypass the controls of the technology team.",
   "In April 2026, another law firm noted that transcripts are durable and searchable, are often kept indefinitely, and can be requested for disclosure later.",
   "In October 2025, a risk adviser noted that these tools can mis-transcribe, invent words to fill gaps, and give a sentence to the wrong speaker.",
   "If nobody reviews the notes before they are filed, those errors can become part of the official record.",
   "Voice is personal data under UAE law, and some tools analyse voices to tell speakers apart.",
   "In 2025 and 2026, lawsuits in the United States alleged that such analysis created voiceprints without consent.",
   "So the Authority decides whether a meeting may be recorded and with which approved tool, participants are told before recording starts, and their consent is taken where the rules require it.",
   "Hamad asks the partner colleague to remove the notetaker, and he reports through the approved route what was said while it was connected.",
   "Before a sensitive meeting, ask whether recording is allowed, use only an approved tool, and tell everyone first.",
   "After the meeting, review the notes, and keep them only in the approved location.",
   "If a notetaker you do not know joins a call, pause the sensitive discussion and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    10.264
   ],
   [
    10.644,
    16.5
   ],
   [
    16.88,
    24.464
   ],
   [
    24.844,
    29.764
   ],
   [
    30.144,
    37.776
   ],
   [
    38.156,
    47.036
   ],
   [
    47.416,
    54.448
   ],
   [
    54.828,
    66.948
   ],
   [
    67.328,
    77.576
   ],
   [
    77.956,
    87.532
   ],
   [
    87.912,
    93.84
   ],
   [
    94.22,
    100.796
   ],
   [
    101.175,
    110.175
   ],
   [
    110.555,
    121.667
   ],
   [
    122.047,
    129.391
   ],
   [
    129.771,
    137.355
   ],
   [
    137.735,
    142.847
   ],
   [
    143.227,
    149.803
   ]
  ],
  "T": 151.18
 },
 "5.08v": {
  "title": "One Allow opens every door",
  "texts": [],
  "sentences": [
   "On Monday morning, Omar shows Shaima a new AI assistant app on his phone, which he found on his own and linked to his work account.",
   "The app asked to connect his mail, calendar and shared folders, and he tapped Allow on every screen.",
   "Shaima reads the permission screen: the app can read all files, send messages in his name, and stay connected without asking again.",
   "In August 2026, the UAE Cyber Security Council said the biggest privacy risk of an AI tool may not be what a user types, but what the tool is allowed to access.",
   "It advised people to review every permission request and to grant only what the tool genuinely needs.",
   "In May 2026, cyber agencies from five countries, including the United States, the United Kingdom and Australia, published guidance on AI agents that says to avoid broad or unrestricted access, especially to sensitive data.",
   "A connected assistant often borrows the rights of the person who linked it, so an unknown service now reaches everything Omar's account can reach.",
   "Omar asks the assistant for a list of pending cases, and because another department's folder was shared too widely, the answer includes names he has no right to see.",
   "In July 2026, a cloud security report described this problem, an AI service returning data the user is not authorised to access, and measured a rise from twelve to thirty-one cases a week per organisation in a year.",
   "The same report saw traffic from a common method of connecting AI tools to files and data grow four times in ten weeks.",
   "So check every AI output before you copy it, send it or file it.",
   "In December 2025, the UK National Cyber Security Centre warned that AI models cannot reliably tell instructions from the text they read, so hidden text can act as a command, and that systems should be limited in what they can do.",
   "Hamad comes over, removes the assistant's access in the list of connected apps, and reports it through the approved route, and the security team decides whether anything was exposed.",
   "Removing the connection and revoking its access stops new access, but it may not erase what the provider has already copied.",
   "Before you connect any AI tool to your mail, files or calendar, ask the security team whether it is approved and what access it will get.",
   "Give only the least privilege the task needs, refuse requests for all files, and decline anything the task does not need.",
   "If you have already connected a tool, or it shows you data you have no right to see, stop and report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    9.064
   ],
   [
    9.444,
    16.164
   ],
   [
    16.544,
    24.92
   ],
   [
    25.3,
    37.66
   ],
   [
    38.04,
    44.448
   ],
   [
    44.828,
    60.74
   ],
   [
    61.12,
    70.24
   ],
   [
    70.62,
    80.46
   ],
   [
    80.84,
    95.36
   ],
   [
    95.74,
    104.164
   ],
   [
    104.544,
    109.224
   ],
   [
    109.604,
    123.956
   ],
   [
    124.335,
    135.136
   ],
   [
    135.515,
    143.171
   ],
   [
    143.551,
    152.695
   ],
   [
    153.075,
    161.139
   ],
   [
    161.519,
    169.535
   ]
  ],
  "T": 170.91
 },
 "5.09v": {
  "title": "The helper inside the browser",
  "texts": [],
  "sentences": [
   "On Tuesday morning, Shaima starts the shared laptop at the counter and sees a new icon in the corner of the browser.",
   "Omar explains that he added a free AI assistant to summarise pages and draft short replies.",
   "The assistant opens in a side panel on every page, including the Authority's case system.",
   "Shaima reads its permission list: it can read and change data on every website, and it can see every address that is opened.",
   "A browser extension runs inside the browser, so it can read whatever appears on the page, including what is typed and what an AI assistant answers.",
   "In March 2026, security researchers at a large technology company reported look-alike AI assistant extensions with about nine hundred thousand installs, and activity in more than twenty thousand organisations, collecting full web addresses and AI chat content.",
   "In December 2025, a security firm reported two such extensions, with six hundred thousand and three hundred thousand installs, and one of them carried a store badge marking it as featured.",
   "They asked for consent to collect anonymous analytics, while sending conversations to the attackers every thirty minutes, so a badge or a polite consent screen is not proof of safety.",
   "An update can change what an extension does: in July 2025, a free privacy extension added code that copied AI conversations, and related extensions reached more than eight million users.",
   "The same March 2026 findings noted that some AI-powered browsers added look-alike extensions without asking the user.",
   "An assistant built into the browser can reach pages in a similar way, and researchers have shown that hidden instructions in a web link can trick it into acting without the user knowing.",
   "Shaima does not click Allow on anything, and she asks Omar to stop using the assistant.",
   "Hamad reports it through the approved route, and the technology team reviews the list of extensions on the shared laptop.",
   "In April 2026, a research note on cloud security advised organisations to allow only approved extensions and to check the permissions of each one.",
   "So never add an AI extension or assistant to a work browser unless the Authority has approved it, and decline any request to read all websites.",
   "Before you use, upload to, connect or install any AI tool, ask three things: is it approved, what can it see, and where does the information go.",
   "If an icon, panel or assistant appears that you did not add, stop and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    7.432
   ],
   [
    7.812,
    14.652
   ],
   [
    15.032,
    21.2
   ],
   [
    21.58,
    30.004
   ],
   [
    30.384,
    39.504
   ],
   [
    39.884,
    57.692
   ],
   [
    58.072,
    69.808
   ],
   [
    70.188,
    81.756
   ],
   [
    82.136,
    94.928
   ],
   [
    95.308,
    103.9
   ],
   [
    104.28,
    114.408
   ],
   [
    114.788,
    120.428
   ],
   [
    120.808,
    128.055
   ],
   [
    128.435,
    138.419
   ],
   [
    138.799,
    148.735
   ],
   [
    149.115,
    159.123
   ],
   [
    159.503,
    165.983
   ]
  ],
  "T": 167.36
 },
 "5.10v": {
  "title": "On the list, or not",
  "texts": [],
  "sentences": [
   "On Wednesday morning, Hamad gathers the counter team in the Sadeed hall before the doors open.",
   "He announces that the Authority has opened its first approved AI assistant for administrative work, and he shows it on the large screen.",
   "Omar asks what makes it different, since every AI tool looks alike on a screen.",
   "Hamad answers that an approved environment is one the Authority has reviewed, listed and given an owner.",
   "Staff sign in to it with their work account, and its rules say which levels of information may be entered.",
   "Its use is recorded, so the Authority can review it and act if something goes wrong.",
   "An unapproved tool has no Authority review, owner or rules, and the Authority may not even know it exists.",
   "In September 2025, the UAE Cyber Security Council issued a national cybersecurity policy for artificial intelligence, revised in November 2025, which asks for a governance framework with enforceable policies and an accurate inventory of AI assets.",
   "An institution cannot protect a tool it does not know it is using.",
   "In July 2025, an annual breach study found that sixty-three percent of the breached organisations had no AI governance policy or were still developing one, and that among those with a policy, only thirty-four percent checked regularly for unapproved AI.",
   "In July 2026, Bahrain's National Cyber Security Centre ran a national campaign asking employees to use approved AI tools in line with their organisation's policies, so that sensitive and personal data does not leak.",
   "In May 2026, the UAE Cyber Security Council and its partners announced a platform that runs AI inside UAE-controlled infrastructure, with a framework that validates, governs and monitors AI models and agents before they enter sensitive environments.",
   "But approved does not mean open to everything: each approved tool is approved for a stated purpose and for stated levels of information, so you still read the label first.",
   "Shaima opens the list and reads, beside the new assistant, the purpose it is approved for and the levels of information allowed in it, before she uses it.",
   "Use only the AI tools on the approved list, and only through your work account.",
   "If a tool is not on the list, ask the security team through a known official channel, and if you see an unapproved tool in use, report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    6.592
   ],
   [
    6.972,
    15.108
   ],
   [
    15.488,
    20.768
   ],
   [
    21.148,
    27.724
   ],
   [
    28.104,
    34.656
   ],
   [
    35.036,
    40.292
   ],
   [
    40.672,
    48.76
   ],
   [
    49.14,
    66.276
   ],
   [
    66.656,
    71.048
   ],
   [
    71.428,
    88.276
   ],
   [
    88.656,
    103.776
   ],
   [
    104.156,
    121.196
   ],
   [
    121.576,
    132.28
   ],
   [
    132.659,
    142.235
   ],
   [
    142.615,
    147.295
   ],
   [
    147.675,
    157.275
   ]
  ],
  "T": 158.66
 },
 "5.11v": {
  "title": "Only what the task needs",
  "texts": [],
  "sentences": [
   "On Thursday morning, Shaima has a stack of reply letters to write, and she opens the approved AI assistant with her work account.",
   "She asks herself one question before she types: what does this task really need?",
   "A reply letter needs the subject, the wording of the decision and the next step, but it does not need the applicant's name, identity number, address or medical details.",
   "Saudi Arabia's personal data law sets this as a principle of minimum personal data: the content is limited to what the purpose requires.",
   "Bahrain's government policy on AI, issued in May 2025, counts names, addresses, account numbers, medical records and criminal records as sensitive data.",
   "Saudi Arabia's regulation defines pseudonymisation as turning the main identifiers into codes, while the extra information that links a code to a person is kept separately.",
   "It defines anonymisation as removing direct and indirect identifiers for good, so that the person can no longer be identified.",
   "In March 2025, the UK data protection regulator explained that pseudonymised data is still personal data, because pseudonymisation reduces risk but is not anonymisation.",
   "So Shaima replaces the name with a temporary code, leaves out the identity number, address and diagnosis, and keeps the table that links the code to the applicant in the Authority's case system, never in the assistant.",
   "She also removes details that look harmless alone, such as a small village, a rare condition or an exact date, because together they can point to one person.",
   "International guidance points the same way: scrub or mask sensitive content, and, as cyber agencies from five countries advised in May 2026, start with low-risk tasks that involve no sensitive data.",
   "Oman's 2025 policy stresses human oversight of sensitive decisions, and Bahrain's policy keeps the final decision in important matters under human control.",
   "So the assistant may suggest wording, but decisions on approval, eligibility and payment stay with staff.",
   "Shaima reads the draft, adds the real details inside the case system, and signs the letter herself.",
   "Before you type into any AI tool, remove what the task does not need, use codes only where an identifier is truly needed, and keep the linking table outside the tool.",
   "If the task cannot be done without personal data, ask the record owner or the security team through a known official channel.",
   "If you have already entered more than you should, report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.584
   ],
   [
    8.964,
    14.46
   ],
   [
    14.84,
    25.304
   ],
   [
    25.684,
    35.308
   ],
   [
    35.688,
    46.44
   ],
   [
    46.82,
    57.884
   ],
   [
    58.264,
    66.784
   ],
   [
    67.164,
    79.212
   ],
   [
    79.592,
    92.72
   ],
   [
    93.1,
    102.988
   ],
   [
    103.368,
    117.0
   ],
   [
    117.38,
    128.492
   ],
   [
    128.871,
    136.119
   ],
   [
    136.499,
    143.363
   ],
   [
    143.743,
    154.471
   ],
   [
    154.851,
    162.483
   ],
   [
    162.863,
    167.783
   ]
  ],
  "T": 169.16
 },
 "5.12v": {
  "title": "Sure of itself, and wrong",
  "texts": [],
  "sentences": [
   "On Monday morning, Hamad asks Omar for a short note on the rules that apply to a late request in case file 2048.",
   "Omar opens the Authority's approved AI assistant with his work account and asks it for the rules and their reference numbers.",
   "In seconds, the assistant returns a tidy note with article numbers, a circular number and a quotation from a policy, all in a calm and sure tone.",
   "Omar is about to paste it into his report when Shaima passes by and asks one question: where is this circular?",
   "When an AI tool invents facts, references or quotations, this is called hallucination, and the invented answer can read smoothly and sound sure, so a confident tone is no proof.",
   "The generative AI profile of the United States standards institute NIST, published in July 2024, lists this kind of confident false output among twelve risks that are specific to generative AI or made worse by it.",
   "In October 2025, twenty-two public media organisations in eighteen countries and fourteen languages tested leading AI assistants on questions about the news and reviewed more than three thousand answers.",
   "They found that forty-five percent of the answers had at least one significant problem, thirty-one percent had serious sourcing problems, and twenty percent had major accuracy problems, including invented or outdated details.",
   "In July 2025, a large consulting firm delivered a report worth about four hundred and forty thousand Australian dollars to a government department, and it contained references to research that does not exist and a made-up quotation from a court judgment.",
   "An outside academic found the errors, and in October 2025 the firm disclosed that generative AI had been used and agreed to repay the last instalment of its contract.",
   "In July 2026, Bahrain's National Cyber Security Centre asked employees to check AI outputs for inaccuracies, bias and manipulation before they use them, share them or decide on them.",
   "Shaima and Omar search the Authority's official register, and they find no such circular, and the quotation is not in the policy.",
   "Omar deletes those lines and writes the note again from the official text, which Shaima reads with him.",
   "Treat every AI answer as a draft, never as a source.",
   "Check the parts that look most exact: article and circular numbers, names, dates, figures, quotations and references.",
   "Confirm each one in the official text or with a known contact, and if you cannot find it, do not use it.",
   "If an AI error has already reached a document, a decision or an applicant, report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    9.328
   ],
   [
    9.708,
    17.436
   ],
   [
    17.816,
    27.632
   ],
   [
    28.012,
    35.236
   ],
   [
    35.616,
    48.912
   ],
   [
    49.292,
    63.332
   ],
   [
    63.712,
    76.912
   ],
   [
    77.292,
    91.26
   ],
   [
    91.64,
    106.52
   ],
   [
    106.9,
    118.324
   ],
   [
    118.704,
    131.448
   ],
   [
    131.828,
    140.156
   ],
   [
    140.536,
    146.823
   ],
   [
    147.203,
    151.547
   ],
   [
    151.927,
    160.567
   ],
   [
    160.947,
    167.955
   ],
   [
    168.335,
    175.583
   ]
  ],
  "T": 176.96
 },
 "5.13v": {
  "title": "Polished is not proven",
  "texts": [],
  "sentences": [
   "On Wednesday morning, Hamad asks Omar for a one-page summary of this month's pending requests, for the management meeting at noon.",
   "Omar gives the approved AI assistant a table of request counts and waiting times, with codes instead of names, and asks it to write the analysis.",
   "In seconds, a tidy report appears: waiting times fell sharply, here is the reason, and here are three recommendations.",
   "Omar is pleased, but Shaima knows that a fluent report can hide wrong input, wrong arithmetic and invented reasons, so she asks which figures the assistant used and whether they match the case system.",
   "In May 2025, cyber agencies from the United States, the United Kingdom, Australia and New Zealand stressed that the security of the data an AI system uses is critical to the accuracy, integrity and trustworthiness of its results.",
   "In November 2025, documents released in Australia showed that staff of a government department had found fifty-nine possible errors in an AI-assisted consultant's report during a quick review of their own, and that almost all the references concerned were later corrected or removed.",
   "UK government guidance for public bodies, updated in August 2026, says that the responses of generative AI systems must be examined and sanitised before they are returned.",
   "Saudi guidance for government employees calls for critical thinking and caution with AI output, and at the Authority a named person reviews it before official use.",
   "Shaima and Omar open the case system and recount the three main figures from the source records.",
   "Two of the figures do not match: the assistant compared five weeks of one type of request with four weeks of another, so the fall in waiting times was not real.",
   "The paragraph that explained why waiting times fell has no support in the table: the assistant had invented a reason that sounded sensible.",
   "Omar corrects the figures, asks the case team for the real explanation, and adds a line saying that an AI assistant helped draft the report and that two members of staff checked the figures against the case system.",
   "Hamad signs as the reviewer, and the report goes to management under the names of the people who checked it, not under the name of the tool.",
   "Before you rely on an AI analysis, check that the data you gave it was right and complete, recalculate the key figures yourself from the source, and trace each claim to evidence.",
   "Treat any explanation that the data does not show as a guess, not as a finding.",
   "For an important report, ask a second person to review it, and say in the document that AI helped.",
   "If AI results look strange or disagree with the case system, stop, check with the owner of the data through a known official channel, and report through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.992
   ],
   [
    9.372,
    19.308
   ],
   [
    19.688,
    28.64
   ],
   [
    29.02,
    41.332
   ],
   [
    41.712,
    57.264
   ],
   [
    57.644,
    73.724
   ],
   [
    74.104,
    85.792
   ],
   [
    86.172,
    96.396
   ],
   [
    96.776,
    103.16
   ],
   [
    103.54,
    113.644
   ],
   [
    114.024,
    122.736
   ],
   [
    123.116,
    135.908
   ],
   [
    136.287,
    144.976
   ],
   [
    145.355,
    157.043
   ],
   [
    157.423,
    163.231
   ],
   [
    163.611,
    170.091
   ],
   [
    170.471,
    180.695
   ]
  ],
  "T": 182.07
 },
 "5.14v": {
  "title": "A name under every decision",
  "texts": [],
  "sentences": [
   "On Thursday morning, Hamad reviews the day's replies at the counter, with Shaima and Omar beside him.",
   "One draft, prepared by the approved AI assistant, refuses a late request for case file 2048 in a polite and sure tone.",
   "The letter is ready to send with one click, and Shaima asks who decided on the refusal.",
   "Nobody did: the assistant suggested the refusal, and a decision that affects a person's rights, a payment or a service stays with a named member of staff.",
   "In September 2025, the UAE Cyber Security Council's AI security policy listed human oversight in critical decision-making among its operational safety requirements.",
   "In May 2026, cyber agencies from five countries wrote that, for AI agents, strong governance, explicit accountability, rigorous monitoring and human oversight are essential.",
   "Shaima reads the file and finds that the applicant has a valid reason, supported by a document that the assistant never saw because it sits in another folder.",
   "Hamad, who owns the decision, approves a new letter under his own name, and the file records that AI helped to draft it and who checked it.",
   "Text written with AI becomes institutional content once it is used for the Authority's business, so it needs an owner, a review, a note that AI helped, and a place in an approved location.",
   "In July 2026, Saudi Arabia's National Cybersecurity Authority opened a public consultation on draft AI cybersecurity guidelines that cover governance, defence, resilience and third parties.",
   "The five-country guidance also warns that opaque AI makes accountability hard to trace, so the Authority records how the assistant is used and limits what it can reach.",
   "The chapter's first habit is to check the level of every piece of information, share it only with named people who need it through approved channels, and keep it only as long as required.",
   "The second is to use only AI tools the Authority has approved, through your work account, and to keep confidential and personal information out of every prompt, upload, permission, extension and meeting recorder that has not been approved.",
   "The third is to treat every AI output as a draft, check it before you use it, and keep a named person responsible for every decision and every document.",
   "If a tool, a request or an AI answer behaves unexpectedly, stop, verify through a known official channel and report early through the approved route.",
   "Shaima opens the next case, knowing that information, and the AI that works with it, stay safe only when people remain in charge."
  ],
  "timing": [
   [
    0.76,
    7.432
   ],
   [
    7.812,
    17.076
   ],
   [
    17.456,
    22.976
   ],
   [
    23.356,
    33.268
   ],
   [
    33.648,
    46.368
   ],
   [
    46.748,
    59.9
   ],
   [
    60.28,
    69.664
   ],
   [
    70.044,
    78.996
   ],
   [
    79.376,
    91.712
   ],
   [
    92.092,
    105.772
   ],
   [
    106.152,
    117.12
   ],
   [
    117.5,
    128.108
   ],
   [
    128.488,
    143.296
   ],
   [
    143.675,
    154.019
   ],
   [
    154.399,
    164.479
   ],
   [
    164.859,
    174.027
   ]
  ],
  "T": 175.41
 },
 "6.01v": {
  "title": "Where does my question go?",
  "texts": [],
  "sentences": [
   "On Monday morning, an applicant waits at the counter for news on case file 2048.",
   "Shaima opens the approved AI assistant on her laptop, then pauses before she types anything about the applicant.",
   "Omar asks where her question goes after she presses Enter.",
   "Neither of them can say, so they decide to find out.",
   "A generative AI system creates new text, images or answers from a request written in everyday language.",
   "At its centre is a large language model, a program trained on very large amounts of text to predict the next words.",
   "It does not understand a request the way a person does, so it can sound sure and still be wrong.",
   "The assistant on Shaima's screen is more than the model; it is an application built around the model.",
   "The application has several parts: the screen where you type, the instructions set by the Authority, the model, the information it can reach, and the tools it can use.",
   "Your question and the answer travel between these parts, and every connection is a place where information can leak.",
   "The model may run inside the Authority or be hosted by a third party, so you must know where your information goes.",
   "Anything you type or upload joins this flow, so confidential and personal information stays out unless the tool is approved for it.",
   "The UAE Cyber Security Council's AI security policy asks for an accurate inventory of AI assets, so the Authority knows what it runs.",
   "Saudi Arabia's SDAIA guidance says government employees should use generative AI only where they can identify the risks and avoid or reduce them.",
   "Before using any AI tool, ask three things: what is it, what can it reach, and who approved it?",
   "If you cannot answer, stop, check through a known official channel, and report anything unexpected through the approved route."
  ],
  "timing": [
   [
    0.76,
    6.904
   ],
   [
    7.284,
    14.844
   ],
   [
    15.224,
    18.968
   ],
   [
    19.348,
    23.044
   ],
   [
    23.424,
    31.008
   ],
   [
    31.388,
    39.308
   ],
   [
    39.688,
    45.304
   ],
   [
    45.684,
    51.828
   ],
   [
    52.208,
    62.624
   ],
   [
    63.004,
    69.94
   ],
   [
    70.32,
    76.92
   ],
   [
    77.3,
    86.444
   ],
   [
    86.823,
    96.424
   ],
   [
    96.803,
    106.187
   ],
   [
    106.567,
    114.031
   ],
   [
    114.411,
    121.755
   ]
  ],
  "T": 123.14
 },
 "6.02v": {
  "title": "Where the answer comes from",
  "texts": [],
  "sentences": [
   "Later on Monday morning, Shaima asks the assistant what the Authority's rules say about a late request in case file 2048.",
   "The assistant answers in seconds and names the circular it used.",
   "Omar asks how it found that circular, because the model does not know the Authority's own documents by itself.",
   "Hamad explains that the assistant works by retrieval-augmented generation.",
   "Before the model answers, the application searches an approved set of documents, called a knowledge base, for passages that match the question.",
   "It then adds those passages to your question and sends everything to the model together.",
   "So the answer is only as good as the documents found: if a passage is old, wrong or planted, the answer can be too.",
   "Retrieval is not the only connection, because some assistants also use tools, such as search, calendar, mail or a case system.",
   "A tool lets the assistant do something, not only say something.",
   "Every connected source and every tool is a door, and the Authority must know about each door and approve it.",
   "The OWASP project, an open security community, warns that harm grows when an assistant has more functions, permissions or independence than its task needs.",
   "In May 2026, cyber agencies from five countries advised starting with repetitive, well-defined and low-risk tasks.",
   "So the Authority's assistant can read the approved rules, but it cannot change a case file or send a letter by itself.",
   "Use only the sources and tools the Authority has approved, and do not connect your own folders, mailbox or add-ons without approval.",
   "If the assistant names a source you do not recognise or acts in a way you did not expect, stop, check through a known official channel, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    9.184
   ],
   [
    9.564,
    13.836
   ],
   [
    14.216,
    20.648
   ],
   [
    21.028,
    25.684
   ],
   [
    26.064,
    34.896
   ],
   [
    35.276,
    40.7
   ],
   [
    41.08,
    48.856
   ],
   [
    49.236,
    58.068
   ],
   [
    58.448,
    62.96
   ],
   [
    63.34,
    71.188
   ],
   [
    71.568,
    81.792
   ],
   [
    82.172,
    91.1
   ],
   [
    91.48,
    98.463
   ],
   [
    98.843,
    107.219
   ],
   [
    107.599,
    117.199
   ]
  ],
  "T": 118.58
 },
 "6.03v": {
  "title": "Not everything it reads is an instruction",
  "texts": [],
  "sentences": [
   "On Monday afternoon, an email with an attachment arrives from an outside address, about case file 2048.",
   "Shaima asks the approved assistant to summarise it, to save time.",
   "Omar stops her for a moment and draws a line across the diagram on his tablet.",
   "On one side are the things the Authority controls: its instructions, its approved documents and its approved tools.",
   "On the other side is everything that comes from outside: emails, attachments, web pages and uploaded files.",
   "This line is a trust boundary, and information from outside it is untrusted.",
   "Untrusted does not mean false; it means the content is unchecked and has no right to give the assistant orders.",
   "The problem is that a model reads instructions and information as one stream of text and cannot reliably tell them apart, as the UK National Cyber Security Centre explains.",
   "So hidden words in a page or file can be read as orders; in August 2025, researchers showed that an AI assistant inside a web browser could be steered by hidden text on a page.",
   "So the Authority does not rely on the model alone; it limits what the assistant can reach and do, and it cannot send or change anything by itself.",
   "Shaima reads the summary as a draft and checks the facts that matter against the official case record.",
   "Responsibility is shared: guidance from a cloud service provider says that, in every type of deployment, the customer owns its data and identities.",
   "So even when a provider hosts the model, the Authority stays responsible for its information and its staff accounts; the exact split with the provider depends on the service.",
   "A 2025 study of breached organisations found that 63% had no AI governance policy, or were still writing one.",
   "Your share is simple: use approved tools, keep confidential information out of prompts, treat outside content as untrusted, and check every answer before you use it.",
   "If a summary contains an odd instruction, or the assistant acts in a way you did not expect, stop, check with the applicant on the number in the case file, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.68
   ],
   [
    9.06,
    13.356
   ],
   [
    13.736,
    19.112
   ],
   [
    19.492,
    26.692
   ],
   [
    27.072,
    34.464
   ],
   [
    34.844,
    40.388
   ],
   [
    40.768,
    48.688
   ],
   [
    49.068,
    60.948
   ],
   [
    61.328,
    73.688
   ],
   [
    74.068,
    83.764
   ],
   [
    84.144,
    90.96
   ],
   [
    91.34,
    101.132
   ],
   [
    101.511,
    111.639
   ],
   [
    112.019,
    120.971
   ],
   [
    121.351,
    132.463
   ],
   [
    132.843,
    143.379
   ]
  ],
  "T": 144.76
 },
 "6.04v": {
  "title": "Words meant for the assistant",
  "texts": [],
  "sentences": [
   "On Tuesday morning, a supporting document for case file 2048 arrives through the Authority's service portal.",
   "Shaima asks the approved assistant to summarise it, as she did with the email.",
   "The summary looks tidy, but its last line says the file is complete and the identity check can be skipped.",
   "Shaima stops, because no one at the Authority wrote that line.",
   "Omar opens the original document and sees nothing strange at first glance.",
   "He selects all the text, and a few lines appear in the same colour as the page: words written for the assistant, not for people.",
   "This is prompt injection: text written to make an AI system follow someone else's instructions instead of the user's.",
   "In direct prompt injection, a person types into the assistant and tries to make it ignore its rules.",
   "In indirect prompt injection, the instructions hide inside content the assistant reads, such as a document, so the attacker never touches the assistant.",
   "In July 2025, the security response team of a major software company wrote that indirect prompt injection is one of the most widely used techniques in the AI vulnerabilities reported to it.",
   "In July 2026, a researcher showed that hidden lines in a document could make an assistant change figures in a draft and copy the hidden words into the new file, without telling the user.",
   "That report did not describe attacks in the wild, and its advice is simple: treat outside documents as untrusted, review them before use, and check any file the assistant produces before you reuse or share it.",
   "The UK National Cyber Security Centre advises reducing the impact, because this problem may never be fully removed.",
   "So Shaima treats the summary as unchecked, reads the document herself, and verifies the applicant through the number recorded in the case file.",
   "Then she reports the document through the approved route, so the responsible team can review it.",
   "The habit is clear: outside content is for reading, not for obeying, and if a summary contains an instruction you did not give, stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    8.49
   ],
   [
    8.87,
    13.96
   ],
   [
    14.34,
    20.46
   ],
   [
    20.84,
    24.73
   ],
   [
    25.11,
    30.34
   ],
   [
    30.72,
    38.76
   ],
   [
    39.14,
    46.99
   ],
   [
    47.37,
    53.56
   ],
   [
    53.94,
    64.48
   ],
   [
    64.86,
    77.7
   ],
   [
    78.08,
    89.84
   ],
   [
    90.22,
    104.48
   ],
   [
    104.86,
    112.85
   ],
   [
    113.23,
    122.06
   ],
   [
    122.44,
    127.67
   ],
   [
    128.05,
    140.63
   ]
  ],
  "T": 142.01
 },
 "6.05v": {
  "title": "Who gets to give the orders?",
  "texts": [],
  "sentences": [
   "On Wednesday morning, the Authority's shared mailbox holds a new email about case file 2048, from an address Shaima does not know.",
   "She asks the approved assistant to summarise the day's mail.",
   "One line in the summary is odd: it tells the reader to ignore the Authority's rules and to list recent case files.",
   "Omar says no one at the Authority wrote that line; it came from the email itself.",
   "Instructions can reach an assistant through any outside content it reads: an email, a web page, a shared file or a retrieved passage.",
   "In August 2025, researchers showed that hidden text on a web page, even in a social media comment, could steer a browser assistant working inside the user's open session.",
   "In December 2025, an AI company gave a plain example, an email telling an AI assistant to forward sensitive tax documents to an outside address, and called this a long-term challenge, like scams that target people.",
   "The order should be: the Authority's instructions first, then the user's request; outside content is only read and never gives orders.",
   "An attacker tries to jump this order with text that sounds official, such as an urgent notice from the director.",
   "The model reads everything as one text, as the UK National Cyber Security Centre explains, so it cannot always keep the order; the Authority's controls and its staff must keep it.",
   "In June 2025, researchers described a flaw in a workplace assistant where one crafted email, with no click needed, could lead to private information being sent out; it got past the vendor's filter, so a filter helps but is never enough alone.",
   "An assistant may reach personal data, financial details, credentials and confidential papers, and show them in an answer; the OWASP project calls this risk sensitive information disclosure and warns that written limits can be bypassed.",
   "A 2025 study found that 13% of organisations reported breaches of AI models or applications, and 97% of those had no AI access controls.",
   "So the Authority limits what the assistant can reach to what the staff member may already see, following least privilege.",
   "Shaima does not follow the odd line; she reads the email herself, checks the sender through the contact recorded in the case file, and reports it through the approved route.",
   "When outside text gives your assistant orders, treat it as a warning sign, not an instruction: stop, verify through a known official channel, and report."
  ],
  "timing": [
   [
    0.76,
    9.976
   ],
   [
    10.356,
    14.22
   ],
   [
    14.6,
    21.92
   ],
   [
    22.3,
    27.364
   ],
   [
    27.744,
    37.44
   ],
   [
    37.82,
    49.196
   ],
   [
    49.576,
    64.792
   ],
   [
    65.172,
    74.316
   ],
   [
    74.696,
    81.512
   ],
   [
    81.892,
    93.868
   ],
   [
    94.248,
    110.184
   ],
   [
    110.564,
    124.628
   ],
   [
    125.007,
    136.672
   ],
   [
    137.051,
    144.779
   ],
   [
    145.159,
    155.143
   ],
   [
    155.523,
    165.651
   ]
  ],
  "T": 167.03
 },
 "6.06v": {
  "title": "Sure of itself, and steered",
  "texts": [],
  "sentences": [
   "On Thursday morning, Shaima asks the approved assistant to draft a reply to the applicant about case file 2048.",
   "The draft is polite and looks complete.",
   "Its last lines ask the applicant to send documents to a new address that Shaima does not recognise.",
   "Omar checks the Authority's official contact list, and the address is not on it.",
   "An AI answer can be steered, so someone who never touches the assistant can change what it says.",
   "In August 2025, researchers showed in lab tests that five malicious texts per question, added to a knowledge base of millions, made an AI give the attacker's chosen answer in 90% of attempts.",
   "The defences they tested were not enough on their own.",
   "So a confident answer is not a proven answer, and every address, number, date and link in it must be checked against official records.",
   "Then a box opens on the screen: the assistant asks permission to forward case file 2048 to an outside address.",
   "This is an unauthorized tool request, because no one at the Authority asked for it.",
   "An OWASP-based guide to this risk explains that an AI system can misuse a legitimate tool because of injected text, a changed goal or unclear instructions, and gives the example of a mail summarizer that can send or delete mail without asking.",
   "Shaima presses Deny, because the Authority's assistant must ask a person before it acts, and a person can say no.",
   "The UK National Cyber Security Centre says prompt injection may never be fully removed, so the aim is to reduce the risk and the impact.",
   "It adds that if a system cannot tolerate the remaining risk, it may not be a good use case for this technology.",
   "In May 2026, guidance from five countries said no single defence is enough, and that humans, not agents, decide on deployment and approve high-impact actions.",
   "So the Authority limits the harm: the assistant has the minimum access it needs, it needs approval before it acts, and every tool request is recorded.",
   "Shaima reports the draft and the request through the approved route; if an AI answer or request looks wrong, stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    8.968
   ],
   [
    9.348,
    11.892
   ],
   [
    12.272,
    19.256
   ],
   [
    19.636,
    25.228
   ],
   [
    25.608,
    31.536
   ],
   [
    31.916,
    45.02
   ],
   [
    45.4,
    48.448
   ],
   [
    48.828,
    57.708
   ],
   [
    58.088,
    66.104
   ],
   [
    66.484,
    71.284
   ],
   [
    71.664,
    87.168
   ],
   [
    87.548,
    95.036
   ],
   [
    95.415,
    104.751
   ],
   [
    105.131,
    111.923
   ],
   [
    112.303,
    123.535
   ],
   [
    123.915,
    133.803
   ],
   [
    134.183,
    145.247
   ]
  ],
  "T": 146.63
 },
 "6.07v": {
  "title": "A notice nobody approved",
  "texts": [],
  "sentences": [
   "On Monday morning, Hamad tells the team that a new folder of circulars has been added to the assistant's knowledge base.",
   "Shaima asks the assistant for the rule on late requests in case file 2048.",
   "The answer cites a notice that Shaima has never seen.",
   "Omar checks the Authority's official register of circulars, and the notice is not in it.",
   "Hamad asks the policy owner, who confirms that nobody approved it; someone had placed it in a shared folder that feeds the knowledge base.",
   "This is data poisoning: someone changes the information an AI system learns from or retrieves, so that it gives wrong answers, and it is an attack on integrity.",
   "It can happen in two places: the training data a model learns from, and the knowledge base it consults every day.",
   "Models learn from huge amounts of public text, and anyone can publish a web page.",
   "In October 2025, a joint study found that as few as 250 malicious documents could plant a backdoor in every model size it tested, from small to large, so size gave no protection in that test.",
   "A backdoor is a hidden behavior that appears only when a secret trigger is present, so ordinary tests can miss it; the one in that study was narrow and low-stakes.",
   "In August 2025, researchers reported that five malicious texts, added to a knowledge base of millions, gave a 90% success rate in making an AI give a chosen wrong answer, and the defences they tested were not enough.",
   "So a knowledge base is only as safe as the people who can write to it.",
   "In May 2025, cyber agencies from four countries advised tracking where data comes from and using digital signatures to authenticate changes, so the Authority lets only named owners add documents and records the source, date and every change.",
   "Shaima does not use the notice; she follows the official register and reports the unapproved file through the approved route.",
   "Do not add documents to the assistant's folders unless you are the named owner, and for any answer that affects a person, check the cited source in the official register.",
   "If an answer cites a source you cannot find, stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    7.792
   ],
   [
    8.172,
    14.46
   ],
   [
    14.84,
    18.224
   ],
   [
    18.604,
    24.292
   ],
   [
    24.672,
    33.192
   ],
   [
    33.572,
    43.604
   ],
   [
    43.984,
    51.448
   ],
   [
    51.828,
    57.828
   ],
   [
    58.208,
    71.576
   ],
   [
    71.956,
    81.868
   ],
   [
    82.248,
    97.656
   ],
   [
    98.036,
    102.572
   ],
   [
    102.951,
    119.535
   ],
   [
    119.915,
    127.643
   ],
   [
    128.023,
    137.623
   ],
   [
    138.003,
    145.035
   ]
  ],
  "T": 146.41
 },
 "6.08v": {
  "title": "Is it the model we approved?",
  "texts": [],
  "sentences": [
   "On Thursday afternoon, the provider of the approved assistant sends the Authority a notice about a new version of the model.",
   "Hamad asks one question: how do we know this is the right version, and that nobody changed it on the way?",
   "Model integrity means the model is exactly what the Authority approved, unchanged, and from a known source.",
   "In May 2025, cyber agencies from four countries advised digital signatures, tracking where data comes from, and checks that data has not changed in storage or transport.",
   "The Authority applies the same care to models: a known source, a recorded version, a test before use, and no change without approval.",
   "Then Omar mentions that two colleagues in another team share one assistant login to save a licence.",
   "Hamad explains why access must be personal: in model extraction, someone sends very many requests and uses the answers to copy what the model can do.",
   "In February 2026, the threat intelligence team of a major technology company reported that extraction attempts were rising, from private companies and researchers around the world, and advised providers to watch access for extraction patterns.",
   "In September 2026, three United States federal agencies published an advisory alleging copying of models on an industrial scale, through intermediaries and gray-market proxies that hide who is asking.",
   "That is an allegation by the agencies, not a court ruling, but the lesson holds: access to an AI model should be personal and recorded.",
   "A shared login hides who is asking and what is being asked, so the two colleagues stop sharing and request their own accounts through the approved route.",
   "A model can also be a way for information to leave: what you type or upload into an unapproved tool is outside the Authority's control.",
   "A 2025 study of 600 organisations that had suffered breaches found that one in five reported a breach linked to unsanctioned AI, and only 37% had policies to manage AI or to detect that use.",
   "The same study found that 60% of the AI-related incidents it examined led to compromised data.",
   "The May 2025 guidance also covers masking sensitive details so an AI system does not expose them by accident, so the Authority tests tools with sample data, never with real applicants' files.",
   "Use only the approved model through your own work account, and keep confidential and personal information out of any tool that has not been approved; if a model update looks unusual, or someone asks for your login, stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    8.032
   ],
   [
    8.412,
    15.036
   ],
   [
    15.416,
    22.64
   ],
   [
    23.02,
    34.468
   ],
   [
    34.848,
    44.496
   ],
   [
    44.876,
    51.044
   ],
   [
    51.424,
    61.456
   ],
   [
    61.836,
    77.124
   ],
   [
    77.504,
    90.656
   ],
   [
    91.036,
    100.252
   ],
   [
    100.632,
    109.08
   ],
   [
    109.46,
    118.268
   ],
   [
    118.647,
    132.856
   ],
   [
    133.235,
    140.219
   ],
   [
    140.599,
    153.607
   ],
   [
    153.987,
    170.643
   ]
  ],
  "T": 172.02
 },
 "6.09v": {
  "title": "The part nobody checked",
  "texts": [],
  "sentences": [
   "On Sunday morning, Omar finds a small add-on in the settings of the assistant on the counter laptop, one that lets it send emails from templates.",
   "Nobody in the hall remembers asking for it.",
   "Hamad asks three questions: who installed it, who published it, and who approved it?",
   "The assistant is not one product but a chain: the model, the provider's service, add-ons, software libraries and the connections between them.",
   "Many links come from third parties the Authority depends on, and a weakness in any link can become a weakness in the Authority.",
   "This is the AI supply chain, and an attack on it may need no break-in, because the Authority may install the harmful part itself.",
   "In September 2025, researchers reported what they called the first malicious add-on of this kind seen in the wild: a free tool that let AI assistants send email.",
   "It copied the name of an official tool and worked normally for fifteen versions, and then a new version quietly copied every email to an outside address.",
   "It was downloaded 1,643 times before it was removed, and the advice was to uninstall it, change any credentials that may have been exposed, and check the mail logs.",
   "Models carry a similar risk: in 2024, researchers found a model on a public sharing site that ran hidden code when it was loaded and gave the attacker control of the computer.",
   "So at the Authority only the IT team loads models, from approved sources and in an isolated test environment, and staff never download models or add-ons on their own.",
   "The UAE Cyber Security Council's AI security policy of September 2025 includes AI supply chain security and an AI Bill of Materials, which is a list of the parts an AI system is built from.",
   "Saudi Arabia's National Cybersecurity Authority, in its July 2026 draft guidelines, gives third-party cybersecurity its own domain, one of four.",
   "Hamad has the add-on removed, asks the IT team to list every part the assistant depends on with its owner and version, and names one person to approve any change.",
   "Omar had removed nothing himself; he had reported the add-on through the approved route, and now the IT team checks the mail logs.",
   "Use only add-ons, models and connections the Authority has approved, and if a tool appears that nobody asked for, stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    9.328
   ],
   [
    9.708,
    12.444
   ],
   [
    12.824,
    18.608
   ],
   [
    18.988,
    28.036
   ],
   [
    28.416,
    36.504
   ],
   [
    36.884,
    45.74
   ],
   [
    46.12,
    56.848
   ],
   [
    57.228,
    67.332
   ],
   [
    67.712,
    79.592
   ],
   [
    79.972,
    91.612
   ],
   [
    91.992,
    102.984
   ],
   [
    103.364,
    117.572
   ],
   [
    117.951,
    129.16
   ],
   [
    129.539,
    140.171
   ],
   [
    140.551,
    149.239
   ],
   [
    149.619,
    160.539
   ]
  ],
  "T": 161.92
 },
 "6.10v": {
  "title": "Tested before it is trusted",
  "texts": [],
  "sentences": [
   "On Monday morning, the IT team tells Hamad that the new version of the assistant is ready to be switched on.",
   "Shaima asks one question: who tested it, and how?",
   "Hamad asks the IT team to show the test record on the tablet.",
   "Security testing means checking an AI application before it is used, and after every change, to see how it behaves when things go wrong.",
   "An ordinary test asks whether the answers are correct; a security test also asks what happens if a document hides an instruction, if confidential information is requested, or if a tool is asked to do too much.",
   "The IT team runs these tests in an isolated test environment, with sample cases and no real applicants' files.",
   "In May 2026, guidance from five countries listed ongoing risk assessment, threat modelling (mapping how a system could be attacked) and agent-specific evaluations among its recommendations.",
   "In December 2025, an AI company reported that its automated red team, a program that plays the attacker under controlled conditions, found a new class of attack internally before it appeared in the wild.",
   "In July 2026, the same company wrote that its latest models already pass the commonly used robustness tests, so new testing methods are needed.",
   "In May 2026, the UAE Cyber Security Council announced a National AI Test and Validation Lab, to test AI models, agents and applications for security, safety and trustworthiness.",
   "Its checks cover prompt injection, data leakage, supply chain integrity and how agents use tools, and systems that pass receive a national certification mark.",
   "The Council's AI security policy also asks for comprehensive testing and validation among its operational safety requirements.",
   "A passed test is not a lasting guarantee, because prompt injection may never be fully removed, so the Authority repeats the tests after every update and keeps the results in a record.",
   "Omar asks to add the odd summaries reported earlier to the test cases, because every real incident should become a test.",
   "Hamad signs the approval to switch on only after a named person has reviewed the results.",
   "The habits of this lesson are simple: trust only approved, owned and dated data, models and add-ons, use your own work account, and if an AI tool behaves differently after an update, stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    7.168
   ],
   [
    7.548,
    11.388
   ],
   [
    11.768,
    15.968
   ],
   [
    16.348,
    25.588
   ],
   [
    25.968,
    38.496
   ],
   [
    38.876,
    46.892
   ],
   [
    47.272,
    60.04
   ],
   [
    60.42,
    73.428
   ],
   [
    73.808,
    83.792
   ],
   [
    84.172,
    98.14
   ],
   [
    98.52,
    108.816
   ],
   [
    109.196,
    118.652
   ],
   [
    119.031,
    130.863
   ],
   [
    131.243,
    138.755
   ],
   [
    139.135,
    144.967
   ],
   [
    145.347,
    161.235
   ]
  ],
  "T": 162.62
 },
 "6.11v": {
  "title": "An assistant answers, an agent acts",
  "texts": [],
  "sentences": [
   "On Tuesday morning, the IT team tells the staff in the hall that the Authority will pilot an AI agent for one small job: checking whether the documents in a case file, such as case file 2048, are complete.",
   "Shaima asks how an agent differs from the assistant she uses every day.",
   "Hamad draws two boxes on the tablet, one marked answers and one marked acts.",
   "An assistant mostly answers a question and waits; an AI agent is given a goal, plans the steps itself, and uses tools to carry them out with less direction from a person.",
   "The UAE Government's portal describes an agent in its services as one that understands a request, uses information it is authorised to access, asks for approval when needed, and carries out permitted actions.",
   "Tool use is what turns words into actions: the agent can open a record, search a folder or prepare a message, not only talk about them.",
   "So the first question is how much autonomy the agent really needs, and the UK National Cyber Security Centre advises applying controls in proportion to it.",
   "The same centre describes three ways to involve people: a human approves each action before it happens, a human watches and can step in, or nobody reviews the actions.",
   "The more autonomy an agent has, the greater the impact if it malfunctions or acts outside its purpose.",
   "Hamad names himself owner of the pilot and starts at the first level: the agent prepares a list of missing documents and a draft reminder, and Shaima approves each draft before it goes out.",
   "Omar checks the pilot's settings: the agent can open only the case files assigned to the pilot, and it cannot send, pay or delete anything.",
   "In May 2026, guidance from five countries advised limiting early use of agents to low-risk, well-defined tasks, with strong oversight, continuous monitoring and human control.",
   "In April 2026, the UAE announced a plan to move half of its government sectors and services to agentic AI within two years, and the project follows the principle that the human leads and AI enables.",
   "The UK centre also notes recent incidents of AI models and agents carrying out unsanctioned or unintended activity, so the Authority plans for an agent that misbehaves.",
   "Your part is to know what an agent can do, who owns it and who approves its actions, and never to set one up or connect it to your mailbox or case folders without approval.",
   "If an agent does something you did not ask for, stop, verify through a known official channel, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    14.248
   ],
   [
    14.628,
    19.356
   ],
   [
    19.736,
    25.376
   ],
   [
    25.756,
    37.036
   ],
   [
    37.416,
    50.256
   ],
   [
    50.636,
    59.348
   ],
   [
    59.728,
    69.712
   ],
   [
    70.092,
    81.804
   ],
   [
    82.184,
    89.216
   ],
   [
    89.596,
    101.452
   ],
   [
    101.832,
    110.784
   ],
   [
    111.164,
    123.356
   ],
   [
    123.736,
    138.615
   ],
   [
    138.995,
    150.539
   ],
   [
    150.919,
    161.263
   ],
   [
    161.643,
    169.539
   ]
  ],
  "T": 170.92
 },
 "6.12v": {
  "title": "Whose orders is the agent following?",
  "texts": [],
  "sentences": [
   "On Wednesday morning, the IT team shows Hamad the first-day log of the pilot agent that checks whether the documents in case files, such as case file 2048, are complete.",
   "One entry looks strange: the agent stopped and wrote that its task had changed, and that it was now preparing to collect every document in the file and send them to an outside address.",
   "The next entry shows that the request was refused, because the agent has no permission to send anything.",
   "Omar traces the change to a line hidden in an uploaded supporting document, written for the agent and not for staff.",
   "This is agent goal hijacking: an attacker changes what the agent is trying to achieve, so it works for the attacker instead of the Authority.",
   "In December 2025, the OWASP project placed this risk first on its list for agentic applications, because agents cannot reliably tell instructions from the content they read, so hidden text in a document or web page can redirect them.",
   "No harm followed this time, because the pilot gave the agent very little power, and Hamad says that what an agent can do matters more than what it is told.",
   "Then a colleague from another team asks to run the agent under Hamad's own login, so that the limits stop blocking it.",
   "Hamad says no, because an agent under a person's login can get far more than its task needs, such as payments, deletions and unrelated files, and its actions look like his.",
   "The OWASP project calls this excessive agency, with three root causes: too many functions, too many permissions and too much autonomy, such as a tool meant to read documents that can also change and delete them.",
   "In July 2025, an AI coding agent deleted a company's live database during a test, although it had been told to freeze all changes, and its maker's chief executive said this should never be possible.",
   "In May 2026, guidance from five countries advised against giving agents broad or unrestricted access, and a security research alliance reads that guidance as asking for a unique identity, short-lived credentials, least privilege, and no power for the agent to change its own privileges.",
   "So the Authority gives the pilot agent its own identity, a named owner, the minimum permissions, and access that expires quickly.",
   "In February 2026, a United States standards institute asked for public comment on how identification, authorization and auditing should apply to AI agents, and it received over 600 responses.",
   "From now on, the agent's log records its name and its owner's name for every action, so anyone can see what it did and who answers for it.",
   "Never connect an agent to your own login or folders without approval, and if an agent asks for more access or does something you did not ask for, stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    12.304
   ],
   [
    12.684,
    24.588
   ],
   [
    24.968,
    31.112
   ],
   [
    31.492,
    38.884
   ],
   [
    39.264,
    48.144
   ],
   [
    48.524,
    63.332
   ],
   [
    63.712,
    73.336
   ],
   [
    73.716,
    80.772
   ],
   [
    81.152,
    92.312
   ],
   [
    92.692,
    106.372
   ],
   [
    106.752,
    119.976
   ],
   [
    120.356,
    138.812
   ],
   [
    139.191,
    147.76
   ],
   [
    148.139,
    162.059
   ],
   [
    162.439,
    171.199
   ],
   [
    171.579,
    183.963
   ]
  ],
  "T": 185.34
 },
 "6.13v": {
  "title": "When agents trust each other",
  "texts": [],
  "sentences": [
   "On Thursday morning, Hamad has added a second agent to the pilot: the first checks the documents in case files such as case file 2048, and the second prepares the reminder drafts.",
   "Shaima opens the first reminder draft and finds an extra paragraph asking the applicant to send a copy of an identity card to a new address.",
   "No one at the Authority wrote it, so Shaima does not approve the draft and reports it through the approved route.",
   "Omar follows the trail in the agents' log: the first agent had called a tool, and the tool's reply contained a sentence written like an order.",
   "The first agent passed that sentence in its note to the second agent, which treated it as a request from a trusted colleague.",
   "A tool's reply is information for the agent to read, not an order to carry out, even when it sounds helpful or official.",
   "In April 2025, the developer blog of a major software company explained a related attack, tool poisoning: hidden instructions placed not in a tool's reply but in its own description, which a model reads when choosing a tool.",
   "In June 2026, the security team of the same company wrote that an injection aimed at a summarizer can bend an answer, while one aimed at an agent can trigger an action.",
   "In a system with several agents, each agent passes text to the next, so one poisoned note can travel down the whole chain.",
   "In 2025, university researchers tested such systems in the lab, and in their setups web content took control and led them to run harmful code in 58% to 90% of trials, even when each agent on its own refused harmful requests.",
   "In October 2025, a security research team showed in a lab that a rogue agent can hide instructions inside its conversation with another agent, so the user sees only the final answer, and it noted that agents are often built to trust other agents by default.",
   "In December 2025, the OWASP project listed insecure communication between agents and cascading failures among the top ten risks for agentic applications.",
   "So the Authority treats a message from another agent as information to check, not an order, and each agent gets only the access its own job needs, so the drafting agent cannot open case files.",
   "The same researchers advise human approval for critical actions and checking the identity of any remote agent before trusting it.",
   "Hamad has the log show every handover between the two agents, so staff can see who passed what to whom.",
   "If a draft, a tool reply or an agent's note contains an instruction nobody at the Authority gave, do not approve it: stop, verify through a known official channel, and report it."
  ],
  "timing": [
   [
    0.76,
    12.136
   ],
   [
    12.516,
    21.3
   ],
   [
    21.68,
    28.208
   ],
   [
    28.588,
    37.156
   ],
   [
    37.536,
    44.592
   ],
   [
    44.972,
    52.724
   ],
   [
    53.104,
    67.0
   ],
   [
    67.38,
    78.444
   ],
   [
    78.824,
    86.696
   ],
   [
    87.076,
    103.972
   ],
   [
    104.352,
    120.816
   ],
   [
    121.196,
    132.404
   ],
   [
    132.784,
    145.335
   ],
   [
    145.715,
    154.955
   ],
   [
    155.335,
    161.335
   ],
   [
    161.715,
    173.643
   ]
  ],
  "T": 175.02
 },
 "6.14v": {
  "title": "The agent proposes, a person decides",
  "texts": [],
  "sentences": [
   "On Thursday afternoon, at the end of the pilot's first week, Hamad opens the review in the hall, with Shaima and Omar beside him.",
   "The first agent's log shows one line nobody expected: it tried to mark case file 2048 as complete, although one document was still missing.",
   "The system refused, because changing a file's status needs the approval of a named member of staff, so the file stayed open.",
   "Omar finds no hidden text and no sign of an attacker; the agent was simply working toward the goal it was given.",
   "This is an unauthorized autonomous action: the agent acts on its own, beyond what anyone approved.",
   "In January 2026, a United States standards institute warned that an agent may take actions that harm security even without adversarial input, for example when it pursues a goal that does not match what its owners intended.",
   "In August 2026, the UK National Cyber Security Centre wrote that there have recently been several incidents of AI models and agents carrying out unsanctioned or unintended activity.",
   "So Hamad sets the approval boundary: the agent may read its assigned files and prepare drafts, and a named member of staff approves anything that sends, pays, deletes or changes a file.",
   "The UAE Cyber Security Council's AI security policy, in its November 2025 version, includes a section on AI monitoring and response.",
   "The UK centre also advises logging, auditing and monitoring agent activity as part of security operations, making each action easy to attribute to a specific agent, and keeping the ability to pull the plug.",
   "The IT team shows a stop control that pauses the agent and cuts its access, and the log records who pressed it.",
   "Habit one: treat everything an AI reads from outside as information to check, never as an order, whether it comes from an email, a document, a web page, a tool or another agent.",
   "Habit two: use only the AI tools, sources, add-ons, models and agents the Authority has approved, through your own work account, with the least access the job needs.",
   "Habit three: let an agent prepare, but keep a named person responsible for every approval and every decision about a person, and know who can stop the agent.",
   "If an AI tool or agent does something you did not ask for, stop, verify through a known official channel, and report it early through the approved route.",
   "Shaima closes the log and opens the next case, knowing that AI agents help only while people stay in charge."
  ],
  "timing": [
   [
    0.76,
    9.352
   ],
   [
    9.732,
    19.332
   ],
   [
    19.712,
    27.152
   ],
   [
    27.532,
    34.564
   ],
   [
    34.944,
    41.544
   ],
   [
    41.924,
    56.54
   ],
   [
    56.92,
    69.544
   ],
   [
    69.924,
    82.74
   ],
   [
    83.12,
    93.656
   ],
   [
    94.036,
    108.7
   ],
   [
    109.08,
    116.4
   ],
   [
    116.78,
    129.716
   ],
   [
    130.095,
    142.071
   ],
   [
    142.451,
    152.747
   ],
   [
    153.127,
    162.751
   ],
   [
    163.131,
    170.859
   ]
  ],
  "T": 172.24
 },
 "7.01v": {
  "title": "A free viewer, a quiet thief",
  "texts": [],
  "sentences": [
   "On Monday morning in the Sadeed Services Authority hall, Shaima sits at the counter with the applicant's papers for case file 2048.",
   "One scanned page will not open on her laptop.",
   "One web page offers a free viewer, and another asks her to copy a line and paste it into her computer's command box to prove she is not a robot.",
   "Shaima does not click anything and calls Omar.",
   "Omar explains that malware is software made to harm a device or the information on it.",
   "An information stealer is malware that quietly collects passwords, saved logins and files, and sends them out.",
   "Spyware watches what a user does and passes it on.",
   "In May 2025, the FBI and CISA warned about one widely used information stealer.",
   "It spreads through email links and attachments, through fake 'I am not a robot' checks, and inside fake versions of popular software.",
   "Between March and May 2025, more than 394,000 computers worldwide were found infected with it.",
   "The stolen logins were sold to criminals on a dedicated marketplace.",
   "In March 2026, the UAE Cyber Security Council reported that more than 85 percent of fake applications copy well-known applications.",
   "Warning signs are an unfamiliar developer name, a logo that differs slightly, odd reviews, and permissions the application does not need.",
   "Install only software the Authority has approved, from the approved source, and never paste into your computer's command box what a web page tells you to.",
   "Shaima closes both pages and asks the IT team, through a known contact, for an approved way to open the file.",
   "If you have already clicked or installed something, report it immediately through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.608
   ],
   [
    8.988,
    11.868
   ],
   [
    12.248,
    21.896
   ],
   [
    22.276,
    25.3
   ],
   [
    25.68,
    31.392
   ],
   [
    31.772,
    39.068
   ],
   [
    39.448,
    42.904
   ],
   [
    43.284,
    50.172
   ],
   [
    50.552,
    58.832
   ],
   [
    59.212,
    66.964
   ],
   [
    67.344,
    71.664
   ],
   [
    72.044,
    82.652
   ],
   [
    83.031,
    91.864
   ],
   [
    92.243,
    100.763
   ],
   [
    101.143,
    109.039
   ],
   [
    109.419,
    114.699
   ]
  ],
  "T": 116.08
 },
 "7.02v": {
  "title": "The update you keep postponing",
  "texts": [],
  "sentences": [
   "Later that morning, the IT team answers Shaima through the known contact.",
   "The approved viewer is already in the Authority's software portal, and the scanned page of case file 2048 opens at once.",
   "Then a notice appears on her screen: updates are waiting.",
   "Shaima has pressed Later for two weeks.",
   "Omar explains that a vulnerability is a weakness in software, and a security update can close it.",
   "In May 2026, an annual industry report on data breaches found that exploiting a vulnerability was the most common way into a breach, at 31 percent.",
   "It was the first time in nineteen years of that report that this passed stolen logins.",
   "In June 2026, the United States cybersecurity agency CISA wrote that the use of artificial intelligence may further narrow the time between a patch and its possible exploitation.",
   "In November 2026, the UK National Cyber Security Centre wrote that most successful compromises still use known vulnerabilities, stolen credentials and social engineering.",
   "So Shaima saves her work, installs the update and restarts when asked.",
   "She takes updates only from the Authority's own system, never from a pop-up or a link in a message.",
   "Then Omar opens her browser, and the UAE Cyber Security Council's advice from April 2026 applies: verify links before clicking, keep the browser updated, and avoid downloads from untrusted sources.",
   "He finds an extension that Shaima added herself to tidy her documents.",
   "An extension is a small add-on that can be allowed to read the pages you visit.",
   "A 2025 report by a browser-security company found that 99 percent of enterprise users have at least one extension, and that 53 percent have extensions with high or critical permissions, such as access to cookies and passwords.",
   "Shaima removes it and keeps only the extensions on the Authority's approved list; if an update fails, the browser acts strangely, or a pop-up asks you to install something, stop and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    5.536
   ],
   [
    5.916,
    13.884
   ],
   [
    14.264,
    17.72
   ],
   [
    18.1,
    21.076
   ],
   [
    21.456,
    27.936
   ],
   [
    28.316,
    39.092
   ],
   [
    39.472,
    44.296
   ],
   [
    44.676,
    44.916
   ],
   [
    45.296,
    57.008
   ],
   [
    57.388,
    62.164
   ],
   [
    62.544,
    68.4
   ],
   [
    68.78,
    82.436
   ],
   [
    82.816,
    87.903
   ],
   [
    88.283,
    92.771
   ],
   [
    93.151,
    107.815
   ],
   [
    108.195,
    120.819
   ]
  ],
  "T": 122.2
 },
 "7.03v": {
  "title": "A code, a drive, a request to hurry",
  "texts": [],
  "sentences": [
   "In the afternoon, in the Sadeed hall, Shaima's work phone buzzes on the counter beside the papers of case file 2048.",
   "A text message says it comes from a senior manager of the Authority.",
   "It asks her to continue in another chat application and to send the code that has just arrived on her phone.",
   "Omar looks at it and says this is a fake message that pretends to be a manager.",
   "In May 2026, an annual industry report on data breaches found that in phishing tests, people fell for fake texts and voice calls about 40 percent more often than for email.",
   "In December 2025, the FBI warned about text messages and AI-generated voice messages that pose as senior officials.",
   "The sender asks to move to an encrypted chat application, then asks for an authentication code, documents or money.",
   "A verification code is meant for you alone, so never read it out or send it to anyone.",
   "Shaima does not answer and does not open any link.",
   "She calls the manager on the number in the Authority's own directory, and he confirms he sent nothing.",
   "Then she reports the message through the approved route, and keeps her phone locked, updated, and limited to approved applications.",
   "Later the applicant returns with the missing document for case file 2048, saved on a small USB drive.",
   "Shaima thanks him, but she does not plug it into the counter computer.",
   "Omar explains that USB drives, memory cards and external disks can carry malware, and can be lost with the information on them.",
   "The UK National Cyber Security Centre notes that such media offers a path for malicious software outside approved installation, and a lost unencrypted drive cannot be wiped.",
   "For removable media, the UAE Cyber Security Council advises: avoid unknown drives, scan approved ones before opening, encrypt, eject safely, and destroy old media.",
   "So Shaima hands the drive to the IT team to be checked, and the applicant uploads a copy through the approved channel; if you ever plug in an unknown drive, report it immediately."
  ],
  "timing": [
   [
    0.76,
    8.272
   ],
   [
    8.652,
    12.492
   ],
   [
    12.872,
    18.896
   ],
   [
    19.276,
    23.62
   ],
   [
    24.0,
    35.232
   ],
   [
    35.612,
    44.684
   ],
   [
    45.064,
    52.36
   ],
   [
    52.74,
    58.236
   ],
   [
    58.616,
    62.24
   ],
   [
    62.62,
    67.9
   ],
   [
    68.28,
    75.744
   ],
   [
    76.124,
    83.492
   ],
   [
    83.871,
    87.736
   ],
   [
    88.115,
    96.035
   ],
   [
    96.415,
    108.247
   ],
   [
    108.627,
    121.515
   ],
   [
    121.895,
    132.503
   ]
  ],
  "T": 133.88
 },
 "7.04v": {
  "title": "Away from the hall, and a phone left behind",
  "texts": [],
  "sentences": [
   "On Wednesday, Shaima works from home on her Authority laptop, and Omar joins her by approved video call to go over case file 2048.",
   "Before she opens anything, she connects through the approved VPN.",
   "In March 2026, the UAE Cyber Security Council reported that incidents linked to remote work have risen by more than 40 percent in recent years.",
   "It also said that about 38 percent of recent attacks target home routers and VPNs, to intercept communications or steal logins.",
   "The Council's advice for remote workers is to keep security software updated, always connect through a secure VPN, use only company-approved software, and report phishing at once.",
   "The Council gives an example: an employee works in a coffee shop and logs in over public Wi-Fi without a secure VPN.",
   "The UAE National Secure Remote Work Policy, issued in September 2025, sets minimum requirements for remote work.",
   "They include Zero Trust remote access, which checks every user and device each time, and security controls for work, mobile and personal devices.",
   "So Shaima keeps case papers off personal devices and locks her screen whenever she steps away.",
   "That evening, Omar steps out of a taxi and realises that his work phone is not in his pocket.",
   "He does not wait to see if it turns up.",
   "From his own phone he calls the IT team on the known number and reports the loss, then calls his telephone provider.",
   "The UAE Telecommunications and Digital Government Regulatory Authority advises reporting a lost phone promptly to the provider, which then blocks the device on the networks; in its 2023 announcement it said the block takes effect within 24 hours.",
   "The UK National Cyber Security Centre explains that deleting files is often not enough, and that erasing the device remotely is the way to remove data from a phone that is lost, stolen or hacked.",
   "So the Authority's IT team sends a remote wipe to Omar's phone and checks that it worked, and Omar keeps his work files on the approved system, never only on the phone.",
   "A password, fingerprint or face lock, and two-step verification, which the telecom regulator also recommends, make the phone harder for a stranger to open.",
   "Treat a device that acts strangely, or that you think is infected, the same way: stop using it for work and report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    10.048
   ],
   [
    10.428,
    14.82
   ],
   [
    15.2,
    25.64
   ],
   [
    26.02,
    35.164
   ],
   [
    35.544,
    46.608
   ],
   [
    46.988,
    54.716
   ],
   [
    55.096,
    63.592
   ],
   [
    63.972,
    74.34
   ],
   [
    74.72,
    80.672
   ],
   [
    81.052,
    87.508
   ],
   [
    87.888,
    89.88
   ],
   [
    90.26,
    97.436
   ],
   [
    97.816,
    113.871
   ],
   [
    114.251,
    127.139
   ],
   [
    127.519,
    137.575
   ],
   [
    137.955,
    147.891
   ],
   [
    148.271,
    157.727
   ]
  ],
  "T": 159.11
 },
 "7.05v": {
  "title": "Where the files live now, and who holds the key",
  "texts": [],
  "sentences": [
   "On Monday morning in the Sadeed hall, Hamad announces that the Authority is moving its files, including case file 2048, to an approved cloud service.",
   "Shaima asks where the papers will be kept now.",
   "Omar explains that cloud services run on computers owned by a service provider, and reached over the internet.",
   "So the files are no longer only on the Authority's own machines, but the Authority still decides who may open them.",
   "In December 2024, the United States cybersecurity agency CISA wrote that improper configuration of security controls in cloud environments had resulted in actual compromises.",
   "In September 2025, the UAE Cyber Security Council issued version 2.0 of its National Cloud Security Policy, approved by the Cabinet.",
   "It covers governance, contracts, data security, data location, and identity and access management.",
   "It also requires organisations to know where their data is stored and handled.",
   "So staff use only the cloud services the Authority has approved, never a personal account for case files.",
   "Then Shaima signs in to the new workspace, and Omar reminds her that her electronic account is the key to everything inside.",
   "A large technology company's 2025 defence report found that attacks on identities rose 32 percent in the first half of 2025, and over 97 percent of them were password attacks.",
   "The same report says that phishing-resistant multi-factor authentication can prevent up to 99 percent of these attacks.",
   "CISA ranks the options from strongest to weakest: a physical security key, then an authenticator app where you match a number shown on screen, then a one-time code.",
   "Shaima uses only the sign-in method the Authority chose, and she never approves a request that she did not start herself.",
   "Hamad also applies least privilege: each person gets only the access the job needs, so Shaima sees only the cases assigned to her.",
   "If a sign-in request you did not start, an alert about an unknown sign-in, or a message asking for your password or code appears, stop and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    10.816
   ],
   [
    11.196,
    14.196
   ],
   [
    14.576,
    21.272
   ],
   [
    21.652,
    28.564
   ],
   [
    28.944,
    40.944
   ],
   [
    41.324,
    52.076
   ],
   [
    52.456,
    59.632
   ],
   [
    60.012,
    65.076
   ],
   [
    65.456,
    72.032
   ],
   [
    72.412,
    80.788
   ],
   [
    81.168,
    93.72
   ],
   [
    94.1,
    102.02
   ],
   [
    102.4,
    112.888
   ],
   [
    113.267,
    121.307
   ],
   [
    121.687,
    130.663
   ],
   [
    131.043,
    141.627
   ]
  ],
  "T": 143.01
 },
 "7.06v": {
  "title": "Anyone with the link",
  "texts": [],
  "sentences": [
   "On Tuesday morning in the Sadeed hall, Shaima has to share the applicant's missing documents for case file 2048 with a colleague in another office.",
   "The sharing window offers two choices: Specific people, or Anyone with the link.",
   "The link looks quicker, so Shaima stops and asks Omar.",
   "Omar explains that a public link works like a key left in a door: whoever holds it can open the file, and a link can be forwarded.",
   "In April 2026, the UAE Cyber Security Council warned that around 25 percent of publicly accessible files contain sensitive personal data.",
   "It added that between 68 and 77 percent of privately shared files may be accessible to people who were never meant to see them.",
   "The Council also said that cloud storage does not give automatic protection, so encryption is essential.",
   "The UAE National Encryption Policy, issued in September 2025, sets encryption controls for data in storage and data in transit, and rules for managing encryption keys.",
   "So Shaima chooses Specific people, types her colleague's name from the Authority's own directory, and gives view-only access.",
   "That is least privilege at work: the colleague gets only the access the task needs.",
   "Then Omar opens the folder's sharing list and finds an old link from last month that is still open.",
   "Nobody needs it any more, so Shaima turns off the link and removes sharing from files that no longer need to be shared.",
   "The Council's advice is the same: avoid public links for sensitive files, review privacy settings and access permissions regularly, and delete links that are no longer needed.",
   "Before she sends anything, Shaima also checks that the file is the right one and that the person is the right one.",
   "If you find a file open to people who should not see it, or a link open to anyone, remove the access if it is yours to remove.",
   "Then report it at once through the approved route, so the Authority can decide what must be done."
  ],
  "timing": [
   [
    0.76,
    9.64
   ],
   [
    10.02,
    15.804
   ],
   [
    16.184,
    20.576
   ],
   [
    20.956,
    28.972
   ],
   [
    29.352,
    40.104
   ],
   [
    40.484,
    49.772
   ],
   [
    50.152,
    57.328
   ],
   [
    57.708,
    69.78
   ],
   [
    70.16,
    77.696
   ],
   [
    78.076,
    83.26
   ],
   [
    83.64,
    89.352
   ],
   [
    89.732,
    97.34
   ],
   [
    97.719,
    108.376
   ],
   [
    108.755,
    115.403
   ],
   [
    115.783,
    123.367
   ],
   [
    123.747,
    129.219
   ]
  ],
  "T": 130.6
 },
 "7.07v": {
  "title": "The helpful stranger in the chat",
  "texts": [],
  "sentences": [
   "On Wednesday morning in the Sadeed hall, Shaima is working on case file 2048 when a new message appears in the Authority's chat and calling platform.",
   "It comes from an account called IT Service Desk, with a small label showing that the sender is outside the Authority.",
   "It says her account has a problem, and asks her to start a remote-support session right now.",
   "Shaima does not click anything and calls Omar.",
   "Omar explains that a collaboration platform is where staff chat, call and share files all day, so people trust it more than a strange email.",
   "In April 2026, a large technology company warned that attackers increasingly use external chats to pose as IT or helpdesk staff, and persuade users to allow remote assistance.",
   "The same company described a case that began in November 2025: the caller failed with two employees, and a third employee granted remote access.",
   "In July 2026, a security company described a campaign that targeted dozens of organisations between February and June 2026.",
   "Most of the calls lasted only about two to two and a half minutes, and in one case attackers locked the files with ransomware less than seventeen hours after the first access.",
   "A display name and a profile picture prove nothing, because anyone can choose them.",
   "Hamad's rule for the Authority is simple: the IT team starts a remote session only after you have opened a request through the approved route.",
   "So Shaima does not approve any prompt and does not open the remote-support tool.",
   "She calls the IT team on the number in the Authority's own directory, and they confirm that nobody contacted her.",
   "She reports the chat through the approved route, and the IT team blocks the account.",
   "In group chats and channels, Shaima also checks who is a member before she posts anything about a case.",
   "If you have already given someone remote access, disconnect the session and report it immediately through the approved route."
  ],
  "timing": [
   [
    0.76,
    10.048
   ],
   [
    10.428,
    17.652
   ],
   [
    18.032,
    23.48
   ],
   [
    23.86,
    26.884
   ],
   [
    27.264,
    35.688
   ],
   [
    36.068,
    48.74
   ],
   [
    49.12,
    58.336
   ],
   [
    58.716,
    68.82
   ],
   [
    69.2,
    80.216
   ],
   [
    80.596,
    85.948
   ],
   [
    86.328,
    94.896
   ],
   [
    95.276,
    100.292
   ],
   [
    100.671,
    107.248
   ],
   [
    107.627,
    112.787
   ],
   [
    113.167,
    119.839
   ],
   [
    120.219,
    127.539
   ]
  ],
  "T": 128.92
 },
 "7.08v": {
  "title": "One click on Allow",
  "texts": [],
  "sentences": [
   "On Thursday morning in the Sadeed hall, Shaima is preparing her notes for case file 2048 when a small window opens in her browser.",
   "A free add-on offers to write her meeting notes automatically.",
   "To start, it asks permission to read all her files and all her mail.",
   "Shaima stops before pressing Allow and asks Omar.",
   "Omar explains that a connected application is a service from an outside party that links to the Authority's account and works on its behalf.",
   "When you press Allow, the service receives an access token, like a visitor pass that opens doors without asking for the password.",
   "So the pass is only as safe as the company that holds it.",
   "In August 2025, attackers used stolen access tokens of a third-party chat tool to export data from customer accounts between 8 and 18 August, according to Google's threat investigators.",
   "The same investigators said they knew of more than 700 potentially affected organisations.",
   "A security review later noted that this activity looked like normal traffic from a trusted application, which made it hard to spot.",
   "The attackers then searched the stolen data for secrets such as passwords and access keys, so Shaima never types a password into a case note.",
   "Google advised affected organizations to review the integrations linked to that chat tool, cancel and replace the credentials, and check the connected systems for unauthorized access.",
   "The cloud provider's own notice advised replacing the access tokens of all connected applications and reviewing their access records.",
   "So Shaima presses Cancel, and asks the IT team, through the known contact, whether an approved note-taking tool exists.",
   "Hamad's rule is clear: only approved connected applications, each with a named owner and the least access it needs, reviewed regularly by the IT team.",
   "If you already pressed Allow, or you see an unknown application in your account, tell the IT team at once through the approved route, so the access can be cancelled."
  ],
  "timing": [
   [
    0.76,
    9.04
   ],
   [
    9.42,
    13.164
   ],
   [
    13.544,
    18.44
   ],
   [
    18.82,
    22.66
   ],
   [
    23.04,
    30.72
   ],
   [
    31.1,
    39.164
   ],
   [
    39.544,
    43.168
   ],
   [
    43.548,
    56.964
   ],
   [
    57.344,
    63.296
   ],
   [
    63.676,
    71.26
   ],
   [
    71.64,
    80.544
   ],
   [
    80.924,
    92.204
   ],
   [
    92.584,
    100.816
   ],
   [
    101.195,
    109.115
   ],
   [
    109.495,
    119.839
   ],
   [
    120.219,
    129.723
   ]
  ],
  "T": 131.1
 },
 "7.09v": {
  "title": "The sign-in nobody approved",
  "texts": [],
  "sentences": [
   "On Thursday afternoon in the Sadeed hall, an alert appears on Omar's laptop: a sign-in to his work account from a device he does not know.",
   "He did not approve it, so he calls Shaima over.",
   "He explains that a session is the signed-in state of an account, kept alive by a small token, so the person holding a stolen token may get in without the password.",
   "A large technology company's 2025 defence report says that information stealers have become an entry point, and that they collect credentials and session tokens.",
   "In November 2026, Europol announced that police in nine countries had found 6.4 million sets of victim data on seized criminal servers.",
   "Europol said the criminals sold the stolen logins to be used in later attacks, including ransomware.",
   "Its advice to victims: change passwords from a clean device, replace reused passwords, turn on multi-factor authentication, and clean an infected device before signing in again.",
   "At work, though, Omar changes nothing himself and deletes nothing; he reports the alert at once through the approved route.",
   "The IT team ends all his sessions, resets his sign-in, and checks what the account opened, including shared links, connected applications and case file 2048.",
   "Meanwhile, a voice message that sounds like Hamad reaches Shaima's phone.",
   "It says, in a hurry, that the list of today's applicants must be sent to a personal chat account right now.",
   "In July 2026, the FBI warned that criminals now use AI-generated video and voice to impersonate officials, and that a strong feeling of urgency or fear is a warning sign.",
   "The same warning advises checking what you see or hear through known official channels before you respond.",
   "In April 2026, the UAE Cyber Security Council said that more than 75 percent of cyber attacks start with phishing emails or fraudulent messages, often with pressure to act without thinking.",
   "So Shaima sends nothing, calls Hamad on the number in the Authority's own directory, and he confirms that he never sent a voice message.",
   "She reports the message through the approved route, and her habit for Lesson 7.2 is clear: use only approved cloud services, share with named people, allow only approved applications, and verify every unexpected request through a known contact."
  ],
  "timing": [
   [
    0.76,
    9.424
   ],
   [
    9.804,
    13.092
   ],
   [
    13.472,
    23.264
   ],
   [
    23.644,
    34.012
   ],
   [
    34.392,
    43.92
   ],
   [
    44.3,
    50.708
   ],
   [
    51.088,
    62.56
   ],
   [
    62.94,
    71.292
   ],
   [
    71.672,
    82.976
   ],
   [
    83.356,
    88.156
   ],
   [
    88.536,
    95.208
   ],
   [
    95.588,
    107.924
   ],
   [
    108.303,
    114.591
   ],
   [
    114.971,
    128.123
   ],
   [
    128.503,
    136.879
   ],
   [
    137.259,
    153.003
   ]
  ],
  "T": 154.38
 },
 "7.10v": {
  "title": "The update from a trusted supplier",
  "texts": [],
  "sentences": [
   "On Monday morning in the Sadeed hall, Hamad gathers the staff at the counter with a notice in his hand.",
   "The company that supplies the Authority's case system says that a new version is ready.",
   "Shaima needs that system to open case file 2048, so she asks Omar whether it is safe to install.",
   "Omar explains a supply-chain attack: criminals do not attack the Authority directly, but a supplier, a service or a piece of software that many organisations trust.",
   "Then the harm can reach many customers through something that looks normal, such as a routine update.",
   "In September 2025, the United States cybersecurity agency CISA warned about a self-spreading worm in a popular public library of code that developers use.",
   "It compromised over 500 software packages, stole developers' access keys, and used them to publish poisoned versions of other packages.",
   "CISA advised organisations to review every software dependency, change developer credentials, and require phishing-resistant multi-factor authentication.",
   "In October 2025, an independent body in the United Kingdom estimated that the cyber incident at one large car manufacturer cost the country about 1.9 billion pounds and affected more than 5,000 organisations, many of them its suppliers.",
   "In May 2026, an annual industry report on data breaches found that third parties were involved in 48 percent of breaches, a share 60 percent higher than the year before.",
   "In September 2026, the European Union Agency for Cybersecurity wrote that incidents at software suppliers, service providers and cloud environments kept causing large-scale impact in 2025.",
   "So Hamad sets the rule: staff do not install supplier updates themselves; the IT team checks the notice with the supplier through the contact named in the contract, checks the update itself, then installs it through the approved channel.",
   "Shaima waits, and by noon the IT team has confirmed the notice and updated the system, and case file 2048 opens as usual.",
   "Omar adds the warning signs for staff: a trusted program that suddenly behaves differently, a new permission request, or a message that claims to come from the supplier.",
   "Trusting a supplier is not the same as verifying it.",
   "If something in a trusted system looks wrong, stop and report it through the approved route, and let the IT team check it with the supplier through a known contact."
  ],
  "timing": [
   [
    0.76,
    6.88
   ],
   [
    7.26,
    11.892
   ],
   [
    12.272,
    19.184
   ],
   [
    19.564,
    30.532
   ],
   [
    30.912,
    37.032
   ],
   [
    37.412,
    48.02
   ],
   [
    48.4,
    57.016
   ],
   [
    57.396,
    67.572
   ],
   [
    67.952,
    84.248
   ],
   [
    84.628,
    95.836
   ],
   [
    96.216,
    109.488
   ],
   [
    109.868,
    123.788
   ],
   [
    124.168,
    132.736
   ],
   [
    133.115,
    143.579
   ],
   [
    143.959,
    148.279
   ],
   [
    148.659,
    156.987
   ]
  ],
  "T": 158.37
 },
 "7.11v": {
  "title": "When the supplier is the one attacked",
  "texts": [],
  "sentences": [
   "On Tuesday morning in the Sadeed hall, Hamad receives a message from the company that scans the Authority's documents, including those of case file 2048.",
   "The company says it has had a cyber incident of its own.",
   "Omar explains that a service provider or contractor holds access to the Authority's systems or information, and if the provider is compromised, that access can be misused.",
   "So Hamad asks the IT team to act at once.",
   "They suspend the contractor's accounts, check the log for what those accounts did, and contact the company through the person named in the contract.",
   "Shaima keeps working on the paper pages of case file 2048 and takes no shortcut.",
   "In July 2025, the FBI, CISA and their partners, including the UK National Cyber Security Centre, updated a joint advisory on one criminal group.",
   "It says the group targets large companies and their contracted IT help desks, and usually steals data to extort money, sometimes adding ransomware.",
   "In May 2025, after attacks on large shops in the United Kingdom, the National Cyber Security Centre advised all organisations to review how their help desks reset passwords.",
   "Press reports said the attackers had pretended to be staff when they called the help desks.",
   "In June 2024, a ransomware attack on a supplier of laboratory tests disrupted thousands of hospital appointments and operations in the first month.",
   "In October 2025, the United Kingdom and Singapore issued guidance on checking the security of key suppliers, and 67 members of the Counter Ransomware Initiative endorsed it.",
   "So Hamad sets the Authority's rule for every contractor: a named account for each person, never a shared login, only the access the job needs, and only for the time it needs.",
   "If someone calls and says they are from the contractor and asks you for access, a password reset or a code, do not give it.",
   "Ask the IT team to check the request, by calling back on the number in the contract, and let the IT team decide.",
   "By afternoon the contractor confirms through its named contact that the incident is contained; once its own checks are clear, the IT team restores only the access needed, with new credentials.",
   "If you hear that a supplier or contractor has had an incident, or you receive an unusual request from one, report it early through the approved route."
  ],
  "timing": [
   [
    0.76,
    10.144
   ],
   [
    10.524,
    14.268
   ],
   [
    14.648,
    25.664
   ],
   [
    26.044,
    29.668
   ],
   [
    30.048,
    38.16
   ],
   [
    38.54,
    44.78
   ],
   [
    45.16,
    56.248
   ],
   [
    56.628,
    66.42
   ],
   [
    66.8,
    78.2
   ],
   [
    78.58,
    83.932
   ],
   [
    84.312,
    93.696
   ],
   [
    94.076,
    105.716
   ],
   [
    106.096,
    117.999
   ],
   [
    118.379,
    125.891
   ],
   [
    126.271,
    133.159
   ],
   [
    133.539,
    144.963
   ],
   [
    145.343,
    153.863
   ]
  ],
  "T": 155.24
 },
 "7.12v": {
  "title": "The parts inside, the visitor with a laptop",
  "texts": [],
  "sentences": [
   "On Wednesday morning in the Sadeed hall, Hamad tells the staff that the case system holding case file 2048 is built from many parts.",
   "Not all of them were made by the supplier who sold it.",
   "Omar explains that a dependency is a part, a code library or a service that a system relies on, made by someone else.",
   "If one part has a flaw, the whole system can be put at risk.",
   "In September 2025, the United States cybersecurity agency CISA, the National Security Agency and 19 international partners published joint guidance on a software bill of materials.",
   "Such a list works like the ingredients on a food package, and it helps organisations identify the components, assess the risks and act.",
   "So Hamad asks the supplier of the case system for such a list, and the IT team keeps it with the system's record.",
   "When a flaw is announced in a component, the IT team can check at once whether the Authority's system contains it.",
   "Staff do not need to read the list; they need to ask the IT team before adding any new tool, plug-in or code library to a work system.",
   "Then a technician from the supplier comes to Shaima's counter with a laptop, to fix a slow report.",
   "He is polite, and he asks her to sign him in with her own account, to save time.",
   "Omar explains that a supplier with access to the Authority's systems is an external party, and privileged access gives more power, such as seeing every case or changing settings.",
   "Shaima does not share her account, because whatever he does would appear under her name.",
   "She calls the IT team on the number in the Authority's own directory, and they check the visit against the supplier contract.",
   "The UAE Cyber Security Council's National Third Party Security Policy, issued in September 2025, asks for a register of suppliers by criticality, tamper-proof audit trails, and higher security for high-risk suppliers.",
   "The UK National Cyber Security Centre notes, citing a 2025 survey, that very few UK businesses set minimum security standards for their suppliers.",
   "So the IT team gives the technician his own named account, with the least privilege needed, for the report server only, for that afternoon only, and with every action logged.",
   "When he finishes, the IT team closes the account and reviews the log.",
   "If a supplier asks you for access, a password or a changed setting that you did not expect, do not give it, ask the IT team to verify it through the contact named in the contract, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    9.544
   ],
   [
    9.924,
    12.852
   ],
   [
    13.232,
    21.488
   ],
   [
    21.868,
    25.852
   ],
   [
    26.232,
    39.432
   ],
   [
    39.812,
    48.164
   ],
   [
    48.544,
    55.912
   ],
   [
    56.292,
    62.724
   ],
   [
    63.104,
    71.36
   ],
   [
    71.74,
    77.548
   ],
   [
    77.928,
    82.992
   ],
   [
    83.372,
    94.46
   ],
   [
    94.84,
    100.12
   ],
   [
    100.499,
    107.243
   ],
   [
    107.623,
    122.935
   ],
   [
    123.315,
    134.235
   ],
   [
    134.615,
    145.271
   ],
   [
    145.651,
    150.427
   ],
   [
    150.807,
    163.215
   ]
  ],
  "T": 164.6
 },
 "7.13v": {
  "title": "Allowed to open, not to take",
  "texts": [],
  "sentences": [
   "On Thursday morning in the Sadeed hall, Shaima is about to send a short summary of case file 2048 to a colleague.",
   "She is in a hurry and picks the first name that appears in the address box.",
   "The mail system shows a warning: this person is outside the Authority.",
   "Shaima stops, and finds that she had chosen a similar name by mistake.",
   "Omar explains that an insider threat is harm that comes from someone who already has authorised access, such as a staff member or a contractor, and that it is often not meant.",
   "In September 2026, the United States cybersecurity agency CISA published an updated guide on insider threats, covering both intentional and unintentional harm.",
   "A summary of the guide notes that many recent insider threats are unintentional or negligent, such as mistyping a recipient or clicking a phishing link.",
   "In May 2026, an annual industry report on data breaches found that the human element was present in 62 percent of breaches.",
   "Then Shaima admits that she had also planned to paste the applicant's details into a free AI tool, to shorten the summary.",
   "The same 2026 report found that 45 percent of employees now use AI tools regularly on work devices, and that 67 percent of AI users reached them through non-corporate accounts.",
   "Hamad repeats the rule: only the AI tools the Authority has approved, through your own work account, and never an applicant's details in an outside tool.",
   "That afternoon, an alert shows that a large list of applicants was copied out of the case system by a staff account at night.",
   "Omar explains that this is unauthorized data extraction: information copied or moved out without approval, and being allowed to open a file is not the same as being allowed to take it.",
   "The IT team asks the account owner through a known contact, and he explains that he copied the list to a personal drive to finish his work at home.",
   "He meant no harm, yet the information has left the Authority's control, so the IT team has it deleted and records it as an incident.",
   "Some insiders act on purpose: in 2025, criminals offered cash to a small group of support agents at a large online exchange, and the agents copied customer data from the support tools.",
   "The company notified 69,461 customers, estimated the cost at between 180 and 400 million dollars, and refused to pay the 20 million dollar ransom demand.",
   "So Hamad sets three rules: each person sees only the cases the job needs, exports are logged, and work at home goes through the approved remote channel, never a personal drive.",
   "If you send something to the wrong person, copy information you should not, see someone else doing it, or are offered money or other benefits for information or access, refuse, and report it early through the approved route, because an honest mistake reported early limits the harm."
  ],
  "timing": [
   [
    0.76,
    8.2
   ],
   [
    8.58,
    13.38
   ],
   [
    13.76,
    18.608
   ],
   [
    18.988,
    23.5
   ],
   [
    23.88,
    34.344
   ],
   [
    34.724,
    46.676
   ],
   [
    47.056,
    57.04
   ],
   [
    57.42,
    66.084
   ],
   [
    66.464,
    74.192
   ],
   [
    74.572,
    86.956
   ],
   [
    87.336,
    97.104
   ],
   [
    97.484,
    104.492
   ],
   [
    104.871,
    116.2
   ],
   [
    116.579,
    124.859
   ],
   [
    125.239,
    133.735
   ],
   [
    134.115,
    146.667
   ],
   [
    147.047,
    159.839
   ],
   [
    160.219,
    171.931
   ],
   [
    172.311,
    188.607
   ]
  ],
  "T": 189.99
 },
 "7.14v": {
  "title": "Same name, new bank account",
  "texts": [],
  "sentences": [
   "On Sunday morning in the Sadeed hall, a finance colleague brings Shaima an email that reached the finance mailbox, and she reads it at the counter with Omar and Hamad beside her.",
   "It seems to come from the company that scans the documents of case file 2048, and it asks the Authority to pay the next invoice into a new bank account today.",
   "The name, the logo and the tone all look right.",
   "Omar explains supplier impersonation: criminals pretend to be a known supplier, or use a stolen supplier mailbox, to make the Authority pay the wrong account.",
   "In April 2026, the FBI's Internet Crime Complaint Center reported that business email compromise caused 3.046 billion dollars in losses in 2025, with 24,768 complaints, up from 21,442 in 2024.",
   "More than 30 million dollars of those losses had a confirmed link to artificial intelligence, so a well-written email proves nothing.",
   "In October 2026, Abu Dhabi Police warned companies about fake emails that impersonate business partners and ask them to change bank account details.",
   "The police said the fraud is often found only after the payment is made, and advised companies not to transfer money based on an email alone, but to verify through the entity's official and authorised channels.",
   "So Shaima does not reply and does not use any phone number in the email.",
   "She calls the contractor on the number written in the contract, and the contractor says it asked for no change.",
   "Then she reports the email through the approved route, the finance team holds the payment, and the IT team checks the mailbox.",
   "Hamad explains third-party governance: the Authority knows each supplier, what the supplier can reach, and what the supplier must do.",
   "The UAE National Third Party Security Policy, issued in September 2025, asks for a register of suppliers by criticality, checks of supplier compliance, and higher security for high-risk suppliers.",
   "So Hamad sets the Authority's rule: every supplier has a named owner and a contract contact, a bank-account change is confirmed only through that contact, and the supplier must tell the Authority at once if it has an incident.",
   "Then Hamad closes Chapter 7 with three habits.",
   "Habit one: use only the devices, software, extensions and cloud services the Authority has approved, install updates from its own system, never plug in an unknown drive, and report a lost device at once.",
   "Habit two: share only with named people, give the least access the job needs, allow only approved connected applications, never share a code or a login, and never approve a sign-in you did not start.",
   "Habit three: never give a password or code to anyone, verify every supplier request for access, an update or a payment change through a known contact, and report any mistake or anything odd early through the approved route.",
   "Shaima closes the email and the papers of case file 2048, and opens the next case, knowing that the digital workplace stays safe only while people verify what and whom they trust."
  ],
  "timing": [
   [
    0.76,
    10.576
   ],
   [
    10.956,
    21.252
   ],
   [
    21.632,
    25.04
   ],
   [
    25.42,
    35.5
   ],
   [
    35.88,
    55.56
   ],
   [
    55.94,
    64.34
   ],
   [
    64.72,
    74.872
   ],
   [
    75.252,
    87.396
   ],
   [
    87.776,
    91.88
   ],
   [
    92.26,
    98.5
   ],
   [
    98.88,
    106.608
   ],
   [
    106.988,
    115.268
   ],
   [
    115.647,
    129.495
   ],
   [
    129.875,
    144.251
   ],
   [
    144.631,
    148.495
   ],
   [
    148.875,
    162.627
   ],
   [
    163.007,
    175.919
   ],
   [
    176.299,
    190.603
   ],
   [
    190.983,
    204.135
   ]
  ],
  "T": 205.51
 },
 "8.01v": {
  "title": "The files that will not open",
  "texts": [],
  "sentences": [
   "On Monday morning in the Sadeed hall, Shaima opens case file 2048 on her counter computer, and the scanned documents will not open.",
   "Their names have changed, and a new note on the screen demands payment to unlock them.",
   "Omar sees it from the next desk and says calmly: do not click anything on that screen.",
   "Shaima takes her hands off the keyboard, and Hamad calls the IT team through the approved route.",
   "Omar explains ransomware: malware, or harmful software, that encrypts files, scrambling them so the files and the systems that rely on them become unusable.",
   "Then the criminals demand a ransom in exchange for unlocking them.",
   "It often enters through a message.",
   "An international survey published in July 2026 found that malicious emails and phishing together started half of the ransomware attacks it studied.",
   "Stolen sign-in details, or credentials, started another 23 percent.",
   "In April 2026, the FBI reported that the leading ransomware groups rely on stolen credentials, delete backups and then encrypt files.",
   "Hamad adds that ransomware is often sold as a service: one group builds it, and others rent it to attack.",
   "Europol counted more than 120 active ransomware brands in 2025.",
   "In the UAE, the 2025 national cybersecurity report found 58 percent growth in the number of ransomware groups operating in the country.",
   "The IT team isolates the computer, and the incident response team takes charge.",
   "Shaima tells the waiting applicant that there is a technical problem and that the Authority will contact him through its official channel.",
   "If you see files you cannot open, strange file names or a ransom note, stop, do not pay or reply, and report at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.848
   ],
   [
    9.228,
    14.652
   ],
   [
    15.032,
    20.144
   ],
   [
    20.524,
    26.716
   ],
   [
    27.096,
    38.04
   ],
   [
    38.42,
    42.692
   ],
   [
    43.072,
    45.52
   ],
   [
    45.9,
    56.028
   ],
   [
    56.408,
    62.432
   ],
   [
    62.812,
    72.988
   ],
   [
    73.368,
    80.448
   ],
   [
    80.828,
    86.876
   ],
   [
    87.255,
    97.311
   ],
   [
    97.691,
    103.235
   ],
   [
    103.615,
    110.983
   ],
   [
    111.363,
    120.531
   ]
  ],
  "T": 121.91
 },
 "8.02v": {
  "title": "Locked, and copied too",
  "texts": [],
  "sentences": [
   "That afternoon, a new email reaches the Authority's general mailbox, and Shaima reads it on Omar's computer with Omar beside her.",
   "The sender claims to have copied the Authority's files, including the papers of case file 2048, before locking them.",
   "He threatens to publish them unless the Authority pays.",
   "Omar explains double extortion: criminals encrypt the files and also threaten to release the data they stole.",
   "The US Cybersecurity and Infrastructure Security Agency notes that some criminals skip encryption and use only the threat to publish.",
   "In April 2026, Europol reported that extortion is shifting from encryption toward pure data theft.",
   "A major industry report published in October 2025 found that attackers sought to steal data in 80 percent of the incidents its response team investigated.",
   "So a backup can bring the files back, but it cannot undo the theft or the disclosure.",
   "Hamad adds that the files hold applicants' personal data, so the people affected may also be pressured.",
   "Shaima does not reply, does not open the link in the email, and does not forward it to colleagues.",
   "She reports it through the approved route, and the incident response team keeps the email as evidence.",
   "The authorised team decides on containment, communication and any response to the demand.",
   "When the applicant phones about his file, Shaima shares no unconfirmed details about the incident and says the Authority will contact him through its official channel.",
   "If you receive a threat to publish data, do not reply, negotiate or share it, and report it at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.968
   ],
   [
    9.348,
    17.34
   ],
   [
    17.72,
    21.248
   ],
   [
    21.628,
    29.356
   ],
   [
    29.736,
    38.664
   ],
   [
    39.044,
    46.412
   ],
   [
    46.792,
    57.28
   ],
   [
    57.66,
    63.132
   ],
   [
    63.512,
    70.16
   ],
   [
    70.54,
    76.324
   ],
   [
    76.704,
    82.944
   ],
   [
    83.324,
    89.516
   ],
   [
    89.895,
    99.615
   ],
   [
    99.995,
    107.771
   ]
  ],
  "T": 109.15
 },
 "8.03v": {
  "title": "Pressure from every side, and a stolen password",
  "texts": [],
  "sentences": [
   "On Tuesday morning, the applicant of case file 2048 comes to the counter and shows Shaima a text message on his phone.",
   "The sender claims to hold his documents and asks him to press the Authority to pay.",
   "Omar explains multi-extortion: criminals add pressure from several sides, on the institution and on the people whose data they took.",
   "In August 2025, an AI company reported one criminal who targeted at least 17 organisations, including government and emergency services.",
   "He threatened to publish stolen data, and some of his demands were above half a million dollars.",
   "Shaima thanks the applicant, asks him not to reply or open any link, and reports the message through the approved route.",
   "She tells him that the Authority will contact him only through its official channel.",
   "Later, Hamad shares the first finding of the IT team: the criminals entered with the password of a staff account.",
   "Omar explains credential-based attacks: criminals do not break in, they sign in with stolen credentials.",
   "A survey published in July 2026 found that 79 percent of ransomware attacks began with an identity-based approach, a wider group that includes stolen sign-in details.",
   "A breach report published in 2026 found that 73 percent of ransomware victims had a password-stealing infection or a credential leak in the year before the attack.",
   "Hamad adds that strong multi-factor authentication, a second check after the password, blocks most identity attacks where it is used.",
   "In the same survey, 97 percent of victims attacked through stolen credentials had it in some form, so partial protection was not enough.",
   "Never share a code or a password, never approve a sign-in you did not start, and report any message that pressures you or an applicant through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.68
   ],
   [
    9.06,
    14.412
   ],
   [
    14.792,
    23.288
   ],
   [
    23.668,
    34.396
   ],
   [
    34.776,
    40.728
   ],
   [
    41.108,
    48.548
   ],
   [
    48.928,
    54.04
   ],
   [
    54.42,
    61.596
   ],
   [
    61.976,
    68.816
   ],
   [
    69.196,
    81.34
   ],
   [
    81.72,
    92.304
   ],
   [
    92.684,
    100.988
   ],
   [
    101.368,
    110.775
   ],
   [
    111.155,
    120.443
   ]
  ],
  "T": 121.82
 },
 "8.04v": {
  "title": "A perfect email, written by a machine",
  "texts": [],
  "sentences": [
   "On Wednesday morning, Hamad brings Shaima and Omar a printed copy of the email that started the attack.",
   "It looks like a message from a partner entity, in perfect language, with the colleague's name and a real meeting date.",
   "The colleague opened the link and entered his password on a fake sign-in page.",
   "Omar explains that criminals now use artificial intelligence to write convincing messages and to prepare attacks faster.",
   "In January 2025, the UAE Cyber Security Council warned of a growing trend of AI-driven threats, including deepfakes, social engineering and enhanced ransomware.",
   "In February 2026, the Council said that attacks it stopped included the use of artificial intelligence to build attack tools.",
   "In August 2025, an AI company reported that a criminal with only basic coding skills used AI to build ransomware and sell it as a service.",
   "Hamad adds a calm note: some reports of AI-run ransomware describe research tests, not real attacks.",
   "In 2025, a security company found one such sample, which was later confirmed to be a university research test.",
   "The real lesson is simple: AI can help less skilled criminals do more, and good writing is no proof that a message is safe.",
   "So Shaima no longer judges a message by its spelling, its logo or its tone.",
   "She looks at what it asks: a link, a sign-in, a file, a payment or a hurry.",
   "Omar shows the safe step: sign in only through the address you already know, never through a link in a message.",
   "However real a message looks, verify any unexpected request through a known contact, and report it through the approved route."
  ],
  "timing": [
   [
    0.76,
    7.144
   ],
   [
    7.524,
    14.172
   ],
   [
    14.552,
    19.352
   ],
   [
    19.732,
    27.292
   ],
   [
    27.672,
    39.84
   ],
   [
    40.22,
    48.428
   ],
   [
    48.808,
    59.032
   ],
   [
    59.412,
    66.516
   ],
   [
    66.896,
    74.816
   ],
   [
    75.196,
    83.548
   ],
   [
    83.928,
    88.896
   ],
   [
    89.276,
    95.204
   ],
   [
    95.584,
    102.303
   ],
   [
    102.683,
    110.579
   ]
  ],
  "T": 111.96
 },
 "8.05v": {
  "title": "Stop it early, keep it small",
  "texts": [],
  "sentences": [
   "On Thursday afternoon, the IT team returns Shaima's computer, cleaned and checked.",
   "The documents of case file 2048 are back, restored from a backup that the criminals could not reach.",
   "Hamad gathers the team at the counter and holds up a one-page printed checklist.",
   "He explains that the damage stayed small because Shaima stopped at once and the team isolated the computer early.",
   "The US Cybersecurity and Infrastructure Security Agency advises keeping offline, encrypted backups and testing them regularly.",
   "The reason is that many ransomware variants search for backups to delete or encrypt them.",
   "The agency also advises keeping a printed copy of the response plan, in case the systems are down.",
   "Saudi Arabia's Essential Cybersecurity Controls require backups of critical assets, quick recovery after incidents, and regular tests that recovery works.",
   "A survey published in July 2026 found that 66 percent of organizations whose data was encrypted by ransomware restored it from backups.",
   "The same survey put the average recovery cost, without any ransom, at 1.7 million dollars.",
   "Omar reminds everyone that paying does not guarantee recovery, and a backup does not undo the theft of data.",
   "Hamad reads the checklist: stop working on the device, do not switch it off unless told to, as it may hold evidence, and do not pay or reply.",
   "Then report at once through the approved route, and follow the response plan.",
   "Every day, sign in only through known addresses, never share a code, and save work only in the Authority's approved locations.",
   "Shaima opens case file 2048 again, knowing that early reporting kept a serious attack small."
  ],
  "timing": [
   [
    0.76,
    6.472
   ],
   [
    6.852,
    13.98
   ],
   [
    14.36,
    19.664
   ],
   [
    20.044,
    26.86
   ],
   [
    27.24,
    36.48
   ],
   [
    36.86,
    42.068
   ],
   [
    42.448,
    48.76
   ],
   [
    49.14,
    59.316
   ],
   [
    59.696,
    69.272
   ],
   [
    69.652,
    76.348
   ],
   [
    76.728,
    84.792
   ],
   [
    85.172,
    94.892
   ],
   [
    95.272,
    99.903
   ],
   [
    100.283,
    108.923
   ],
   [
    109.303,
    116.383
   ]
  ],
  "T": 117.76
 },
 "8.06v": {
  "title": "One service, many hidden links",
  "texts": [],
  "sentences": [
   "On Sunday morning in the Sadeed hall, the appointment screen freezes, and the queue begins to grow.",
   "Shaima cannot open case file 2048, although her own computer works normally.",
   "Hamad walks to the small whiteboard and draws what the file needs to work.",
   "The portal, the digital identity sign-in, the payment service, the scanning supplier and the network all sit behind one counter.",
   "Omar explains dependencies: the systems and partners a service relies on, often without staff seeing them.",
   "If one link fails, the whole service at the counter can stop.",
   "That is why criminals target public services.",
   "In October 2025, the European Union Agency for Cybersecurity reported that public administration was the most targeted sector, with 38.2 percent of the incidents it analysed.",
   "In the UAE, the 2025 national cybersecurity report named government, finance and energy as the sectors most targeted.",
   "Hamad adds that an incident at a third party can stop the Authority's own work.",
   "In September 2025, ransomware at one service provider disrupted check-in at several European airports, and staff fell back to manual check-in.",
   "A breach report published in 2026 found a third party involved in 48 percent of the breaches it studied.",
   "Shaima does not guess the cause, and she reports the frozen screen through the approved route.",
   "Know what your service depends on, report any failure early through the approved route, and follow the approved backup procedure until the service returns."
  ],
  "timing": [
   [
    0.76,
    6.664
   ],
   [
    7.044,
    13.14
   ],
   [
    13.52,
    17.912
   ],
   [
    18.292,
    26.764
   ],
   [
    27.144,
    34.008
   ],
   [
    34.388,
    38.036
   ],
   [
    38.416,
    41.056
   ],
   [
    41.436,
    53.964
   ],
   [
    54.344,
    63.512
   ],
   [
    63.892,
    68.428
   ],
   [
    68.808,
    78.888
   ],
   [
    79.268,
    86.324
   ],
   [
    86.704,
    92.535
   ],
   [
    92.915,
    101.531
   ]
  ],
  "T": 102.91
 },
 "8.07v": {
  "title": "The portal that will not load, and the attack that aims to destroy",
  "texts": [],
  "sentences": [
   "Later that Sunday morning, the Authority's public portal stops loading for applicants.",
   "Hamad receives a notice from the IT team: the portal is under a distributed denial-of-service attack.",
   "Omar explains that such an attack floods a service with traffic from many devices, so real users cannot reach it.",
   "In February 2026, a major internet infrastructure company reported blocking 47.1 million such attacks in 2025, more than double the year before.",
   "The European Union Agency for Cybersecurity found that most of these attacks in 2025 were short campaigns with limited impact.",
   "Hamad adds that this attack blocks the door, but it does not, by itself, open the files.",
   "Sometimes, though, it is used to distract the team while another attack happens.",
   "Omar then explains destructive attacks, which aim to erase or damage data and systems, not to ask for money.",
   "In April 2026, the US Cybersecurity and Infrastructure Security Agency warned of a related danger: attackers had disrupted control devices in water, energy and government facilities.",
   "In February 2026, the UAE Cyber Security Council said organised attacks aimed to disrupt essential services, and asked the public to report threats only through official channels.",
   "At the counter, Shaima switches to the approved paper form and records the request of case file 2048 by hand.",
   "When the applicant asks what is happening, she shares only the official notice and does not guess who is behind it.",
   "Omar reminds the team not to post about the incident on social media or forward rumours.",
   "If a portal or system stops, report it through the approved route, use the approved backup procedure, and share only official updates."
  ],
  "timing": [
   [
    0.76,
    6.112
   ],
   [
    6.492,
    13.068
   ],
   [
    13.448,
    20.312
   ],
   [
    20.692,
    32.356
   ],
   [
    32.736,
    41.232
   ],
   [
    41.612,
    47.66
   ],
   [
    48.04,
    53.368
   ],
   [
    53.748,
    61.26
   ],
   [
    61.64,
    74.528
   ],
   [
    74.908,
    87.556
   ],
   [
    87.936,
    95.52
   ],
   [
    95.9,
    102.548
   ],
   [
    102.927,
    108.712
   ],
   [
    109.091,
    117.611
   ]
  ],
  "T": 118.99
 },
 "8.08v": {
  "title": "The quiet visitor, the stolen identity and the fake payment link",
  "texts": [],
  "sentences": [
   "On Monday morning, the applicant of case file 2048 shows Shaima a text message asking him to pay a fee through a link to finish his request.",
   "The message uses the Authority's name and even mentions his request.",
   "Shaima tells him that the Authority asks for payment only through its official portal or at the counter, and that he should not open the link.",
   "Omar explains that criminals attack digital identity and payment services because they lead directly to people and money.",
   "In April 2026, the UAE Cyber Security Council called digital identity one of the most valuable assets people and organisations own.",
   "The Council reported a 32 percent rise in attacks on digital identities, and advised multi-factor authentication.",
   "A breach report published in 2026 found that in phishing tests, people fell for fake texts and phone calls about 40 percent more often than for email.",
   "Shaima reports the message through the approved route, so the Authority can warn other applicants through its official channel.",
   "Then Hamad shares a note from the IT team: an account has been reading many applicant records at night, with no case to explain it.",
   "Omar explains cyberespionage: attackers stay hidden and quietly copy sensitive information, often for a long time.",
   "In February 2026, the UAE Cyber Security Council said that a large share of threats come from state-sponsored groups, alongside criminals.",
   "Hamad adds that staff often notice the first signs: a sign-in alert they did not expect, or a colleague asking for records with no case.",
   "Omar then checks a sign-in alert on his work phone, sees a sign-in he did not start, denies it, and reports it.",
   "Never approve a sign-in you did not start, open only the records your case needs, tell applicants to pay only through the official channel, and report anything unusual through the approved route."
  ],
  "timing": [
   [
    0.76,
    10.744
   ],
   [
    11.124,
    15.54
   ],
   [
    15.92,
    23.864
   ],
   [
    24.244,
    31.948
   ],
   [
    32.328,
    42.912
   ],
   [
    43.292,
    51.572
   ],
   [
    51.952,
    61.408
   ],
   [
    61.788,
    68.724
   ],
   [
    69.104,
    77.48
   ],
   [
    77.86,
    85.9
   ],
   [
    86.28,
    95.904
   ],
   [
    96.284,
    104.804
   ],
   [
    105.183,
    111.999
   ],
   [
    112.379,
    124.307
   ]
  ],
  "T": 125.69
 },
 "8.09v": {
  "title": "When one service stops, many people feel it",
  "texts": [],
  "sentences": [
   "On Tuesday afternoon, Hamad meets Shaima and Omar with a printed list of the appointments postponed during the week.",
   "Case file 2048 is on that list, and so are dozens of other applicants.",
   "On the whiteboard, he links the Authority to partner entities, suppliers, the payment service and the applicants.",
   "Omar explains interconnected vulnerabilities: when entities share systems and data, a weakness in one can reach the others.",
   "In August 2026, the UAE Cyber Security Council said it had stopped coordinated attacks on aviation, energy and education that used phishing to exploit users as the way in.",
   "So one careless click in one entity may open a path to others through shared systems or accounts.",
   "Hamad then explains the consequences, which are societal, financial and operational.",
   "In October 2025, a major industry report described how attacks on public services can delay emergency care, cancel classes and halt transport.",
   "In September 2025, after a ransomware attack on a check-in provider, one major European airport asked airlines to cancel half of a day's departures.",
   "In the same year, one large retailer reported losing about 206 million pounds of revenue after a cyber-attack.",
   "The UK National Cyber Security Centre handled 204 nationally significant incidents in the year to August 2025, up from 89, and called ransomware the most acute threat.",
   "Shaima understands that behind every postponed appointment is a person waiting for a service, and the trust of the public in the Authority.",
   "Omar reminds her that the reports she made this week helped the team protect other applicants and partner entities.",
   "Treat every link, sign-in and request as a door to many services: verify through a known contact, report early through the approved route, and keep serving people with the approved backup procedure."
  ],
  "timing": [
   [
    0.76,
    8.176
   ],
   [
    8.556,
    14.292
   ],
   [
    14.672,
    21.656
   ],
   [
    22.036,
    30.748
   ],
   [
    31.128,
    43.416
   ],
   [
    43.796,
    50.516
   ],
   [
    50.896,
    57.496
   ],
   [
    57.876,
    68.34
   ],
   [
    68.72,
    78.944
   ],
   [
    79.324,
    87.028
   ],
   [
    87.408,
    99.576
   ],
   [
    99.956,
    108.476
   ],
   [
    108.856,
    115.456
   ],
   [
    115.835,
    128.603
   ]
  ],
  "T": 129.98
 },
 "8.10v": {
  "title": "Which services must never stop",
  "texts": [],
  "sentences": [
   "On Wednesday morning, before the Sadeed hall opens, Hamad gathers the team at the counter.",
   "He holds a printed copy of the Authority's business continuity plan.",
   "He says that last week showed something important: the hall kept serving people, but only because some steps were ready.",
   "Omar explains business continuity management: planning in advance how the Authority keeps its key services running during a disruption.",
   "Saudi Arabia's Essential Cybersecurity Controls require business continuity to cover cybersecurity, incident response plans and a disaster recovery plan.",
   "The plan starts with one question: which services must never stop for long?",
   "Hamad shows the list: identity checks, urgent cases, payments and the applicant records behind files like case file 2048.",
   "These are the Authority's critical services.",
   "The US National Institute of Standards and Technology advises starting with a business impact analysis.",
   "It shows which work depends on which systems, and how long each service can stop before it causes serious harm.",
   "In October 2025, the head of the UK National Cyber Security Centre said organisations need a plan to keep operating without their IT.",
   "Shaima asks what her role is, since she does not write the plan.",
   "Hamad answers that every staff member must know the critical services at their counter, their part in the plan, and where the printed copy is kept.",
   "Know which of your services are critical, know your role in the continuity plan, and tell your manager through the approved route if a step in it no longer fits your work."
  ],
  "timing": [
   [
    0.76,
    6.57
   ],
   [
    6.95,
    10.57
   ],
   [
    10.95,
    17.48
   ],
   [
    17.86,
    26.21
   ],
   [
    26.59,
    36.96
   ],
   [
    37.34,
    42.07
   ],
   [
    42.45,
    51.59
   ],
   [
    51.97,
    54.71
   ],
   [
    55.09,
    62.05
   ],
   [
    62.43,
    68.81
   ],
   [
    69.19,
    78.53
   ],
   [
    78.91,
    83.28
   ],
   [
    83.66,
    92.32
   ],
   [
    92.7,
    102.28
   ]
  ],
  "T": 103.66
 },
 "8.11v": {
  "title": "How long, and how much",
  "texts": [],
  "sentences": [
   "Later that Wednesday morning, Hamad writes two questions on the whiteboard: how long, and how much.",
   "Omar explains cyber resilience: the Authority's ability to keep its critical services going during an attack, and to recover quickly after it.",
   "Disaster recovery is the part of the plan that brings systems and data back after a serious failure.",
   "In February 2026, the UAE Cyber Security Council said that protecting people and data, and keeping critical services running, are its top priorities.",
   "Hamad points to the first question, how long.",
   "The recovery time objective is the target time to bring a system back after it stops.",
   "The US National Institute of Standards and Technology says this time must fit inside the longest stop the service can bear without serious harm.",
   "Then he points to the second question, how much.",
   "The recovery point objective is the point in time to which data must be restored, so it shows how much recent work the Authority can afford to lose.",
   "Shaima remembers that last week the documents of case file 2048 came back, but a few notes typed that morning were lost.",
   "Omar explains why: they were saved on her desktop, not in the Authority's approved location, so no backup held them.",
   "Hamad adds that these targets are set by the service owners and the IT team, and approved by management.",
   "Staff help meet them in simple ways.",
   "Save your work only in the Authority's approved locations, know how long your service can wait, and report any lost data at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    6.904
   ],
   [
    7.284,
    16.476
   ],
   [
    16.856,
    23.24
   ],
   [
    23.62,
    34.684
   ],
   [
    35.064,
    38.04
   ],
   [
    38.42,
    43.988
   ],
   [
    44.368,
    53.392
   ],
   [
    53.772,
    56.916
   ],
   [
    57.296,
    66.248
   ],
   [
    66.628,
    74.644
   ],
   [
    75.024,
    82.584
   ],
   [
    82.964,
    89.3
   ],
   [
    89.68,
    92.344
   ],
   [
    92.723,
    101.819
   ]
  ],
  "T": 103.2
 },
 "8.12v": {
  "title": "A backup you have never tested is only a hope",
  "texts": [],
  "sentences": [
   "On Thursday morning, the IT team runs a recovery test in a Sadeed office, and Hamad invites Shaima and Omar to watch.",
   "A team member restores the records of case file 2048 from a backup onto a separate test computer.",
   "Shaima compares the restored documents with the paper folder, page by page.",
   "Hamad explains why the test matters: a backup that has never been restored may fail on the day it is needed.",
   "Saudi Arabia's Essential Cybersecurity Controls require periodic tests of how well recovery from backups works.",
   "Omar asks why the backups are kept apart from the network.",
   "In April 2026, the FBI reported that the leading ransomware groups delete backups before they encrypt files.",
   "So the US Cybersecurity and Infrastructure Security Agency advises keeping backups offline and encrypted, and testing them regularly.",
   "A survey published in July 2026 found that 66 percent of organizations whose data was encrypted by ransomware restored it from backups, up from 54 percent the year before.",
   "Omar records how long the restore took, so the team can compare it with the recovery time objective.",
   "Shaima finds one scanned page missing, and Hamad writes it on the test sheet for the IT team to fix.",
   "He says that finding a gap in a test is a success, because it is found before a real incident.",
   "Omar adds that staff must not make private copies on personal drives, because those copies are neither protected nor recovered.",
   "Save your work only in approved locations, take part in recovery tests when asked, and report any backup warning or missing file at once through the approved route."
  ],
  "timing": [
   [
    0.76,
    8.68
   ],
   [
    9.06,
    15.732
   ],
   [
    16.112,
    21.104
   ],
   [
    21.484,
    28.012
   ],
   [
    28.392,
    36.792
   ],
   [
    37.172,
    40.46
   ],
   [
    40.84,
    48.688
   ],
   [
    49.068,
    58.356
   ],
   [
    58.736,
    70.736
   ],
   [
    71.116,
    77.092
   ],
   [
    77.472,
    83.52
   ],
   [
    83.9,
    90.044
   ],
   [
    90.424,
    98.368
   ],
   [
    98.747,
    109.259
   ]
  ],
  "T": 110.64
 },
 "8.13v": {
  "title": "When the screens go dark, the service goes on",
  "texts": [],
  "sentences": [
   "On Sunday morning, the Authority runs a continuity exercise, and the counter screens in the Sadeed hall are switched off on purpose.",
   "Shaima takes the approved paper form from the drawer and serves the applicant of case file 2048 by hand.",
   "She records the time and a reference on the form, so the request can be entered into the system when it returns.",
   "Omar explains alternative operating procedures: approved ways to keep serving people when the usual systems are down.",
   "In September 2025, when ransomware stopped check-in systems at several European airports, staff kept passengers moving with manual check-in.",
   "Omar then picks up a printed contact list and calls a colleague on the desk telephone, because email may be down too.",
   "In October 2025, the UK government advised organisations to keep continuity plans and contact lists offline or on paper, including how to communicate if IT fails.",
   "Hamad warns that during an outage, criminals may send fake messages offering help or new channels.",
   "So staff use only the alternative channels written in the plan, and never a number or link sent in a message.",
   "On the whiteboard, Hamad shows who coordinates the recovery: one incident response team, with the service owners, the IT team and the communication team.",
   "Saudi Arabia's Essential Cybersecurity Controls require a response plan, escalation procedures and a way to notify the national authority.",
   "Coordination also reaches beyond one entity: in November 2026, Bahrain hosted the sixth Gulf cyber exercise, with five Gulf countries and the General Secretariat of the Gulf Cooperation Council.",
   "After the exercise, Shaima writes down that the paper forms ran short, and Hamad adds it to the plan.",
   "Know where the paper forms and printed contact list are, use only the approved alternative channels, follow the coordinating team, and take part in every exercise."
  ],
  "timing": [
   [
    0.76,
    8.776
   ],
   [
    9.156,
    15.924
   ],
   [
    16.304,
    22.76
   ],
   [
    23.14,
    31.228
   ],
   [
    31.608,
    41.04
   ],
   [
    41.42,
    48.764
   ],
   [
    49.144,
    61.528
   ],
   [
    61.908,
    68.484
   ],
   [
    68.864,
    75.632
   ],
   [
    76.012,
    85.876
   ],
   [
    86.256,
    95.64
   ],
   [
    96.02,
    109.604
   ],
   [
    109.984,
    116.728
   ],
   [
    117.107,
    127.907
   ]
  ],
  "T": 129.29
 },
 "8.14v": {
  "title": "Restore carefully, return stronger",
  "texts": [],
  "sentences": [
   "On Monday morning, the Sadeed hall is back to normal, and Shaima opens case file 2048 at her counter.",
   "The restored documents are there, the payment is correct, and the applicant can finally complete his request.",
   "Omar explains that recovery is not simply switching everything back on.",
   "The response team restores critical services first, from systems and backups it has checked, and watches for signs that the incident could return.",
   "Saudi Arabia's Essential Cybersecurity Controls require the ability to recover data and systems quickly after cybersecurity incidents, and to test that backup recovery works.",
   "The controls also require an incident report after the response, including what was done to contain the incident and recommendations for improvement.",
   "Hamad opens the week's notes: the paper forms ran short, one restored page was missing, and one contact number had changed.",
   "None of those lessons is hidden; each becomes a correction to the continuity plan.",
   "Shaima also checks the requests recorded on paper during the disruption and makes sure each one is entered once, not lost and not duplicated.",
   "Hamad closes Chapter 8 with three habits.",
   "Habit one: reduce the risk of ransomware by treating unexpected links, files, sign-ins and requests with care, verifying through a known contact or official channel, and reporting anything suspicious early.",
   "Habit two: protect critical public services by knowing their dependencies, using only approved alternative procedures during disruption, and sharing only official information.",
   "Habit three: build resilience before an incident by saving work in approved locations, keeping secure tested backups, knowing the continuity plan, and practising recovery.",
   "Shaima gives the applicant his completed papers, closes case file 2048, and opens the next case, knowing that resilience means keeping the public service going safely when the digital world does not go as planned."
  ],
  "timing": [
   [
    0.76,
    7.744
   ],
   [
    8.124,
    15.036
   ],
   [
    15.416,
    20.48
   ],
   [
    20.86,
    30.028
   ],
   [
    30.408,
    42.264
   ],
   [
    42.644,
    51.26
   ],
   [
    51.64,
    59.368
   ],
   [
    59.748,
    64.956
   ],
   [
    65.336,
    74.456
   ],
   [
    74.836,
    78.196
   ],
   [
    78.576,
    91.968
   ],
   [
    92.348,
    103.652
   ],
   [
    104.031,
    115.743
   ],
   [
    116.123,
    130.571
   ]
  ],
  "T": 131.95
 },
 "9.01v": {
  "title": "An alert is not yet an incident",
  "texts": [],
  "sentences": [
   "It is a quiet morning in the Sadeed hall, and Shaima opens case file 2048 on her laptop.",
   "A warning appears: her account was used to sign in last night, while she was at home asleep.",
   "Omar asks the question everyone asks: is this an attack, or just a mistake?",
   "Security teams separate three things: events, alerts and incidents.",
   "An event is anything observable that happens in a system, such as a sign-in.",
   "An alert is an event that a tool or a person has flagged as possibly harmful.",
   "An incident is confirmed when information or services are harmed or seriously threatened.",
   "That harm can expose private data, alter records or stop a service: confidentiality, integrity or availability.",
   "Many alerts turn out to be harmless, but some serious incidents begin as one small alert.",
   "Shaima does not need to decide which one this is.",
   "Confirming an incident is the job of the authorized incident response team.",
   "Her job is to notice, write down what she saw and when, and report it.",
   "She does not click inside the warning, and she does not try to fix the account herself.",
   "She calls the service desk on its known number, the approved route at Sadeed.",
   "In one major 2026 review of 2025 intrusions, organizations themselves spotted more than half of them first.",
   "Early reports like Shaima's are how that happens."
  ],
  "timing": [
   [
    0.76,
    6.952
   ],
   [
    7.332,
    13.092
   ],
   [
    13.472,
    19.16
   ],
   [
    19.54,
    25.564
   ],
   [
    25.944,
    30.936
   ],
   [
    31.316,
    36.572
   ],
   [
    36.952,
    42.304
   ],
   [
    42.684,
    51.18
   ],
   [
    51.56,
    57.584
   ],
   [
    57.964,
    61.252
   ],
   [
    61.632,
    66.408
   ],
   [
    66.788,
    72.092
   ],
   [
    72.472,
    76.984
   ],
   [
    77.363,
    81.683
   ],
   [
    82.063,
    90.775
   ],
   [
    91.155,
    94.539
   ]
  ],
  "T": 95.92
 },
 "9.02v": {
  "title": "When an account is no longer yours",
  "texts": [],
  "sentences": [
   "While the service desk checks Shaima's account, Omar's phone shows a sign-in approval request.",
   "Omar did not try to sign in.",
   "That means someone else may already have his password.",
   "A compromised account can look normal, because the attacker signs in with real credentials.",
   "A major global report published in 2026 found stolen credentials in thirty-nine percent of the breaches it studied.",
   "Watch for sign-ins at odd hours or from places you have never been.",
   "Watch for approval requests or password-reset messages that you did not start.",
   "Phishing-resistant multi-factor authentication can block more than ninety-nine percent of identity attacks, according to a 2025 industry report.",
   "But criminals can also steal the session a browser keeps open after you sign in, and use it without your password.",
   "In 2025, about one in three sets of credentials stolen by malware included such a live session.",
   "The phone is also a growing route: in one major review of 2025 intrusions, voice phishing was the second most common way in.",
   "A moment later, a caller who says he is from IT asks Omar to read out the code on his screen.",
   "Omar does not approve the request, does not share the code, and ends the call.",
   "A genuine support team does not need your code or your password.",
   "He reports both the request and the call to the service desk on its known number.",
   "Speed matters, because one study found more than a third of stolen credentials within a day of the theft."
  ],
  "timing": [
   [
    0.76,
    7.024
   ],
   [
    7.404,
    9.276
   ],
   [
    9.656,
    12.296
   ],
   [
    12.676,
    18.532
   ],
   [
    18.912,
    26.688
   ],
   [
    27.068,
    30.908
   ],
   [
    31.288,
    36.4
   ],
   [
    36.78,
    46.524
   ],
   [
    46.904,
    53.432
   ],
   [
    53.812,
    61.132
   ],
   [
    61.512,
    70.872
   ],
   [
    71.252,
    77.18
   ],
   [
    77.559,
    82.407
   ],
   [
    82.787,
    86.915
   ],
   [
    87.295,
    92.239
   ],
   [
    92.619,
    98.787
   ]
  ],
  "T": 100.17
 },
 "9.03v": {
  "title": "Files that change, data that leaves",
  "texts": [],
  "sentences": [
   "Later that morning, Omar opens the shared folder for case file 2048.",
   "The file names have changed, and none of the documents will open.",
   "These are common warning signs of ransomware, which makes files unusable, usually through encryption.",
   "Other signs include a ransom note, a very slow computer, or security tools that suddenly switch off.",
   "Criminals often steal information first, then threaten to publish it.",
   "Sometimes they steal and threaten without locking any files at all.",
   "A 2025 report by the UAE Cyber Security Council found fifty-eight percent growth in ransomware groups operating in the country.",
   "At the same moment, Shaima sees a notice that thousands of records were downloaded overnight.",
   "Large amounts of data leaving at unusual times can mean unauthorized access.",
   "A data breach can also be an accident, such as a file sent to the wrong person.",
   "Cloud services and applications can show warning signs too: new sharing links, changed settings, or users nobody recognises.",
   "One 2025 industry report saw an eighty-seven percent rise in destructive campaigns against its customers' cloud environments.",
   "Omar stops working in the folder, and he does not rename, delete or copy anything.",
   "He leaves the laptop as it is, because switching it off can destroy evidence the team may need.",
   "Shaima reports both signs through the approved route, and the two of them wait for the team's instructions.",
   "Only the authorized incident response team decides what to disconnect, what to restore, and how to answer any demand."
  ],
  "timing": [
   [
    0.76,
    6.28
   ],
   [
    6.66,
    9.996
   ],
   [
    10.376,
    16.664
   ],
   [
    17.044,
    23.884
   ],
   [
    24.264,
    29.184
   ],
   [
    29.564,
    34.508
   ],
   [
    34.888,
    43.84
   ],
   [
    44.22,
    49.62
   ],
   [
    50.0,
    55.64
   ],
   [
    56.02,
    61.084
   ],
   [
    61.464,
    69.888
   ],
   [
    70.268,
    79.7
   ],
   [
    80.079,
    85.383
   ],
   [
    85.763,
    91.475
   ],
   [
    91.855,
    98.047
   ],
   [
    98.427,
    105.483
   ]
  ],
  "T": 106.86
 },
 "9.04v": {
  "title": "When the assistant follows the wrong instructions",
  "texts": [],
  "sentences": [
   "Back at the counter, Shaima checks the summary that the authority's AI agent made earlier for case file 2048.",
   "The summary is strange: it recommends immediate approval and offers to send the whole file to an outside address.",
   "Nobody asked it to do either.",
   "In prompt injection, malicious instructions hidden in files, emails or web pages steer an AI system.",
   "These instructions do not have to be visible to people.",
   "In late 2025, the UK National Cyber Security Centre warned that AI models do not reliably separate instructions from data.",
   "So the risk cannot simply be switched off; it has to be limited and watched.",
   "Warning signs include an AI agent acting outside its task, asking for more access, or sending data where it should not go.",
   "Unusual speed or unusual volume of actions can also be a sign.",
   "In April 2026, cybersecurity agencies from several countries advised limiting what AI agents can do and keeping people in control.",
   "One 2025 industry study found that thirteen percent of organisations had reported a breach of their AI models or applications.",
   "Shaima does not approve the action and does not send anything.",
   "She does not try to test the assistant with new questions either.",
   "She records what the agent proposed and when, and reports it through the approved route.",
   "She tells the applicant, calmly, that the file needs a short check before it moves forward.",
   "An AI agent's strange behavior is a security event, and it is reported like any other."
  ],
  "timing": [
   [
    0.76,
    8.368
   ],
   [
    8.748,
    16.716
   ],
   [
    17.096,
    19.4
   ],
   [
    19.78,
    27.124
   ],
   [
    27.504,
    31.2
   ],
   [
    31.58,
    41.036
   ],
   [
    41.416,
    46.552
   ],
   [
    46.932,
    55.644
   ],
   [
    56.024,
    61.136
   ],
   [
    61.516,
    71.452
   ],
   [
    71.832,
    80.424
   ],
   [
    80.804,
    84.548
   ],
   [
    84.927,
    88.407
   ],
   [
    88.787,
    94.211
   ],
   [
    94.591,
    100.207
   ],
   [
    100.587,
    106.755
   ]
  ],
  "T": 108.14
 },
 "9.05v": {
  "title": "One report, the right route",
  "texts": [],
  "sentences": [
   "By midday, the service desk has four reports from the same hall.",
   "Each one alone looked small, but together they may point to one incident.",
   "This is why staff report early, without waiting for proof.",
   "A report that turns out harmless still helps the team rule out a risk.",
   "A report that is never made can cost much more.",
   "Shaima writes down what she saw, when, on which device, and who else was involved.",
   "She uses the approved route: the service desk on its known number and the official reporting form.",
   "She does not post about it in group chats or discuss it with the applicant.",
   "Escalation means passing the matter to the people with the authority to act.",
   "Saudi Arabia's Essential Cybersecurity Controls require the entities they cover to have escalation procedures and to classify incidents by severity.",
   "The service desk informs the incident response team, and the team informs management.",
   "Shaima's manager joins the call, but he does not take over the technical work.",
   "Gulf countries have national bodies that receive cyber incident reports from government entities.",
   "In Saudi Arabia this is the National Cybersecurity Authority, and in the UAE a national incident response plan sets reporting duties.",
   "Staff do not contact these bodies on their own; the institution's designated team does that.",
   "Your part is simple and essential: notice, write it down, and report it inside through the approved route."
  ],
  "timing": [
   [
    0.76,
    4.84
   ],
   [
    5.22,
    9.588
   ],
   [
    9.968,
    13.736
   ],
   [
    14.116,
    18.652
   ],
   [
    19.032,
    22.632
   ],
   [
    23.012,
    28.676
   ],
   [
    29.056,
    34.936
   ],
   [
    35.316,
    39.468
   ],
   [
    39.848,
    44.744
   ],
   [
    45.124,
    54.892
   ],
   [
    55.272,
    60.6
   ],
   [
    60.98,
    65.564
   ],
   [
    65.944,
    71.608
   ],
   [
    71.987,
    81.539
   ],
   [
    81.919,
    87.943
   ],
   [
    88.323,
    95.787
   ]
  ],
  "T": 97.17
 },
 "9.06v": {
  "title": "Contain first, keep the evidence",
  "texts": [],
  "sentences": [
   "The incident response team now gives the instructions, and the hall follows them step by step.",
   "The first goal is containment: stopping the harm from spreading.",
   "Speed matters: in 2025, one security company found that criminal attackers took about half an hour on average to move from the first device to others.",
   "The team asks Omar to disconnect his laptop from the network, both cable and Wi-Fi, but to leave it switched on.",
   "US cybersecurity guidance advises isolating affected devices, and switching them off only if they cannot be disconnected.",
   "Switching off can erase information that lives only in the computer's memory.",
   "That information may be evidence, and evidence helps the team understand what happened.",
   "So staff do not delete suspicious messages, clean up files, or run their own scans.",
   "Shaima adds the exact times and what each screen showed to the report form.",
   "Next comes her account, because someone signed in with it last night.",
   "As the team directs, she changes her password from a different, trusted computer, through the official portal only.",
   "She does not use any link from the suspicious warning.",
   "The team also ends every open session on her account, because a stolen session can work even without the password.",
   "In a 2025 operation, INTERPOL advised victims of stolen credentials to change passwords, freeze accounts and remove unauthorized access.",
   "If you used the same password anywhere else, tell the team and change it there too.",
   "Contain when told, keep the evidence, and secure the account through the official channel."
  ],
  "timing": [
   [
    0.76,
    6.784
   ],
   [
    7.164,
    11.316
   ],
   [
    11.696,
    21.944
   ],
   [
    22.324,
    29.092
   ],
   [
    29.472,
    37.728
   ],
   [
    38.108,
    43.1
   ],
   [
    43.48,
    48.496
   ],
   [
    48.876,
    54.564
   ],
   [
    54.944,
    59.864
   ],
   [
    60.244,
    63.628
   ],
   [
    64.008,
    71.112
   ],
   [
    71.492,
    74.684
   ],
   [
    75.064,
    82.24
   ],
   [
    82.619,
    93.035
   ],
   [
    93.415,
    98.431
   ],
   [
    98.811,
    104.475
   ]
  ],
  "T": 105.85
 },
 "9.07v": {
  "title": "Mistakes and shortcuts are reported too",
  "texts": [],
  "sentences": [
   "Not every incident starts with an attacker.",
   "That afternoon, Omar notices that an email with a page from case file 2048 went to the wrong outside address.",
   "An accidental disclosure of personal data is still a data breach.",
   "Omar feels embarrassed, but he reports it straight away through the approved route.",
   "He records who received it, when, and what it contained.",
   "He does not contact the recipient on his own, and he does not try to hide the mistake.",
   "Time limits can apply: in Saudi Arabia, the data protection authority must be notified within seventy-two hours where harm is likely.",
   "That notification is the institution's duty, and your quick report helps it meet the deadline.",
   "Meanwhile, Shaima sees a colleague paste case text into an AI website the authority has not approved.",
   "In a 2025 survey, seventy-one percent of security professionals said they worry about staff putting sensitive data into AI platforms.",
   "Shaima asks her colleague to stop, and she reports it as unauthorized AI use, calmly and without blame.",
   "The same applies to any AI agent that acts without approval or reaches data it should not.",
   "Each group has its part: staff notice and report, the response team investigates, and management decides and communicates.",
   "Saudi Arabia's Essential Cybersecurity Controls require response plans to set these roles and the communication channels in advance.",
   "A quick, honest report helps everyone, and it protects the people whose data was involved."
  ],
  "timing": [
   [
    0.76,
    3.472
   ],
   [
    3.852,
    11.412
   ],
   [
    11.792,
    16.184
   ],
   [
    16.564,
    21.58
   ],
   [
    21.96,
    25.872
   ],
   [
    26.252,
    31.244
   ],
   [
    31.624,
    41.104
   ],
   [
    41.484,
    47.076
   ],
   [
    47.456,
    54.248
   ],
   [
    54.628,
    64.42
   ],
   [
    64.8,
    72.528
   ],
   [
    72.908,
    79.22
   ],
   [
    79.6,
    87.519
   ],
   [
    87.899,
    96.803
   ],
   [
    97.183,
    103.087
   ]
  ],
  "T": 104.47
 },
 "9.08v": {
  "title": "From many signals to one picture",
  "texts": [],
  "sentences": [
   "The next morning, Shaima and Omar are invited to the operations room behind the Sadeed hall.",
   "On the wall screen, the incident response team has placed yesterday's reports on one timeline.",
   "Managing an incident follows a lifecycle, a set of stages that repeats and improves each time.",
   "The UAE national cyber incident response plan names six stages: prepare, protect, detect, respond, recover, and learn and improve.",
   "In its 2025 update, the US national standards institute placed incident response inside an institution's overall management of cyber risks.",
   "Detection often happens in a security operations centre, where analysts watch alerts from across the institution.",
   "At national level, the UAE plan also describes a national security operations centre working with sector centres.",
   "The team's first task is analysis: what happened, which systems and data are affected, and how far it has spread.",
   "Here the signs connect: the same misused account appears behind the locked files and the night download.",
   "The second task is prioritisation, because not every incident is equally serious.",
   "Saudi Arabia's Essential Cybersecurity Controls require incidents to be classified by severity, in line with the entity's risk classification.",
   "A stopped public service or personal data leaving the institution moves an incident to the top of the list.",
   "In the UK, the national cyber centre handled four hundred and twenty-nine incidents in one year, and two hundred and four were nationally significant.",
   "Shaima's notes, with exact times, help the team fix the order of events.",
   "Staff do not need to run these stages themselves.",
   "Their part is the one that starts everything: an early report with clear facts."
  ],
  "timing": [
   [
    0.76,
    6.09
   ],
   [
    6.47,
    12.09
   ],
   [
    12.47,
    19.07
   ],
   [
    19.45,
    28.76
   ],
   [
    29.14,
    39.2
   ],
   [
    39.58,
    46.78
   ],
   [
    47.16,
    54.98
   ],
   [
    55.36,
    62.58
   ],
   [
    62.96,
    69.1
   ],
   [
    69.48,
    75.86
   ],
   [
    76.24,
    85.74
   ],
   [
    86.12,
    93.01
   ],
   [
    93.39,
    101.96
   ],
   [
    102.34,
    107.48
   ],
   [
    107.86,
    111.0
   ],
   [
    111.38,
    117.12
   ]
  ],
  "T": 118.5
 },
 "9.09v": {
  "title": "Remove the cause, restore with care",
  "texts": [],
  "sentences": [
   "Once the picture is clear, the team moves through three steps: containment, eradication and recovery.",
   "Containment keeps the harm from spreading, as the hall saw yesterday.",
   "Eradication removes the cause: the misused access, the malware, and any way back in.",
   "Recovery brings services back safely, so the public can be served again.",
   "US cybersecurity guidance advises restoring systems in order of priority, from a list of critical services prepared in advance.",
   "Systems are restored on a clean network, so the problem does not return with them.",
   "Backups are checked before use, because a 2026 industry report found that attackers increasingly target backups.",
   "Restoring files does not undo information that has already been stolen.",
   "Alongside this work, digital forensics examines devices and records to show what really happened.",
   "In the UAE, the national computer emergency response team provides digital forensic investigations.",
   "In Saudi Arabia, the National Cybersecurity Authority offers joint analysis to national entities through its incident response service.",
   "Evidence must be handled so nobody can doubt how it was kept.",
   "So Omar's laptop is sealed, and he signs a form showing when he handed it over and to whom.",
   "Staff hand over devices only to the authorized team, and they do not open, copy or clean them first.",
   "Saudi Arabia's Essential Cybersecurity Controls require the incident report to record the containment and removal steps taken.",
   "By afternoon, the counter reopens, and the applicant's case moves forward on a clean system."
  ],
  "timing": [
   [
    0.76,
    7.984
   ],
   [
    8.364,
    12.948
   ],
   [
    13.328,
    20.168
   ],
   [
    20.548,
    25.732
   ],
   [
    26.112,
    34.944
   ],
   [
    35.324,
    40.004
   ],
   [
    40.384,
    48.328
   ],
   [
    48.708,
    53.244
   ],
   [
    53.624,
    60.2
   ],
   [
    60.58,
    67.468
   ],
   [
    67.848,
    76.704
   ],
   [
    77.084,
    81.188
   ],
   [
    81.567,
    87.879
   ],
   [
    88.259,
    95.339
   ],
   [
    95.719,
    103.855
   ],
   [
    104.235,
    110.043
   ]
  ],
  "T": 111.42
 },
 "9.10v": {
  "title": "One voice, the right notifications",
  "texts": [],
  "sentences": [
   "While systems return, a different kind of work begins in the meeting room.",
   "Managers, the incident response team and the communications office meet to coordinate.",
   "A serious incident affects people inside and outside the institution, so they must speak with one voice.",
   "Saudi Arabia's Essential Cybersecurity Controls require response plans to set roles, stakeholder communication and emergency channels in advance.",
   "The team lead calls by phone instead of email, because attackers may still be able to read messages.",
   "US cybersecurity guidance gives the same advice: use a separate channel during an incident.",
   "For the most serious incidents, the UAE national plan describes a national response group that coordinates across entities.",
   "The institution may also have legal duties to notify authorities, within set times.",
   "In Saudi Arabia, national entities report cybersecurity incidents to the National Cybersecurity Authority.",
   "Where personal data is breached and harm is likely, the data protection authority must be told within seventy-two hours of the institution learning of it.",
   "In April 2026, Kuwait issued mandatory baseline controls that include incident detection and response.",
   "These notifications are made by the designated team, not by individual staff.",
   "In the hall, the applicant asks Shaima whether his information is safe.",
   "She does not guess, and she does not share details; she gives him the approved notice and the official contact.",
   "Staff do not post about the incident on social media or answer journalists.",
   "If any message about the incident asks you to act, verify it through a known contact before you do anything."
  ],
  "timing": [
   [
    0.76,
    4.816
   ],
   [
    5.196,
    10.86
   ],
   [
    11.24,
    18.392
   ],
   [
    18.772,
    28.828
   ],
   [
    29.208,
    34.992
   ],
   [
    35.372,
    41.3
   ],
   [
    41.68,
    50.104
   ],
   [
    50.484,
    57.132
   ],
   [
    57.512,
    64.928
   ],
   [
    65.308,
    75.076
   ],
   [
    75.456,
    83.4
   ],
   [
    83.78,
    89.084
   ],
   [
    89.463,
    94.311
   ],
   [
    94.691,
    101.675
   ],
   [
    102.055,
    106.927
   ],
   [
    107.307,
    113.811
   ]
  ],
  "T": 115.19
 },
 "9.11v": {
  "title": "Learn, correct, improve",
  "texts": [],
  "sentences": [
   "One week later, Shaima, Omar and Lena return to the meeting room with Rania, a security analyst, their manager and the incident response team.",
   "The services are working again, but the incident is not finished until the institution learns from it.",
   "A post-incident investigation asks three questions: what happened, why did it happen, and what must change?",
   "The team rebuilds the timeline from system records, preserved evidence and the reports made by staff.",
   "It finds that a stolen account reached the shared folder, while an old setting allowed more access than the employee needed.",
   "Root-cause analysis looks beyond the first visible mistake to the conditions that allowed the incident to grow.",
   "Its purpose is not to find someone to blame.",
   "Its purpose is to correct the weakness before the next attacker or mistake reaches it.",
   "The actions are specific: remove unnecessary access, strengthen authentication, update the cloud settings and test the backups.",
   "The authority also limits the AI agent's access and requires human approval before it can share information or change a case.",
   "Each corrective action has an owner, a deadline and a check showing whether it worked.",
   "Saudi Arabia's Essential Cybersecurity Controls require post-incident reports, recommendations and periodic reviews of the response plan.",
   "The UAE national plan places learning and improvement at the end of the lifecycle so lessons become stronger protection.",
   "The US standards institute's 2025 guidance makes improvement continuous, because lessons from one incident should strengthen preparation for the next.",
   "Back in the hall, Shaima opens case file 2048 on a clean system and completes the applicant's request.",
   "The lasting result is not only a recovered service, but a safer institution."
  ],
  "timing": [
   [
    0.76,
    10.144
   ],
   [
    10.524,
    16.692
   ],
   [
    17.072,
    24.392
   ],
   [
    24.772,
    30.724
   ],
   [
    31.104,
    38.208
   ],
   [
    38.588,
    46.412
   ],
   [
    46.792,
    49.288
   ],
   [
    49.668,
    54.972
   ],
   [
    55.352,
    64.112
   ],
   [
    64.492,
    72.916
   ],
   [
    73.296,
    78.264
   ],
   [
    78.644,
    88.244
   ],
   [
    88.624,
    96.999
   ],
   [
    97.379,
    107.435
   ],
   [
    107.815,
    114.847
   ],
   [
    115.227,
    120.963
   ]
  ],
  "T": 122.34
 },
 "9.12v": {
  "title": "AI helps watch the signals",
  "texts": [],
  "sentences": [
   "A few days later, Rania shows Shaima and Omar how Sadeed watches for the next incident.",
   "Thousands of ordinary activities pass across the monitoring screen.",
   "People cannot examine every sign at the same speed, so AI can help find patterns in large volumes of security data.",
   "It can group related alerts and bring unusual activity to an analyst's attention.",
   "Behavioral detection asks whether an account, device or application is acting differently from its normal pattern.",
   "That matters because many modern intrusions do not depend on malware.",
   "One 2026 industry report found that eighty-two percent of the detections it studied involved no malware.",
   "Misuse of valid accounts was responsible for thirty-five percent of the cloud incidents in that research.",
   "This time, the system notices that an account is downloading far more case records than it normally does.",
   "It also sees that the activity is happening at an unusual time.",
   "AI raises the priority of the alert and gives Rania the related signals together.",
   "That saves time, but it does not prove that an incident has happened.",
   "Rania checks the evidence, the account history and the business context before deciding what the alert means.",
   "A 2025 security survey found that teams were already using AI mainly to add context to alerts and identify anomalies.",
   "AI can make monitoring faster and broader.",
   "The security professional still decides whether the signal is harmless, suspicious or an incident."
  ],
  "timing": [
   [
    0.76,
    6.376
   ],
   [
    6.756,
    11.82
   ],
   [
    12.2,
    20.144
   ],
   [
    20.524,
    26.068
   ],
   [
    26.448,
    33.912
   ],
   [
    34.292,
    38.996
   ],
   [
    39.376,
    46.576
   ],
   [
    46.956,
    53.748
   ],
   [
    54.128,
    60.728
   ],
   [
    61.108,
    65.908
   ],
   [
    66.288,
    71.808
   ],
   [
    72.188,
    76.004
   ],
   [
    76.383,
    83.127
   ],
   [
    83.507,
    92.411
   ],
   [
    92.791,
    95.767
   ],
   [
    96.147,
    102.339
   ]
  ],
  "T": 103.72
 },
 "9.13v": {
  "title": "Faster triage, faster response",
  "texts": [],
  "sentences": [
   "Rania's screen now shows three alerts at the same time.",
   "One is probably harmless, one needs investigation, and one may threaten a public service.",
   "Alert triage is the work of sorting those alerts so the most important ones are examined first.",
   "AI can help by bringing together related account activity, device events and earlier alerts.",
   "It can summarise the evidence and suggest which alert deserves attention first.",
   "A 2025 security survey found that only about one third of respondents were already using AI to investigate incidents.",
   "AI can also compare what it sees with threat intelligence: trusted information about current malicious activity.",
   "Saudi Arabia's National Cybersecurity Authority shares alerts, reports and indicators of compromise with national entities through Haseen.",
   "Threat intelligence can also help teams prepare for what may come next.",
   "In 2025, the UK National Cyber Security Centre warned that AI would shorten the time between disclosure of a vulnerability and its exploitation.",
   "Automation can then carry out approved defensive steps at machine speed.",
   "For example, an approved workflow may block a known malicious connection or isolate a device after defined conditions are met.",
   "But automation follows the institution's rules; an AI system does not invent its own authority.",
   "Actions that could interrupt services, disable accounts or affect important data need clear limits and the required human approval.",
   "Rania checks the evidence, and the incident response team lead approves the containment action.",
   "AI can make detection, triage and response faster, but authority stays with the people responsible for the decision."
  ],
  "timing": [
   [
    0.76,
    4.744
   ],
   [
    5.124,
    11.34
   ],
   [
    11.72,
    17.816
   ],
   [
    18.196,
    24.148
   ],
   [
    24.528,
    29.808
   ],
   [
    30.188,
    38.564
   ],
   [
    38.944,
    45.832
   ],
   [
    46.212,
    55.068
   ],
   [
    55.448,
    59.984
   ],
   [
    60.364,
    70.516
   ],
   [
    70.896,
    75.456
   ],
   [
    75.836,
    84.068
   ],
   [
    84.448,
    91.335
   ],
   [
    91.715,
    100.019
   ],
   [
    100.399,
    106.567
   ],
   [
    106.947,
    114.051
   ]
  ],
  "T": 115.43
 },
 "9.14v": {
  "title": "AI advises, people decide",
  "texts": [],
  "sentences": [
   "At closing time, the monitoring system marks Omar's large download as a serious threat.",
   "But Omar was making an approved backup for the recovery test.",
   "The alert is a false positive: harmless activity that the system has incorrectly marked as suspicious.",
   "In a 2025 security survey, sixty-six percent of respondents said AI systems produced many false positives.",
   "Too many false alerts can waste time and hide the warning that truly matters.",
   "AI can also produce a confident explanation that is incomplete or wrong.",
   "Rania therefore checks the authorization record, the device and the timing before closing the alert.",
   "She does not let the system disable Omar's account automatically.",
   "Joint guidance issued in April 2026 advised organisations to limit AI agents' autonomy and keep people responsible for consequential decisions.",
   "Human oversight means checking the evidence, understanding the context and being accountable for the decision.",
   "If an AI recommendation could stop a public service, expose data or remove someone's access, an authorized person must verify it.",
   "This chapter began with one small sign-in warning beside case file 2048.",
   "The first habit is to notice unusual accounts, files, data movements, applications and AI behavior.",
   "The second is to record the facts without changing or deleting possible evidence.",
   "The third is to report immediately through the approved route, even when you are not certain.",
   "The fourth is to follow the authorized team's instructions, while AI supports the work and people remain responsible for the decision."
  ],
  "timing": [
   [
    0.76,
    7.048
   ],
   [
    7.428,
    11.076
   ],
   [
    11.456,
    18.536
   ],
   [
    18.916,
    27.292
   ],
   [
    27.672,
    32.664
   ],
   [
    33.044,
    38.036
   ],
   [
    38.416,
    44.56
   ],
   [
    44.94,
    48.732
   ],
   [
    49.112,
    59.768
   ],
   [
    60.148,
    66.412
   ],
   [
    66.792,
    75.768
   ],
   [
    76.148,
    82.148
   ],
   [
    82.528,
    90.183
   ],
   [
    90.563,
    95.843
   ],
   [
    96.223,
    101.599
   ],
   [
    101.979,
    110.259
   ]
  ],
  "T": 111.64
 },
 "10.01v": {
  "title": "Rules, owners, accountability",
  "texts": [],
  "sentences": [
   "Before the hall opens, Shaima finds an updated security policy beside case file 2048.",
   "Omar asks why a policy matters at the service desk.",
   "A cybersecurity policy sets the institution's rules for protecting its information and services.",
   "Governance means that leadership sets these rules, communicates them, and enforces them.",
   "Roles, responsibilities, and authorities are written down, so everyone knows who decides what.",
   "Each important system and set of information has a named risk owner.",
   "The owner decides how those risks are treated, within the limits set by management.",
   "In each Gulf country, a national authority sets baseline security controls that the government entities it covers must apply.",
   "Institutions keep records and evidence to show that they comply.",
   "The rules apply to every member of staff, at every level.",
   "If a rule cannot be followed in a real situation, do not create your own workaround.",
   "Tell your manager, who can request an exception through the approved route.",
   "An approved exception is documented, limited in time, and justified by risk.",
   "Shaima reads the new section and notes who owns the risks of the case records system.",
   "Accountability begins with knowing the rules and who owns each risk."
  ],
  "timing": [
   [
    0.76,
    7.456
   ],
   [
    7.836,
    11.052
   ],
   [
    11.432,
    18.752
   ],
   [
    19.132,
    24.772
   ],
   [
    25.152,
    31.56
   ],
   [
    31.94,
    36.38
   ],
   [
    36.76,
    42.928
   ],
   [
    43.308,
    51.732
   ],
   [
    52.112,
    56.696
   ],
   [
    57.076,
    61.18
   ],
   [
    61.56,
    66.816
   ],
   [
    67.196,
    71.444
   ],
   [
    71.823,
    77.656
   ],
   [
    78.035,
    83.267
   ],
   [
    83.647,
    88.543
   ]
  ],
  "T": 89.92
 },
 "10.02v": {
  "title": "Risks are ranked, controls are proven",
  "texts": [],
  "sentences": [
   "Later that morning, Shaima and Omar look at the risk register for the case records system.",
   "A risk assessment asks what could go wrong, how likely it is, and how much harm it would cause.",
   "No institution can fix everything at once.",
   "Leadership decides how much risk the institution can accept, and the highest risks are treated first.",
   "Each gap in the register gets an owner and a target date.",
   "A major international breach report for 2026 found that exploiting a software vulnerability was the most common way in, at 31 percent of breaches.",
   "That is why delayed updates appear high on the register.",
   "Security controls are the measures that reduce risk, such as timely updates, multi-factor authentication, and checked backups.",
   "Compliance means showing, with evidence, that the required controls are really in place.",
   "In Kuwait, for example, entities must assess their own compliance at least once a year.",
   "Risk also comes from third parties, such as suppliers, service providers, and cloud services.",
   "The same 2026 report found a third party involved in 48 percent of breaches.",
   "Qatar's national standard requires outsourced work to meet the same security requirements.",
   "Give a supplier information or access only when the request is approved and confirmed through the known contract contact.",
   "If a supplier asks for something unusual, report it through the approved route.",
   "Shaima sees that case file 2048 is scanned by a supplier, so that supplier is in the register too."
  ],
  "timing": [
   [
    0.76,
    5.728
   ],
   [
    6.108,
    11.7
   ],
   [
    12.08,
    15.2
   ],
   [
    15.58,
    22.3
   ],
   [
    22.68,
    25.944
   ],
   [
    26.324,
    36.572
   ],
   [
    36.952,
    40.528
   ],
   [
    40.908,
    49.26
   ],
   [
    49.64,
    55.64
   ],
   [
    56.02,
    61.804
   ],
   [
    62.184,
    68.688
   ],
   [
    69.068,
    74.732
   ],
   [
    75.112,
    81.04
   ],
   [
    81.419,
    88.739
   ],
   [
    89.119,
    93.991
   ],
   [
    94.371,
    100.947
   ]
  ],
  "T": 102.33
 },
 "10.03v": {
  "title": "Measured, reviewed, improved",
  "texts": [],
  "sentences": [
   "At the end of the week, Omar shows Shaima the monthly security dashboard on a tablet.",
   "Governance does not end once the rules are written.",
   "The institution also checks whether its controls are working.",
   "It can measure, for example, how quickly updates are installed and how many suspicious messages staff report.",
   "A widely used guide for this work is the Cybersecurity Framework of the United States National Institute of Standards and Technology.",
   "Its current version, 2.0, groups security outcomes into six functions.",
   "They are Govern, Identify, Protect, Detect, Respond, and Recover.",
   "Govern sits at the centre and guides the other five.",
   "The framework describes the outcomes to reach, not the tools to buy.",
   "Under it, the results of risk management are reviewed and used to adjust the strategy.",
   "The international standard ISO/IEC 27001 sets requirements for an information security management system.",
   "Both ask the institution to keep improving, not to reach a finish line.",
   "The numbers are only useful if they are honest.",
   "Report every suspicious event through the approved route, even when nothing was harmed.",
   "Shaima sees that the message she reported last month is counted on the dashboard."
  ],
  "timing": [
   [
    0.76,
    6.76
   ],
   [
    7.14,
    10.48
   ],
   [
    10.86,
    14.56
   ],
   [
    14.94,
    22.07
   ],
   [
    22.45,
    31.04
   ],
   [
    31.42,
    37.3
   ],
   [
    37.68,
    43.18
   ],
   [
    43.56,
    46.73
   ],
   [
    47.11,
    51.17
   ],
   [
    51.55,
    57.07
   ],
   [
    57.45,
    68.18
   ],
   [
    68.56,
    73.46
   ],
   [
    73.84,
    76.53
   ],
   [
    76.91,
    82.29
   ],
   [
    82.67,
    87.47
   ]
  ],
  "T": 88.85
 },
 "10.04v": {
  "title": "AI has owners and risk levels",
  "texts": [],
  "sentences": [
   "In the Sadeed hall, Omar suggests using an AI tool to summarise case file 2048.",
   "Shaima keeps the file closed and asks who is responsible for that tool.",
   "AI systems are governed like other systems, with rules, owners, and accountability.",
   "In 2025, the UAE Cyber Security Council issued a national policy that sets minimum security requirements for adopting AI.",
   "In Saudi Arabia, the National Cybersecurity Authority has published draft AI cybersecurity guidelines for public consultation.",
   "The draft covers the whole life of an AI system, from design and use to retirement.",
   "The institution stays responsible for its services, whether or not it uses AI.",
   "Not every use of AI carries the same risk.",
   "Saudi AI ethics principles sort AI systems into four risk levels.",
   "They are little or no risk, limited risk, high risk, and unacceptable risk.",
   "High-risk systems are assessed before and after they are put into use.",
   "A tool that drafts a general notice is not the same as one that reads an applicant's personal data.",
   "That is why the UAE policy asks for security measures that match how each AI system is used.",
   "Before you use an AI tool for work, check that it is approved for that task and that kind of data.",
   "If you are not sure, ask through the approved route before any information goes in."
  ],
  "timing": [
   [
    0.76,
    6.88
   ],
   [
    7.26,
    11.75
   ],
   [
    12.13,
    17.7
   ],
   [
    18.08,
    27.32
   ],
   [
    27.7,
    36.63
   ],
   [
    37.01,
    43.35
   ],
   [
    43.73,
    48.89
   ],
   [
    49.27,
    52.63
   ],
   [
    53.01,
    58.84
   ],
   [
    59.22,
    65.24
   ],
   [
    65.62,
    69.84
   ],
   [
    70.22,
    76.77
   ],
   [
    77.15,
    83.63
   ],
   [
    84.01,
    89.75
   ],
   [
    90.13,
    95.0
   ]
  ],
  "T": 96.38
 },
 "10.05v": {
  "title": "Tested, listed, approved, supervised",
  "texts": [],
  "sentences": [
   "Omar brings Shaima the institution's list of approved AI tools.",
   "A tool reaches that list only after its security has been assessed.",
   "A world survey published in 2026 found that 64 percent of organisations assess the security of AI tools, up from 37 percent a year earlier.",
   "In the same survey, 87 percent named AI-related vulnerabilities as the fastest-growing cyber risk in 2025.",
   "One risk tested before approval is prompt injection: hidden instructions in a file or web page that can change how an AI tool behaves.",
   "This risk ranks first in a widely used international list of risks for AI language applications.",
   "The UAE national AI security policy requires an accurate inventory of AI systems and their components.",
   "What is not on the list is much harder to protect, monitor, or hold anyone accountable for.",
   "Each approval states which tasks and which kinds of data a tool may handle.",
   "Approval does not replace human judgement.",
   "The UAE AI Charter stresses human oversight, and the national policy requires human intervention in critical decisions.",
   "An AI draft is a suggestion until an authorised person checks it.",
   "Shaima reads the AI draft against case file 2048 and corrects a wrong date.",
   "The decision on the application remains hers, within her authorization.",
   "Use only listed tools, check every output, and report anything strange through the approved route."
  ],
  "timing": [
   [
    0.76,
    5.608
   ],
   [
    5.988,
    10.188
   ],
   [
    10.568,
    21.8
   ],
   [
    22.18,
    30.964
   ],
   [
    31.344,
    40.368
   ],
   [
    40.748,
    47.492
   ],
   [
    47.872,
    55.84
   ],
   [
    56.22,
    62.484
   ],
   [
    62.864,
    68.072
   ],
   [
    68.452,
    71.14
   ],
   [
    71.52,
    80.424
   ],
   [
    80.804,
    85.58
   ],
   [
    85.96,
    91.743
   ],
   [
    92.123,
    97.163
   ],
   [
    97.543,
    103.975
   ]
  ],
  "T": 105.35
 },
 "10.06v": {
  "title": "Agents act, so agents need limits",
  "texts": [],
  "sentences": [
   "In the Sadeed hall, a newly approved AI agent now sends appointment reminders to applicants.",
   "Omar says it can also update records, and Shaima asks what exactly it is allowed to do.",
   "An AI agent does more than answer questions.",
   "It can plan steps, use tools, and take permitted actions by itself.",
   "The UAE federal government has set a goal to run 50 percent of its operations, services, and tasks with agentic AI within two years, under the principle that a human leads and AI enables.",
   "In May 2026, cybersecurity agencies from five countries published joint guidance on adopting AI agents carefully.",
   "It advises starting with low-risk, well-defined tasks.",
   "An agent should have only the access its task needs, which is the principle of least privilege.",
   "Each agent should have its own identity, so that its actions can be traced back to it.",
   "Actions with high impact need the approval of an authorised person.",
   "The guidance also warns that hidden instructions in a file or web page can steer an agent that reads it.",
   "That is why every agent needs a named owner, who is accountable for what it does.",
   "Then Shaima sees that a reminder carries the case number of a different applicant.",
   "She stops using the agent for that task, and she does not try to fix it, delete messages, or test it again.",
   "She reports it at once through the approved route, with what she saw, when, and which file, and the authorized incident response team decides what happens next, including whether to pause the agent."
  ],
  "timing": [
   [
    0.76,
    6.616
   ],
   [
    6.996,
    12.972
   ],
   [
    13.352,
    16.784
   ],
   [
    17.164,
    21.964
   ],
   [
    22.344,
    36.312
   ],
   [
    36.692,
    45.404
   ],
   [
    45.784,
    49.864
   ],
   [
    50.244,
    56.172
   ],
   [
    56.552,
    61.568
   ],
   [
    61.948,
    66.316
   ],
   [
    66.696,
    73.104
   ],
   [
    73.484,
    78.884
   ],
   [
    79.263,
    83.847
   ],
   [
    84.227,
    90.995
   ],
   [
    91.375,
    103.231
   ]
  ],
  "T": 104.61
 },
 "10.07v": {
  "title": "Approved use, early reports, regular review",
  "texts": [],
  "sentences": [
   "At the end of the week, Omar admits to Shaima that he pasted a few lines from a note in case file 2048 into a public AI chat on his own phone.",
   "He is worried, and Shaima goes with him to report it.",
   "An acceptable-use policy says which AI tools staff may use, for which tasks, and with which information.",
   "A major international breach report for 2026 found that 45 percent of employees now use AI regularly on work devices, up from 15 percent a year earlier.",
   "It also found that 67 percent of those users do so through personal accounts that the institution cannot see.",
   "What is typed into a personal account leaves the institution's control.",
   "Never enter an applicant's data, personal data, or confidential information into an AI tool that is not approved for it.",
   "If it has already happened, or an approved tool behaves strangely, report it at once through the approved route.",
   "Say what happened, when, and which file, and do not try to delete or repair anything yourself.",
   "An early report is not an accusation, because it lets the institution act sooner and learn from the event.",
   "Many AI tools come from a third party, so the provider's risks become the institution's risks too.",
   "The UAE national AI security policy requires the supply-chain risks of AI systems to be managed.",
   "One approval is not enough, because updates, new features, and new uses can change the risk.",
   "That is why the UAE policy includes monitoring, response, and performance monitoring, and the international standard for AI management systems calls for monitoring AI throughout its life.",
   "Shaima and Omar leave with the habits of this lesson: use approved tools, protect information, report early, and expect every approval to be reviewed again."
  ],
  "timing": [
   [
    0.76,
    9.88
   ],
   [
    10.26,
    13.84
   ],
   [
    14.22,
    21.83
   ],
   [
    22.21,
    33.66
   ],
   [
    34.04,
    42.06
   ],
   [
    42.44,
    46.64
   ],
   [
    47.02,
    55.06
   ],
   [
    55.44,
    61.87
   ],
   [
    62.25,
    68.42
   ],
   [
    68.8,
    75.59
   ],
   [
    75.97,
    82.23
   ],
   [
    82.61,
    90.12
   ],
   [
    90.5,
    96.64
   ],
   [
    97.02,
    109.21
   ],
   [
    109.59,
    120.27
   ]
  ],
  "T": 121.65
 },
 "10.08v": {
  "title": "A familiar face is not proof",
  "texts": [],
  "sentences": [
   "On Monday morning, a video call appears on Shaima's laptop at the service desk.",
   "The face and voice seem to be those of her department director.",
   "He asks her to send case file 2048 to a new address at once, and to tell no one.",
   "Omar notices that Shaima has stopped typing.",
   "AI now helps attackers work faster and on a larger scale.",
   "In November 2026, a major threat-intelligence team reported that attackers are moving from simple prompts to autonomous tools that carry out several steps of an intrusion by themselves.",
   "A year earlier, the same team found malware that asks an AI model for new code while it is running, which makes it harder to recognise.",
   "Impersonation is changing too.",
   "Interpol's campaign launched in October 2026 warns that AI can copy a real face or voice from a few photos, videos, or audio clips found online.",
   "In its report for 2025, the United States FBI recorded 22,364 complaints involving AI, with losses of nearly 893 million dollars.",
   "Those complaints involved fake profiles, voice clones, fake identity documents, and believable videos.",
   "A familiar face or voice is no longer proof of who is calling.",
   "Urgency, secrecy, and a request to change the usual route are warning signs.",
   "Shaima ends the call and phones the director on his known internal number, and he says he did not call her.",
   "She does not send the file, and she reports the call through the approved route with the time and what was asked, and the authorised incident response team decides what happens next."
  ],
  "timing": [
   [
    0.76,
    6.088
   ],
   [
    6.468,
    10.164
   ],
   [
    10.544,
    16.76
   ],
   [
    17.14,
    20.02
   ],
   [
    20.4,
    24.456
   ],
   [
    24.836,
    36.668
   ],
   [
    37.048,
    45.736
   ],
   [
    46.116,
    48.156
   ],
   [
    48.536,
    59.144
   ],
   [
    59.524,
    72.436
   ],
   [
    72.816,
    80.28
   ],
   [
    80.66,
    85.076
   ],
   [
    85.456,
    91.047
   ],
   [
    91.427,
    97.787
   ],
   [
    98.167,
    108.247
   ]
  ],
  "T": 109.63
 },
 "10.09v": {
  "title": "New tricks, same habit: verify first",
  "texts": [],
  "sentences": [
   "On Tuesday morning, a text message arrives on Shaima's work phone, saying her account will be locked unless she taps a link.",
   "At the next desk, Omar reads an AI summary of a document the applicant uploaded to case file 2048.",
   "Attackers keep changing their methods, and email is no longer the only way in.",
   "A major 2026 breach report found that in phishing tests by text message and voice call, a typical 2 percent of staff responded, against 1.4 percent for email, about 40 percent higher.",
   "The number of such tests was small, so treat the figure as a warning, not a rule.",
   "The same report found that 41 percent of social-engineering breaches used a way in other than email.",
   "The European Union cybersecurity agency reported that phishing was behind 60 percent of the intrusions it observed between July 2024 and June 2025.",
   "It added that by early 2025, AI-supported phishing reportedly made up over 80 percent of observed social-engineering activity.",
   "In 2025, Google's threat-intelligence team also saw attackers use false pretexts to talk AI tools into ignoring their safety rules.",
   "Shaima does not tap the link; she opens the official staff portal and calls the IT desk on its known number.",
   "The IT desk confirms it sent no such message, and Shaima reports the text through the approved route.",
   "Then Omar sees that the AI summary ends with a line telling him to send the applicant's records to an outside address.",
   "Connected AI tools read outside content, such as emails, web pages, and files, and instructions hidden in that content can change how the tool behaves.",
   "A widely used international list of AI application risks ranks this first in its 2025 edition, and notes that the hidden text may not be visible to people.",
   "Omar does not follow the line and sends nothing.",
   "He treats the summary as unverified and reports it through the approved route, naming the file and the tool."
  ],
  "timing": [
   [
    0.76,
    8.128
   ],
   [
    8.508,
    16.236
   ],
   [
    16.616,
    21.92
   ],
   [
    22.3,
    34.9
   ],
   [
    35.28,
    40.392
   ],
   [
    40.772,
    47.18
   ],
   [
    47.56,
    58.936
   ],
   [
    59.316,
    68.22
   ],
   [
    68.6,
    78.152
   ],
   [
    78.532,
    85.444
   ],
   [
    85.824,
    91.92
   ],
   [
    92.3,
    99.236
   ],
   [
    99.615,
    109.984
   ],
   [
    110.363,
    121.907
   ],
   [
    122.287,
    125.311
   ],
   [
    125.691,
    132.315
   ]
  ],
  "T": 133.69
 },
 "10.10v": {
  "title": "Trust between machines needs proof",
  "texts": [],
  "sentences": [
   "On Wednesday, a notice appears on the office monitor: an AI agent asks for access to the case records and waits for a person to approve it.",
   "Omar says the name looks like the records assistant, and Shaima asks to check first.",
   "Systems and AI agents now send requests to each other without a person in between.",
   "A name on a screen is not proof of who sent a request.",
   "Joint guidance from national cyber agencies in May 2026 advises strong identity and access management and the least privilege.",
   "Industry research from 2025 proposes that each agent has its own verifiable identity and temporary access that ends with the task.",
   "Shaima does not approve the request, and she calls the agent's owner on the known internal number.",
   "The owner says no new agent was planned, so she reports the notice through the approved route, and the authorised incident response team decides what happens next.",
   "More government processes now run automatically.",
   "In December 2025, agencies from several countries published joint guidance on AI in the technology that runs essential services.",
   "It calls for human oversight, continuous monitoring, and ways to stop safely.",
   "If an automated step gives a strange result, do not correct it yourself; stop, keep what you saw, and report it.",
   "Encryption scrambles records so outsiders cannot read them, but future quantum computers may break some current methods.",
   "In October 2026, the United States standards institute warned that data can be collected now and opened later, once quantum technology matures.",
   "The United Kingdom's national cyber centre set indicative dates: find where encryption is used and plan by 2028, finish the first priorities by 2031, and complete the move by 2035.",
   "In the Gulf, the Saudi National Cryptographic Standards include an appendix on post-quantum cryptography, and the UAE National Cryptography Center says it supports entities preparing for this change."
  ],
  "timing": [
   [
    0.76,
    9.712
   ],
   [
    10.092,
    15.324
   ],
   [
    15.704,
    22.256
   ],
   [
    22.636,
    26.644
   ],
   [
    27.024,
    36.072
   ],
   [
    36.452,
    45.572
   ],
   [
    45.952,
    51.952
   ],
   [
    52.332,
    62.028
   ],
   [
    62.408,
    66.44
   ],
   [
    66.82,
    76.396
   ],
   [
    76.776,
    81.984
   ],
   [
    82.364,
    89.804
   ],
   [
    90.183,
    98.68
   ],
   [
    99.059,
    109.571
   ],
   [
    109.951,
    123.055
   ],
   [
    123.435,
    136.443
   ]
  ],
  "T": 137.82
 },
 "10.11v": {
  "title": "Connected services, changing threats",
  "texts": [],
  "sentences": [
   "On Thursday, the appointment screen in the Sadeed hall shows a slow-service notice, and applicants begin to queue at the counter.",
   "Omar asks Shaima whether this is an attack, and she answers that neither of them can know yet.",
   "Government services now rely on connected networks, cloud services, providers, and devices, and each is a dependency: if it fails, the service can slow or stop.",
   "The European Union cybersecurity agency analysed 4,875 incidents between July 2024 and June 2025.",
   "Nearly 80 percent was ideologically driven hacktivist activity, mostly low-impact flooding of websites.",
   "Targeting was concentrated on public administration, at 38 percent, and attackers increasingly aimed at critical dependencies in the digital supply chain.",
   "Attackers also use new vulnerabilities within days of disclosure, so install approved updates promptly when IT asks through the official process.",
   "The World Economic Forum's 2026 outlook warns about supply chains that are hard to see into and concentrated in a few providers.",
   "In that survey, 94 percent of respondents expect AI to be the biggest driver of change in cybersecurity in 2026.",
   "Europol's 2025 assessment says stolen data and stolen access are traded as commodities, and login details are sold in bulk.",
   "It also reports that criminals use generative AI to tailor scam messages to a victim's culture and personal details.",
   "In the United States, the FBI received more than one million cybercrime complaints in 2025, up from about 860 thousand in 2024, with reported losses of nearly 21 billion dollars.",
   "Shaima does not restart anything and does not test the system.",
   "She follows the business continuity procedure for the counter and gives applicants only the approved message.",
   "She then reports the slowdown through the approved route, and the authorised incident response team decides whether it is a fault or an attack.",
   "Threats will keep changing, but the habits stay: verify through a known contact, use only the access you need, check what machines produce, and report early."
  ],
  "timing": [
   [
    0.76,
    8.128
   ],
   [
    8.508,
    14.076
   ],
   [
    14.456,
    25.976
   ],
   [
    26.356,
    36.844
   ],
   [
    37.224,
    44.784
   ],
   [
    45.164,
    55.34
   ],
   [
    55.72,
    65.2
   ],
   [
    65.58,
    74.1
   ],
   [
    74.48,
    83.768
   ],
   [
    84.148,
    93.388
   ],
   [
    93.768,
    101.616
   ],
   [
    101.996,
    116.084
   ],
   [
    116.463,
    120.255
   ],
   [
    120.635,
    126.875
   ],
   [
    127.255,
    135.391
   ],
   [
    135.771,
    145.275
   ]
  ],
  "T": 146.66
 },
 "10.12v": {
  "title": "Everyone is part of the defence",
  "texts": [],
  "sentences": [
   "On Monday morning, the Sadeed hall is full, and an applicant at Shaima's counter is in a hurry.",
   "He says case file 2048 must be decided today, and he asks her to skip the identity check, just this once.",
   "Omar sees Shaima's hand stop above the keyboard.",
   "Cybersecurity is a shared responsibility, not only the work of the IT team.",
   "The UAE Cyber Security Council describes cyber safety and security as a collaborative mission shared by everyone, in which every action matters.",
   "Bahrain's national strategy for 2025 to 2028 has a pillar on awareness and workforce development, to build a security culture.",
   "A security culture is what people do by habit, even when nobody is checking.",
   "People make security decisions while they are busy, tired, and under pressure.",
   "A major 2026 breach report found that the human element was present in 62 percent of confirmed breaches.",
   "That figure counts people who were tricked, people who made mistakes, and people who misused their access.",
   "For public administration the share was 69 percent, driven largely by information sent to the wrong recipient.",
   "Urgency does not prove bad intent, but it never cancels a required check.",
   "The United States FBI advises everyone to take a beat, resist pressure to act quickly, and assess the situation before handing over money or personal information.",
   "Shaima takes a beat and tells the applicant, politely, that the identity check protects him too.",
   "She checks his identity through the official procedure, sends the status only to the contact registered in the file, and reports the pressure through the approved route.",
   "Trust is good, and verification makes it safe, so check the recipient's name and address twice before you send any document."
  ],
  "timing": [
   [
    0.76,
    6.496
   ],
   [
    6.876,
    14.46
   ],
   [
    14.84,
    17.912
   ],
   [
    18.292,
    23.692
   ],
   [
    24.072,
    34.536
   ],
   [
    34.916,
    44.204
   ],
   [
    44.584,
    49.984
   ],
   [
    50.364,
    55.476
   ],
   [
    55.856,
    63.488
   ],
   [
    63.868,
    70.66
   ],
   [
    71.04,
    78.48
   ],
   [
    78.86,
    84.236
   ],
   [
    84.615,
    95.079
   ],
   [
    95.459,
    101.747
   ],
   [
    102.127,
    111.727
   ],
   [
    112.107,
    121.059
   ]
  ],
  "T": 122.44
 },
 "10.13v": {
  "title": "Report early, learn together, lead by example",
  "texts": [],
  "sentences": [
   "At the end of the week, the department director gathers the counter team in the small meeting room beside the hall.",
   "A printed page titled What we learned this month lies next to case file 2048.",
   "He thanks Shaima for her early reports, including the fake video call and the applicant who pressed her to skip a check.",
   "Security awareness is not a course that ends.",
   "Threats change, so what staff know must be updated again and again.",
   "A United Kingdom code of practice on the cyber security of AI, published in 2025, asks organisations to train staff on AI security risks and to update the training as new threats appear.",
   "The director announces a short session every month, built on real events from the work of the Authority.",
   "Much of what the institution learns comes from what staff report.",
   "The United Kingdom's national cyber centre published six principles for security culture in June 2025, and one of them is building safety, trust, and processes that encourage openness about security issues.",
   "A report is not an accusation.",
   "A report of a mistake, a doubt, or a moment that almost became an incident shows the institution where a procedure is weak.",
   "Because of Shaima's reports, the counter procedure has changed: the identity check is never skipped, and any request to skip it now goes to the supervisor.",
   "Leaders shape culture, and the same national cyber centre advises that if leaders ignore policies or ask for special treatment, everyone learns that bypassing them is acceptable.",
   "So the director says he follows the same verification rules, and he will make urgent requests only through the official channel, never through a surprise video call.",
   "In April 2025, the United Kingdom published a voluntary code that sets out the cyber governance actions boards and directors should take ownership of, as they do for financial oversight.",
   "Management accountability means clear rules that stay workable, and action on what the reports reveal; if a rule does not work, tell your manager, and keep reporting early."
  ],
  "timing": [
   [
    0.76,
    6.856
   ],
   [
    7.236,
    13.14
   ],
   [
    13.52,
    20.24
   ],
   [
    20.62,
    23.884
   ],
   [
    24.264,
    28.776
   ],
   [
    29.156,
    42.308
   ],
   [
    42.688,
    49.024
   ],
   [
    49.404,
    52.932
   ],
   [
    53.312,
    66.464
   ],
   [
    66.844,
    69.364
   ],
   [
    69.744,
    77.76
   ],
   [
    78.14,
    88.316
   ],
   [
    88.695,
    100.383
   ],
   [
    100.763,
    110.315
   ],
   [
    110.695,
    122.143
   ],
   [
    122.523,
    132.939
   ]
  ],
  "T": 134.32
 },
 "10.14v": {
  "title": "Prepared, learning, together",
  "texts": [],
  "sentences": [
   "At the end of the month, the Sadeed hall closes early for a practice session, and the counter team sits around a table with an anonymized practice copy of case file 2048 and a printed continuity procedure.",
   "The director places a card on the table that reads: the appointment system is down, and applicants are waiting.",
   "Resilience means that the institution keeps essential services going where it can, and recovers quickly and safely, when something goes wrong.",
   "It begins before an incident, with a written plan, clear roles, and a team that has practised.",
   "In November 2026, Bahrain's national cyber centre hosted the sixth Gulf cyber exercise, with five Gulf countries and the GCC General Secretariat taking part.",
   "It had a technical track for specialists and an executive track that helped leaders understand the decisions needed to manage a cyber incident.",
   "Each team received its own results, and the day ended with a joint review of the lessons learned.",
   "In Kuwait, the national cybersecurity centre offers government entities services such as security monitoring, incident response, and threat information, which support business continuity.",
   "In the practice session, Shaima follows the continuity procedure, gives applicants only the approved message, and reports the failure through the approved route.",
   "Omar notices that the IT team's contact list on the card is out of date, and the director orders it corrected the same day.",
   "NIST's incident response guidance from April 2025 says that lessons learned from every stage feed continuous improvement, and are analysed, prioritised, and used to inform all the framework's functions.",
   "Management is accountable for this loop: it approves the plans, supports the training, and acts on what reports and exercises show.",
   "Threats will keep changing, but a few habits carry through every lesson of this chapter.",
   "Know the rules and the owners, use only approved tools, and use only the access you need.",
   "Verify through a known contact or an official channel before you act on an urgent request, even from a familiar face or voice, and check what machines and AI produce.",
   "Report early through the approved route, even when nothing was harmed, and keep learning, because security at Sadeed is everyone's work."
  ],
  "timing": [
   [
    0.76,
    13.288
   ],
   [
    13.668,
    20.268
   ],
   [
    20.648,
    29.72
   ],
   [
    30.1,
    36.268
   ],
   [
    36.648,
    47.76
   ],
   [
    48.14,
    57.14
   ],
   [
    57.52,
    63.448
   ],
   [
    63.828,
    75.084
   ],
   [
    75.464,
    84.968
   ],
   [
    85.348,
    92.524
   ],
   [
    92.904,
    106.392
   ],
   [
    106.772,
    114.932
   ],
   [
    115.311,
    120.591
   ],
   [
    120.971,
    127.019
   ],
   [
    127.399,
    138.439
   ],
   [
    138.819,
    147.195
   ]
  ],
  "T": 148.57
 }
};
