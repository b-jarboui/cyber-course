// Risks are ranked, controls are proven.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '10.1',
  actors: { maya: 'desk', omar: 'beside' },
  shots: [[0, 'pair'], [S(1), 'display'], [S(3), 'desk'], [S(7), 'pair'], [S(10), 'display'], [S(13), 'desk'], [S(15), 'pair']],
  actions: {
    maya: [[0, S(1), 'paper'], [S(1), S(7), 'read'], [S(7), S(10), 'paper'], [S(10), S(15), 'read'], [S(15), D.T, 'talk', 'omar']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(7), 'paper'], [S(7), S(10), 'listen', 'maya'], [S(10), S(15), 'paper'], [S(15), D.T, 'listen', 'maya']],
  },
  displays: {
    desk: [
      [0, S(7), 'file', 'Risk register · Case records', 'neutral'],
      [S(7), S(10), 'tick', 'Controls · Evidence checked', 'safe'],
      [S(10), S(15), 'link', 'Third-party scanning supplier', 'alert'],
      [S(15), D.T, 'folder', 'Supplier listed in register', 'neutral'],
    ],
  },
  plates: [
    [S(0), E(0), 'Risk register · Case records'],
    [S(7), E(7), 'Controls backed by evidence'],
    [S(15), E(15), 'Scanning supplier in register'],
  ],
  screens: [
    [S(0), S(1), win('Risk register · Case records', row('Delayed updates', 'High priority · Owner set', 'no') + row('Weak sign-in', 'Medium · MFA required', 'warn') + row('Backup check', 'Controlled · Verified', 'ok'))],
    [S(15), E(15), win('Risk register · Third parties', row('Supplier', 'DocScan · Document scanning', 'hi') + row('Scope', 'Case 2048 scanned files', 'warn') + row('Contract contact', 'Listed & verified', 'ok'), 'good')],
  ],
  pages: [
    hero(S(1), S(7), 'Likelihood and impact guide priority', 'made/register_book+made/balance_scale+made/traffic_light', [
      ['Highest risks are treated first', S(3), 'v-navy'],
      ['Every gap gets an owner and due date', S(4), 'v-teal'],
      ['31% of breaches used software flaws (2026 report)', S(5), 'v-coral'],
    ]),
    hero(S(7), S(10), 'Controls need evidence', 'made/own_shield+made/own_signed_document', [
      ['Updates, MFA and checked backups cut risk', S(7), 'v-teal'],
      ['Compliance proves controls with evidence', S(8), 'v-navy'],
      ['Annual self-assessment in Kuwait', S(9), 'v-teal'],
    ]),
    hero(S(10), S(15), 'Third parties share our risk', 'made/supplier_truck+made/own_policy_binder', [
      ['48% of breaches involved third parties (2026 report)', S(11), 'v-coral'],
      ['Outsourced work meets the same rules', S(12), 'v-navy'],
      ['Verify requests via contract contact', S(13), 'v-teal'],
    ]),
  ],
}));
