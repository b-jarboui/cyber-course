﻿// Round 2 editorial tools. No elapsed-time state, simulation, or remote runtime assets.
import { THREE, C, V, group, mesh, rbox, cyl } from './kit.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { OutlinePass } from 'three/addons/postprocessing/OutlinePass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';

export const backOut=u=>{const v=u-1;return 1+2.4*v*v*v+1.4*v*v;};
export const clamp=x=>Math.min(1,Math.max(0,x));
export const side = (u,y,d=0) => V((u+d)*Math.SQRT1_2,y,(d-u)*Math.SQRT1_2);
export function placePerson(p,origin,u,d=0,rot=.78) {
 const v=side(u,0,d).add(origin);p.at(v.x,v.z,rot);
}

// Original library meshes, normalized without changing their materials.
export async function libraryModel(name,parent,height=1) {
 document.documentElement.dataset.loadingModel=name;
 let object;
 if(['laptop','computerScreen','computerKeyboard'].includes(name)) {
  const path='assets/library/kenney/';
  const materials=await new MTLLoader().loadAsync(path+name+'.mtl');materials.preload();
  object=await new OBJLoader().setMaterials(materials).loadAsync(path+name+'.obj');
 } else {
  const path=name.startsWith('Prop_')?'assets/library/quaternius/'+name+'.gltf':'assets/'+name+'.glb';
  object=(await new GLTFLoader().loadAsync(path)).scene;
 }
 const bounds=new THREE.Box3().setFromObject(object),size=bounds.getSize(V(0,0,0));
 const k=height/size.y;object.scale.setScalar(k);
 object.position.set(-(bounds.min.x+size.x/2)*k,-bounds.min.y*k,-(bounds.min.z+size.z/2)*k);
 const holder=group(parent);holder.add(object);holder.userData.library=name;
 object.traverse(o=>{if(o.isMesh)o.castShadow=o.receiveShadow=true;});
 return holder;
}

// A turntable: each item comes to the front when it is named. Time alone sets the angle, so seeking stays exact.
export function carousel(parent,items,r=.8) {
 const g=group(parent),spin=group(g),n=items.length,step=Math.PI*2/n,slots=[];
 mesh(cyl(r+.14,r+.2,.1,72),C.navy,0,.05,0,g);
 const rim=mesh(new THREE.TorusGeometry(r+.15,.022,10,96),new THREE.MeshStandardMaterial({color:C.sand,emissive:C.sand,emissiveIntensity:.3,roughness:.4}),0,.105,0,g);rim.rotation.x=Math.PI/2;
 items.forEach((o,i)=>{
  const a=i*step,p=group(spin,Math.sin(a)*r*.68,.1,Math.cos(a)*r*.68);
  mesh(cyl(.2,.23,.1,36),C.paper,0,.05,0,p);
  const lift=group(p,0,.1,0);lift.add(o);slots.push({p,lift,a});
 });
 return {g,spin,slots,update(t,times,after=1e9,drift=.5) {
  let turn=0,active=0;
  times.forEach((x,i)=>{if(i){turn+=step*backOut(clamp((t-x)/.6));if(t>=x)active=i;}});
  if(t>after)turn+=drift*(t-after);
  spin.rotation.y=-turn;
  slots.forEach(({p,lift,a})=>{
   const front=Math.max(0,Math.cos(a-turn))**3;
   p.rotation.y=-(a-turn);lift.scale.setScalar(.7+.62*front);lift.position.y=.1+.1*front;
  });
  return active;
 }};
}

// A protective dome that grows up out of the floor.
export function dome(parent,r,colour=C.teal,line='#7fd8cf') {
 const g=group(parent);
 const fill=mesh(new THREE.SphereGeometry(r,48,20,0,Math.PI*2,0,Math.PI/2),new THREE.MeshStandardMaterial({color:colour,emissive:colour,emissiveIntensity:.25,transparent:true,opacity:.16,side:THREE.DoubleSide,depthWrite:false,roughness:.3}),0,0,0,g);fill.castShadow=false;
 const net=new THREE.LineSegments(new THREE.WireframeGeometry(new THREE.SphereGeometry(r*1.005,14,6,0,Math.PI*2,0,Math.PI/2)),new THREE.LineBasicMaterial({color:line,transparent:true,opacity:.75}));g.add(net);
 const foot=mesh(new THREE.TorusGeometry(r,.03,10,96),new THREE.MeshStandardMaterial({color:line,emissive:line,emissiveIntensity:.5}),0,.02,0,g);foot.rotation.x=Math.PI/2;
 g.userData.net=net;g.userData.fill=fill;
 return g;
}

// A crowd of small figures that spreads out from the centre: the few first, then everyone else.
export function crowd(parent,few,all,spacing=.062) {
 const stuff=()=>new THREE.MeshStandardMaterial({roughness:.6});
 const body=new THREE.InstancedMesh(new THREE.CylinderGeometry(.018,.042,.13,10),stuff(),all),head=new THREE.InstancedMesh(new THREE.SphereGeometry(.035,12,10),stuff(),all);
 const spots=[],colour=new THREE.Color(),m=new THREE.Matrix4(),at=V(0,0,0),q=new THREE.Quaternion(),size=V(1,1,1);
 for(let i=0;i<all;i++){
  const r=spacing*Math.sqrt(i+34),a=i*2.39996;spots.push([Math.sin(a)*r,Math.cos(a)*r]);
  colour.set(i<few?C.tealD:C.coral);body.setColorAt(i,colour);head.setColorAt(i,colour);
 }
 parent.add(body,head);body.frustumCulled=head.frustumCulled=false;body.castShadow=head.castShadow=true;
 return {update(t,from,full,gone) {
  const on=t>=from&&t<gone+.4;body.visible=head.visible=on;if(!on)return;
  spots.forEach(([x,z],i)=>{
   const born=i<few?from+i*.14:from+1+(i-few)/(all-few)*(full-from-1);
   const k=Math.max(.0001,backOut(clamp((t-born)/.28))*(1-clamp((t-gone)/.35))*(i<few?1.7:1));
   size.setScalar(k);
   at.set(x,.065*k,z);body.setMatrixAt(i,m.compose(at,q,size));
   at.set(x,.16*k,z);head.setMatrixAt(i,m.compose(at,q,size));
  });
  body.instanceMatrix.needsUpdate=head.instanceMatrix.needsUpdate=true;
 }};
}

// One solid character, standing on its own centre: a large question mark, for example.
let drawn;
export async function glyph(parent,ch,size,tone='navy') {
 if(/[a-z0-9]/i.test(ch)) return group(parent); // No words or numbers inside 3D.
 drawn??=new FontLoader().loadAsync('vendor/fonts/droid_sans_bold.typeface.json');
 const geo=new TextGeometry(ch,{font:await drawn,size,height:size*.3,curveSegments:8,bevelEnabled:true,bevelThickness:size*.03,bevelSize:size*.02,bevelSegments:3});
 geo.center();
 const [face,side]=TONE[tone].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:.4,emissive:c,emissiveIntensity:.14}));
 const m=new THREE.Mesh(geo,[face,side]);m.castShadow=true;parent.add(m);
 return m;
}

// One entry per sentence: 'text', ['text', tone], a list shown in turn across the sentence, or null for no word.
const N='navy',T='teal',A='amber',R='coral';
const words={
 '1.01v':Array(38).fill(null),
 '1.04v':Array(22).fill(null),
 '1.04s':[null,['Threat',R],['Threat',R],null,[['Only 5 needed',T],['340 can open it',R]],null,null,null,null],
 '1.01':[['Submitted',T],['Waiting',A],null,['Public service',N],['Responsibility',T],[['Information',N],['Identities',N],['Software',N],['Suppliers',N],['Decisions',N]],['Trustworthy',T],['Fictional',N],['Public-sector decisions',N],[['Service counter',N],['Systems',T],['Artificial intelligence',T]],['The person',N],['Protection',T]],
 '1.02':[['What needs protection?',N],['Information asset',T],[['Applicant record',N],['Employee file',N],['Device',N],['Application',N],['Systems',N]],['Digital identity',T],['Identity informs access',T],['Dependencies',N],['External services',N],['Critical infrastructure',R],['Not all ours',N],['Know what you rely on',A],[['Information',T],['Access',T],['Infrastructure',T]]],
 '1.03':[['Three promises',N],['Confidentiality',N],['A link is not permission',R],['Integrity',T],['No silent changes',R],['Approved changes',T],['Availability',T],['Together',N],['Private but unavailable',A],['Online but wrong',R],['Public notice',N],[['Who may see it?',N],['Who may change it?',N],['Can they use it?',N]]],
 '1.04':[['Six different words',N],['Threat',R],['Threat',R],['Vulnerability',A],[['Only 5 needed',T],['340 can open it',R]],['Likelihood + harm',A],[['Sensitivity',A],['Exposure',A],['Protections',T]],['Incident',R],['Unauthorized access',R],['Event',N],['Alert',A],['No need to classify',T],['Report it',T]],
 '1.05':[[['People',A],['Technology',A],['Organization',A]],['Unchecked request',R],['Software weakness',A],['Nobody responsible',R],['One leads to the next',R],['Warnings must be clear',T],['Too hard, too slow',A],[['Training',T],['Usable process',T],['Technology',T],['Clear roles',T],['Support',T]],['Raise concerns',T],['Make it workable',T],['Check the conditions',N]],
 '1.06':[['Shared responsibility',N],['Leaders: direction + resources',N],['Owners judge risk',N],['Teams improve protection',N],['Specialist expertise',N],['Staff: protect + report',N],['Policy, oversight, risk',T],['Defense in depth',T],[['Access controls',T],['Maintained software',T],['Restricted connections',T],['Monitoring',T],['Recovery',T]],['Another control stops it',R],['No single guarantee',R],['Owners, review, practice',T]],
};
const TONE={navy:['#333f6b','#222b4c'],teal:['#2f8a8d','#1e5f62'],amber:['#e39a2c','#a9701a'],coral:['#d9583f','#9d3a28']};

// When each word stands: lists share their sentence, and a repeated word simply stays up.
function schedule(id,D) {
 const list=[];
 words[id].forEach((e,i)=>{
  if(!e)return;
  const [a,b]=D.timing[i],parts=Array.isArray(e[0])?e:[e];
  parts.forEach(([text,tone],n)=>{
   const from=a+(b-a)*n/parts.length,to=a+(b-a)*(n+1)/parts.length,last=list[list.length-1];
   if(last&&last.text===text)last.to=to;else list.push({text,tone,from,to});
  });
 });
 list.forEach((w,i)=>{const next=list[i+1];w.to=next?Math.min(next.from,w.to+1.2):w.to+.5;});
 return list;
}

export async function installEditorial(stage,D,id) {
 const {scene,camera,renderer}=stage,calm=['1.01v','1.04s','1.04v','1.05','1.06'].includes(id);
 const plan=schedule(id,D);
 // Timing still drives the approved room response. No lettering is built.
 window.__words=[];
 const target=new THREE.WebGLRenderTarget(720,1280,{type:THREE.HalfFloatType,samples:4});
 const composer=new EffectComposer(renderer,target);composer.addPass(new RenderPass(scene,camera));
 const outline=new OutlinePass(new THREE.Vector2(360,640),scene,camera);
 outline.edgeStrength=2.6;outline.edgeThickness=1.3;outline.edgeGlow=.15;outline.pulsePeriod=0;
 outline.visibleEdgeColor.set(C.teal);outline.hiddenEdgeColor.set('#000000');composer.addPass(outline);
 const bloom=new UnrealBloomPass(new THREE.Vector2(360,640),.1,.25,1.6);composer.addPass(bloom);
 composer.addPass(new OutputPass());
 let width=0,height=0;
 stage.render=()=>composer.render(0); // Passes have no wall-clock pulse or accumulated delta.
 stage.editorial={outline};
 const up=V(0,1,0),warm=new THREE.Color('#ffb9a6'),lights=[];
 scene.traverse(o=>{if(o.isLight)lights.push({o,power:o.intensity,colour:o.color.clone()});});
 return t=>{
  // Suppress text sprites after scene updates; mechanisms and colour cues remain.
  scene.traverse(o=>{if(o.isSprite&&o.userData.size)o.visible=false;});
  const W=renderer.domElement.clientWidth,H=renderer.domElement.clientHeight;
  // Story shots and the two closing mechanisms hold their authored framing.
  if(!calm){stage.dir.applyAxisAngle(up,.1*Math.sin(t*.29)+.035*Math.sin(t*.71+1));stage.apply();}
  const breath=calm?1:1.02+.02*Math.sin(t*.37);
  camera.zoom=breath;camera.updateProjectionMatrix();camera.updateMatrixWorld();
  // The room reacts to the word: harm dims and warms it, caution a little.
  // Keep the approved room colour response independent of removed editorial words.
  let mood=id==='1.01v'?Math.min(1,(stage.outage||0)/.12):0;
  for(const w of plan){const k=clamp((t-w.from)/.35)*(1-clamp((t-w.to+.25)/.35));mood=Math.max(mood,w.tone==='coral'?k:w.tone==='amber'?.3*k:0);}
  const power=(1-.3*mood)*(1-.72*(stage.outage||0));
  lights.forEach(l=>{l.o.intensity=l.power*power;l.o.color.copy(l.colour).lerp(warm,.5*mood);});
  if(width!==W||height!==H){width=W;height=H;composer.setSize(W,H);}
  outline.selectedObjects=stage.focus?[stage.focus]:[];outline.enabled=!!stage.focus;
 };
}

