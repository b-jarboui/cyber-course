// People library. Scenes only name roles; the selected context decides who plays each role.
// Rule for every entry: acceptable for the Arab market. Modern office style is fine, always modest:
// covered neckline, long sleeves, long trousers or skirts. No short dresses, no Pakistani or Afghan dress.
// local: true applies the Arab look (olive skin, brown eyes). darkHair: light hair made dark.
// Models: Microsoft Rocketbox, MIT licence (people/LICENSE-Rocketbox.txt).
export const LIBRARY = {
  // Arab look, women
  'arab-woman-lead': { model: 'Female_Adult_05', gender: 'f', local: true },
  'arab-woman-plum': { model: 'Business_Female_04', gender: 'f', local: true },
  'arab-woman-senior': { model: 'Business_Female_02', gender: 'f', local: true },
  'arab-woman-citizen': { model: 'Female_Adult_15', gender: 'f', local: true },
  'arab-woman-finance': { model: 'Female_Adult_14', gender: 'f', local: true },
  'arab-woman-legal': { model: 'Female_Adult_04', gender: 'f', local: true, darkHair: true },
  'arab-woman-comms': { model: 'Female_Adult_09', gender: 'f', local: true },
  'arab-woman-analyst': { model: 'Female_Adult_07', gender: 'f', local: true },
  // Arab look, men
  'arab-man-navy': { model: 'Business_Male_06', gender: 'm', local: true },
  'arab-man-senior': { model: 'Male_Adult_05', gender: 'm', local: true },
  'arab-man-young': { model: 'Male_Adult_07', gender: 'm', local: true },
  'arab-man-helpdesk': { model: 'Male_Adult_08', gender: 'm', local: true },
  'arab-man-admin': { model: 'Male_Adult_20', gender: 'm', local: true },
  'arab-man-supplier': { model: 'Male_Adult_14', gender: 'm', local: true },
  'arab-man-analyst': { model: 'Male_Adult_02', gender: 'm', local: true },
  'arab-man-official': { model: 'Business_Male_07', gender: 'm', local: true },
  // Gulf dress
  // Emirati dress (Bassem 2026-11-23): white ghutra for every Gulf man, never the red-checked shemagh.
  'gulf-man-sandals': { model: 'Male_Adult_19', gender: 'm', bright: 1.35, scarf: 'keffiyeh_white.jpg' },
  'gulf-man-shoes': { model: 'Male_Adult_21', gender: 'm', bright: 1.35, scarf: 'keffiyeh_white.jpg' },
  'gulf-man-official': { model: 'Male_Adult_19', gender: 'm', bright: 1.35, scarf: 'keffiyeh_white.jpg', body: 'body_beige.jpg' },   // Hamad: light beige kandura, so he is never confused with Omar
  'gulf-woman-abaya': { model: 'Female_Adult_10', gender: 'f' },
  // Expatriates, used only in the Gulf cast
  'expat-woman-teal': { model: 'Business_Female_01', gender: 'f' },
  'expat-woman-senior': { model: 'Business_Female_02', gender: 'f' },
  'expat-man-navy': { model: 'Business_Male_05', gender: 'm' },
  'expat-man-asian': { model: 'Business_Male_02', gender: 'm' },
  'expat-man-senior': { model: 'Male_Adult_03', gender: 'm' },
};

// Two casts covering the whole course. Arab countries: local people only, no Gulf dress, no expatriates.
// Gulf countries: Gulf dress mixed with modern people, because the Gulf workforce includes many expatriates.
export const CONTEXTS = {
  arab: {
    label: 'Arab countries',
    cast: {
      maya: 'arab-woman-lead', omar: 'arab-man-navy', priya: 'arab-woman-plum', lena: 'arab-woman-senior', citizen: 'arab-man-senior',
      citizenWoman: 'arab-woman-legal', citizenYoung: 'arab-man-young', helpdesk: 'arab-man-helpdesk',
      admin: 'arab-man-admin', finance: 'arab-woman-finance', supplier: 'arab-man-supplier', legal: 'arab-woman-comms',
      comms: 'arab-woman-citizen', analyst: 'arab-man-analyst', analystWoman: 'arab-woman-analyst', official: 'arab-man-official', visitor: 'arab-man-official',
    },
  },
  gulf: {
    label: 'Gulf countries',
    cast: {
      maya: 'gulf-woman-abaya', omar: 'gulf-man-shoes', priya: 'arab-woman-plum', lena: 'expat-woman-senior', citizen: 'gulf-man-sandals',
      citizenWoman: 'gulf-woman-abaya', citizenYoung: 'gulf-man-shoes', helpdesk: 'expat-man-navy',
      admin: 'expat-man-asian', finance: 'expat-woman-teal', supplier: 'expat-man-senior', legal: 'arab-woman-comms',
      comms: 'arab-woman-lead', analyst: 'arab-man-analyst', analystWoman: 'arab-woman-analyst', official: 'gulf-man-official', visitor: 'expat-man-navy',
    },
  },
};
export const ROLES = {
  maya: 'Case officer', omar: 'Security coordinator', priya: 'Procurement officer', lena: 'Service director', citizen: 'Applicant, older',
  citizenWoman: 'Applicant, woman', citizenYoung: 'Applicant, young', helpdesk: 'IT helpdesk', admin: 'System administrator', finance: 'Finance officer',
  supplier: 'Supplier', legal: 'Privacy and legal', comms: 'Communications', analyst: 'Security analyst', analystWoman: 'Security analyst', official: 'Senior official', visitor: 'Office visitor',
};
