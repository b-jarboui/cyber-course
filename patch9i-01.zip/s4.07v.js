// The application asks for more.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, mail, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['lena', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.2',
  set: 'office',
  actors: { lena: 'desk', omar: 'beside' },
  handsets: { omar: [[S(11), S(13), 'mobile']] },
  shots: [[0, 'desk'], [S(1), 'display'], [S(3), 'pair'], [S(8), 'display'], [S(11), 'desk'], [S(13), 'pair']],
  actions: {
    lena: [[0, S(11), 'read'], [S(11), S(12), 'type'], [S(12), S(13), 'read'], [S(13), D.T, 'type']],
    omar: [[0, S(11), 'listen', 'lena'], [S(11), S(13), 'call'], [S(13), D.T, 'talk', 'lena']],
  },
  displays: {
    desk: [[0, S(1), 'file-text', 'Revised supplier document', 'neutral'], [S(1), S(11), 'setting', 'App permission request', 'alert'], [S(11), S(13), 'folder', 'Procurement record', 'safe'], [S(13), D.T, 'bell', 'Report sent', 'safe']],
  },
  plates: [[S(0), E(0), 'Lena · Procurement'], [S(1), E(1), 'Files, messages and contacts'], [S(11), E(11), 'Request closed'], [S(12), E(12), 'No revised document']],
  screens: [
    [S(0), S(1), win('Inbox', mail('Supplier Portal', 'updates@vendor-docs.example', 'Revised supplier document', 'Sign in to review the revised document.'), 'alert')],
    [S(1), S(2), win('DocView App · Permissions', row('Read your files', 'Requested', 'no') + row('Read your messages', 'Requested', 'no') + row('Read your contacts', 'Requested', 'no') + note('Too broad for a document viewer.', 'no'), 'alert')],
    [S(13), S(14), win('Security report', row('App request', 'Closed · Not approved', 'ok') + row('Included', 'Link and permission screen', 'ok') + note('Reported via the approved route.'), 'good')],
  ],
  pages: [
    hero(S(2), S(8), 'Genuine sign-in, risky request', 'lock+setting', [
      ['Approval gives the app a token', S(4), 'v-amber'],
      ['Signed in ≠ every request safe', S(5), 'v-navy'],
    ]),
    hero(S(8), S(10), 'Read every permission', 'file-text+zoom', [
      ['Files, messages and contacts', S(9), 'v-amber'],
    ]),
    hero(S(10), S(13), 'Do not authorize unknown applications', 'computer+shield', [
      ['Check via approved channel', S(11), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Approved by mistake? Report now', 'setting+bell', [
      ['Revoke access and end sessions', S(15), 'v-teal'],
    ]),
  ],
}));
