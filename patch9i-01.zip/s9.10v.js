// One voice, the right notifications.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'lena', 'comms', 'maya', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '9.3',
  set: [[0, S(12), 'meeting'], [S(12), D.T, 'hall']],
  actorSets: { official: 'meeting', lena: 'meeting', comms: 'meeting', maya: 'hall', citizen: 'hall' },
  actors: { official: 'seat1', lena: 'seat2', comms: 'seat3', maya: 'counter', citizen: 'visitor' },
  file: [[0, D.T, 1, 1]],
  landline: 'desk',
  shots: [[0, 'table'], [S(2), 'desk'], [S(4), 'table'], [S(7), 'desk'], [S(12), 'counter'], [S(13), 'her'], [S(14), 'counter']],
  actions: {
    lena: [[0, S(4), 'paper'], [S(4), S(7), 'extension'], [S(7), D.T, 'paper']],
    official: [[0, S(2), 'talk', 'comms'], [S(2), S(7), 'paper'], [S(7), S(12), 'talk', 'lena'], [S(12), D.T, 'paper']],
    comms: [[0, S(4), 'paper'], [S(4), S(7), 'listen', 'lena'], [S(7), D.T, 'paper']],
    maya: [[0, S(12), 'read'], [S(12), S(13), 'listen', 'citizen'], [S(13), S(15), 'paper'], [S(15), D.T, 'talk', 'citizen']],
    citizen: [[0, S(12), 'listen', 'maya'], [S(12), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'maya']],
  },
  displays: {
    desk: [
      [0, S(4), 'file', 'Status sheet · Case 2048', 'neutral'],
      [S(4), S(7), 'mobile', 'Separate phone channel · Active', 'safe'],
      [S(7), D.T, 'megaphone', 'Official notices · Approved', 'safe'],
    ],
    counter: [
      [0, S(12), 'file', 'Approved public notice · 2048', 'safe'],
      [S(12), D.T, 'shield', 'Share approved message only', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Managers · IR team · Comms'],
    [S(4), E(4), 'Desk phone · Not email'],
    [S(9), E(9), '72-hour legal duty · Designated team'],
    [S(13), E(13), 'Printed official notice handed over'],
  ],
  screens: [
    [S(1), S(2), win('Coordination sheet · Case 2048', row('Incident team', 'Technical response & facts', 'ok') + row('Management', 'Decisions & legal duties', 'ok') + row('Communications', 'Approved public message', 'ok'))],
    [S(12), S(13), win('Approved notice · Hall counter', row('Applicant question', 'Is my information safe?', 'hi') + row('Approved reply', 'Hand over printed notice', 'ok') + row('Official contact', 'Listed on the notice', 'ok') + note('Do not guess or share extra details.', 'warn'), 'good')],
  ],
  pages: [
    hero(S(2), S(7), 'One plan · one voice', 'made/own_megaphone+made/own_desk_phone', [
      ['Plans set roles and emergency channels', S(3), 'v-navy'],
      ['Use phone, not email, during an incident', S(4), 'v-teal'],
      ['National groups coordinate major incidents', S(6), 'v-navy'],
    ]),
    hero(S(7), S(12), "Notification is the institution's duty", 'made/gavel+made/own_clock', [
      ['Report cyber incidents to national bodies', S(8), 'v-navy'],
      ['Data breaches: notify within 72 hours', S(9), 'v-amber'],
      ['Designated team notifies, not staff alone', S(11), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Share only the approved message', 'made/own_signed_document+made/own_shield', [
      ['Give only approved notices and contacts', S(13), 'v-teal'],
      ['Never post online or speak to press', S(14), 'v-coral'],
      ['Verify incident action requests via known contact', S(15), 'v-navy'],
    ]),
  ],
}));
