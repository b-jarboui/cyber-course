// The right voice, the right answers
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["maya"];
export default chapterHall((S, E, D) => ({
  lesson: "3.1",
  actors: { maya: 'desk' },
  landline: 'desk',
  shots: [[0,'desk'], [S(1),'display'], [S(3),'desk'], [S(10),'pair'], [S(13),'desk'], [S(14),'desk']],
  actions: { maya: [[0,S(12),'extension'], [S(12),S(13),'read'], [S(13),S(14),'extension'], [S(14),D.T,'type']] },
  displays: { desk: [[0,S(3),'folder','Case 2048','neutral'], [S(3),S(13),'mobile','Change of mobile number','alert'], [S(13),S(14),'mobile','Number already on file','safe'], [S(14),D.T,'folder','Call noted in file','safe']] },
  setupProps: evidence({
    surfaces: { deskPaper: [[0,D.T,'checklist','Identity check']] },
    inserts: [[S(2),E(2),'deskPaper']],
  }),
  plates: [[S(0),E(0),'Service line'], [S(3),E(3),'Change of mobile number'], [S(13),E(13),'Number already on file']],
  screens: [
    [S(1), S(3), q => win('Service line', reveal([
      row('File', 'Case 2048', 'hi'),
      row('Full name', 'Matches file', 'warn'),
      row('Date of birth', 'Matches file', 'warn'),
      note('Familiar voice and correct answers.', 'warn'),
    ], q))],
    [S(3), S(4), win('Change of mobile number', row('Number already on file', '+971 50 XXX 0147', 'ok') + row('Requested phone', '+971 50 XXX 0762', 'no') + note('Claims old phone was lost.', 'no'), 'alert')],
    [S(13), S(15), q => win('Case 2048', reveal([
      row('Number already on file', '+971 50 XXX 0147', 'ok'),
      row('Applicant reply', 'Never called', 'ok'),
      row('Mobile number', 'Unchanged · Reported', 'ok'),
    ], q), 'good')],
  ],
  pages: [
    hero(S(4), S(6), "A voice is not proof of identity", "made/headset+made/id_badge", [
      ["Service line", S(4), "v-navy"],
    ]),
    hero(S(6), S(10), "Personal details can be stolen", "made/case_folder+made/id_badge", [
      ["Date of birth", S(6), "v-amber"],
      ["Caller number can be faked", S(8), "v-amber"],
    ]),
    hero(S(10), S(13), "Change records only after verification", "made/id_badge+made/case_folder", [
      ["Official digital service", S(11), "v-teal"],
    ]),
  ],
}));
