// Away from the hall, and a phone left behind.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.1',
  set: [[0, S(9), 'home'], [S(9), D.T, 'taxi']],
  actorSets: { maya: 'home', omar: 'taxi' },
  actors: { maya: 'desk', omar: 'kerb' },
  handsets: { omar: [[S(11), S(15), 'bell']] },
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(8), 'display'], [S(9), 'kerb'], [S(11), 'close'], [S(14), 'kerb'], [S(16), 'close']],
  actions: {
    maya: [[0, S(1), 'read'], [S(1), S(2), 'type'], [S(2), S(8), 'read'], [S(8), S(9), 'type'], [S(9), D.T, 'read']],
    omar: [[S(9), S(11), 'talk'], [S(11), S(14), 'dial'], [S(14), D.T, 'call']],
  },
  displays: {
    desk: [
      [0, S(1), 'computer', 'Video call · Case 2048', 'neutral'],
      [S(1), S(8), 'shield', 'Approved VPN connected', 'safe'],
      [S(8), S(14), 'lock', 'Screen locked · Work device', 'safe'],
      [S(14), D.T, 'mobile', 'Lost phone · Remote erase', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Remote work · Authority laptop'],
    [S(1), E(1), 'Approved VPN connected'],
    [S(9), E(9), 'Work phone left in taxi'],
    [S(11), E(11), 'Calls IT and phone provider'],
    [S(14), E(14), 'Remote wipe sent'],
  ],
  screens: [
    [S(0), S(2), q => win('Authority laptop · Remote', reveal([row('Device', 'Authority laptop', 'ok'), row('Approved VPN', 'vpn.sadeed.gov.example', 'ok'), row('Video call', 'Approved · Case 2048', 'ok')], q), 'good')],
    [S(9), S(11), phone('Lost work phone', row('Device', 'Omar · Work phone', 'warn') + row('Last seen', 'Left in taxi', 'no') + row('Action', 'Report immediately · Do not wait', 'hi'))],
  ],
  pages: [
    hero(S(2), S(6), 'Secure remote work', 'made/laptop+made/own_wifi', [
      ['Remote incidents rose over 40%', S(2), 'v-coral'],
      ['Avoid public Wi-Fi without approved VPN', S(5), 'v-amber'],
    ]),
    hero(S(6), S(9), 'Approved VPN only', 'made/own_shield+made/own_laptop_lock', [
      ['Zero Trust access and device controls', S(7), 'v-teal'],
      ['No work files on personal devices; lock screen', S(8), 'v-navy'],
    ]),
    hero(S(11), S(13), 'Lost device: report at once', 'made/own_mobile+made/own_bell', [
      ['Do not wait; call IT and phone provider', S(11), 'v-coral'],
      ['Provider blocks device on the networks', S(12), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Remote erase', 'made/own_mobile+made/own_lock', [
      ['IT wipes data; keep files on approved systems', S(14), 'v-teal'],
      ['Strange device? Stop work and report at once', S(16), 'v-amber'],
    ]),
  ],
}));
