// Report early, learn together, lead by example.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar', 'finance', 'comms'];
export default chapterHall((S, E, D) => ({
  lesson: '10.4',
  set: 'meeting',
  whiteboard: { title: 'What we learned this month', items: ['Early reports help', 'Never skip ID check', 'Official channels only'] },
  actors: { official: 'board', maya: 'seat1', omar: 'seat2', finance: 'seat3', comms: 'head' },
  file: [[0, D.T, 0, 0]],
  shots: [[0, 'gathering'], [S(1), 'file'], [S(2), 'board'], [S(6), 'gathering'], [S(11), 'table'], [S(12), 'gathering'], [S(14), 'board']],
  actions: {
    official: [[0, S(2), 'paper'], [S(2), S(6), 'talk', 'maya'], [S(6), S(12), 'paper'], [S(12), D.T, 'talk', 'maya']],
    maya: [[0, D.T, 'listen', 'official']],
    omar: [[0, D.T, 'listen', 'official']],
    finance: [[0, D.T, 'listen', 'official']],
    comms: [[0, D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(6), 'file', 'What we learned this month', 'neutral'],
      [S(6), S(12), 'tick', 'New rule · Refer skips to supervisor', 'safe'],
      [S(12), D.T, 'shield', 'Official channel only · All staff', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Team meeting · End of the week'],
    [S(1), E(1), 'What we learned this month'],
    [S(11), E(11), 'Procedure improved from reports'],
    [S(13), E(13), 'Same rules for leaders too'],
  ],
  screens: [
    [S(1), S(3), win('What we learned this month', row('Report 1', 'Fake director video call', 'ok') + row('Report 2', 'Pressure to skip ID check', 'ok') + row('Outcome', 'Thanked · Procedure improved', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(7), 'Training is continuous', 'made/own_whiteboard+made/own_calendar', [
      ['Awareness is not a one-time course', S(3), 'v-navy'],
      ['Update AI training as new threats appear', S(5), 'v-teal'],
      ['Monthly session built on real events', S(6), 'v-teal'],
    ]),
    hero(S(7), S(12), 'A report is not an accusation', 'made/own_bell+made/own_incident_binder', [
      ['Entities only learn from what is reported', S(7), 'v-navy'],
      ['Openness and trust encourage early reports', S(8), 'v-teal'],
      ['Near-misses show where rules are weak', S(10), 'v-amber'],
    ]),
    hero(S(12), D.T, 'Leaders follow the same rules', 'made/gavel+made/own_policy_binder', [
      ['Special treatment teaches rule-breaking', S(12), 'v-coral'],
      ['Leaders use official channels for urgent work', S(13), 'v-teal'],
      ['Management is accountable', S(14), 'v-navy'],
    ]),
  ],
}));
