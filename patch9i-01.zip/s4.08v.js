// The new phone that was not his.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['finance', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.2',
  set: [[0, S(10), 'office'], [S(10), S(11), 'hall'], [S(11), D.T, 'office']],
  actorSets: { finance: 'office', omar: 'hall' },
  actors: { finance: 'desk', omar: 'counter' },
  landline: 'desk',
  handsets: { omar: [[S(9), S(12), 'mobile']] },
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(8), 'display'], [S(9), 'desk'], [S(10), 'counter'], [S(11), 'desk'], [S(13), 'wide']],
  actions: {
    finance: [[0, S(8), 'extension'], [S(8), S(9), 'read'], [S(9), S(11), 'extension'], [S(11), D.T, 'type']],
    omar: [[0, S(9), 'type'], [S(9), S(11), 'call'], [S(11), D.T, 'type']],
  },
  displays: {
    desk: [[0, S(8), 'mobile', 'Urgent reset request', 'alert'], [S(8), S(11), 'file-text', 'Official staff record', 'safe'], [S(11), D.T, 'shield', 'Reset refused · Reported', 'safe']],
    counter: [[0, D.T, 'folder', 'Case 2048', 'neutral']],
  },
  plates: [[S(0), E(0), 'IT service desk'], [S(1), E(1), 'Urgent reset request'], [S(9), E(9), 'Official staff record'], [S(10), E(10), 'No request made'], [S(11), E(11), 'Reset refused']],
  screens: [
    [S(1), S(3), win('IT Service Desk · Reset', row('Caller claims', 'Omar · Staff #2140', 'warn') + row('Request', 'Reset password & new phone', 'no') + row('Caller number', '+971 50 000 0913', 'no') + note('Urgent call from an unverified number.', 'warn'), 'alert')],
    [S(10), S(11), win('Official staff record', row('Registered number', '+971 50 000 0326', 'ok') + row('Omar replied', 'No request · Phone working', 'ok'), 'good')],
    [S(11), S(12), win('Reset refused', row('Password reset', 'Refused', 'ok') + row('Device enrollment', 'Blocked', 'ok') + row('Impersonation', 'Reported', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(5), 'Urgency is not identity', 'clock+made/id_badge', [
      ['Known details are not proof', S(3), 'v-amber'],
    ]),
    hero(S(5), S(8), 'No unknown device enrollment', 'mobile+made/padlock_open', [
      ['Attacker registers own device', S(5), 'v-coral'],
      ['Trusted way back into account', S(6), 'v-amber'],
    ]),
    hero(S(8), S(10), 'Use the approved recovery check', 'made/register_book+shield', [
      ['Ignore caller-supplied number', S(8), 'v-teal'],
    ]),
    hero(S(12), D.T, 'Call back using the official record', 'made/register_book+mobile+bell', [
      ['Never bypass the identity check', S(12), 'v-teal'],
      ['Unknown device? Report at once', S(13), 'v-amber'],
    ]),
  ],
}));
