﻿// Shared 3D kit for the cybersecurity course: one building, one cast, reusable objects.
// A scene only places these objects and moves them; nothing here belongs to a single scene.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';

export { THREE };

export const C = {
  wall: '#f3eee5', wallTop: '#fbf8f2', floor: '#ece7dd', grout: '#dcd5c7', plinth: '#f1ece3', sky: '#f2eee6',
  navy: '#333f6b', navyD: '#283356', navyL: '#3e4b7c', teal: '#3f8d90', tealD: '#2f7477', sand: '#e6cda3', sandD: '#d4b583',
  powder: '#a7c1e2', powderD: '#8eaad0', plum: '#6d3b54', amber: '#e9a23b', coral: '#e0705a', green: '#4f8a55',
  metal: '#c6c9cd', metalD: '#9a9ea3', glass: '#cfe0da', ceiling: '#e3e5ea', paper: '#fbf8f1', dark: '#2b2f3a',
};

// ---------- small helpers ----------
export const clamp01 = x => Math.min(1, Math.max(0, x));
export const smooth = x => x * x * (3 - 2 * x);
export const ramp = (t, a, b) => smooth(clamp01((t - a) / (b - a)));
export const pulse = (t, a, b, c, d) => ramp(t, a, b) - ramp(t, c, d);
export const lerp = (a, b, k) => a + (b - a) * k;
export const V = (x, y, z) => new THREE.Vector3(x, y, z);
const hash = n => { const s = Math.sin(n * 127.1) * 43758.5453; return s - Math.floor(s); };

const matCache = new Map();
export function mat(c, o = {}) {
  const key = c + JSON.stringify(o);
  if (!matCache.has(key)) matCache.set(key, new THREE.MeshStandardMaterial({ color: c, roughness: 0.78, metalness: 0, ...o }));
  return matCache.get(key);
}
export const metal = () => mat(C.metal, { roughness: 0.4, metalness: 0.15 });
export const frosted = (c = C.glass, opacity = 0.5) => mat(c, { transparent: true, opacity, roughness: 0.25, depthWrite: false });
export function mesh(geo, m, x = 0, y = 0, z = 0, parent) {
  const o = new THREE.Mesh(geo, typeof m === 'string' ? mat(m) : m);
  o.position.set(x, y, z);
  o.castShadow = o.receiveShadow = true;
  if (parent) parent.add(o);
  return o;
}
export const rbox = (w, h, d, r = 0.03) => new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2.01, h / 2.01, d / 2.01));
export const box = (w, h, d) => new THREE.BoxGeometry(w, h, d);
export const cyl = (r1, r2, h, n = 28) => new THREE.CylinderGeometry(r1, r2, h, n);
export const sph = (r, a = 20, b = 14) => new THREE.SphereGeometry(r, a, b);
export function group(parent, x = 0, y = 0, z = 0) { const g = new THREE.Group(); g.position.set(x, y, z); if (parent) parent.add(g); return g; }
export function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}
// A tube between two points, used for rails, tracks and connectors.
export function bar(a, b, r, m, parent) {
  const d = b.clone().sub(a), o = mesh(cyl(r, r, d.length(), 14), m, 0, 0, 0, parent);
  o.position.copy(a).addScaledVector(d, 0.5);
  o.quaternion.setFromUnitVectors(V(0, 1, 0), d.normalize());
  return o;
}
// Fades a whole group in or out. Materials are cloned once so shared colours stay untouched.
export function setOpacity(g, k) {
  g.visible = k > 0.004;
  g.traverse(o => {
    if (!o.isMesh) return;
    if (!o.userData.own) { o.material = o.material.clone(); o.userData.own = true; o.userData.op = o.material.opacity; }
    o.material.transparent = k < 0.999 || o.userData.op < 1;
    o.material.opacity = o.userData.op * k;
  });
}
export function pop(g, k, base = 1) { g.visible = k > 0.004; g.scale.setScalar(Math.max(0.001, base * k * (1 + 0.14 * Math.sin(Math.PI * k)))); }

// ---------- stage: renderer, light, camera ----------
export function createStage(el) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  el.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(C.sky);
  const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 120);
  const hemi = new THREE.HemisphereLight('#ffffff', '#e8e2d6', 1.18);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight('#fff6e8', 1.45);
  sun.position.set(-7, 14, 9);
  sun.castShadow = true;
  const phone = matchMedia('(pointer:coarse)').matches;
  sun.shadow.mapSize.set(phone ? 2048 : 4096, phone ? 2048 : 4096);
  Object.assign(sun.shadow.camera, { left: -13, right: 13, top: 13, bottom: -13, near: 1, far: 40 });
  sun.shadow.bias = -0.00008; sun.shadow.normalBias = 0.003;
  scene.add(sun);
  const fill = new THREE.DirectionalLight('#eef3ff', 0.28); fill.position.set(9, 6, 6); scene.add(fill);

  const dir = V(1, 0.86, 1).normalize();
  const view = { x: -1.6, y: 1, z: -0.4, w: 9.4, h: 16.7, f: 0.42 };
  function apply() {
    const W = el.clientWidth || 1, H = el.clientHeight || 1, a = W / H;
    const vh = Math.max(view.w / a, a > 1 ? view.w * 0.72 : view.h);
    const vw = vh * a;
    camera.left = -vw / 2; camera.right = vw / 2; camera.top = vh * view.f; camera.bottom = -vh * (1 - view.f);
    camera.position.set(view.x, view.y, view.z).addScaledVector(dir, 50);
    camera.lookAt(view.x, view.y, view.z);
    camera.updateProjectionMatrix();
  }
  function resize() { renderer.setSize(el.clientWidth, el.clientHeight); apply(); }
  addEventListener('resize', resize); resize();
  // Moves the camera through a list of shots: [{t0, t1, x, y, z, w, e}] with height following the phone shape.
  // w is the width of the view in metres. e is camera height: 0.86 looks down on the room, 0.4 is near eye level.
  // f is how far down the screen the target sits: 0.42 is the middle of the picture, 0.2 leaves room for a screen below.
  function shots(t, list) {
    let s = list[0], e = s.e ?? 0.86, az = s.az ?? null;
    Object.assign(view, { x: s.x, y: s.y, z: s.z, w: s.w, h: s.w * 16 / 9, f: s.f ?? 0.42 });
    for (let i = 1; i < list.length; i++) {
      const b = list[i], k = ramp(t, b.t0, b.t1);
      if (k <= 0) break;
      view.x = lerp(view.x, b.x, k); view.y = lerp(view.y, b.y, k); view.z = lerp(view.z, b.z, k);
      view.w = lerp(view.w, b.w, k); view.h = view.w * 16 / 9;
      e = lerp(e, b.e ?? 0.86, k); view.f = lerp(view.f, b.f ?? 0.42, k);
      if (az !== null || b.az !== undefined) az = lerp(az ?? Math.PI / 4, b.az ?? Math.PI / 4, k);
    }
    if (!stage.lockDir) {
      if (az === null) dir.set(1, e, 1).normalize();
      else dir.set(Math.SQRT2 * Math.sin(az), e, Math.SQRT2 * Math.cos(az)).normalize();
    }
    apply();
  }
  const stage = { renderer, scene, camera, view, dir, lights: { hemi, sun, fill }, apply, shots, render: () => renderer.render(scene, camera) };
  return stage;
}

// ---------- plants ----------
let leafGeo;
function leaf() {
  if (leafGeo) return leafGeo;
  const g = new THREE.PlaneGeometry(1, 1, 10, 4), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const u = p.getX(i) + 0.5, v = p.getY(i) * 2;
    const wdt = Math.pow(Math.sin(Math.PI * Math.min(1, u * 0.97 + 0.015)), 0.75) * 0.21 * (1 + 0.25 * Math.sin(u * 3));
    p.setXYZ(i, u, -0.34 * u * u + Math.abs(v) * wdt * 0.42, v * wdt);
  }
  g.computeVertexNormals();
  return (leafGeo = g);
}
const LEAF = ['#4e8344', '#5c9450', '#467a3f', '#67a05a'].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.62, side: THREE.DoubleSide }));
export function plant(parent, x, y, z, s = 1, pot = '#fbf7ef', tall = 1) {
  const g = group(parent, x, y, z);
  mesh(cyl(0.3 * s, 0.33 * s, 0.03 * s), C.sand, 0, 0.015 * s, 0, g);
  mesh(cyl(0.3 * s, 0.22 * s, 0.56 * s), mat(pot, { roughness: 0.42 }), 0, 0.31 * s, 0, g);
  mesh(new THREE.TorusGeometry(0.29 * s, 0.022 * s, 8, 28), mat(pot, { roughness: 0.42 }), 0, 0.59 * s, 0, g).rotation.x = Math.PI / 2;
  mesh(cyl(0.28 * s, 0.28 * s, 0.02), '#5a4332', 0, 0.585 * s, 0, g);
  const H = 1.25 * s * tall;
  mesh(cyl(0.022 * s, 0.03 * s, H), '#6b5a43', 0, 0.58 * s + H / 2, 0, g);
  const n = Math.round(13 + 3 * tall);
  for (let i = 0; i < n; i++) {
    const k = i / (n - 1), piv = group(g, 0, 0.72 * s + H * k * 0.98, 0);
    piv.rotation.y = i * 2.399;
    const l = mesh(leaf(), LEAF[i % 4], 0, 0, 0, piv);
    const size = s * (0.72 - 0.26 * k) * (0.9 + 0.2 * hash(i));
    l.scale.set(size, size, size * 1.15);
    l.rotation.z = 0.62 - 0.35 * k;
  }
  return g;
}

// ---------- furniture ----------
export function chair(parent, x, z, rotY = 0) {
  const g = group(parent, x, 0, z); g.rotation.y = rotY;
  mesh(rbox(0.62, 0.13, 0.6, 0.05), C.powder, 0, 0.4, 0, g);
  const back = mesh(rbox(0.6, 0.62, 0.1, 0.05), C.powder, 0, 0.74, -0.3, g); back.rotation.x = -0.1;
  for (const s of [-1, 1]) {
    bar(V(s * 0.28, 0.34, 0.26), V(s * 0.28, 0, 0.3), 0.018, metal(), g);
    bar(V(s * 0.28, 0.34, -0.26), V(s * 0.28, 0, -0.32), 0.018, metal(), g);
    mesh(rbox(0.06, 0.04, 0.46, 0.015), C.sand, s * 0.34, 0.62, 0, g);
    bar(V(s * 0.34, 0.35, 0.14), V(s * 0.34, 0.61, 0.14), 0.016, metal(), g);
  }
  return g;
}
export function officeChair(parent, x, z, rotY = 0) {
  const g = group(parent, x, 0, z); g.rotation.y = rotY;
  mesh(rbox(0.52, 0.1, 0.5, 0.04), C.powder, 0, 0.41, 0, g);
  mesh(rbox(0.5, 0.62, 0.08, 0.04), C.powder, 0, 0.77, -0.25, g);
  mesh(cyl(0.03, 0.03, 0.34), C.metalD, 0, 0.21, 0, g);
  for (let i = 0; i < 5; i++) {
    const a = i / 5 * Math.PI * 2;
    bar(V(0, 0.09, 0), V(Math.sin(a) * 0.28, 0.06, Math.cos(a) * 0.28), 0.016, mat(C.dark), g);
    mesh(sph(0.035), C.dark, Math.sin(a) * 0.28, 0.035, Math.cos(a) * 0.28, g);
  }
  return g;
}
export function laptop(parent, x, y, z, rotY = 0, s = 1) {
  const g = group(parent, x, y, z); g.rotation.y = rotY; g.scale.setScalar(s);
  mesh(rbox(0.46, 0.022, 0.32, 0.01), mat('#c9ccd1', { roughness: 0.35, metalness: 0.55 }), 0, 0.011, 0, g);
  mesh(box(0.42, 0.003, 0.2), C.dark, 0, 0.023, -0.03, g);
  const lid = group(g, 0, 0.022, -0.15); lid.rotation.x = -0.32;
  mesh(rbox(0.46, 0.3, 0.014, 0.01), mat('#c9ccd1', { roughness: 0.35, metalness: 0.55 }), 0, 0.15, 0, lid);
  const screen = mesh(new THREE.PlaneGeometry(0.42, 0.26), new THREE.MeshBasicMaterial({ color: '#dfe9f2' }), 0, 0.15, 0.008, lid);
  screen.castShadow = false;
  g.userData.screen = screen;
  return g;
}
export function monitor(parent, x, y, z, rotY = 0) {
  const g = group(parent, x, y, z); g.rotation.y = rotY;
  mesh(rbox(0.3, 0.02, 0.2, 0.01), C.metalD, 0, 0.01, 0, g);
  mesh(rbox(0.05, 0.28, 0.03, 0.012), C.metalD, 0, 0.15, -0.02, g);
  mesh(rbox(0.68, 0.42, 0.04, 0.015), mat('#3a3e46', { roughness: 0.5 }), 0, 0.42, 0, g);
  mesh(new THREE.PlaneGeometry(0.63, 0.37), mat('#6c7482', { roughness: 0.2 }), 0, 0.42, 0.022, g).castShadow = false;
  return g;
}

// Load the existing CC0 equipment before scene readiness, so close shots never
// capture a placeholder. The source has raised key fields; fit separate caps
// over those fields to give fingers real key surfaces to press.
const keyboardMaterials = await new MTLLoader().loadAsync('assets/library/kenney/computerKeyboard.mtl');
keyboardMaterials.preload();
const keyboardSource = await new OBJLoader().setMaterials(keyboardMaterials).loadAsync('assets/library/kenney/computerKeyboard.obj');
export function keyboard(parent, x, y, z, yaw = Math.PI/2) {
  const g = group(parent, x, y, z); g.name = 'Kenney keyboard with individual keycaps'; g.rotation.y = yaw;
  const asset = keyboardSource.clone(true), bounds = new THREE.Box3().setFromObject(asset), size = bounds.getSize(V(0,0,0));
  asset.scale.set(.42/size.x, .022/size.y, .15/size.z);
  asset.position.set(-bounds.min.x*asset.scale.x-.21, -.011-bounds.min.y*asset.scale.y, -bounds.min.z*asset.scale.z-.075);
  g.add(asset); asset.traverse(o=>{if(o.isMesh)o.castShadow=o.receiveShadow=true;});
  const caps = mat('#424d54', {roughness:.52});
  for(let row=0;row<4;row++) for(let col=0;col<12;col++) {
    const zKey=-.047+row*.025;
    const cap = mesh(rbox(.022,.004,.019,.002),caps,-.177+col*.028,-.00103+(zKey+.05397)*.1323,zKey,g);
    cap.name = `Key ${row}:${col}`;
  }
  mesh(rbox(.14,.004,.018,.002),caps,-.025,-.002,-.067,g).name='Space bar';
  g.userData.library='computerKeyboard';
  return g;
}
// A sand folder. open = 0 closed, 1 fanned open; used as the running symbol of the citizen's case.
export function folder(parent, x = 0, y = 0, z = 0, s = 1, colour = C.sand) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(rbox(0.44, 0.012, 0.32, 0.005), mat(colour, { roughness: 0.9 }), 0, 0.006, 0, g);
  mesh(rbox(0.42, 0.006, 0.3, 0.003), C.paper, 0, 0.015, 0, g);
  const cover = mesh(rbox(0.44, 0.01, 0.32, 0.005), mat(colour, { roughness: 0.9 }), 0, 0.023, 0, g);
  mesh(rbox(0.13, 0.012, 0.03, 0.005), mat(C.sandD, { roughness: 0.9 }), -0.1, 0.022, -0.17, g);
  g.userData.cover = cover;
  g.userData.open = k => { const a = k * 2.5; cover.rotation.x = -a; cover.position.set(0, 0.023 + 0.16 * Math.sin(a), -0.16 + 0.16 * Math.cos(a)); };
  return g;
}
export function standingFolders(parent, x, y, z, rotY = 0, n = 4) {
  const g = group(parent, x, y, z); g.rotation.y = rotY;
  mesh(rbox(0.5, 0.14, 0.3, 0.02), mat(C.metal, { roughness: 0.5, metalness: 0.3 }), 0, 0.07, 0, g);
  const cols = [C.sand, C.powder, '#eadfca', C.sandD, C.powderD];
  for (let i = 0; i < n; i++) mesh(rbox(0.42, 0.32, 0.018, 0.006), mat(cols[i % 5], { roughness: 0.9 }), 0, 0.22, -0.09 + i * (0.18 / Math.max(1, n - 1)), g);
  return g;
}

// ---------- the building ----------
export function createBuilding(scene) {
  const b = group(scene);
  const H = 3.05, T = 0.3;
  const X0 = -5, Z0 = -4.5, X1 = 6.2, Z1 = 4.2;
  const wallM = mat(C.wall, { roughness: 0.9 }), capM = mat(C.wallTop, { roughness: 0.9 });
  const wall = (x, z, w, d, y0 = 0, h = H, m = wallM) => {
    const o = mesh(box(w, h, d), m, x + w / 2, y0 + h / 2, z + d / 2, b);
    if (y0 + h >= H - 0.01) mesh(box(w, 0.02, d), capM, x + w / 2, H + 0.01, z + d / 2, b).castShadow = false;
    return o;
  };

  // Ground plinth and tiled floors.
  const tiles = canvasTex(1024, 1024, (g, w) => {
    g.fillStyle = C.floor; g.fillRect(0, 0, w, w);
    for (let i = 0; i < 64; i++) { g.fillStyle = `rgba(255,250,240,${0.05 + 0.1 * hash(i)})`; g.fillRect((i % 8) * 128, Math.floor(i / 8) * 128, 128, 128); }
    g.strokeStyle = C.grout; g.lineWidth = 3;
    for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(i * 128, 0); g.lineTo(i * 128, w); g.moveTo(0, i * 128); g.lineTo(w, i * 128); g.stroke(); }
  });
  tiles.wrapS = tiles.wrapT = THREE.RepeatWrapping; tiles.repeat.set(2.2, 2.2);
  const ground = mesh(new THREE.PlaneGeometry(90, 90), mat(C.sky, { roughness: 1 }), 0, -0.36, 0, b); ground.rotation.x = -Math.PI / 2; ground.castShadow = false;
  const slabW = X1 + 10, slabD = Z1 + 10;
  mesh(box(slabW, 0.3, slabD), C.wallTop, X1 - slabW / 2, -0.15, Z1 - slabD / 2, b);
  mesh(box(slabW + 0.5, 0.05, slabD + 0.5), C.metal, X1 - slabW / 2 + 0.05, -0.33, Z1 - slabD / 2 + 0.05, b);
  const floorM = new THREE.MeshStandardMaterial({ map: tiles, roughness: 0.7 });
  const f = mesh(new THREE.PlaneGeometry(slabW - 0.2, slabD - 0.2), floorM, X1 - slabW / 2, 0.004, Z1 - slabD / 2, b);
  f.rotation.x = -Math.PI / 2; f.castShadow = false;

  // Left wall: sand end block, frosted window, pillar, opening.
  mesh(rbox(0.56, 0.5, 0.56, 0.03), C.sand, X0 - T / 2 + 0.02, H - 0.05, Z1 - 0.34, b);
  wall(X0 - T, 2.9, T, Z1 - 2.9);
  wall(X0 - T, 0.5, T, 2.4, 0, 0.95); wall(X0 - T, 0.5, T, 2.4, 2.45, H - 2.45);
  const win = mesh(box(0.04, 1.5, 2.4), frosted('#d4e3dc', 0.72), X0 - T / 2, 1.7, 1.7, b); win.castShadow = false;
  for (const z of [0.52, 2.88]) mesh(box(0.34, 1.5, 0.05), metal(), X0 - T / 2, 1.7, z, b);
  mesh(box(0.34, 0.05, 2.4), metal(), X0 - T / 2, 0.97, 1.7, b); mesh(box(0.34, 0.05, 2.4), metal(), X0 - T / 2, 2.43, 1.7, b);
  wall(X0 - T, -1.6, T, 2.1);
  mesh(box(0.02, 0.26, 2.1), C.teal, X0 + 0.012, 2.62, -0.55, b);
  mesh(rbox(0.04, 0.7, 0.86, 0.02), mat(C.metal, { roughness: 0.42, metalness: 0.55 }), X0 + 0.02, 1.68, -0.55, b);
  for (const y of [1.76, 1.64]) mesh(box(0.012, 0.045, 0.62), C.wallTop, X0 + 0.046, y, -0.55, b);
  wall(X0 - T, -2.95, T, 1.35, 2.45, H - 2.45);
  wall(X0 - T, Z0 - 4.2, T, Z0 - T - (Z0 - 4.2) + 1.55);
  mesh(box(0.02, 0.26, 1.3), C.teal, X0 + 0.012, 2.62, -2.3, b);

  // Back wall: plain run, sliding door, sign, wider run.
  wall(X0 - 4.2, Z0 - T, 4.2 - T, T);
  wall(X0 - T, Z0 - T, 5.3, T);
  const DX = 0.3, DW = 2.5;
  wall(DX, Z0 - T, DW, T, 2.45, H - 2.45);
  wall(DX + DW, Z0 - T, X1 - DX - DW, T);
  mesh(box(DW + 0.2, 0.09, 0.36), metal(), DX + DW / 2, 2.42, Z0 - T / 2, b);
  for (const s of [DX - 0.04, DX + DW + 0.04]) mesh(box(0.1, 2.42, 0.36), metal(), s, 1.21, Z0 - T / 2, b);
  mesh(rbox(0.56, 0.1, 0.09, 0.02), C.dark, DX + DW / 2, 2.6, Z0 + 0.05, b);
  mesh(sph(0.018), new THREE.MeshBasicMaterial({ color: '#5ed08a' }), DX + DW / 2 + 0.2, 2.6, Z0 + 0.1, b).castShadow = false;
  const leaves = [-1, 1].map(s => {
    const l = group(b, DX + DW / 2 + s * DW / 4, 0, Z0 - T / 2);
    const p = mesh(box(DW / 2 - 0.06, 2.34, 0.04), frosted('#d4e3dc', 0.62), 0, 1.2, 0, l); p.castShadow = false;
    mesh(box(0.05, 2.34, 0.06), metal(), s * (DW / 4 - 0.05), 1.2, 0, l);
    return l;
  });
  mesh(box(1.9, 0.26, 0.02), C.teal, 4.4, 2.62, Z0 + 0.012, b);
  mesh(box(0.92, 0.5, 0.03), C.wallTop, 4.55, 1.72, Z0 + 0.02, b);
  mesh(box(0.92, 0.12, 0.034), C.navy, 4.55, 1.91, Z0 + 0.02, b);
  for (const [y, w] of [[1.76, 0.6], [1.66, 0.44]]) mesh(box(w, 0.035, 0.036), C.powder, 4.4 - (0.6 - w) / 2, y, Z0 + 0.02, b);
  mesh(rbox(0.18, 0.24, 0.03, 0.012), C.dark, 3.5, 1.3, Z0 + 0.02, b);

  // Entrance ramp with a glass balustrade and steel handrail.
  const ramp3 = group(b, 0, 0, 0);
  mesh(box(5.6, 0.1, 1.15), mat('#e7e3da', { roughness: 0.8 }), 3.1, 0.05, Z0 + 0.6, ramp3);
  mesh(box(4.4, 0.92, 0.03), frosted('#d4e3dc', 0.55), 3.5, 0.56, Z0 + 1.2, ramp3).castShadow = false;
  bar(V(1, 1.06, Z0 + 1.2), V(5.9, 1.06, Z0 + 1.2), 0.03, metal(), ramp3);
  bar(V(1, 1.06, Z0 + 1.2), V(0.4, 1.06, Z0 + 0.3), 0.03, metal(), ramp3);
  for (const x of [1.0, 3.4, 5.8]) bar(V(x, 0.05, Z0 + 1.2), V(x, 1.06, Z0 + 1.2), 0.024, metal(), ramp3);

  // Rooms behind the walls, so the cutaway reads as a real building.
  const seat = (p, x, z, r) => chair(p, x, z, r);
  for (const x of [1.0, 1.75, 2.5]) { seat(b, x, -7.2, 0); seat(b, x, -6.2, Math.PI); }
  for (const z of [-0.2, 0.55, 1.3]) seat(b, -8.2, z, Math.PI / 2);
  mesh(box(0.02, 0.26, 3.2), C.teal, -9.0 + 0.02, 1.0, 0.5, b);
  wall(-9.3, Z0 + 0.0, 0.3, Z1 - Z0);
  wall(X0, -9, X1 - X0, T);
  plant(b, -8.3, 0, -2.6, 0.9, C.sand);
  plant(b, 4.8, 0, -7.8, 0.9, C.sand);

  // Permanent room dressing.
  plant(b, -4.45, 0, 3.55, 0.9, C.sand);
  plant(b, -4.1, 0, -3.8, 1, '#fbf7ef', 1.05);
  plant(b, -0.25, 0, -3.95, 1, C.sand, 1.2);
  plant(b, 5.3, 0, 3.45, 0.6, C.powder);
  chair(b, 3.2, 3.2, -Math.PI / 2 - 0.3);
  chair(b, 3.2, 2.2, -Math.PI / 2 - 0.3);

  // Ceiling panel held back over the rear rooms, so it never covers the action.
  const roof = group(b, -3, 0, -6.2);
  mesh(rbox(9.6, 0.16, 7.8, 0.05), mat(C.ceiling, { roughness: 0.9 }), -1.4, 3.45, -1.0, roof);
  mesh(box(9.7, 0.05, 7.9), C.wallTop, -1.4, 3.34, -1.0, roof);

  return { group: b, roof, doors: leaves, door(k) { leaves[0].position.x = DX + DW / 4 - k * 0.95 * DW / 2; leaves[1].position.x = DX + 3 * DW / 4 + k * 0.95 * DW / 2; } };
}

// Service counter: L-shaped navy desk with a frosted privacy screen and back cabinets.
export function createCounter(parent, full = true) {
  const g = group(parent);
  const navy = mat(C.navy, { roughness: 0.6 }), top = mat(C.navyL, { roughness: 0.46 });
  // Back cabinets along the left wall.
  mesh(rbox(0.72, 0.92, 3.5, 0.02), navy, -4.6, 0.5, 0.5, g);
  mesh(rbox(0.78, 0.06, 3.56, 0.02), top, -4.58, 0.97, 0.5, g);
  mesh(box(0.74, 0.08, 3.5), C.sand, -4.6, 0.04, 0.5, g);
  for (const z of [-0.7, 0.1, 0.9, 1.7]) {
    mesh(box(0.01, 0.74, 0.74), C.navyD, -4.235, 0.54, z, g);
    mesh(rbox(0.02, 0.2, 0.024, 0.008), metal(), -4.22, 0.62, z + 0.26, g);
  }
  // Front desk.
  mesh(rbox(0.86, 0.96, 3.6, 0.02), navy, -2.1, 0.52, -0.25, g);
  mesh(rbox(1.0, 0.07, 3.72, 0.03), top, -2.12, 1.02, -0.25, g);
  mesh(box(0.9, 0.1, 3.64), C.sand, -2.1, 0.05, -0.25, g);
  mesh(rbox(1.5, 0.96, 0.8, 0.02), navy, -3.15, 0.52, 1.25, g);
  mesh(rbox(1.62, 0.07, 0.92, 0.03), top, -3.12, 1.02, 1.25, g);
  mesh(box(1.54, 0.1, 0.84), C.sand, -3.15, 0.05, 1.25, g);
  mesh(rbox(0.26, 1.02, 0.9, 0.02), C.sand, -1.72, 0.52, 1.58, g).visible = false;
  // Privacy screen and standing files.
  const screen = mesh(box(3.3, 0.72, 0.03), frosted('#d4e3dc', 0.55), -2.3, 1.42, -2.02, g); screen.castShadow = false;
  // Keep the approved full-width pane. Independent floor stanchions carry its
  // overhanging ends; neither end relies on the narrow countertop beneath it.
  for (const x of [-3.9, -.7]) {
    mesh(rbox(.18, .012, .18, .012), metal(), x, .010, -2.02, g);
    bar(V(x, .016, -2.02), V(x, 1.78, -2.02), .018, metal(), g);
    for (const y of [1.10, 1.72]) mesh(rbox(.052, .042, .055, .006), metal(), x, y, -2.02, g);
  }
  standingFolders(g, -3.1, 1.05, 1.3, Math.PI / 2 + 0.2);
  if (full) {
    plant(g, -4.55, 1.0, -0.8, 0.42, C.powder, 0.5);
    monitor(g, -2.1, 1.05, -.66, -1.3);
    keyboard(g, -2.42, 1.066, -.45);
  }
  return g;
}

