import { AR, tr } from './i18n.js';
import { OWN, iconSrc } from './own-art.js';
// 2D edition 3. Licensed library scenes composed into case-specific explanations.
// All transitions and library animation are functions of narration time, including reverse seeking.
const pages = new WeakMap(), sources = new Map();
const NS = 'http://www.w3.org/2000/svg';
let serial = 0, styleReady;
function source(name) {
  if (!sources.has(name)) sources.set(name, fetch(new URL(`./assets/2d/${name}.svg`,import.meta.url)).then(r=>{if(!r.ok)throw Error(`Missing 2D asset: ${name}`);return r.text();}));
  return sources.get(name);
}
function installStyle() {
  return styleReady ??= fetch(new URL('./assets/2d/pages.css',import.meta.url)).then(r=>{if(!r.ok)throw Error('Missing 2D stylesheet');return r.text();}).then(css=>{const s=document.createElement('style');s.id='vl-library-style';s.textContent=css;document.head.append(s);});
}
function node(p, cls, html, x, y, w, h) {
  const n = document.createElement('div');
  n.className = cls;
  n.innerHTML = tr(html);
  n.style.cssText = `left:${x}px;top:${y}px;width:${w}px;${h ? `height:${h}px;` : ''}`;
  if (AR) {
    n.dir = 'rtl';
    if (p.classList?.contains('v-page')) n.style.scale = '-1 1';
  }
  p.append(n);
  if (AR && n.matches('.v-text, .v-card')) {
    if (!h) n.style.maxHeight = (640 - y) + 'px';
    fitAr(n);
  }
  return n;
}
// Measure only text boxes, after scene-specific styles have been applied and the page is visible.
function fitAr(n) {
  let authoredSize, lastText;
  function fit() {
    if (!n.clientWidth || !n.clientHeight) return;
    authoredSize ??= n.style.fontSize;
    n.style.fontSize = authoredSize;
    const size = parseFloat(getComputedStyle(n).fontSize);
    for (let px = size - 1; px >= 12 && (n.scrollWidth > n.clientWidth + 1 || n.scrollHeight > n.clientHeight + 1); px--) {
      n.style.fontSize = px + 'px';
    }
    lastText = n.textContent;
  }
  const page = n.closest('.v-page');
  if (!page.arFits) {
    page.arFits = [];
    const fitPage = () => { if (page.clientWidth) page.arFits.forEach(fn => fn()); };
    // The page has fixed dimensions. Resizing its text cannot retrigger this observer.
    new ResizeObserver(fitPage).observe(page);
    document.fonts.ready.then(fitPage);
    document.fonts.addEventListener('loadingdone', fitPage);
  }
  page.arFits.push(fit);
  new MutationObserver(() => { if (n.textContent !== lastText) fit(); })
    .observe(n, { childList: true, characterData: true, subtree: true });
}
function text(p,html,x,y,w,cls=''){return node(p,`v-text ${cls}`,html,x,y,w);}
function card(p,html,x,y,w,h,cls=''){return node(p,`v-card ${cls}`,html,x,y,w,h);}
function wire(p,d,cls='',at=p.a) {const s=document.createElementNS(NS,'svg');s.setAttribute('viewBox','0 0 360 640');s.classList.add('v-wires');s.innerHTML=`<path class="${cls}" d="${d}"/>`;p.root.append(s);reveal(p,s,at,.35);return s;}
const clamp = n => Math.max(0,Math.min(1,n));
const ease = n => {const q=clamp(n);return q*q*(3-2*q);};
// A single, seekable transfer. The packet and its route share a cue; neither
// runs on wall time or leaves a disconnected mark before the explanation.
function transfer(p,d,at,span=1.5,cls=''){
  const route=wire(p,d,`v-route ${cls}`,at),path=route.firstElementChild;
  const dot=document.createElementNS(NS,'circle');dot.setAttribute('r','5');dot.classList.add('v-packet');route.append(dot);
  let length;
  p.moves.push(t=>{length??=path.getTotalLength();const q=clamp((t-at)/span),pt=path.getPointAtLength(length*ease(q));dot.setAttribute('cx',pt.x);dot.setAttribute('cy',pt.y);dot.style.opacity=t>=at&&q<1?'1':'0';path.style.strokeDasharray=`${length}`;path.style.strokeDashoffset=length*(1-ease(q));});return route;
}
function reveal(p,n,at,span=.65){p.moves.push(t=>{const q=Math.max(0,Math.min(1,(t-at)/span));n.style.opacity=q;n.style.transform=`translateY(${(1-q)*8}px)`;});return n;}
function state(p,at,fn){p.moves.push(t=>fn(t>=at,t));}
function timedAnimations(host){
  // Freeze the clock: it cannot advance on wall time after a seek. Every
  // animation position is supplied explicitly by the narration timeline.
  const all=host.getAnimations({subtree:true});all.forEach(a=>{a.pause();a.currentTime=0;});
  // The globe contains 36 independently projected meridians/dots. Their orbit
  // adds no teaching information and is expensive to scrub in Chromium.
  // Keep that detailed scene in a stable pose and animate its actual packet.
  return host.dataset.asset==='global-edge-network'?all.filter(a=>a.effect.target.classList.contains('pk')):all;
}
// Rendered 3D art (3dicons, CC0). A scene name maps to icons; 'a+b+c' names them directly.
const ART3D={'deployment-pipeline':'file-text+setting+tick','database':'folder+locker','login-authentication':'lock+key','api-request':'computer+link','global-edge-network':'flash+wifi','search':'file-text+zoom','server-monitoring':'computer+chart','cloud-sync':'folder+tick','email-sent':'mail+file-text','gauge-meter':'target+chart','online-payment':'credit-card+dollar','notifications':'megaphone+chat'};
// Real office objects only (Bassem 2026-11-23): every symbolic picture is shown as the real object it stands for.
// Choices from the Codex/Astra review of the 391 own pictures; one central table, the scene files stay as they are.
const REAL={
  'made/own_bell':'made/own_desk_phone', bell:'made/own_desk_phone',
  'made/own_shield':'made/own_policy_binder', shield:'made/own_policy_binder',
  'made/own_warning_beacon':'made/control_desk', 'made/traffic_light':'made/control_desk',
  'made/own_key':'made/id_badge', key:'made/id_badge',
  'made/padlock_open':'made/own_badge_reader', 'made/own_lock':'made/own_badge_reader', lock:'made/own_badge_reader',
  'made/robot_arm':'made/laptop', 'made/own_tools':'made/laptop', tools:'made/laptop',
  'made/own_link':'made/network_switch', link:'made/network_switch',
  'made/own_zoom':'made/own_file', zoom:'made/own_file',
  'made/balance_scale':'made/own_policy_binder', 'made/gavel':'made/own_policy_binder', 'made/signpost':'made/register_book',
  'made/supplier_truck':'made/parcel',
  'made/own_megaphone':'made/own_file', megaphone:'made/own_file',
  'made/own_money':'made/own_credit_card', money:'made/own_credit_card', dollar:'made/own_credit_card',
  'made/own_setting':'made/own_computer', setting:'made/own_computer',
  'made/own_puzzle':'made/own_tick', puzzle:'made/own_tick',
};
function composed(p,host,names,at){
  names=[...new Set(names.map(x=>REAL[x]||x))];   // swap symbols for real objects, no picture twice
  const n=names.length,w=host.clientWidth||parseFloat(host.style.width),h=parseFloat(host.style.height)||w*.7;
  const spots=n===1?[[.5,.5,.92]]:n===2?[[.4,.5,.84],[.76,.68,.52]]:[[.5,.46,.76],[.17,.7,.46],[.83,.7,.46]];
  names.forEach((name,i)=>{
    const own=!name.startsWith('made/')&&OWN.has(name),[sx,cy,s]=spots[i],cx=AR?1-sx:sx,size=h*s,img=new Image();const src=name.startsWith('made/')?name:iconSrc(name);img.src=new URL(`./assets/2d/${src}.${src.startsWith('made/')?'webp':'png'}`,import.meta.url).href;img.alt='';img.className=name.startsWith('made/')||own?'v-made':'v-3d';
    img.onerror=()=>{console.error(`Missing 2D image: ${src} (${img.src})`);};
    img.style.cssText=`position:absolute;left:${cx*w-size/2}px;top:${cy*h-size/2}px;width:${size}px;height:${size}px;z-index:${n-i}`;host.append(img);p.pending.push(img.decode().catch(err=>{console.error(`Missing or unreadable 2D image: ${src} (${img.src})`,err);}));
    // Each object arrives in turn, then rests with a slow drift that follows narration time.
    p.moves.push(t=>{const q=ease((t-at-i*.35)/.7),d=Math.sin((t+i*1.7)*.8)*3;img.style.opacity=q;img.style.transform=`translateY(${(1-q)*26+d}px) scale(${.82+.18*q}) rotate(${Math.sin((t+i)*.5)*1.2}deg)`;});
  });
}
function artwork(p,name,x,y,w,h,at=p.a){
  const host=node(p.root,'v-art','',x,y,w,h);host.dataset.asset=name;reveal(p,host,at);p.assets.add(name);
  if(ART3D[name]||name.includes('+')||name.startsWith('made/')){composed(p,host,(ART3D[name]||name).split('+'),at);return host;}
  p.pending.push(source(name).then(raw=>{
    const doc=new DOMParser().parseFromString(raw,'image/svg+xml');
    if(doc.querySelector('parsererror'))throw Error(`Invalid SVG: ${name}`);
    const svg=doc.documentElement;
    // Stock engineering callouts are tiny; lesson labels use our >=22px typography.
    // Unused stock blur/shadow layers can leave compositor fragments outside
    // the illustration in Chromium. Remove them before the first SVG paint.
    svg.querySelectorAll('text,.lbl,title,desc,.shs,.shf').forEach(n=>n.remove());
    if(name==='global-edge-network')svg.querySelectorAll('.mer,.dot,.node,.ring,.hot,.dash,.back,.call').forEach(n=>{n.style.animation='none';});
    const original=svg.id, unique=`${original}-${++serial}`;
    if(original){svg.innerHTML=svg.innerHTML.replaceAll(original,unique);svg.id=unique;}
    svg.removeAttribute('width');svg.removeAttribute('height');svg.setAttribute('aria-hidden','true');
    svg.style.cssText='width:100%;height:100%;--svm-accent:#2f7477;--svm-ink:#26305a;--svm-nt:#fffdf8;--svm-w:#fffdf8;--svm-nl:#9dbdb7;--svm-nr:#46547d;--svm-pt:#dce7df;--svm-stroke:1.35';
    if(original){const style=document.createElementNS(NS,'style');style.textContent=`#${unique} .gl,#${unique} .grn{fill:#2f7477}#${unique} .gt{fill:#7db8ab}#${unique} .gr{fill:#24595c}#${unique} .at{fill:#e8b758}#${unique} .al{fill:#c9811a}#${unique} .ar{fill:#8f5c22}#${unique} .rl,#${unique} .red{fill:#c6543b}#${unique} .rt{fill:#efa58c}#${unique} .rr{fill:#93432f}#${unique} .sg{stroke:#2f7477}#${unique} .dt{opacity:.85}`;svg.append(style);}
    host.append(document.importNode(svg,true));host.getBoundingClientRect();
    host.sceneAnimations=timedAnimations(host);
    p.moves.push(t=>(host.sceneAnimations||[]).forEach(a=>{const timing=a.effect.getTiming();const time=host.sceneClock?host.sceneClock(t):Math.max(0,t-at)*1000;const hold=name==='email-sent'?.6:.78;const frame=Math.min(time,Number(timing.delay)+Number(timing.duration)*hold);if(a.currentTime!==frame)a.currentTime=frame;}));
  }));return host;
}
function icon(p,name,x,y,size=38,at=p.a){const n=artwork(p,'tabler/'+name,x,y,size,size,at);n.classList.add('v-icon');return n;}
function status(p,html,x,y,w,cls=''){return card(p,html,x,y,w,undefined,`v-status ${cls}`);}
function record(p,x,y,w=312,cls='') {return card(p,'<div class="v-record-title">Case 2048</div><div class="v-field">Identity <b>•••• ••••</b></div><div class="v-field">Contact <b>•••• ••••</b></div>',x,y,w,158,`v-record ${cls}`);}
function header(p,title){text(p.root,(AR?tr(document.getElementById('kicker')?.textContent||'Lesson 1.1 · Version 3'):(document.getElementById('kicker')?.textContent||'Lesson 1.1 · Version 3').toUpperCase()),24,16,312,'v-kicker');text(p.root,title,24,49,312,'v-heading');}
function accountGrid(p,y,at,restrict=false){
  const host=node(p.root,'v-account-grid','',24,y,312,258);p.assets.add('tabler/id-badge-2');
  p.pending.push(source('tabler/id-badge-2').then(raw=>{const svg=new DOMParser().parseFromString(raw,'image/svg+xml').documentElement;svg.querySelector('path[stroke="none"]')?.remove();
    host.innerHTML=Array.from({length:340},(_,i)=>`<span class="${i<5?'permitted':'excess'}" aria-hidden="true">${svg.outerHTML}</span>`).join('');host.setAttribute('aria-label',tr('340 staff accounts; only 5 caseworkers permitted'));
  }));
  let cells;
  p.moves.push(t=>{
    cells??=host.querySelectorAll('span');
    // Five valid permissions stay teal. Excess access fills progressively, or
    // drains back to those five in the conditional restriction example.
    const q=clamp((t-at)/2.8),count=restrict?340-Math.floor(q*335):5+Math.floor(q*335);
    cells.forEach((n,i)=>{n.style.opacity=i<5?'1':i<count?'1':'.12';});
    host.dataset.count=count;host.classList.toggle('restricted',restrict);host.classList.toggle('expanded',!restrict);
  });return host;
}
const layouts={
  purpose(p,c){
    header(p,'A service worth\nprotecting');
    const scene=artwork(p,'made/p101_purpose',4,187,352,277,p.a);
    text(p.root,'Application',24,151,220,'v-label');
    const review=text(p.root,'Case review',172,435,164,'v-label');reveal(p,review,p.a+1.3);
    transfer(p,'M72 183V233L180 295L285 355V423',p.a+.3,2.1);
    const outcome=card(p.root,'Public decision',24,490,312,72,'v-navy v-result');reveal(p,outcome,p.a+2.4);
    const note=text(p.root,'Sadeed is fictional',24,589,312,'v-note');
    state(p,c.cues.trust,on=>{note.textContent=tr(on?'Trustworthy. Working.':'Sadeed is fictional');scene.classList.toggle('v-live',on);outcome.classList.toggle('v-confirmed',on);});
  },
  assets(p,c){
    header(p,'Information assets\nSupport the work');
    const frames=[0,1,2,3,4].map(i=>artwork(p,`made/p101_assets_k_${i}`,0,170,360,360,p.a)),db=frames[0];
    p.moves.push(t=>{const m=c.cues.more,k=t<m?0:t<m+1.8?1:t<m+4?2:t<m+7.5?3:4;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const r=card(p.root,'Case 2048 <strong>Applicant record</strong>',24,145,312,72,'v-asset-record');reveal(p,r,c.cues.case);
    const files=card(p.root,'Employee<br>files',24,459,146,84,'v-asset-label');reveal(p,files,c.cues.more);icon(p,'address-book',128,481,30,c.cues.more);
    const devices=card(p.root,'Devices<br>& apps',190,459,146,84,'v-asset-label');reveal(p,devices,c.cues.more+1.8);icon(p,'device-laptop',294,481,30,c.cues.more+1.8);
    const systems=text(p.root,'Processing & storage',24,561,312,'v-label');reveal(p,systems,c.cues.more+4);
    text(p.root,'Work depends on all of them',24,601,312,'v-note');state(p,c.cues.more+4,on=>db.classList.toggle('v-live',on));
  },
  identity(p,c){
    header(p,'Recognized.\nThen permitted.');
    const kind=text(p.root,'Person identity',24,148,260,'v-label');
    const variants=[['id-badge-2','Person identity'],['device-laptop','Device identity'],['app-window','Application identity'],['cpu','AI agent identity']];
    const symbols=variants.map(([name])=>icon(p,name,296,145,36));
    p.moves.push(t=>{const i=t>=c.cues.decision?0:Math.min(3,Math.max(0,Math.floor((t-p.a)/1.7)));kind.textContent=tr(t>=c.cues.decision?'Identity checked':variants[i][1]);symbols.forEach((n,j)=>{n.style.opacity=+(i===j);});});
    const recog=text(p.root,'Identity recognized',24,199,312,'v-note');reveal(p,recog,c.cues.decision);
    // The wings stay shut for recognition alone and swing open once permission is granted.
    const frames=[0,18,36,54,72,90].map(a=>artwork(p,`made/turnstile_w${a}`,-10,228,380,264,p.a+.2)),gate=frames[0];
    p.moves.push(t=>{const k=Math.round(ease((t-c.cues.granted)/1.1)*5);frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const token=icon(p,'id-badge-2',77,296,48,p.a+.4);token.classList.add('v-token');
    p.moves.push(t=>{const q=ease((t-c.cues.decision)/1.2),r=ease((t-c.cues.granted-.4)/1.1);token.style.transform=`translate(${(AR?-1:1)*(q*75+r*87)}px,${q*43+r*50}px)`;token.style.opacity=t>=p.a+.4&&t<c.cues.granted+1.8?'1':'0';});
    const access=text(p.root,'Permission required',24,493,312,'v-permission');reveal(p,access,c.cues.permission);
    state(p,c.cues.granted,on=>{access.textContent=tr(on?'Permission granted':'Permission required');access.classList.toggle('v-allowed',on);gate.classList.toggle('v-live',on);});
    const file=status(p.root,'Case 2048 opens',24,554,312,'v-navy v-result');reveal(p,file,c.cues.granted+1.6);
  },
  dependencies(p,c){
    header(p,'Services depend\non other services');text(p.root,'Sadeed · Case 2048',24,145,312,'v-label');
    const frames=[0,1,2,3,4,5,6].map(i=>artwork(p,`made/p101_dependencies_k_${i}`,0,196,360,360,p.a+.15)),scene=frames[0];
    p.moves.push(t=>{const k=t>=c.cues.understand?6:t>=c.cues.elsewhere?5:[0,1,2,3].filter(i=>t>=c.cues.services+i*.5+.2).length;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const nodes=[['user-scan','Identity',24,194,'M94 264V304L118 328'],['credit-card','Payments',204,194,'M270 264V308L254 329'],['antenna-bars-5','Comms',24,493,'M94 493V468L125 450'],['bolt','Electricity',204,493,'M270 493V468L253 450']];
    nodes.forEach(([n,l,x,y,d],i)=>{
      const at=c.cues.services+i*.5;const h=card(p.root,l,x,y,132,70,'v-dependency');h.style.paddingTop='39px';icon(p,n,x+48,y+3,34,at);reveal(p,h,at);
      state(p,at+1.4,on=>h.classList.toggle('v-connected',on));
    });
    const note=text(p.root,'Some run elsewhere',24,592,312,'v-note');reveal(p,note,c.cues.elsewhere);state(p,c.cues.understand,on=>{note.textContent=tr(on?'Know what you rely on':'Some run elsewhere');scene.classList.toggle('v-live',on);});
  },
  infrastructure(p,c){
    header(p,'One supply.\nSeveral services.');
    const frames=[0,1,2].map(i=>artwork(p,`made/p101_infrastructure_k_${i}`,0,104,360,330,p.a)),network=frames[0],power=frames[0];
    p.moves.push(t=>{const k=t<c.cues.cut?0:t<c.cues.cut+.35?1:2;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const supply=text(p.root,'Electricity',24,365,312,'v-label v-supply');
    const trunk=wire(p,'M180 401V428M65 450V428H295V450M180 428V450','v-power',p.a+.6);
    const routes=['M180 401V428H65V450','M180 401V450','M180 401V428H295V450'];routes.forEach(d=>{const r=transfer(p,d,p.a+1,1.6);state(p,c.cues.cut,on=>r.style.visibility=on?'hidden':'visible');});
    const destinations=[];
    [['building-hospital','Healthcare',8,124],['droplet','Water',140,94],['antenna-bars-5','Comms',246,106]].forEach(([n,l,x,w],i)=>{
      const h=card(p.root,l,x,452,w,112,'v-service v-center v-powered');h.style.paddingTop='76px';const art=icon(p,n,x+(w-52)/2,464,52);destinations.push([h,art]);
      state(p,c.cues.cut+.15*i,on=>{h.classList.toggle('v-off',on);art.classList.toggle('v-dark',on);});
    });
    const cut=text(p.root,'Supply cut · Example',24,365,312,'v-label v-cut-label');reveal(p,cut,c.cues.cut,.2);
    const foot=text(p.root,'Shared dependence',24,593,312,'v-note');
    state(p,c.cues.cut,on=>{supply.style.visibility=on?'hidden':'visible';trunk.classList.toggle('v-cut',on);trunk.firstElementChild.setAttribute('d',on?'M180 401V408M180 422V428M65 450V428H295V450M180 428V450':'M180 401V428M65 450V428H295V450M180 428V450');network.classList.toggle('v-disrupted',on);power.classList.toggle('v-dark',on);foot.textContent=tr(on?'Disruption can spread':'Shared dependence');});
  },
  confidentiality(p,c){
    header(p,'Confidentiality\nControlled access');
    record(p.root,24,146,312,'v-private-record');icon(p,'shield-check',288,157,30,p.a);
    const permit=text(p.root,'Authorized case team',24,289,312,'v-note');reveal(p,permit,p.a+.3);
    const frames=[0,1,2,3,4].map(i=>artwork(p,`made/p101_confidentiality_k_${i}`,0,226,360,360,p.a+.25));
    p.moves.push(t=>{const g=t-p.a-.4,k=t>=c.cues.link+1.1?4:t>=c.cues.link?3:g<0?0:g<.8?1:2;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const stop=text(p.root,'No permission',24,500,172,'v-denial');reveal(p,stop,c.cues.link+1.1);
    const wrong=card(p.root,'Wrong recipient',24,539,312,56,'v-coral');reveal(p,wrong,c.cues.wrong);
    const packet=icon(p,'mail-forward',281,551,32,c.cues.wrong);p.moves.push(t=>{packet.style.transform=`translateX(${(AR?-1:1)*(-70+70*ease((t-c.cues.wrong)/1.3))}px)`;});
    const foot=text(p.root,'Would disclose private details',24,604,312,'v-note');reveal(p,foot,c.cues.wrong+.3);
  },
  integrity(p,c){
    header(p,'Integrity\nCheck the decision');
    const approved=card(p.root,'Case 2048 <strong>Approved</strong>',24,147,312,68,'v-teal v-case-approved');approved.setAttribute('aria-label',tr('Actual case decision: Approved. The changing decision below is a hypothetical example.'));
    const frames=[0,1,2,3,4,5,6].map(i=>artwork(p,`made/p101_integrity_k_${i}`,0,182,360,360,p.a+.2)),scene=frames[0];
    // The page closes before the "saved" sentence, so the correction is shown while the checks are described.
    const fixed=Math.min(c.cues.saved,c.cues.checks+2.4);
    p.moves.push(t=>{const k=t<c.cues.could+.6?0:t<c.cues.could+.9?1:t<c.cues.checks?2:t<fixed?3:t<fixed+.3?4:t<fixed+.7?5:6;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const example=text(p.root,'Could happen',24,224,312,'v-scenario');reveal(p,example,c.cues.could);
    const decision=card(p.root,'Approved',61,463,238,54,'v-decision v-teal');reveal(p,decision,c.cues.could);
    const caught=text(p.root,'Improper change caught',24,526,312,'v-denial');reveal(p,caught,c.cues.checks);
    const checks=card(p.root,'Checked correction<br><strong>Who · What · When</strong>',24,558,312,75,'v-navy v-audit');reveal(p,checks,c.cues.checks);const history=icon(p,'history',288,575,32,c.cues.checks);history.style.color='#fffdf8';
    p.moves.push(t=>{
      const changed=t>=c.cues.could+.9&&t<fixed;decision.textContent=tr(changed?'Refused':'Approved');decision.classList.toggle('v-coral',changed);decision.classList.toggle('v-teal',!changed);decision.classList.toggle('v-caught',t>=c.cues.checks&&t<fixed);
      example.textContent=tr(t>=fixed?'Example · Checked correction':'Could happen · Unapproved change');scene.classList.toggle('v-live',t>=c.cues.checks);caught.textContent=tr(t>=fixed?'':'Improper change caught');
      checks.innerHTML=tr(t>=fixed?'Correction saved<br><strong>Audit trail retained</strong>':'Checked correction<br><strong>Who · What · When</strong>');
    });
  },
  availability(p,c){
    header(p,'Availability\nThe service waits');
    const accessible=status(p.root,'Record · Accessible',24,147,312,'v-teal');
    text(p.root,'Request · Records',24,219,312,'v-label');
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p101_availability_k_${i}`,0,160,360,360,p.a)),servers=frames[0];
    const step=text(p.root,'',24,530,312,'v-note');
    p.moves.push(t=>{const k=Math.max(0,Math.min(5,Math.floor((t-p.a-.4)/.95)));frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});
      step.textContent=tr(t>=c.cues.earlier-.5?'':['Request sent','Link down · Waiting','Link down · Waiting','Link down · Waiting','Link repaired','Record served when needed'][k]);});
    const offline=card(p.root,'Identity check<br><strong>Offline</strong>',24,480,146,108,'v-coral v-branch');reveal(p,offline,c.cues.earlier);
    wire(p,'M92 453V480','v-denied',c.cues.earlier);wire(p,'M170 530H190','v-denied',c.cues.earlier+1.1);
    const waiting=card(p.root,'Case 2048<br><strong>Waiting</strong>',190,480,146,108,'v-amber v-branch');reveal(p,waiting,c.cues.earlier+1.1);
    const foot=text(p.root,'The case has to wait',24,597,312,'v-note');reveal(p,foot,c.cues.earlier+1.1);
    const stopped=icon(p,'id-badge-2',263,381,46,c.cues.earlier);stopped.classList.add('v-offline-token');
    state(p,c.cues.earlier,on=>{servers.classList.toggle('v-disrupted',on);accessible.classList.toggle('v-record-available',on);});
  },
  notice(p,c){
    header(p,'Public information\nCorrect. Available.');
    const notice=card(p.root,'Public notice<br><strong>Opening hours</strong>',24,147,312,98,'v-navy');notice.style[AR?'paddingLeft':'paddingRight']='65px';const calendar=icon(p,'calendar-clock',278,171,42);calendar.style.color='#fffdf8';
    const frames=[0,1,2].map(i=>artwork(p,`made/p101_notice_k_${i}`,0,214,360,360,p.a+.2)),scene=frames[0];
    p.moves.push(t=>{const k=t<p.a+1.2?0:t<c.cues.hours+.6?1:2;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const correct=text(p.root,'Correct at the source',24,550,312,'v-note');reveal(p,correct,p.a+.6);
    const online=text(p.root,'Available to the public',24,594,312,'v-label');reveal(p,online,c.cues.hours+.6);state(p,c.cues.hours+1.2,on=>scene.classList.toggle('v-live',on));
  },
  together(p,c){
    header(p,'One record.\nThree protections.');
    // One record case: lock (private), seal (correct), lamp (usable). Losing any one dims the whole case.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p101_together_k_${i}`,0,130,360,360,p.a)),check=frames[0];
    const on=[p.a+.5,p.a+1.1,p.a+1.7];
    p.moves.push(t=>{const k=t>=c.cues.wrong?5:t>=c.cues.retrieve?4:on.filter(a=>t>=a).length;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const labels=['Private','Correct','Usable'].map((l,i)=>{const e=text(p.root,l,14+i*112,440,108,'v-label');e.style.textAlign='center';reveal(p,e,on[i]);return e;});
    const correct=labels[1],usable=labels[2];
    const foot=text(p.root,'All three protect the record',24,520,312,'v-note');reveal(p,foot,on[2]+.4);
    p.moves.push(t=>{const w=t>=c.cues.wrong,r=t>=c.cues.retrieve&&!w;
      usable.textContent=tr(r?'Cannot retrieve':'Usable');usable.classList.toggle('v-denial',r);correct.textContent=tr(w?'Wrong information':'Correct');correct.classList.toggle('v-denial',w);
      foot.textContent=tr(t>=c.cues.wrong?'Online, but the information is wrong':t>=c.cues.retrieve?'Private, but not usable':'All three protect the record');});
  },
  vulnerability(p,c){
    header(p,'Vulnerability\nExcess permission');
    text(p.root,'Case 2048 · Access setting',24,145,312,'v-label');
    const good=card(p.root,'<strong class="v-number">5</strong><span>permitted</span>',24,195,138,110,'v-teal v-count');
    const broad=card(p.root,'<strong class="v-number">5</strong><span>have access</span>',180,195,156,110,'v-amber v-count');reveal(p,broad,c.cues.broad,.2);
    // Five keys for the five caseworkers; as the count climbs, more and more keys hang on the board and the cabinet lamp turns amber.
    const frames=[0,1,2,3,4].map(i=>artwork(p,`made/p104_vulnerability_k_${i}`,40,312,280,280,p.a));
    p.moves.push(t=>{const q=clamp((t-c.cues.broad)/2.8),k=t<c.cues.broad?0:1+Math.min(3,Math.floor(q*4));frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});broad.querySelector('strong').textContent=5+Math.floor(q*335);});
    const note=text(p.root,'Access ≠ evidence of misuse',24,598,312,'v-note');reveal(p,note,c.cues.weakness);good.setAttribute('aria-label',tr('Only five caseworkers are permitted'));
  },
  threat(p,c){
    header(p,'Threat\nTwo ways to harm');
    // Deliberate: a key already in the lock opens the drawer and the file is copied into a briefcase. Accidental: a folder slips into the outgoing mail.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p104_threat_k_${i}`,-6,196,372,284,p.a+.2));
    p.moves.push(t=>{const d=t-c.cues.ways,k=d<0?0:d<.8?1:d<1.6?2:d<2.6?3:d<3.2?4:5;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const a=card(p.root,'Deliberate<br><strong>Misuse of access</strong>',24,485,146,105,'v-navy v-branch');reveal(p,a,c.cues.ways);
    const b=card(p.root,'Accidental<br><strong>Private details shared</strong>',188,485,148,122,'v-amber v-branch');reveal(p,b,c.cues.ways+2.6);
    transfer(p,'M180 409V456H96V485',c.cues.ways,1.4);transfer(p,'M180 409V456H262V485',c.cues.ways+2.6,1.4,'v-warning-route');
    const inside=text(p.root,'Could originate inside Sadeed',24,151,312,'v-note');reveal(p,inside,c.cues.inside);
  },
  risk(p,c){
    header(p,'Risk\nTwo judgments');
    // Keys pile up and the first gauge (how likely) climbs; when the seriousness card appears the drawer opens on the identity card and the second gauge climbs.
    const frames=[0,1,2,3,4].map(i=>artwork(p,`made/p104_risk_k_${i}`,-4,176,368,282,p.a)),gauge=frames[0];
    p.moves.push(t=>{const q=t-p.a,k=q<.9?0:q<1.8?1:t<p.a+2.5?2:t<p.a+3.3?3:4;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    [['How\nlikely',14,'right',p.a+.2],['How\nserious',264,'left',p.a+2.5]].forEach(([l,x,al,at])=>{const n=text(p.root,l,x,226,82,'v-note');n.style.fontSize='16px';n.style.textAlign=AR?(al==='right'?'left':'right'):al;n.style.whiteSpace='pre';reveal(p,n,at);});
    const likelihood=text(p.root,'Likelihood',24,151,312,'v-label');reveal(p,likelihood,p.a+.2);
    const chance=text(p.root,'Chance of harm',24,438,312,'v-note');reveal(p,chance,p.a+.2);
    const consequence=card(p.root,'Consequences<br><strong>Seriousness of harm</strong>',24,491,312,86,'v-navy');reveal(p,consequence,p.a+2.5);
    transfer(p,'M180 466V491',p.a+2.5,1);
    const note=text(p.root,'Access widens opportunity',24,599,312,'v-note');reveal(p,note,c.cues.opportunity);state(p,c.cues.opportunity,on=>gauge.classList.toggle('v-opportunity',on));
  },
  consequences(p,c){
    header(p,'Consequences\nBeyond the record');record(p.root,24,147,312,'v-consequence-record');
    // Copies of the identity card travel to a payment terminal that turns red (fraud) and a mailbox that fills (unwanted contact).
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p104_consequences_k_${i}`,-4,262,368,262,p.a+.2));
    p.moves.push(t=>{const h=t-c.cues.harm,k=h<-.8?0:h<-.2?1:h<.4?2:h<2?3:h<2.6?4:5;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const fraud=card(p.root,'Possible<br><strong>Fraud</strong>',24,529,138,88,'v-coral v-branch');reveal(p,fraud,c.cues.harm);
    const contact=card(p.root,'Possible<br><strong>Unwanted contact</strong>',181,529,155,103,'v-amber v-branch');reveal(p,contact,c.cues.harm+2);
    transfer(p,'M97 277V315',c.cues.harm,1.1,'v-warning-route');transfer(p,'M263 277V321',c.cues.harm+2,1.1,'v-warning-route');icon(p,'phone',286,467,40,c.cues.harm+2);
  },
  reporting(p,c){
    header(p,'Report facts.\nStart assessment.');
    const report=card(p.root,'Case 2048<br><strong>Permitted: 5</strong><br><strong>Setting: 340</strong>',24,148,312,126,'v-navy v-report');const reportIcon=icon(p,'report',280,168,38);reportIcon.style.color='#fffdf8';
    // The setting turns amber, the report rides the approved route to the security desk, and its lamp switches on when the team assesses.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p104_reporting_k_${i}`,-2,280,364,250,p.a+.3));
    p.moves.push(t=>{const r=(t-c.cues.assess+.9)/.9,k=t<p.a+.6?0:r<0?1:r<1?2+Math.floor(r*3):t<c.cues.assess+.4?4:5;frames.forEach((f,i)=>{f.style.visibility=i===Math.min(5,k)?'visible':'hidden';});});
    const route=text(p.root,'Approved reporting route',24,283,312,'v-note');reveal(p,route,p.a+.3);transfer(p,'M180 316V354',c.cues.assess-.7,1.1);
    const proof=text(p.root,'Misuse proof not needed',24,527,312,'v-permission');reveal(p,proof,c.cues.proof);
    const team=card(p.root,'Team assesses response',24,576,312,56,'v-teal');reveal(p,team,c.cues.assess);
  },
  reduce(p,c){
    header(p,'Restrict access.\nAssess exposure.');
    const count=card(p.root,'If restricted <strong class="v-number">340</strong><span>have access</span>',24,146,312,125,'v-teal v-restriction');
    // The extra keys come off as the count falls to five; when "check earlier access" appears a magnifier slides over the access log.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p104_restrict_k_${i}`,0,268,360,300,p.a));
    p.moves.push(t=>{const q=clamp((t-p.a)/2.8),m=t-c.cues.still-.8,k=m>=.5?5:m>=0?4:Math.min(3,Math.floor(q*3.999));frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    p.moves.push(t=>{const n=340-Math.floor(clamp((t-p.a)/2.8)*335);count.querySelector('strong').textContent=n;count.querySelector('span').textContent=tr(n===5?'permitted':'have access');});
    const sensitive=text(p.root,'Still sensitive',24,567,312,'v-label');reveal(p,sensitive,c.cues.still);icon(p,'file-text',298,566,30,c.cues.still);
    const assess=text(p.root,'Check earlier access · Assess',24,599,312,'v-permission');reveal(p,assess,c.cues.still+.8);
  },
  weakness(p,c){
    header(p,'Nobody owns\nthe approval');
    const request=card(p.root,'Sensitive change',24,146,312,56,'v-navy');
    // The change form hops from tray to tray with no owner; once a name badge is in place it lands and is stamped.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p105_nobody_owns_k_${i}`,10,196,340,266,p.a)),scene=frames[0];
    p.moves.push(t=>{const e=t-c.cues.refuse-1.6,k=e<0?Math.floor(Math.max(0,t-p.a)/1.1)%3:Math.min(5,3+Math.floor(e/.6));frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const owner=text(p.root,'Who approves?',24,446,312,'v-permission');reveal(p,owner,c.cues.token);
    state(p,c.cues.chain,on=>{owner.textContent=tr(on?'Each weakness feeds the next':'Who approves?');});
    const links=[['People','user-scan',8],['Device','device-laptop',124],['Process','report',240]].map(([l,n,x],i)=>{
      const at=c.cues.chain+i*.7,h=card(p.root,l,x,498,112,98,'v-teal v-center');h.style.cssText+='padding:58px 0 0;';const art=icon(p,n,x+38,508,36,p.a);reveal(p,h,p.a);
      state(p,at,on=>{h.classList.toggle('v-coral',on);h.classList.toggle('v-teal',!on);});art.style.color='#26305a';return h;
    });
    wire(p,'M120 547H124','v-denied',c.cues.chain+.4);wire(p,'M236 547H240','v-denied',c.cues.chain+1.1);
    return links;
  },
  usable(p,c){
    header(p,'A safe action\nmust be practical');
    const warning=card(p.root,'Warning unclear',24,146,312,56,'v-coral');
    // The form gets stuck in a tangled route; when the route becomes short and straight it reaches the approved tray.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p105_practical_k_${i}`,-10,200,380,320,p.a)),scene=frames[0];
    p.moves.push(t=>{const m=t-c.cues.maze,s=m-4.6,k=m<0?0:s<0?Math.min(2,Math.floor(m/.8)):Math.min(5,3+Math.floor(s/.5));frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    state(p,c.cues.clear,on=>{warning.textContent=tr(on?'Use the approved portal':'Warning unclear');warning.classList.toggle('v-teal',on);warning.classList.toggle('v-coral',!on);scene.classList.toggle('v-live',on);});
    const label=text(p.root,'Approved process',24,520,312,'v-label');reveal(p,label,c.cues.maze);
    const slow=text(p.root,'Hard to find. Too slow.',24,568,312,'v-permission');reveal(p,slow,c.cues.maze+2.6);
    state(p,c.cues.maze+4.6,on=>{slow.textContent=tr(on?'Make it easy to follow':'Hard to find. Too slow.');slow.classList.toggle('v-allowed',on);});
  },
  combine(p,c){
    header(p,'Protection needs\nall of these');
    // Each thing's lamp turns green as its card appears; the secure door opens only once all five are in place.
    const frames=[0,1,2,3,4,5,6,7,8].map(i=>artwork(p,`made/p105_all_these_k_${i}`,30,136,300,250,p.a)),scene=frames[0];
    p.moves.push(t=>{const n=Math.max(0,Math.min(5,Math.floor((t-c.cues.first)/c.cues.step)+1)),open=Math.round(ease((t-c.cues.first-4*c.cues.step-.6)/1.2)*3),k=n<5?n:5+open;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    // Each card's icon is the same thing the scene shows: manual, checklist, computer, name badge, phone.
    const parts=[['Training','book',14,386],['Processes','checklist',184,386],['Technology','device-laptop',14,458],['Clear roles','id-badge-2',184,458],['Support','phone',99,530]];
    parts.forEach(([l,n,x,y],i)=>{const at=c.cues.first+i*c.cues.step,h=card(p.root,l,x,y,162,60,'v-teal');h.style[AR?'paddingRight':'paddingLeft']='10px';if(AR)h.style.paddingLeft='36px';h.style.whiteSpace='nowrap';reveal(p,h,at);icon(p,n,x+130,y+17,26,at);});
    state(p,c.cues.first+4*c.cues.step+.6,on=>{scene.classList.toggle('v-live',on);});
    const done=text(p.root,'Then the safe action is possible',24,600,312,'v-note');done.style.fontSize='22px';done.style.whiteSpace='nowrap';done.style.letterSpacing='-.4px';reveal(p,done,c.cues.first+4*c.cues.step+.6);
  },
  examine(p,c){
    header(p,'When something\ngoes wrong');
    // The magnifier looks at the misplaced folder first, then widens to take in the broken reader and the missing approval too.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p105_examine_k_${i}`,6,140,348,250,p.a));
    p.moves.push(t=>{const w=t-c.cues.wider,k=t<p.a+.3?0:w<0?1:w<.5?3:4;frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const act=card(p.root,'Individual action',24,398,312,56,'v-amber v-center');reveal(p,act,p.a+.3);
    const a=card(p.root,'Conditions',24,488,148,60,'v-teal v-center'),b=card(p.root,'Controls',188,488,148,60,'v-teal v-center');
    reveal(p,a,c.cues.wider);reveal(p,b,c.cues.wider+.5);
    transfer(p,'M120 454V488',c.cues.wider,.6);transfer(p,'M240 454V488',c.cues.wider+.5,.6);
    const note=text(p.root,'Examine all three',24,574,312,'v-note');reveal(p,note,c.cues.wider+1.2);
  },
  governance(p,c){
    header(p,'Governance\nconnects the roles');
    text(p.root,'Policy · Oversight · Risk',24,145,312,'v-label');
    // Each role's station lights as its card links in; when all four are lit, cables join them into one loop.
    const frames=[0,1,2,3,4,5].map(i=>artwork(p,`made/p106_governance_k_${i}`,10,262,340,240,p.a+.15)),scene=frames[0];
    p.moves.push(t=>{const l=t-c.cues.link,k=l<0?0:l>=3.2?5:Math.min(4,1+Math.floor(l/.7));frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    [['id-badge-2','Leaders',24,194,'M94 264V304L118 328'],['user-scan','Owners',204,194,'M270 264V308L254 329'],['shield-check','Security',24,493,'M94 493V468L125 450'],['report','Staff',204,493,'M270 493V468L253 450']].forEach(([n,l,x,y,d],i)=>{
      const at=c.cues.link+i*.7,h=card(p.root,l,x,y,132,70,'v-dependency');h.style.paddingTop='39px';icon(p,n,x+48,y+3,34,p.a);reveal(p,h,p.a);transfer(p,d,at,1);state(p,at+1,on=>h.classList.toggle('v-connected',on));
    });
    const note=text(p.root,'Clear owners, informed decisions',24,592,312,'v-note');reveal(p,note,c.cues.link+3.2);state(p,c.cues.link+3.2,on=>scene.classList.toggle('v-live',on));
  },
  depth(p,c){
    header(p,'Defense in depth\nSeveral protections');
    const X=180,Y=330,radii=[150,124,98,72,46],s=document.createElementNS(NS,'svg');s.setAttribute('viewBox','0 0 360 640');s.classList.add('v-wires');p.root.append(s);
    const rings=radii.map(r=>{const n=document.createElementNS(NS,'circle');n.setAttribute('cx',X);n.setAttribute('cy',Y);n.setAttribute('r',r);n.setAttribute('fill','none');n.setAttribute('stroke-width','9');s.append(n);return n;});
    const core=icon(p,'file-text',X-22,Y-22,44,p.a);core.style.color='#26305a';
    const names=['Access controls','Maintained software','Restricted connections','Monitoring','Recovery'],icons=['id-badge-2','app-window','link','report','history'];
    const marks=radii.map((r,i)=>{const a=(-90+i*72)*Math.PI/180,n=icon(p,icons[i],X+Math.cos(a)*r-15,Y+Math.sin(a)*r-15,30,c.cues.layers+i*c.cues.step);n.style.background='#f2eee6';n.style.borderRadius='50%';n.style.padding='3px';return n;});
    const name=text(p.root,'',24,497,312,'v-label'),foot=text(p.root,'',24,545,312,'v-note');name.style.textAlign=foot.style.textAlign='center';
    const threat=document.createElementNS(NS,'circle');threat.setAttribute('r','10');threat.setAttribute('fill','#c6543b');threat.setAttribute('stroke','#fffdf8');threat.setAttribute('stroke-width','3');s.append(threat);
    p.moves.push(t=>{
      const on=Math.floor((t-c.cues.layers)/c.cues.step),failed=t>=c.cues.fail+1.1,caught=t>=c.cues.fail+2.7;
      rings.forEach((n,i)=>{const shown=t<c.cues.layers||on>=i;n.setAttribute('stroke',i===0&&failed?'#c6543b':i===3&&caught?'#e2a133':'#2f7477');n.style.opacity=shown?(i===on&&t<c.cues.fail?1:.5):.1;n.setAttribute('stroke-dasharray',i===0&&failed?'10 12':'none');});
      name.textContent=tr(t>=c.cues.fail?(caught?'Monitoring detects it':'One control fails'):t>=c.cues.layers?names[Math.min(4,on)]:'');
      foot.textContent=tr(caught?'The others still protect':'');
      // The attempt crosses the failed outer control and stops at monitoring.
      const q=ease((t-c.cues.fail)/2.7);threat.setAttribute('cx',X+172-(172-radii[3]-14)*q);threat.setAttribute('cy',Y);threat.style.opacity=t>=c.cues.fail?1:0;
      marks.forEach(n=>n.style.visibility='visible');
    });
  }
};
export const page2d={NS,text,card,wire,transfer,reveal,state,artwork,icon,status,record,header,clamp,ease};
export const addLayouts=more=>Object.assign(layouts,more);
export function concept(B,a,z,config){
  installStyle();const panel=B.panel();B.during(panel,a,z);
  if(!B.libraryCanvas){
    // Native HTML composition avoids repainting an entire SVG foreignObject for
    // each moving library part. The original board still owns its page wipes.
    const canvas=document.createElement('div');canvas.style.cssText='position:absolute;left:50%;top:50%;width:360px;height:640px;transform-origin:center';B.svg.after(canvas);B.libraryCanvas=canvas;
    const resize=()=>{const r=B.svg.parentElement.getBoundingClientRect();canvas.style.transform=`translate(-50%,-50%) scale(${Math.min(r.width/360,r.height/640)})`;};resize();
    B.libraryResize=new ResizeObserver(resize);B.libraryResize.observe(B.svg.parentElement);
  }
  const root=document.createElement('div');root.className='v-page';if(AR)root.dir='rtl';root.style.cssText='position:absolute;inset:0;display:none';if(AR)root.style.scale='-1 1';/* Arabic: page laid out right to left; node() turns each item back so text reads normally */root.dataset.concept=config.scene;root.dataset.start=a;root.dataset.end=z;root.dataset.cues=JSON.stringify(config.cues);B.libraryCanvas.append(root);const p={a,z,root,moves:[],assets:new Set(),pending:[installStyle()]};
  if(!layouts[config.scene])throw Error(`Unknown concept composition: ${config.scene}`);layouts[config.scene](p,config);p.ready=Promise.all(p.pending);const list=pages.get(B)||[];list.push(p);pages.set(B,list);return panel;
}
export async function readyPages(B){await Promise.all((pages.get(B)||[]).map(p=>p.ready));}
export function seekPages(B,t){
  let active=false;
  for(const p of pages.get(B)||[]){
    const on=t>=p.a&&t<p.z;
    if(p.on!==on){
      p.on=on;p.root.style.display=on?'block':'none';
      if(on){
        // Only the current composition participates in layout and painting.
        p.root.getBoundingClientRect();
        for(const host of p.root.querySelectorAll('.v-art'))host.sceneAnimations=timedAnimations(host);
      }
    }
    if(on){active=true;p.moves.forEach(fn=>fn(t));}
  }
  document.body.classList.toggle('vl-2d-active',active);
}
