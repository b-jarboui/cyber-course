// Different actors. Who they are is a concept (2D); what staff and specialists do is the story (3D).
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.2', serve: [[0, S(1)], [S(4) - .5, S(5)]],
  shots: ['wide', { t0: 2.2, t1: 4.2, shot: 'hall' }, [S(2) - .1, 'counter'], [S(3) - .1, 'desk'], [S(4) - .1, 'queue'], { t0: S(4) + 2.5, t1: E(4) - 1, shot: 'counter' }, [S(6) - .1, 'her'], [S(7) - .1, 'desk'], [S(8) - .1, 'her'], [S(9) - .1, 'desk'], [S(10) - .1, 'counter']],
  plates: [
    [S(0) + .5, E(0) + .1, `Public institutions<br>${coral('Different hostile activity')}`],
    [S(4) + .1, S(4) + 3.6, `Cyberespionage<br>${coral('Can stay hidden')}`],
    [S(4) + 3.7, E(4), `Systems keep running<br>${coral('Information is collected')}`],
    [S(8) + .1, E(8) + .1, `Employees<br>${teal('Notice and report')}`],
    [S(9) + .1, E(9) + .1, `Identifying the actor<br>${teal('Specialist work')}`],
  ],
  screen: [[S(9) - .3, S(10) + .4, '#bfe0d6']], omarWatch: [[S(9), S(10) + 1]],
  pages: [
    { a: S(1) - .5, z: S(3) + 6.4, list: [
      { z: S(3) - .2, scene: 'criminals', cues: { a: S(1) + 2.6, b: S(1) + 3.6, c: S(1) + 5, net: S(2) } },
      { a: S(3) - .2, scene: 'state', cues: { a: S(3) + 2.2, b: S(3) + 3.7, c: S(3) + 5.2 } },
    ] },
    { a: S(5) - .5, z: S(8) - .4, list: [
      { z: S(6) - .1, scene: 'hacktivist', cues: { a: S(5) + 3.4, b: S(5) + 4.4, c: S(5) + 5.4 } },
      { a: S(6) - .1, scene: 'overlap', cues: { claim: S(7), same: S(7) + 4 } },
    ] },
    { a: S(10) - .4, z: D.T + 1, list: [{ scene: 'question', cues: { a: S(10) + 1.6, b: S(10) + 6 } }] },
  ],
}));
