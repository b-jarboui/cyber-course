// A code, a drive, a request to hurry.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '7.1',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor' },
  enter: { citizen: S(11) },
  file: [[0, D.T, 1, 1]],
  landline: true,
  handsets: { maya: [[0, S(9), 'chat'], [S(10), S(11), 'lock']] },
  shots: [[0, 'her'], [S(1), 'counter'], [S(3), 'staff'], [S(4), 'her'], [S(9), 'her'], [S(10), 'counterDisplay'], [S(11), 'counter'], [S(12), 'her'], [S(13), 'staff'], [S(16), 'counter']],
  actions: {
    maya: [[0, S(3), 'text'], [S(3), S(9), 'listen', 'omar'], [S(9), S(10), 'extension'], [S(10), S(11), 'type'], [S(11), S(12), 'listen', 'citizen'], [S(12), S(13), 'talk', 'citizen'], [S(13), S(16), 'listen', 'omar'], [S(16), D.T, 'file']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(9), 'talk', 'maya'], [S(9), S(13), 'listen', 'maya'], [S(13), S(16), 'talk', 'maya'], [S(16), D.T, 'listen', 'maya']],
    citizen: [[S(11), S(16), 'usb', 'maya'], [S(16), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(10), 'folder', 'Case 2048', 'neutral'],
      [S(10), S(11), 'bell', 'Fake text reported', 'safe'],
      [S(11), S(16), 'folder', 'Case 2048 · USB declined', 'alert'],
      [S(16), D.T, 'tick', 'Approved upload channel', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Text claiming to be manager'],
    [S(9), E(9), 'Directory call · Sent nothing'],
    [S(11), E(11), 'USB drive at the counter'],
    [S(16), E(16), 'Drive to IT · Approved upload'],
  ],
  screens: [
    [S(1), S(3), q => phone('Work phone · Text', reveal([row('Sender', '+971 50 000 0147', 'warn'), row('Claims', 'Senior Manager · Authority', 'warn'), note('Move to another chat and send the code.', 'no'), row('Your code', '•••••• (For you alone)', 'no')], q))],
    [S(9), S(11), win('Authority directory · Check', row('Manager', 'Called on official number', 'ok') + row('Answer', 'Sent no message', 'ok') + row('Action', 'Reported via approved route', 'ok'), 'good')],
    [S(11), S(13), win('Counter · Case 2048', row('Brought in', 'Missing document on USB drive', 'warn') + row('Counter computer', 'Not plugged in', 'ok') + note('Do not plug unknown drives in.', 'warn'))],
  ],
  pages: [
    hero(S(4), S(7), 'Fake text message', 'made/own_mobile+made/own_chat', [
      ['Fake texts and calls succeed more often', S(4), 'v-coral'],
      ['Move to another chat? Pause and check', S(6), 'v-amber'],
    ]),
    hero(S(7), S(9), 'Never share a code', 'made/own_lock+made/own_mobile', [
      ['A verification code is for you alone', S(7), 'v-coral'],
      ['Do not reply or open links', S(8), 'v-teal'],
    ]),
    hero(S(13), S(16), 'External storage media', 'made/usb_stick+made/own_backup_drive', [
      ['Unknown drives can carry hidden malware', S(13), 'v-coral'],
      ['Avoid, scan, encrypt, eject, destroy old media', S(15), 'v-teal'],
    ]),
    hero(S(16), D.T, 'Verify, then report', 'made/own_desk_phone+made/own_bell', [
      ['Use directory numbers and approved uploads', S(16), 'v-teal'],
      ['Plugged in an unknown drive? Report at once', (S(16) + E(16)) / 2, 'v-coral'],
    ]),
  ],
}));
