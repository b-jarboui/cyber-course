// From many signals to one picture.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['lena', 'maya', 'omar', 'analyst'];
export default chapterHall((S, E, D) => ({
  lesson: '9.3',
  set: 'ops',
  actors: { lena: 'director', maya: 'beside', omar: 'deskGuest', analyst: 'desk' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'gathering'], [S(1), 'display'], [S(2), 'gathering'], [S(5), 'desk'], [S(7), 'staff'], [S(9), 'gathering'], [S(13), 'pair'], [S(14), 'gathering']],
  actions: {
    lena: [[0, S(2), 'talk', 'maya'], [S(2), S(7), 'paper'], [S(7), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'maya']],
    maya: [[0, S(7), 'listen', 'lena'], [S(7), S(13), 'read'], [S(13), S(14), 'paper'], [S(14), D.T, 'talk', 'lena']],
    omar: [[0, S(13), 'listen', 'lena'], [S(13), D.T, 'listen', 'maya']],
    analyst: [[0, S(7), 'type'], [S(7), S(13), 'read'], [S(13), D.T, 'type']],
  },
  displays: {
    counter: [
      [0, S(7), 'clock', 'Timeline · Case 2048 reports', 'neutral'],
      [S(7), S(13), 'zoom', 'Linked · Same misused account', 'alert'],
      [S(13), D.T, 'tick', 'Order of events confirmed', 'safe'],
    ],
    desk: [
      [0, S(9), 'computer', 'SOC · Monitoring alerts', 'neutral'],
      [S(9), D.T, 'bell', 'High priority · Public service', 'alert'],
    ],
  },
  plates: [
    [S(0), E(0), 'Operations room · Next morning'],
    [S(1), E(1), 'Reports linked on one timeline'],
    [S(8), E(8), 'Same misused account linked'],
    [S(13), E(13), 'Exact times build the timeline'],
  ],
  screens: [
    [S(1), S(2), win('Incident timeline · Case 2048', row('02:18', 'Night sign-in · Shaima account', 'warn') + row('02:40', 'Bulk cloud download', 'no') + row('09:10', 'Unexpected approval & IT call', 'warn') + row('10:45', 'Shared folder files locked', 'no'), 'alert')],
  ],
  pages: [
    hero(S(2), S(7), 'Prepare · Protect · Detect · Respond · Recover · Learn', 'made/own_whiteboard+made/control_desk', [
      ['Six-stage national incident lifecycle', S(3), 'v-navy'],
      ['SOC analysts monitor alerts institution-wide', S(5), 'v-teal'],
    ]),
    hero(S(7), S(13), 'Analyse, then prioritise', 'made/own_zoom+made/traffic_light', [
      ['Analysis maps affected systems and spread', S(7), 'v-navy'],
      ['Classify severity by risk and public impact', S(10), 'v-amber'],
      ['UK NCSC handled 429 incidents in one year', S(12), 'v-coral'],
    ]),
    hero(S(13), D.T, 'Your notes build the timeline', 'made/own_incident_binder+made/own_clock', [
      ['Exact times fix the order of events', S(13), 'v-teal'],
      ['An early, factual report starts every stage', S(15), 'v-navy'],
    ]),
  ],
}));
