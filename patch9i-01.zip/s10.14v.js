// Prepared, learning, together.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar', 'finance', 'comms'];
export default chapterHall((S, E, D) => ({
  lesson: '10.4',
  set: 'meeting',
  whiteboard: { title: 'Practice drill · Continuity', items: ['System down scenario', 'Printed procedure', 'Update IT contact list'] },
  actors: { official: 'head', maya: 'seat1', omar: 'seat2', finance: 'seat3', comms: 'seat4' },
  file: [[0, D.T, 1, 1]],
  habits: true,
  shots: [[0, 'gathering'], [S(1), 'file'], [S(2), 'gathering'], [S(8), 'table'], [S(9), 'desk'], [S(10), 'gathering'], [S(12), 'habits'], [S(14), 'gathering']],
  actions: {
    official: [[0, S(2), 'paper'], [S(2), S(8), 'talk', 'maya'], [S(8), S(9), 'listen', 'maya'], [S(9), S(10), 'talk', 'omar'], [S(10), D.T, 'talk', 'maya']],
    maya: [[0, S(8), 'listen', 'official'], [S(8), S(9), 'paper'], [S(9), D.T, 'listen', 'official']],
    omar: [[0, S(9), 'listen', 'official'], [S(9), S(10), 'paper'], [S(10), D.T, 'listen', 'official']],
    finance: [[0, D.T, 'listen', 'official']],
    comms: [[0, D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(8), 'calendar', 'Practice drill · System down', 'alert'],
      [S(8), S(9), 'file', 'Continuity procedure followed', 'neutral'],
      [S(9), S(12), 'tools', 'IT contact list updated same day', 'safe'],
      [S(12), D.T, 'shield', "Sadeed · Security is everyone's work", 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Monthly practice session · Hall closed'],
    [S(1), E(1), 'Drill: appointment system down'],
    [S(9), E(9), 'Old IT list fixed the same day'],
    [S(12), E(12), 'Chapter 10 · Core security habits'],
  ],
  screens: [
    [S(1), S(2), win('Practice drill · Scenario card', row('Situation', 'Appointment system is down', 'no') + row('Hall status', 'Applicants are waiting', 'warn') + row('Reference', 'Printed continuity procedure', 'hi'), 'alert')],
    [S(8), S(10), win('Practice drill · Findings', row('Counter steps', 'Approved message · Reported', 'ok') + row('Gap found', 'IT contact list out of date', 'warn') + row('Action', 'Updated the same day', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(8), 'Plan, practise, recover', 'made/own_policy_binder+made/own_shield', [
      ['Keep serving and recover fast from faults', S(2), 'v-teal'],
      ['Written plan, clear roles, practised team', S(3), 'v-navy'],
      ['GCC exercises and national centres support', S(4), 'v-teal'],
    ]),
    hero(S(10), S(12), 'Management acts on lessons', 'made/own_whiteboard+made/own_tools', [
      ['Lessons from every stage drive improvement', S(10), 'v-teal'],
      ['Management approves, trains and fixes gaps', S(11), 'v-navy'],
    ]),
    hero(S(12), D.T, "Security is everyone's work", 'made/own_shield+made/own_bell+made/own_tick', [
      ['Know rules and owners; approved tools only', S(13), 'v-navy'],
      ['Verify, report early', S(14), 'v-teal'],
      ["Keep learning; security is everyone's work", S(15), 'v-teal'],
    ]),
  ],
}));
