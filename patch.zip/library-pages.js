// 2D edition 3. Licensed library scenes composed into case-specific explanations.
// All transitions and library animation are functions of narration time, including reverse seeking.
const pages = new WeakMap(), sources = new Map();
const NS = 'http://www.w3.org/2000/svg';
let serial = 0, styleReady;
function source(name) {
  if (!sources.has(name)) sources.set(name, fetch(new URL(`./assets/2d/${name}.svg`,import.meta.url)).then(r=>{if(!r.ok)throw Error(`Missing 2D asset: ${name}`);return r.text();}));
  return sources.get(name);
}
function installStyle() {
  return styleReady ??= fetch(new URL('./assets/2d/pages.css',import.meta.url)).then(r=>{if(!r.ok)throw Error('Missing 2D stylesheet');return r.text();}).then(css=>{const s=document.createElement('style');s.id='vl-library-style';s.textContent=css;document.head.append(s);});
}
function node(p,cls,html,x,y,w,h){const n=document.createElement('div');n.className=cls;n.innerHTML=html;n.style.cssText=`left:${x}px;top:${y}px;width:${w}px;${h?`height:${h}px;`:''}`;p.append(n);return n;}
function text(p,html,x,y,w,cls=''){return node(p,`v-text ${cls}`,html,x,y,w);}
function card(p,html,x,y,w,h,cls=''){return node(p,`v-card ${cls}`,html,x,y,w,h);}
function wire(p,d,cls='',at=p.a) {const s=document.createElementNS(NS,'svg');s.setAttribute('viewBox','0 0 360 640');s.classList.add('v-wires');s.innerHTML=`<path class="${cls}" d="${d}"/>`;p.root.append(s);reveal(p,s,at,.35);return s;}
const clamp = n => Math.max(0,Math.min(1,n));
const ease = n => {const q=clamp(n);return q*q*(3-2*q);};
// A single, seekable transfer. The packet and its route share a cue; neither
// runs on wall time or leaves a disconnected mark before the explanation.
function transfer(p,d,at,span=1.5,cls=''){
  const route=wire(p,d,`v-route ${cls}`,at),path=route.firstElementChild;
  const dot=document.createElementNS(NS,'circle');dot.setAttribute('r','5');dot.classList.add('v-packet');route.append(dot);
  let length;
  p.moves.push(t=>{length??=path.getTotalLength();const q=clamp((t-at)/span),pt=path.getPointAtLength(length*ease(q));dot.setAttribute('cx',pt.x);dot.setAttribute('cy',pt.y);dot.style.opacity=t>=at&&q<1?'1':'0';path.style.strokeDasharray=`${length}`;path.style.strokeDashoffset=length*(1-ease(q));});return route;
}
function reveal(p,n,at,span=.65){p.moves.push(t=>{const q=Math.max(0,Math.min(1,(t-at)/span));n.style.opacity=q;n.style.transform=`translateY(${(1-q)*8}px)`;});return n;}
function state(p,at,fn){p.moves.push(t=>fn(t>=at,t));}
function timedAnimations(host){
  // Freeze the clock: it cannot advance on wall time after a seek. Every
  // animation position is supplied explicitly by the narration timeline.
  const all=host.getAnimations({subtree:true});all.forEach(a=>{a.pause();a.currentTime=0;});
  // The globe contains 36 independently projected meridians/dots. Their orbit
  // adds no teaching information and is expensive to scrub in Chromium.
  // Keep that detailed scene in a stable pose and animate its actual packet.
  return host.dataset.asset==='global-edge-network'?all.filter(a=>a.effect.target.classList.contains('pk')):all;
}
// Rendered 3D art (3dicons, CC0). A scene name maps to icons; 'a+b+c' names them directly.
const ART3D={'deployment-pipeline':'file-text+setting+tick','database':'folder+locker','login-authentication':'lock+key','api-request':'computer+link','global-edge-network':'flash+wifi','search':'file-text+zoom','server-monitoring':'computer+chart','cloud-sync':'folder+tick','email-sent':'mail+file-text','gauge-meter':'target+chart','online-payment':'credit-card+dollar','notifications':'megaphone+chat'};
function composed(p,host,names,at){
  const n=names.length,w=host.clientWidth||parseFloat(host.style.width),h=parseFloat(host.style.height)||w*.7;
  const spots=n===1?[[.5,.5,.92]]:n===2?[[.4,.5,.84],[.76,.68,.52]]:[[.5,.46,.76],[.17,.7,.46],[.83,.7,.46]];
  names.forEach((name,i)=>{
    const [cx,cy,s]=spots[i],size=h*s,img=new Image();img.src=new URL(`./assets/2d/${name.startsWith('made/')?'':'icons3d/'}${name}.png`,import.meta.url).href;img.alt='';img.className=name.startsWith('made/')?'v-made':'v-3d';
    img.style.cssText=`position:absolute;left:${cx*w-size/2}px;top:${cy*h-size/2}px;width:${size}px;height:${size}px;z-index:${n-i}`;host.append(img);p.pending.push(img.decode().catch(()=>{}));
    // Each object arrives in turn, then rests with a slow drift that follows narration time.
    p.moves.push(t=>{const q=ease((t-at-i*.35)/.7),d=Math.sin((t+i*1.7)*.8)*3;img.style.opacity=q;img.style.transform=`translateY(${(1-q)*26+d}px) scale(${.82+.18*q}) rotate(${Math.sin((t+i)*.5)*1.2}deg)`;});
  });
}
function artwork(p,name,x,y,w,h,at=p.a){
  const host=node(p.root,'v-art','',x,y,w,h);host.dataset.asset=name;reveal(p,host,at);p.assets.add(name);
  if(ART3D[name]||name.includes('+')||name.startsWith('made/')){composed(p,host,(ART3D[name]||name).split('+'),at);return host;}
  p.pending.push(source(name).then(raw=>{
    const doc=new DOMParser().parseFromString(raw,'image/svg+xml');
    if(doc.querySelector('parsererror'))throw Error(`Invalid SVG: ${name}`);
    const svg=doc.documentElement;
    // Stock engineering callouts are tiny; lesson labels use our >=22px typography.
    // Unused stock blur/shadow layers can leave compositor fragments outside
    // the illustration in Chromium. Remove them before the first SVG paint.
    svg.querySelectorAll('text,.lbl,title,desc,.shs,.shf').forEach(n=>n.remove());
    if(name==='global-edge-network')svg.querySelectorAll('.mer,.dot,.node,.ring,.hot,.dash,.back,.call').forEach(n=>{n.style.animation='none';});
    const original=svg.id, unique=`${original}-${++serial}`;
    if(original){svg.innerHTML=svg.innerHTML.replaceAll(original,unique);svg.id=unique;}
    svg.removeAttribute('width');svg.removeAttribute('height');svg.setAttribute('aria-hidden','true');
    svg.style.cssText='width:100%;height:100%;--svm-accent:#2f7477;--svm-ink:#26305a;--svm-nt:#fffdf8;--svm-w:#fffdf8;--svm-nl:#9dbdb7;--svm-nr:#46547d;--svm-pt:#dce7df;--svm-stroke:1.35';
    if(original){const style=document.createElementNS(NS,'style');style.textContent=`#${unique} .gl,#${unique} .grn{fill:#2f7477}#${unique} .gt{fill:#7db8ab}#${unique} .gr{fill:#24595c}#${unique} .at{fill:#e8b758}#${unique} .al{fill:#c9811a}#${unique} .ar{fill:#8f5c22}#${unique} .rl,#${unique} .red{fill:#c6543b}#${unique} .rt{fill:#efa58c}#${unique} .rr{fill:#93432f}#${unique} .sg{stroke:#2f7477}#${unique} .dt{opacity:.85}`;svg.append(style);}
    host.append(document.importNode(svg,true));host.getBoundingClientRect();
    host.sceneAnimations=timedAnimations(host);
    p.moves.push(t=>(host.sceneAnimations||[]).forEach(a=>{const timing=a.effect.getTiming();const time=host.sceneClock?host.sceneClock(t):Math.max(0,t-at)*1000;const hold=name==='email-sent'?.6:.78;const frame=Math.min(time,Number(timing.delay)+Number(timing.duration)*hold);if(a.currentTime!==frame)a.currentTime=frame;}));
  }));return host;
}
function icon(p,name,x,y,size=38,at=p.a){const n=artwork(p,'tabler/'+name,x,y,size,size,at);n.classList.add('v-icon');return n;}
function status(p,html,x,y,w,cls=''){return card(p,html,x,y,w,undefined,`v-status ${cls}`);}
function record(p,x,y,w=312,cls='') {return card(p,'<div class="v-record-title">Case 2048</div><div class="v-field">Identity <b>•••• ••••</b></div><div class="v-field">Contact <b>•••• ••••</b></div>',x,y,w,158,`v-record ${cls}`);}
function header(p,title){text(p.root,(document.getElementById('kicker')?.textContent||'Lesson 1.1 · Version 3').toUpperCase(),24,16,312,'v-kicker');text(p.root,title,24,49,312,'v-heading');}
function accountGrid(p,y,at,restrict=false){
  const host=node(p.root,'v-account-grid','',24,y,312,258);p.assets.add('tabler/id-badge-2');
  p.pending.push(source('tabler/id-badge-2').then(raw=>{const svg=new DOMParser().parseFromString(raw,'image/svg+xml').documentElement;svg.querySelector('path[stroke="none"]')?.remove();
    host.innerHTML=Array.from({length:340},(_,i)=>`<span class="${i<5?'permitted':'excess'}" aria-hidden="true">${svg.outerHTML}</span>`).join('');host.setAttribute('aria-label','340 staff accounts; only 5 caseworkers permitted');
  }));
  let cells;
  p.moves.push(t=>{
    cells??=host.querySelectorAll('span');
    // Five valid permissions stay teal. Excess access fills progressively, or
    // drains back to those five in the conditional restriction example.
    const q=clamp((t-at)/2.8),count=restrict?340-Math.floor(q*335):5+Math.floor(q*335);
    cells.forEach((n,i)=>{n.style.opacity=i<5?'1':i<count?'1':'.12';});
    host.dataset.count=count;host.classList.toggle('restricted',restrict);host.classList.toggle('expanded',!restrict);
  });return host;
}
const layouts={
  purpose(p,c){
    header(p,'A service worth\nprotecting');
    const scene=artwork(p,'made/p101_purpose',4,187,352,277,p.a);
    text(p.root,'Application',24,151,220,'v-label');
    const review=text(p.root,'Case review',172,435,164,'v-label');reveal(p,review,p.a+1.3);
    transfer(p,'M72 183V233L180 295L285 355V423',p.a+.3,2.1);
    const outcome=card(p.root,'Public decision',24,490,312,72,'v-navy v-result');reveal(p,outcome,p.a+2.4);
    const note=text(p.root,'Sadeed is fictional',24,589,312,'v-note');
    state(p,c.cues.trust,on=>{note.textContent=on?'Trustworthy. Working.':'Sadeed is fictional';scene.classList.toggle('v-live',on);outcome.classList.toggle('v-confirmed',on);});
  },
  assets(p,c){
    header(p,'Information assets\nSupport the work');
    const db=artwork(p,'made/p101_assets',6,202,348,254,p.a);
    const r=card(p.root,'Case 2048 <strong>Applicant record</strong>',24,145,312,72,'v-asset-record');reveal(p,r,c.cues.case);
    transfer(p,'M180 217V268',c.cues.case+.3,1.1);
    const files=card(p.root,'Employee<br>files',24,459,146,84,'v-asset-label');reveal(p,files,c.cues.more);icon(p,'address-book',128,481,30,c.cues.more);
    const devices=card(p.root,'Devices<br>& apps',190,459,146,84,'v-asset-label');reveal(p,devices,c.cues.more+1.8);icon(p,'device-laptop',294,481,30,c.cues.more+1.8);
    transfer(p,'M97 459V432L153 399',c.cues.more,1.3);transfer(p,'M263 459V432L207 399',c.cues.more+1.8,1.3);
    const systems=text(p.root,'Processing & storage',24,561,312,'v-label');reveal(p,systems,c.cues.more+4);
    text(p.root,'Work depends on all of them',24,601,312,'v-note');state(p,c.cues.more+4,on=>db.classList.toggle('v-live',on));
  },
  identity(p,c){
    header(p,'Recognized.\nThen permitted.');
    const kind=text(p.root,'Person identity',24,148,260,'v-label');
    const variants=[['id-badge-2','Person identity'],['device-laptop','Device identity'],['app-window','Application identity'],['cpu','AI agent identity']];
    const symbols=variants.map(([name])=>icon(p,name,296,145,36));
    p.moves.push(t=>{const i=t>=c.cues.decision?0:Math.min(3,Math.max(0,Math.floor((t-p.a)/1.7)));kind.textContent=t>=c.cues.decision?'Identity checked':variants[i][1];symbols.forEach((n,j)=>{n.style.opacity=+(i===j);});});
    const recog=text(p.root,'Identity recognized',24,199,312,'v-note');reveal(p,recog,c.cues.decision);
    // The wings stay shut for recognition alone and swing open once permission is granted.
    const frames=[0,18,36,54,72,90].map(a=>artwork(p,`made/turnstile_w${a}`,-10,228,380,264,p.a+.2)),gate=frames[0];
    p.moves.push(t=>{const k=Math.round(ease((t-c.cues.granted)/1.1)*5);frames.forEach((f,i)=>{f.style.visibility=i===k?'visible':'hidden';});});
    const token=icon(p,'id-badge-2',77,296,48,p.a+.4);token.classList.add('v-token');
    p.moves.push(t=>{const q=ease((t-c.cues.decision)/1.2),r=ease((t-c.cues.granted-.4)/1.1);token.style.transform=`translate(${q*75+r*87}px,${q*43+r*50}px)`;token.style.opacity=t>=p.a+.4&&t<c.cues.granted+1.8?'1':'0';});
    const access=text(p.root,'Permission required',24,493,312,'v-permission');reveal(p,access,c.cues.permission);
    state(p,c.cues.granted,on=>{access.textContent=on?'Permission granted':'Permission required';access.classList.toggle('v-allowed',on);gate.classList.toggle('v-live',on);});
    const file=status(p.root,'Case 2048 opens',24,554,312,'v-navy v-result');reveal(p,file,c.cues.granted+1.6);
  },
  dependencies(p,c){
    header(p,'Services depend\non other services');text(p.root,'Sadeed · Case 2048',24,145,312,'v-label');
    const scene=artwork(p,'made/p101_dependencies',10,274,340,224,p.a+.15);
    const nodes=[['user-scan','Identity',24,194,'M94 264V304L118 328'],['credit-card','Payments',204,194,'M270 264V308L254 329'],['antenna-bars-5','Comms',24,493,'M94 493V468L125 450'],['bolt','Electricity',204,493,'M270 493V468L253 450']];
    nodes.forEach(([n,l,x,y,d],i)=>{
      const at=c.cues.services+i*.5;const h=card(p.root,l,x,y,132,70,'v-dependency');h.style.paddingTop='39px';icon(p,n,x+48,y+3,34,at);reveal(p,h,at);transfer(p,d,at+.2,1.2);
      state(p,at+1.4,on=>h.classList.toggle('v-connected',on));
    });
    const note=text(p.root,'Some run elsewhere',24,592,312,'v-note');reveal(p,note,c.cues.elsewhere);state(p,c.cues.understand,on=>{note.textContent=on?'Know what you rely on':'Some run elsewhere';scene.classList.toggle('v-live',on);});
  },
  infrastructure(p,c){
    header(p,'One supply.\nSeveral services.');
    const network=artwork(p,'made/p101_infrastructure',57,151,291,213,p.a);const power=icon(p,'bolt',25,200,60,p.a);
    const supply=text(p.root,'Electricity',24,365,312,'v-label v-supply');
    const trunk=wire(p,'M180 401V428M65 450V428H295V450M180 428V450','v-power',p.a+.6);
    const routes=['M180 401V428H65V450','M180 401V450','M180 401V428H295V450'];routes.forEach(d=>{const r=transfer(p,d,p.a+1,1.6);state(p,c.cues.cut,on=>r.style.visibility=on?'hidden':'visible');});
    const destinations=[];
    [['building-hospital','Healthcare',8,124],['droplet','Water',140,94],['antenna-bars-5','Comms',246,106]].forEach(([n,l,x,w],i)=>{
      const h=card(p.root,l,x,452,w,112,'v-service v-center v-powered');h.style.paddingTop='76px';const art=icon(p,n,x+(w-52)/2,464,52);destinations.push([h,art]);
      state(p,c.cues.cut+.15*i,on=>{h.classList.toggle('v-off',on);art.classList.toggle('v-dark',on);});
    });
    const cut=text(p.root,'Supply cut · Example',24,365,312,'v-label v-cut-label');reveal(p,cut,c.cues.cut,.2);
    const foot=text(p.root,'Shared dependence',24,593,312,'v-note');
    state(p,c.cues.cut,on=>{supply.style.visibility=on?'hidden':'visible';trunk.classList.toggle('v-cut',on);trunk.firstElementChild.setAttribute('d',on?'M180 401V408M180 422V428M65 450V428H295V450M180 428V450':'M180 401V428M65 450V428H295V450M180 428V450');network.classList.toggle('v-disrupted',on);power.classList.toggle('v-dark',on);foot.textContent=on?'Disruption can spread':'Shared dependence';});
  },
  confidentiality(p,c){
    header(p,'Confidentiality\nControlled access');
    record(p.root,24,146,312,'v-private-record');icon(p,'shield-check',288,157,30,p.a);
    const permit=text(p.root,'Authorized case team',24,289,312,'v-note');reveal(p,permit,p.a+.3);
    const gate=artwork(p,'made/p101_confidentiality',96,318,264,216,p.a+.25);gate.sceneClock=()=>1700;
    const link=card(p.root,'A link',24,337,114,56,'v-link-token');reveal(p,link,c.cues.link);const linkIcon=icon(p,'link',76,15,24,c.cues.link);link.append(linkIcon);
    p.moves.push(t=>{const q=ease((t-c.cues.link)/1.1);link.style.transform=`translate(${q*36}px,${q*38}px)`;});
    const stop=text(p.root,'No permission',24,500,172,'v-denial');reveal(p,stop,c.cues.link+1.1);wire(p,'M150 420L96 494','v-denied',c.cues.link+1.1);
    const wrong=card(p.root,'Wrong recipient',24,539,312,56,'v-coral');reveal(p,wrong,c.cues.wrong);
    const packet=icon(p,'mail-forward',281,551,32,c.cues.wrong);p.moves.push(t=>{packet.style.transform=`translateX(${-70+70*ease((t-c.cues.wrong)/1.3)}px)`;});
    const foot=text(p.root,'Would disclose private details',24,604,312,'v-note');reveal(p,foot,c.cues.wrong+.3);
  },
  integrity(p,c){
    header(p,'Integrity\nCheck the decision');
    const approved=card(p.root,'Case 2048 <strong>Approved</strong>',24,147,312,68,'v-teal v-case-approved');approved.setAttribute('aria-label','Actual case decision: Approved. The changing decision below is a hypothetical example.');
    const scene=artwork(p,'made/register_book',-2,242,364,250,p.a+.2);
    const example=text(p.root,'Could happen',24,224,312,'v-scenario');reveal(p,example,c.cues.could);
    const decision=card(p.root,'Approved',61,463,238,54,'v-decision v-teal');reveal(p,decision,c.cues.could);
    const caught=text(p.root,'Improper change caught',24,526,312,'v-denial');reveal(p,caught,c.cues.checks);
    const checks=card(p.root,'Checked correction<br><strong>Who · What · When</strong>',24,558,312,75,'v-navy v-audit');reveal(p,checks,c.cues.checks);const history=icon(p,'history',288,575,32,c.cues.checks);history.style.color='#fffdf8';
    p.moves.push(t=>{
      const changed=t>=c.cues.could+.9&&t<c.cues.saved;decision.textContent=changed?'Refused':'Approved';decision.classList.toggle('v-coral',changed);decision.classList.toggle('v-teal',!changed);decision.classList.toggle('v-caught',t>=c.cues.checks&&t<c.cues.saved);
      example.textContent=t>=c.cues.saved?'Example · Checked correction':'Could happen · Unapproved change';scene.classList.toggle('v-live',t>=c.cues.checks);caught.textContent=t>=c.cues.saved?'':'Improper change caught';
      checks.innerHTML=t>=c.cues.saved?'Correction saved<br><strong>Audit trail retained</strong>':'Checked correction<br><strong>Who · What · When</strong>';
    });
  },
  availability(p,c){
    header(p,'Availability\nThe service waits');
    const accessible=status(p.root,'Record · Accessible',24,147,312,'v-teal');
    text(p.root,'Identity service',24,219,312,'v-label');
    const servers=artwork(p,'made/p101_availability',-2,239,364,241,p.a);
    const offline=card(p.root,'Identity check<br><strong>Offline</strong>',24,480,146,108,'v-coral v-branch');reveal(p,offline,c.cues.earlier);
    wire(p,'M92 453V480','v-denied',c.cues.earlier);wire(p,'M170 530H190','v-denied',c.cues.earlier+1.1);
    const waiting=card(p.root,'Case 2048<br><strong>Waiting</strong>',190,480,146,108,'v-amber v-branch');reveal(p,waiting,c.cues.earlier+1.1);
    const foot=text(p.root,'The case has to wait',24,597,312,'v-note');reveal(p,foot,c.cues.earlier+1.1);
    const stopped=icon(p,'id-badge-2',263,381,46,c.cues.earlier);stopped.classList.add('v-offline-token');
    state(p,c.cues.earlier,on=>{servers.classList.toggle('v-disrupted',on);accessible.classList.toggle('v-record-available',on);});
  },
  notice(p,c){
    header(p,'Public information\nCorrect. Available.');
    const notice=card(p.root,'Public notice<br><strong>Opening hours</strong>',24,147,312,98,'v-navy');notice.style.paddingRight='65px';const calendar=icon(p,'calendar-clock',278,171,42);calendar.style.color='#fffdf8';
    const scene=artwork(p,'made/p101_notice',-6,267,372,267,p.a+.2);scene.sceneClock=t=>Math.max(0,t-c.cues.hours)*1000;
    transfer(p,'M180 245V305',c.cues.hours,1.1);
    const correct=text(p.root,'Correct at the source',24,550,312,'v-note');reveal(p,correct,p.a+.6);
    const online=text(p.root,'Available to the public',24,594,312,'v-label');reveal(p,online,c.cues.hours+.6);state(p,c.cues.hours+1.2,on=>scene.classList.toggle('v-live',on));
  },
  together(p,c){
    header(p,'One record.\nThree protections.');
    const gate=artwork(p,'made/safe',0,181,180,147,p.a);gate.sceneClock=()=>2600;
    const check=artwork(p,'made/register_book',176,181,180,147,p.a+.2);
    text(p.root,'Private',24,149,138,'v-label');const correct=text(p.root,'Correct',204,149,132,'v-label');
    record(p.root,24,345,312,'v-recap-record');
    transfer(p,'M82 299V327H118V345',p.a+.6,1.2);transfer(p,'M278 299V327H240V345',p.a+.8,1.2);
    const service=artwork(p,'made/server_rack',12,478,218,147,p.a+.5);wire(p,'M180 473V492H259V542','',p.a+.8);
    const usable=text(p.root,'Usable',226,557,110,'v-note');
    state(p,c.cues.retrieve,on=>{usable.innerHTML=on?'Cannot<br>retrieve':'Usable';usable.classList.toggle('v-denial',on);service.classList.toggle('v-disrupted',on);});
    state(p,c.cues.wrong,on=>{correct.textContent=on?'Wrong decision':'Correct';correct.classList.toggle('v-denial',on);check.classList.toggle('v-fault',on);});
  },
  vulnerability(p,c){
    header(p,'Vulnerability\nExcess permission');
    text(p.root,'Case 2048 · Access setting',24,145,312,'v-label');
    const good=card(p.root,'<strong class="v-number">5</strong><span>permitted</span>',24,195,138,110,'v-teal v-count');
    const broad=card(p.root,'<strong class="v-number">5</strong><span>have access</span>',180,195,156,110,'v-amber v-count');reveal(p,broad,c.cues.broad,.2);
    // The open cabinet shows the weakness first, then gives way to the count of accounts.
    const cabinet=artwork(p,'made/key_cabinet',46,318,268,268,p.a);
    const grid=accountGrid(p,328,c.cues.broad);p.moves.push(t=>{const q=clamp((t-c.cues.broad)/.6);cabinet.style.opacity=1-q;grid.style.opacity=q;broad.querySelector('strong').textContent=5+Math.floor(clamp((t-c.cues.broad)/2.8)*335);});
    const note=text(p.root,'Access ≠ evidence of misuse',24,598,312,'v-note');reveal(p,note,c.cues.weakness);good.setAttribute('aria-label','Only five caseworkers are permitted');grid.setAttribute('role','img');
  },
  threat(p,c){
    header(p,'Threat\nTwo ways to harm');
    const scene=artwork(p,'made/fishing_hook',-6,204,372,269,p.a+.2);scene.sceneClock=t=>Math.max(0,t-c.cues.ways)*1000;
    const a=card(p.root,'Deliberate<br><strong>Misuse of access</strong>',24,485,146,105,'v-navy v-branch');reveal(p,a,c.cues.ways);
    const b=card(p.root,'Accidental<br><strong>Private details shared</strong>',188,485,148,122,'v-amber v-branch');reveal(p,b,c.cues.ways+2.6);
    transfer(p,'M180 409V456H96V485',c.cues.ways,1.4);transfer(p,'M180 409V456H262V485',c.cues.ways+2.6,1.4,'v-warning-route');
    const inside=text(p.root,'Could originate inside Sadeed',24,151,312,'v-note');reveal(p,inside,c.cues.inside);
  },
  risk(p,c){
    header(p,'Risk\nTwo judgments');
    const gauge=artwork(p,'made/balance_scale',-4,180,368,274,p.a);
    const likelihood=text(p.root,'Likelihood',24,151,312,'v-label');reveal(p,likelihood,p.a+.2);
    const chance=text(p.root,'Chance of harm',24,438,312,'v-note');reveal(p,chance,p.a+.2);
    const consequence=card(p.root,'Consequences<br><strong>Seriousness of harm</strong>',24,491,312,86,'v-navy');reveal(p,consequence,p.a+2.5);
    transfer(p,'M180 466V491',p.a+2.5,1);
    const note=text(p.root,'Access widens opportunity',24,599,312,'v-note');reveal(p,note,c.cues.opportunity);state(p,c.cues.opportunity,on=>gauge.classList.toggle('v-opportunity',on));
  },
  consequences(p,c){
    header(p,'Consequences\nBeyond the record');record(p.root,24,147,312,'v-consequence-record');
    artwork(p,'online-payment',-4,291,368,238,c.cues.harm);
    const fraud=card(p.root,'Possible<br><strong>Fraud</strong>',24,529,138,88,'v-coral v-branch');reveal(p,fraud,c.cues.harm);
    const contact=card(p.root,'Possible<br><strong>Unwanted contact</strong>',181,529,155,103,'v-amber v-branch');reveal(p,contact,c.cues.harm+2);
    transfer(p,'M97 277V315',c.cues.harm,1.1,'v-warning-route');transfer(p,'M263 277V321',c.cues.harm+2,1.1,'v-warning-route');icon(p,'phone',286,467,40,c.cues.harm+2);
  },
  reporting(p,c){
    header(p,'Report facts.\nStart assessment.');
    const report=card(p.root,'Case 2048<br><strong>Permitted: 5</strong><br><strong>Setting: 340</strong>',24,148,312,126,'v-navy v-report');const reportIcon=icon(p,'report',280,168,38);reportIcon.style.color='#fffdf8';
    const scene=artwork(p,'made/headset',-2,294,364,231,p.a+.3);scene.sceneClock=t=>Math.max(0,t-c.cues.assess)*1000;
    const route=text(p.root,'Approved reporting route',24,283,312,'v-note');reveal(p,route,p.a+.3);transfer(p,'M180 316V354',c.cues.assess-.7,1.1);
    const proof=text(p.root,'Misuse proof not needed',24,527,312,'v-permission');reveal(p,proof,c.cues.proof);
    const team=card(p.root,'Team assesses response',24,576,312,56,'v-teal');reveal(p,team,c.cues.assess);
  },
  reduce(p,c){
    header(p,'Restrict access.\nAssess exposure.');
    const count=card(p.root,'If restricted <strong class="v-number">340</strong><span>have access</span>',24,146,312,125,'v-teal v-restriction');
    accountGrid(p,291,p.a,true);
    p.moves.push(t=>{const n=340-Math.floor(clamp((t-p.a)/2.8)*335);count.querySelector('strong').textContent=n;count.querySelector('span').textContent=n===5?'permitted':'have access';});
    const sensitive=text(p.root,'Still sensitive',24,567,312,'v-label');reveal(p,sensitive,c.cues.still);icon(p,'file-text',298,566,30,c.cues.still);
    const assess=text(p.root,'Check earlier access · Assess',24,599,312,'v-permission');reveal(p,assess,c.cues.still+.8);
  },
  weakness(p,c){
    header(p,'Nobody owns\nthe approval');
    const request=card(p.root,'Sensitive change',24,146,312,56,'v-navy');
    const scene=artwork(p,'made/p105_nobody_owns',22,206,316,250,p.a);
    const owner=text(p.root,'Who approves?',24,446,312,'v-permission');reveal(p,owner,c.cues.token);
    const route=transfer(p,'M90 202V238L180 296L270 352V396',c.cues.token,1.8,'v-warning-route');
    const back=transfer(p,'M270 396V352L180 296L90 238V202',c.cues.refuse,1.6,'v-warning-route');
    state(p,c.cues.chain,on=>{route.style.visibility=back.style.visibility=on?'hidden':'visible';scene.classList.toggle('v-fault',on);owner.textContent=on?'Each weakness feeds the next':'Who approves?';});
    const links=[['People','user-scan',8],['Device','device-laptop',124],['Process','report',240]].map(([l,n,x],i)=>{
      const at=c.cues.chain+i*.7,h=card(p.root,l,x,498,112,98,'v-teal v-center');h.style.cssText+='padding:58px 0 0;';const art=icon(p,n,x+38,508,36,p.a);reveal(p,h,p.a);
      state(p,at,on=>{h.classList.toggle('v-coral',on);h.classList.toggle('v-teal',!on);});art.style.color='#26305a';return h;
    });
    wire(p,'M120 547H124','v-denied',c.cues.chain+.4);wire(p,'M236 547H240','v-denied',c.cues.chain+1.1);
    return links;
  },
  usable(p,c){
    header(p,'A safe action\nmust be practical');
    const warning=card(p.root,'Warning unclear',24,146,312,56,'v-coral');
    const scene=artwork(p,'made/p105_practical',30,204,300,204,p.a);scene.sceneClock=t=>Math.max(0,t-c.cues.clear)*1000;
    state(p,c.cues.clear,on=>{warning.textContent=on?'Use the approved portal':'Warning unclear';warning.classList.toggle('v-teal',on);warning.classList.toggle('v-coral',!on);scene.classList.toggle('v-live',on);});
    const label=text(p.root,'Approved process',24,414,312,'v-label');reveal(p,label,c.cues.maze);
    transfer(p,'M40 556V464H110V540H180V464H250V540H320V464',c.cues.maze,5.4,'v-warning-route');
    const slow=text(p.root,'Hard to find. Too slow.',24,568,312,'v-permission');reveal(p,slow,c.cues.maze+2.6);
  },
  combine(p,c){
    header(p,'Protection needs\nall of these');
    const scene=artwork(p,'made/p105_all_these',20,146,320,228,p.a);
    const parts=[['Training','id-badge-2',14,386],['Processes','report',184,386],['Technology','device-laptop',14,458],['Clear roles','user-scan',184,458],['Support','phone',99,530]];
    parts.forEach(([l,n,x,y],i)=>{const at=c.cues.first+i*c.cues.step,h=card(p.root,l,x,y,162,60,'v-teal');h.style.paddingLeft='10px';h.style.whiteSpace='nowrap';reveal(p,h,at);icon(p,n,x+130,y+17,26,at);});
    state(p,c.cues.first+4*c.cues.step+.6,on=>{scene.classList.toggle('v-live',on);});
    const done=text(p.root,'Then the safe action is possible',24,600,312,'v-note');done.style.fontSize='22px';done.style.whiteSpace='nowrap';done.style.letterSpacing='-.4px';reveal(p,done,c.cues.first+4*c.cues.step+.6);
  },
  examine(p,c){
    header(p,'When something\ngoes wrong');
    artwork(p,'made/p105_examine',6,146,348,244,p.a);
    const act=card(p.root,'Individual action',24,398,312,56,'v-amber v-center');reveal(p,act,p.a+.3);
    const a=card(p.root,'Conditions',24,488,148,60,'v-teal v-center'),b=card(p.root,'Controls',188,488,148,60,'v-teal v-center');
    reveal(p,a,c.cues.wider);reveal(p,b,c.cues.wider+.5);
    transfer(p,'M120 454V488',c.cues.wider,.6);transfer(p,'M240 454V488',c.cues.wider+.5,.6);
    const note=text(p.root,'Examine all three',24,574,312,'v-note');reveal(p,note,c.cues.wider+1.2);
  },
  governance(p,c){
    header(p,'Governance\nconnects the roles');
    text(p.root,'Policy · Oversight · Risk',24,145,312,'v-label');
    const scene=artwork(p,'made/p106_governance',10,274,340,224,p.a+.15);
    [['id-badge-2','Leaders',24,194,'M94 264V304L118 328'],['user-scan','Owners',204,194,'M270 264V308L254 329'],['shield-check','Security',24,493,'M94 493V468L125 450'],['report','Staff',204,493,'M270 493V468L253 450']].forEach(([n,l,x,y,d],i)=>{
      const at=c.cues.link+i*.7,h=card(p.root,l,x,y,132,70,'v-dependency');h.style.paddingTop='39px';icon(p,n,x+48,y+3,34,p.a);reveal(p,h,p.a);transfer(p,d,at,1);state(p,at+1,on=>h.classList.toggle('v-connected',on));
    });
    const note=text(p.root,'Clear owners, informed decisions',24,592,312,'v-note');reveal(p,note,c.cues.link+3.2);state(p,c.cues.link+3.2,on=>scene.classList.toggle('v-live',on));
  },
  depth(p,c){
    header(p,'Defence in depth\nSeveral protections');
    const X=180,Y=330,radii=[150,124,98,72,46],s=document.createElementNS(NS,'svg');s.setAttribute('viewBox','0 0 360 640');s.classList.add('v-wires');p.root.append(s);
    const rings=radii.map(r=>{const n=document.createElementNS(NS,'circle');n.setAttribute('cx',X);n.setAttribute('cy',Y);n.setAttribute('r',r);n.setAttribute('fill','none');n.setAttribute('stroke-width','9');s.append(n);return n;});
    const core=icon(p,'file-text',X-22,Y-22,44,p.a);core.style.color='#26305a';
    const names=['Access controls','Maintained software','Restricted connections','Monitoring','Recovery'],icons=['id-badge-2','app-window','link','report','history'];
    const marks=radii.map((r,i)=>{const a=(-90+i*72)*Math.PI/180,n=icon(p,icons[i],X+Math.cos(a)*r-15,Y+Math.sin(a)*r-15,30,c.cues.layers+i*c.cues.step);n.style.background='#f2eee6';n.style.borderRadius='50%';n.style.padding='3px';return n;});
    const name=text(p.root,'',24,497,312,'v-label'),foot=text(p.root,'',24,545,312,'v-note');name.style.textAlign=foot.style.textAlign='center';
    const threat=document.createElementNS(NS,'circle');threat.setAttribute('r','10');threat.setAttribute('fill','#c6543b');threat.setAttribute('stroke','#fffdf8');threat.setAttribute('stroke-width','3');s.append(threat);
    p.moves.push(t=>{
      const on=Math.floor((t-c.cues.layers)/c.cues.step),failed=t>=c.cues.fail+1.1,caught=t>=c.cues.fail+2.7;
      rings.forEach((n,i)=>{const shown=t<c.cues.layers||on>=i;n.setAttribute('stroke',i===0&&failed?'#c6543b':i===3&&caught?'#e2a133':'#2f7477');n.style.opacity=shown?(i===on&&t<c.cues.fail?1:.5):.1;n.setAttribute('stroke-dasharray',i===0&&failed?'10 12':'none');});
      name.textContent=t>=c.cues.fail?(caught?'Monitoring detects it':'One control fails'):t>=c.cues.layers?names[Math.min(4,on)]:'';
      foot.textContent=caught?'The others still protect':'';
      // The attempt crosses the failed outer control and stops at monitoring.
      const q=ease((t-c.cues.fail)/2.7);threat.setAttribute('cx',X+172-(172-radii[3]-14)*q);threat.setAttribute('cy',Y);threat.style.opacity=t>=c.cues.fail?1:0;
      marks.forEach(n=>n.style.visibility='visible');
    });
  }
};
export const page2d={NS,text,card,wire,transfer,reveal,state,artwork,icon,status,record,header,clamp,ease};
export const addLayouts=more=>Object.assign(layouts,more);
export function concept(B,a,z,config){
  installStyle();const panel=B.panel();B.during(panel,a,z);
  if(!B.libraryCanvas){
    // Native HTML composition avoids repainting an entire SVG foreignObject for
    // each moving library part. The original board still owns its page wipes.
    const canvas=document.createElement('div');canvas.style.cssText='position:absolute;left:50%;top:50%;width:360px;height:640px;transform-origin:center';B.svg.after(canvas);B.libraryCanvas=canvas;
    const resize=()=>{const r=B.svg.parentElement.getBoundingClientRect();canvas.style.transform=`translate(-50%,-50%) scale(${Math.min(r.width/360,r.height/640)})`;};resize();
    B.libraryResize=new ResizeObserver(resize);B.libraryResize.observe(B.svg.parentElement);
  }
  const root=document.createElement('div');root.className='v-page';root.style.cssText='position:absolute;inset:0;display:none';root.dataset.concept=config.scene;root.dataset.start=a;root.dataset.end=z;root.dataset.cues=JSON.stringify(config.cues);B.libraryCanvas.append(root);const p={a,z,root,moves:[],assets:new Set(),pending:[installStyle()]};
  if(!layouts[config.scene])throw Error(`Unknown concept composition: ${config.scene}`);layouts[config.scene](p,config);p.ready=Promise.all(p.pending);const list=pages.get(B)||[];list.push(p);pages.set(B,list);return panel;
}
export async function readyPages(B){await Promise.all((pages.get(B)||[]).map(p=>p.ready));}
export function seekPages(B,t){
  let active=false;
  for(const p of pages.get(B)||[]){
    const on=t>=p.a&&t<p.z;
    if(p.on!==on){
      p.on=on;p.root.style.display=on?'block':'none';
      if(on){
        // Only the current composition participates in layout and painting.
        p.root.getBoundingClientRect();
        for(const host of p.root.querySelectorAll('.v-art'))host.sceneAnimations=timedAnimations(host);
      }
    }
    if(on){active=true;p.moves.forEach(fn=>fn(t));}
  }
  document.body.classList.toggle('vl-2d-active',active);
}
