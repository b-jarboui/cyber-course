// A digital problem becomes a public problem. The lesson returns to the applicant.
import { hallScene, CAST_APPLICANT, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST_APPLICANT;
export default hallScene((S, E, D) => ({
  lesson: '1.2', front: 'citizen', serve: [[S(9), D.T]],
  shots: ['hall', { t0: S(1) - .6, t1: S(1) + .6, shot: 'queue' }, [S(8) - .1, 'her'], [S(9) - .1, 'queue'], { t0: S(10) + 1, t1: S(10) + 4, shot: 'hall' }],
  young: { walk: S(1) }, tint: [[S(1), S(2), .12]],
  plates: [
    [S(0) + .5, E(0) + .1, `A digital incident<br>${coral('A public-service problem')}`],
    [S(1) + .1, E(1) + .1, `Identity service down<br>${coral('Application stops')}`],
    [S(8) + .1, E(8) + .1, `Staff<br>${teal('Report, use alternatives')}`, 205],
    [S(9) + .1, E(9) + .1, `The applicant<br>${teal('At the counter')}`],
    [S(10) + .1, E(10) + .4, `Available, correct, private<br>${teal('One service')}`],
  ],
  pages: [{ a: S(2) - .5, z: S(8) - .4, list: [
    { z: S(3) - .2, scene: 'hero', cues: { title: 'Payment disrupted\nMoney arrives late', art: 'made/p112_payment_f', lines: [['Intended recipient waits', S(2) + 2.6, 'v-coral']] } },
    { a: S(3) - .2, z: S(4) - .2, scene: 'hero', cues: { title: 'One provider\nSeveral institutions', art: 'made/p112_provider_c', items: [['Health', S(3) + 2.2, 'v-coral'], ['Water', S(3) + 2.6, 'v-coral'], ['Finance', S(3) + 3, 'v-coral']] } },
    { a: S(4) - .2, z: S(6) - .2, scene: 'hero', cues: { title: 'Essential services\nReal consequences', art: 'made/p112_essential_d', items: [['Service', S(4) + 2.4, 'v-coral'], ['Finance', S(4) + 3.4, 'v-coral'], ['Society', S(4) + 4.4, 'v-coral']], lines: [['Some affect safety', S(5), 'v-amber']] } },
    { a: S(6) - .2, z: S(7) - .2, scene: 'hero', cues: { title: 'What decides\nthe impact', art: 'made/p112_impact_e', items: [['Service', S(6) + 1.8, 'v-navy'], ['Duration', S(6) + 3.2, 'v-navy'], ['Alternatives', S(6) + 5, 'v-navy']] } },
    { a: S(7) - .2, scene: 'hero', cues: { title: 'Prepare before\nit happens', art: 'made/p112_prepare_e', live: S(7) + 5, lines: [['Identify critical services', S(7) + 2, 'v-teal'], ['Continuity arrangements', S(7) + 4, 'v-teal'], ['Test recovery', S(7) + 5.6, 'v-teal']] } },
  ] }],
}));
