import { restoreTeachingTable } from './v1-set.js';
// Case 2048: people in 3D, every technical explanation on a continuous 2D page.
import { THREE, C, V, mesh, rbox, group, folder, lerp, ramp, pulse } from './kit.js';
import { createPerson, loadMotion } from './people.js';
import { atCounter, counterTyping } from './sets.js';
import { frameShots, quietScreens } from './astra.js';
import { readyPages, seekPages } from './library-pages.js';
import { pagesB } from './pages2d-b.js';
import { createBoard } from './board.js';
import { serverCut } from './made.js';

export const texts = [];
export const cast = ['maya', 'citizen', 'comms', 'citizenYoung', 'priya'];

export default async function ({ stage, scene, b, createCounter, S, E, D, ui }) {
  await loadMotion(['m_gestic_shrug_02', 'm_idle_nervous_03', 'f_gestic_listen_deny_05', 'm_walk_start','m_walk_neutral_01', 'm_walk_stop', 'm_idle_neutral_02', 'm_idle_neutral_03', 'f_idle_neutral_01', 'f_idle_neutral_02',
    'f_walk_start', 'f_walk_neutral_01', 'f_walk_stop', 'f_turn_left_120', 'f_turn_left_60_to_walk', 'f_gestic_listen_deny_01', 'f_gestic_listen_accept_01', 'f_idle_look_around_01', 'm_idle_look_around_01', 'm_idle_look_around_02', 'm_gestic_listen_accept_01']);
  document.getElementById('kicker').textContent = 'Lesson 1.1 · Version 4';
  document.getElementById('cap').style.fontSize = '21px';
  createCounter(scene);
  await restoreTeachingTable(scene);
  const maya = createPerson('maya', scene), applicant = createPerson('citizen', scene), woman = createPerson('comms', scene), young = createPerson('citizenYoung', scene), rania = createPerson('priya', scene);
  for (const p of [maya,applicant,woman,young,rania]) p.continuousMotion = true;

  // Restore the approved folder prop from ../scenes/s1.01.js.
  const file = folder(scene, 0, 0, 0, 1.05);
  file.name='Case folder';
  const carry = V(0,0,0), forward = V(0,0,0), side = V(0,0,0), down = V(0,-1,0);
  const basis = new THREE.Matrix4(), qCarry = new THREE.Quaternion(), qFlat = new THREE.Quaternion();
  // The printed decision lies on the counter, within Shaima's reach.
  // The near edge overhangs the worktop by 30 mm: the thumb can get underneath
  // without passing through the counter before the sheet lifts.
  const REST = V(-2.50, 1.05565, -.80), READ = V(-2.47, 1.29, -.527);
  const sheet = group(scene); sheet.rotation.order = 'YZX';
  mesh(rbox(.3, .0003, .21, .0001), C.paper, 0, 0, 0, sheet);
  mesh(rbox(.05, .00005, .17, .00002), C.teal, .1, .000175, 0, sheet);
  for (const x of [.04, .005, -.03, -.065, -.1]) mesh(rbox(.012, .00005, .16, .00002), C.powderD, x, .000175, 0, sheet);

  // Routes. The applicant arrives; later two more people arrive behind him when the service stops.
  const rot = -Math.PI / 2, at = [-1.3, -.3], walkM = ['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop'], walkF = ['f_walk_start', 'f_walk_neutral_01', 'f_walk_stop'];
  // Two full stride cycles: a real walk across the hall, not a step and a stop.
  const route = applicant.planTo(['m_walk_start', 'm_walk_neutral_01', 'm_walk_neutral_01', 'm_walk_stop', 'm_idle_neutral_02'], at[0], at[1], rot, 3.0, .3, 'm_idle_neutral_02');
  const wRoute = woman.planTo([...walkF, 'f_idle_neutral_02'], -.35, -.3, rot, S(12) + .9), yRoute = young.planTo([...walkM, 'm_idle_neutral_03'], .5, -.3, rot, S(12) + 2.6);
  const tDark = S(12) + 1.2, tNod = S(24) + 1.8;
  const aLook = applicant.plan(['m_idle_look_around_01', 'm_gestic_shrug_02', 'm_idle_nervous_03', 'm_idle_neutral_02'], at[0], at[1], rot, tDark + .3, .4, route);
  const aNod = applicant.plan(['m_gestic_listen_accept_01', 'm_idle_neutral_02'], at[0], at[1], rot, tNod, .4, aLook);
  const wLook = woman.plan(['f_idle_look_around_01', 'f_idle_neutral_02'], -.35, -.3, rot, Math.max(tDark+.7,wRoute.segs.at(-1).t0+.5), .4, wRoute);
  const yLook = young.plan(['m_idle_look_around_02', 'm_idle_neutral_03'], .5, -.3, rot, Math.max(tDark+.5,yRoute.segs.at(-1).t0+.5), .4, yRoute);
  // Rania, from another team, is at the cabinets. She walks over to see Case 2048 and Shaima refuses.
  // Approach along the staff aisle, then turn towards Shaima. A real start
  // precedes the stop; the return turn stays clear of Shaima's shoulders.
  const r1 = rania.planTo(['f_walk_start', 'f_walk_stop', 'f_turn_left_120', 'f_idle_neutral_02'], -3.5, .08, 2.1, E(19) + .25, .3, 'f_idle_neutral_02');
  const R0 = r1.segs[0];
  const r2 = rania.plan(['f_gestic_listen_accept_01', 'f_turn_left_60_to_walk', 'f_walk_stop', 'f_idle_neutral_02'], r1.end.x, r1.end.z, r1.yaw, S(20) + 5.4, .3, r1);
  const deny = maya.plan(['f_gestic_listen_deny_05', 'f_idle_neutral_01'], -2.8, -.45, 1.8, S(20) + 2.1, .4, 'f_idle_neutral_01');

  // ---------- 2D helpers ----------
  const B = createBoard(D.T), { tl } = B;
  const say = (a, z, text) => {
    const plate = document.createElement('div');
    plate.style.cssText = 'position:absolute;left:16px;bottom:170px;padding:8px 14px;border-radius:12px;background:#fffdf8;color:#26305a;font:800 22px/1.2 "Segoe UI",Arial;box-shadow:0 4px 14px rgba(38,48,90,.18);opacity:0;pointer-events:none';
    plate.innerHTML = text;
    document.getElementById('stage').after(plate);
    tl.fromTo(plate, { opacity: 0 }, { opacity: 1, duration: .3, immediateRender: false }, a);
    tl.to(plate, { opacity: 0, duration: .25 }, z);
  };

  // ---------- 2D: identity and permission ----------
  const pages2d = await import('./pages2d.js');
  document.getElementById('cap').style.fontSize = '22px';
  say(S(2) + .6, S(3) - .2, 'Sadeed Service<br>Authority<br><span style="color:#2f7477">Case 2048</span>');
  say(S(12) + .3, E(13) + 1.2, 'Applicant ID check<br><span style="color:#c6543b">Cannot complete</span>');
  say(S(24) + .1, S(25) + 2, 'Applicant ID check<br><span style="color:#2f7477">Working again</span>');
  say(S(4)+.1,E(4)+.5,'Public services<br><span style="color:#2f7477">Trustworthy and working</span>');
  say(S(31)+.1,E(31)+.1,'Earlier<br><span style="color:#c6543b">Identity not verified</span>');
  say(S(32)+.1,E(32)+1,'Case 2048<br><span style="color:#c6543b">Had to wait</span>');
  say(S(29)+.1,E(29)+.4,'Shaima<br><span style="color:#2f7477">Correction saved</span>');
  say(E(19)+.6,deny.t0-.3,'Rania<br><span style="color:#2f7477">Another team</span>');
  say(deny.t0+.1,S(21)-.6,'Shaima<br><span style="color:#c6543b">Permission required</span>');

  // Keep the board open across consecutive concepts: page changes never reveal the room.
  const open1 = S(3)-.5, close1 = S(12)-.5;
  B.open(open1);
  pages2d.purpose(B,S,E,open1,S(4)-.5);
  // Why it matters is said over the working hall, then the concepts continue.
  B.close(S(4)-.5); B.open(S(5)-.5);
  pages2d.identity(B,S,E,S(9)-.5,close1);
  B.close(close1);
  const open2 = E(13)+1.3, close2 = E(19)+.4;
  B.open(open2);
  pages2d.dependencies(B,S,E,open2,S(18)-.1);
  B.close(close2);
  // Rania's request and Shaima's refusal are acted in the room, before the record view.
  B.open(S(21)-.5); B.close(S(24)-.5);
  B.open(S(26)-.5);
  pages2d.integrity(B,S,E,S(26)-.5,S(29)-.5);
  // Saving the correction is an action, so it is seen in the room.
  B.close(S(29)-.5); B.open(S(30)-.5);
  pages2d.notice(B,S,E,S(33)-.1,S(35)-.1);
  pagesB({B,S,E,D});
  B.end();
  await readyPages(B);

  // ---------- the 3D story ----------
  const keys = V(-2.46, 1.121, -.45), screenAt = V(-2.1, 1.47, -.66), faceOf = (p, h = 1.5) => p.g.position.clone().setY(h);
  const wideShot = { x: -.6, y: 1.0, z: .1, w: 7.8, e: .68, f: .44 }, her = { x: -2.25, y: 1.3, z: -.42, w: 2.7, e: .42, f: .42 }, hall = { x: -1.3, y: 1.3, z: -.1, w: 5, e: .5, f: .45 };
  const teach = { x: -2, y: 1.3, z: -.1, w: 2.9, e: .42, f: .42 }, queue = { x: -1, y: 1.1, z: -.3, w: 4.2, e: .42, f: .44 }, town3 = { x: -.45, y: 1, z: .15, w: 4.7, e: .46, f: .46 };
  const staff = { x: -3, y: 1.3, z: -.75, w: 2.9, e: .42, f: .42 }, finale = { x: -1.3, y: 1.2, z: -.2, w: 4.7, e: .46, f: .45 };
  const cutTo = (x, shot) => ({ t0: x - .62, t1: x - .6, ...shot });

  const cut = serverCut(S(12) + .2, S(12) + 1.7, S(13) - .1);
  return t => {
    cut(t);
    tl.time(t, false);
    seekPages(B, t);
    // The room gives way completely to an opaque concept page after its wipe.
    stage.conceptPage = (t>=open1+.4 && t<S(4)-.5) || (t>=S(5)-.1 && t<close1) || (t>=open2+.4 && t<close2) ||
      (t>=S(21)-.1 && t<S(24)-.5) || (t>=S(26)-.1 && t<S(29)-.5) || (t>=S(30)-.1 && t<S(31)-.5) || t>=S(33)-.1;
    quietScreens(ui, t);
    stage.focus = null;

    // Shaima watches the applicant arrive, then starts work.
    const work = ramp(t, S(2) + .1, S(2) + 1);
    atCounter(maya, applicant, t, work);
    maya.g.visible = applicant.g.visible = true;
    maya.sway = 0; applicant.reset(); applicant.idle(t); applicant.sway = 0;
    if(t < route.t0) { const start=route.segs[0]; applicant.at(start.x,start.z,start.yaw).play('m_idle_neutral_02',t,true); }
    else if (t < aLook.t0) applicant.follow(route, t, true); else if (t < aNod.t0) applicant.follow(aLook, t, true); else applicant.follow(aNod, t, true);

    // People arrive behind him when the service stops, and look round when the power goes.
    woman.reset(); woman.idle(t, 3); woman.sway = 0; woman.g.visible = t >= wRoute.t0 - .1;
    if (t < wLook.t0) woman.follow(wRoute, t, true); else woman.follow(wLook, t, true);
    young.reset(); young.idle(t, 4); young.sway = 0; young.g.visible = t >= yRoute.t0 - .1;
    if (t < yLook.t0) young.follow(yRoute, t, true); else young.follow(yLook, t, true);
    woman.smile = young.smile = .1;
    woman.look(V(-2.5, 1.5, -.5), .6); young.look(V(-2.5, 1.5, -.5), .5);

    // Rania walks over, and goes back when Shaima refuses.
    rania.reset(); rania.idle(t, 5); rania.sway = 0;
    if (t < r1.t0) rania.at(R0.x, R0.z, R0.yaw).play('f_idle_neutral_02', t, true); else if (t < r2.t0) rania.follow(r1, t, true); else rania.follow(r2, t, true);
    const peek = pulse(t, r1.t0 + 2.6, r1.t0 + 3.4, r2.t0 + 1.6, r2.t0 + 2.2);
    rania.look(screenAt, peek); rania.smile = .15;
    rania.look(faceOf(maya), pulse(t, deny.t0 - .1, deny.t0 + .4, r2.t0 + 1.4, r2.t0 + 1.9));

    // Shaima: recorded standing body, hands on the keyboard. She lifts them only to refuse.
    if (t < deny.t0) maya.play('f_idle_neutral_01', t, true); else maya.follow(deny, t, true);
    const free = pulse(t, deny.t0 - .35, deny.t0 + .05, deny.t0 + 3, deny.t0 + 3.6);
    const waiting = pulse(t,S(12)+.4,S(12)+1,S(24)-.4,S(24)+.2);
    // She stops typing for the whole handover, and goes back to the keys once the folder is open.
    // Calm handover (ChatGPT animator review): eased timing, a short half step, a small turn.
    const smooth = u => u * u * (3 - 2 * u);
    const A = route.segs.at(-2).t1, folderHands = smooth(pulse(t,A+.75,A+1.5,A+5.35,A+6.35));
    // A short side step so the folder lies in front of her, then back to the keyboard.
    const step = smooth(pulse(t,A+.95,A+1.65,A+4.9,A+5.75));
    if (step>0) { maya.g.position.z=lerp(maya.g.position.z,-.24,step); maya.g.rotation.y=lerp(maya.g.rotation.y,maya.g.rotation.y-.1,step); }
    const typingTime = Math.min(t,S(12)+.4)+Math.max(0,t-(S(24)+.2)), toKeys = work*(1-Math.max(free,folderHands));
    if (toKeys>0 && toKeys<1) {
      // Lift above the worktop before crossing its edge. A straight joint
      // blend from the resting/gesturing arms cut through the counter lip.
      maya.ik.R = maya.ik.L = null; maya.flush();
      const turn = new THREE.Quaternion().setFromAxisAngle(V(1,0,0),Math.PI);
      for (const side of ['L','R']) {
        const wrist=maya.arm[side].wrist, target=wrist.localToWorld(V(7.5,0,0));
        target.lerp(keys.clone().add(V(0,0,side==='R'?.095:-.095)),toKeys);
        target.y += .08*Math.sin(Math.PI*toKeys);
        const quaternion=wrist.getWorldQuaternion(new THREE.Quaternion()).slerp(turn,toKeys);
        maya.reach(side,target,1,null,{grip:.15,quaternion});
      }
    } else if (toKeys>=1) {
      counterTyping(maya,typingTime,1);
      for(const side of ['L','R']) maya.ik[side].t.y=keys.y;
    }
    else maya.ik.R = maya.ik.L = null;

    // She reaches for the printed decision, lifts it in both hands, reads it and compares it with her screen.
    const t0 = S(24) + .3, back = S(27), a = pulse(t, t0, t0 + .9, back + 1.05, back + 1.75), lift = pulse(t, t0 + 1.1, t0 + 2.4, back, back + 1), join = pulse(t, t0 + 1.7, t0 + 2.4, back, back + .8);
    sheet.position.lerpVectors(REST, READ, lift); sheet.rotation.set(0, .23 * lift, 1.1 * lift); sheet.updateMatrixWorld(true);
    if (a > 0) {
      // Pick up the near corners, within reach of the respective shoulders.
      // Her left hand secures the resting sheet before the lift begins.
      maya.grasp('L',sheet,V(-.145,0,-.095),V(1,0,0),a);
      maya.grasp('R',sheet,V(-.145,0,.095),V(1,0,0),join);
    }

    // Where each of them looks.
    if (t < S(2)) maya.look(faceOf(applicant), ramp(t, 2, 3.5));
    else if (a > 0) { maya.look(sheet.position, 1); maya.look(screenAt, pulse(t, t0 + 4.3, t0 + 4.8, t0 + 5.8, t0 + 6.3)); }
    else {
      maya.look(screenAt, 1);
      maya.look(faceOf(rania), free);
      maya.look(faceOf(applicant), pulse(t,S(12)+.8,S(12)+1.3,S(12)+3.2,S(12)+3.8));
      maya.look(faceOf(applicant), pulse(t, S(24), S(24) + .5, S(25)-.7, S(25)));
      maya.look(faceOf(applicant), ramp(t, S(36), S(36) + 1));
    }
    maya.smile = lerp(t < S(2) + 1 || t > tNod ? .3 : .12,.04,waiting);
    applicant.smile = t > tNod ? .35 : .15;
    applicant.look(V(-2.8, 1.5, -.45), ramp(t, 3, 4.2));

    // One recorded approach, one continuous handover. No procedural walk.
    const arrived = route.segs.at(-2).t1;
    const liftFolder = ramp(t, arrived-.2, arrived+.55);
    // He lays the folder on the counter, turned to face her. She draws it to her with both hands, then flips the cover over.
    const give = smooth(ramp(t, arrived+.55, arrived+1.55)), slideZ = smooth(ramp(t, arrived+1.95, arrived+2.9)), slideX = slideZ;
    // The cover opens in one soft motion.
    const flip = smooth(ramp(t, arrived+3.35, arrived+4.65)), open = 1.2566*flip;
    const angle = applicant.g.rotation.y;
    forward.set(Math.sin(angle),0,Math.cos(angle));
    applicant.flush();
    applicant.grip.R=.95; applicant.arm.R.wrist.localToWorld(carry.set(7.5,0,0));
    side.crossVectors(down,forward).normalize(); basis.makeBasis(forward.clone().negate(),side.clone().negate(),down); qCarry.setFromRotationMatrix(basis);
    // The same corner stays in his hand from the first frame to release.
    // Carry it outside his coat, move it clear of his body, then flatten it.
    carry.addScaledVector(forward,.19*1.05).addScaledVector(side,.014*1.05+.028).addScaledVector(down,.14*1.05+.025);
    // A clear handover bay, beside the keyboard and monitor. Both consecutive
    // scenes share this placement; the folder rests on the actual countertop.
    const offered=V(-1.85,1.24,-.3).lerp(V(-2.15,1.0553,-.24),give);
    offered.x=lerp(offered.x,-2.42,slideX); offered.z=lerp(offered.z,-.12,slideZ);
    file.position.copy(carry).lerp(offered,liftFolder);
    const flatten=ramp(t,arrived+.05,arrived+.65);
    qFlat.setFromAxisAngle(V(0,1,0),-Math.PI/2*ramp(t,arrived+.05,arrived+1.2)); file.quaternion.copy(qCarry).slerp(qFlat,flatten); file.userData.open(open);
    if(flip>=1) file.userData.cover.position.y=.008;
    const release = 1-ramp(t,arrived+1.5,arrived+1.9);
    file.updateMatrixWorld(true);
    applicant.grasp('R',file,V(.19,.014,-.14),V(0,0,1),release,.028,.003);
    // Both hands take the near edge; the left keeps it steady while the right lifts the cover.
    // Hands low and close together, only while needed; no arms held out while she reads.
    const holdL=smooth(pulse(t,arrived+1.5,arrived+2.05,arrived+3.65,arrived+4.1)), holdR=smooth(pulse(t,arrived+1.5,arrived+2.05,arrived+3.05,arrived+3.4));
    maya.bend=Math.max(maya.bend||0,.085*smooth(pulse(t,arrived+1.55,arrived+2.0,arrived+2.85,arrived+3.35))+.035*smooth(pulse(t,arrived+4.2,arrived+4.55,arrived+5.2,arrived+5.7)));
    if(holdL>0) maya.grasp('L',file,V(-.12,.014,.12),V(0,0,-1),holdL,.018,.003);
    if(holdR>0) maya.grasp('R',file,V(.12,.014,.12),V(0,0,-1),holdR,.018,.003);
    const operate=smooth(pulse(t,arrived+3.25,arrived+3.55,arrived+4.4,arrived+4.75));
    if(operate>0) maya.grasp('R',file.userData.cover,V(.12,0,.12),V(0,0,-1),operate,.008,.003);
    maya.look(file.position,smooth(pulse(t,arrived+.65,arrived+1.3,arrived+5.35,arrived+6.15)));
    file.visible = !stage.conceptPage;

    for (const p of [maya,applicant,woman,young,rania]) p.g.visible = p.g.visible && !stage.conceptPage;
    // Rania enters the story when she approaches the counter.
    rania.g.visible = !stage.conceptPage && t>=E(19)-.2;

    stage.outage = .12 * Math.max(pulse(t,S(12),S(12)+1,S(24)-.5,S(24)+.3), pulse(t,S(31),S(31)+.8,E(32),E(32)+.8));
    frameShots(stage, t, [
      wideShot,
      { t0: 1.5, t1: 2.0, x: route.segs[0].x, y: 1.1, z: route.segs[0].z, w: 2.3, e: .48, f: .4 },
      { t0: 2.3, t1: 3.2, x: .5, y: 1.1, z: -.3, w: 5.8, e: .5, f: .44 },
      { t0: S(2) + .4, t1: S(2) + 1.3, ...her },
      { t0: S(3) - .2, t1: S(3) + 1.6, ...hall },
      { t0: S(5) - .6, t1: S(5) + .9, ...teach },
      cutTo(S(12), queue),
      
      { t0: E(19), t1: E(19)+.3, ...staff },
      { t0: S(24) - .4, t1: S(24) + .8, ...her },
      cutTo(S(30), queue),
      cutTo(S(35), finale),
    ]);
    // One deliberate over-shoulder reading angle exposes the document and its
    // grips instead of looking through the monitor and the open folder lid.
    const readAngle=pulse(t,t0-.5,t0+.5,back+.8,back+1.6);
    if(readAngle>0&&!stage.lockDir) {
      stage.dir.set(lerp(1,-.35,readAngle),lerp(.42,1.0,readAngle),lerp(1,.65,readAngle)).normalize();stage.apply();
    }
  };
}
