// AI can help the defenders, if people check it.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.3', serve: [[S(8), S(8) + 1]],
  shots: ['desk', [S(6) - .1, 'desk'], [S(8) - .1, 'her']],
  screen: [[S(0) + .4, S(1), '#bfe0d6'], [S(6), S(7), '#efc46c']], omarWatch: [[S(6), S(7)]],
  lena: { walk: S(8) - 1, nod: S(9) + 2 },
  plates: [
    [S(0) + .5, E(0) + .1, `AI for defenders<br>${teal('Huge volumes of data')}`],
    [S(6) + .1, E(6) + .1, `Omar<br>${teal('Checks the observations')}`],
    [S(8) + .1, E(8) + .1, `Your role<br>${teal('Remains important')}`],
    [S(9) + .2, E(9) + .3, `An early report<br>${teal('Adds what monitoring lacks')}`, 205],
  ],
  pages: [
    { a: S(1) - .5, z: S(6) - .4, list: [
      { z: S(3) - .2, scene: 'hero', cues: { title: 'Patterns across\nall its systems', art: 'made/control_desk', live: S(1) + 4.4, items: [['Accounts', S(1) + 2.4], ['Devices', S(1) + 3.2], ['Cloud', S(1) + 4]], lines: [['Summaries and priorities', S(2) + .4, 'v-teal']] } },
      { a: S(3) - .2, scene: 'hero', cues: { title: 'Convincing is\nnot verified', art: 'made/p115_verified', lines: [['Normal behaviour flagged', S(4) + .4, 'v-amber'], ['Event missed, wrong analysis', S(4) + 3, 'v-amber'], ['Automation beyond intent', S(5) + .8, 'v-coral']] } },
    ] },
    { a: S(7) - .4, z: S(8) - .4, list: [{ scene: 'hero', cues: { title: 'Defensive AI\nneeds oversight', art: 'made/p115_oversight', items: [['Test', S(7) + 2.4], ['Monitor', S(7) + 3.6], ['Limit', S(7) + 4.6]], lines: [['Human review', S(7) + 6, 'v-navy']] } }] },
  ],
}));
