// AI increases operational speed. Claims need evidence; defenders keep working.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.3', serve: [[S(9), S(9) + 1]],
  shots: ['desk', [S(8) - .1, 'desk'], [S(9) - .1, 'her']],
  screen: [[S(0) + .4, S(1), '#efc46c'], [S(8), S(9) + .2, '#bfe0d6']], omarWatch: [[S(8), S(9) + .2]],
  plates: [
    [S(0) + .5, E(0) + .1, `AI<br>${coral('Technical activity too')}`],
    [S(8) + .1, E(8) + .1, `Defenders<br>${teal('Maintain and respond')}`],
    [S(9) + .1, E(9) + .1, `Everyone<br>${teal('Limit access, update, report')}`],
  ],
  pages: [
    { a: S(1) - .5, z: S(8) - .4, list: [
      { z: S(3) - .3, scene: 'hero', cues: { title: 'Faster and\nat greater scale', art: 'made/p114_speed', items: [['Analyze', S(1) + 1.4, 'v-coral'], ['Exploit', S(1) + 3, 'v-coral'], ['Generate', S(1) + 4.6, 'v-coral']], lines: [['Repeated tasks, more speed', S(2) + 1, 'v-amber']] } },
      { a: S(3) - .3, z: S(5) - .3, scene: 'autonomy', cues: { auto: S(4) } },
      { a: S(5) - .3, scene: 'hero', cues: { title: 'These capabilities\nvary', art: 'made/p114_vary', lines: [['Generated code can fail', S(6), 'v-amber'], ['Conclusions can be wrong', S(6) + 1.8, 'v-amber'], ['"Autonomous"? Show evidence', S(7), 'v-navy']] } },
    ] },
    { a: S(10) - .4, z: D.T + 1, list: [{ scene: 'hero', cues: { title: 'Neither claim\nIs the full story', art: 'made/p114_claims', items: [['Dramatic claim', S(10) + 1.4, 'v-amber'], ['Reassuring label', S(10) + 3, 'v-amber']] } }] },
  ],
}));
