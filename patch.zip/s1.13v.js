// AI makes deception more convincing. Shaima checks anyway.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.3', serve: [[0, S(1)]],
  shots: ['hall', [S(7) - .1, 'her'], [S(8) + .2, 'staff']],
  lena: { walk: S(8) - 2.6, nod: S(8) + 1 },
  plates: [
    [S(0) + .5, E(0) + .1, `AI tools<br>${coral('Can analyse public information')}`],
    [S(7) + .1, E(7) + .1, `Shaima<br>${coral('Knows the subject')}`],
    [S(8) + .1, E(8) + .1, `She checks<br>${teal('An established route')}`],
  ],
  pages: [
    { a: S(1) - .5, z: S(7) - .4, list: [
      { z: S(3) - .3, scene: 'hero', cues: { title: 'AI helps gather\nand target', art: 'made/p113_gather_e', items: [['People', S(2) + 1.8, 'v-amber'], ['Work', S(2) + 4, 'v-amber'], ['Language', S(2) + 5, 'v-amber']], lines: [['Reconnaissance', S(1) + .6, 'v-navy']] } },
      { a: S(3) - .3, scene: 'hero', cues: { title: 'Polished message\nProves nothing', art: 'made/p113_polished_e', lines: [['No obvious mistakes', S(3) + 1.8, 'v-amber'], ['Real project, familiar style', S(4) + .2, 'v-amber'], ['Sender: not established', S(6), 'v-coral']] } },
    ] },
    { a: S(9) - .4, z: D.T + 1, list: [{ scene: 'hero', cues: { title: 'Treat it with care\nAI or not', art: 'made/p113_care_e', lines: [['Requested action', S(10) + 1, 'v-navy'], ['Information involved', S(10) + 2.4, 'v-navy'], ['Evidence of authority', S(10) + 3.8, 'v-teal']] } }] },
  ],
}));
