// Trust arrives through other people, and harm can start inside.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.2', serve: [[0, S(1)]],
  shots: ['hall', [S(4) - .1, 'counter'], [S(8) - .1, 'staff'], [S(11) - .1, 'her']],
  lena: { walk: S(9) - 3.2, nod: S(9) + .4 }, tint: [[S(5), S(7) - .6, .08]],
  plates: [
    [S(0) + .5, E(0) + .1, `Suppliers, contractors<br>${teal('Connected services')}`],
    [S(4) + .1, E(4) + .1, `Inside the boundary<br>${coral('Harm can start here too')}`],
    [S(5) + .1, E(5) + .1, `Deliberate<br>${coral('Misused access')}`],
    [S(6) + .1, E(6) + .1, `Unintentional<br>${coral('Wrong audience')}`, 205],
    [S(8) + .1, E(8) + .1, `Report<br>${teal('The approved route')}`],
    [S(9) + .1, E(9) + .1, `Describe<br>${teal('What you observed')}`],
    [S(10) + .1, E(10) + .1, `Avoid<br>${coral('Unsupported accusations')}`],
    [S(11) + .1, E(11) + .3, `Authorized teams<br>${teal('Need the facts')}`],
  ],
  pages: [
    { a: S(1) - .5, z: S(4) - .4, list: [{ scene: 'hero', cues: { title: 'Supply-chain risk\nHarm arrives', art: 'made/p111_supply_chain_e', items: [['Update', S(1) + 4.4, 'v-coral'], ['Service', S(1) + 6, 'v-coral'], ['Access', S(1) + 8, 'v-coral']], lines: [['Trust needs defined duties', S(3) + .4, 'v-teal'], ['Monitoring and review', S(3) + 3.8, 'v-teal']] } }] },
    { a: S(7) - .4, z: S(8) - .4, list: [{ scene: 'hero', cues: { title: 'Access should fit\nits purpose', art: 'made/p111_access_purpose_e', lines: [['Different investigations', S(7) + .6, 'v-navy'], ['Authorized purpose only', S(7) + 3.8, 'v-teal']] } }] },
  ],
}));
