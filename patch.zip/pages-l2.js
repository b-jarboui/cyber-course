// 2D pages for Lessons 1.2 and 1.3. Same family as library-pages.js: library art, moving with the words.
import { addLayouts, page2d } from './library-pages.js';
const { NS, text, card, wire, transfer, reveal, state, artwork, icon, header, ease } = page2d;

// Cards that arrive one by one under the art, each joined to it.
function joined(p, items, y, h = 60) {
  const n = items.length, w = n === 2 ? 148 : 104, gap = n === 2 ? 16 : 0, step = n === 2 ? 164 : 104;
  items.forEach(([label, at, cls = 'v-teal'], i) => {
    const x = n === 2 ? 24 + i * step : 8 + i * (step + 8), c = card(p.root, label, x, y, w, h, `${cls} v-center`);
    c.style.padding = '8px 0'; c.style.display = 'flex'; c.style.alignItems = 'center'; c.style.justifyContent = 'center'; c.style.lineHeight = '1.1';
    reveal(p, c, at); transfer(p, `M${x + w / 2} ${y - 26}V${y}`, at, .5);
  });
  return gap;
}

// Each page receives its cues directly.
const add = more => addLayouts(Object.fromEntries(Object.entries(more).map(([k, f]) => [k, (p, c) => f(p, c.cues)])));

add({
  criminals(p, c) {
    header(p, 'Cybercriminals\nSeek profit');
    artwork(p, 'made/p107_criminals', 10, 146, 340, 226, p.a);
    joined(p, [['Fraud', c.a], ['Stolen data', c.b], ['Extortion', c.c]], 394, 74);
    const spec = text(p.root, 'Organized networks', 24, 486, 312, 'v-label'); reveal(p, spec, c.net);
    [['mail-forward', 62], ['cpu', 164], ['credit-card', 266]].forEach(([n, x], i) => { const m = icon(p, n, x, 526, 40, c.net + .3 + i * .5); m.style.color = '#26305a'; });
    transfer(p, 'M106 546H160M208 546H262', c.net + .3, 1.4);
    const note = text(p.root, 'Work divided among specialists', 24, 586, 312, 'v-note'); note.style.whiteSpace = 'nowrap'; note.style.letterSpacing = '-.4px'; reveal(p, note, c.net + 1.2);
  },
  state(p, c) {
    header(p, 'State-sponsored\nactivity');
    artwork(p, 'made/p107_state', 34, 150, 292, 214, p.a);
    const items = [['Sensitive information', c.a], ['Strategic advantage', c.b], ['Disruption', c.c]];
    items.forEach(([l, at], i) => { const n = card(p.root, l, 24, 382 + i * 72, 312, 58, 'v-navy'); reveal(p, n, at); });
  },
  hacktivist(p, c) {
    header(p, 'Hacktivists\nPolitical motive');
    const art = artwork(p, 'made/p107_hacktivist', 20, 150, 320, 220, p.a); art.sceneClock = t => Math.max(0, t - c.a) * 1000;
    joined(p, [['Attention', c.a], ['Disruption', c.b], ['Exposure', c.c]], 394, 74);
    const note = text(p.root, 'Motive may shape the target', 24, 496, 312, 'v-note'); reveal(p, note, c.c + 1);
  },
  overlap(p, c) {
    header(p, 'The categories\noverlap');
    const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 360 640'); s.classList.add('v-wires'); p.root.append(s);
    const circles = [[132, 262, '#2f7477'], [228, 262, '#c9811a'], [180, 346, '#26305a']].map(([x, y, col]) => { const n = document.createElementNS(NS, 'circle'); n.setAttribute('r', '92'); n.setAttribute('fill', col); n.setAttribute('fill-opacity', '.2'); n.setAttribute('stroke', col); n.setAttribute('stroke-width', '3'); s.append(n); return [n, x, y]; });
    const lab = [['Profit', 58, 212], ['Intelligence', 216, 212], ['Politics', 136, 392]].map(([l, x, y]) => { const n = text(p.root, l, x, y, 130, 'v-label'); return n; });
    p.moves.push(t => { const q = ease((t - p.a) / 1.4); circles.forEach(([n, x, y]) => { n.setAttribute('cx', 180 + (x - 180) * q * 1); n.setAttribute('cy', 290 + (y - 290) * q); }); lab.forEach(n => { n.style.opacity = q; }); });
    const claim = card(p.root, 'A claimed motive is not proof', 24, 462, 312, 56, 'v-amber v-center'); claim.style.whiteSpace = 'nowrap'; claim.style.padding = '13px 0'; reveal(p, claim, c.claim);
    const same = text(p.root, 'Same methods, different actors', 24, 536, 312, 'v-note'); same.style.whiteSpace = 'nowrap'; same.style.letterSpacing = '-.3px'; reveal(p, same, c.same);
  },
  // The common page: library art as the hero, then what the words add, in time with them.
  hero(p, c) {
    header(p, c.title);
    const art = artwork(p, c.art, 20, 146, 320, 226, p.a);
    if (c.clock !== undefined) art.sceneClock = t => Math.max(0, t - c.clock) * 1000;
    if (c.fault !== undefined) state(p, c.fault, on => art.classList.toggle('v-disrupted', on));
    if (c.live !== undefined) state(p, c.live, on => art.classList.toggle('v-live', on));
    if (c.items) joined(p, c.items, 394, 74);
    (c.lines || []).forEach(([label, at, cls = 'v-navy'], i) => { const n = card(p.root, label, 24, (c.items ? 482 : 386) + i * 70, 312, 58, cls); n.style.padding = '13px 14px'; n.style.whiteSpace = 'nowrap'; n.style.letterSpacing = '-.3px'; reveal(p, n, at); });
    if (c.note) { const n = text(p.root, c.note[0], 24, 600, 312, 'v-note'); n.style.whiteSpace = 'nowrap'; n.style.letterSpacing = '-.3px'; reveal(p, n, c.note[1]); }
  },
  // Someone else's credential passes the gate.
  stolen(p, c) {
    header(p, 'A stolen identity\nStill opens the door');
    // The same speed gate as in Lesson 1.1 swings open for the stolen credential.
    const frames = [0, 18, 36, 54, 72, 90].map(a => artwork(p, `made/turnstile_w${a}`, -10, 150, 380, 264, p.a));
    p.moves.push(t => { const k = Math.round(ease((t - c.pass) / 1.1) * 5); frames.forEach((f, i) => { f.style.visibility = i === k ? 'visible' : 'hidden'; }); });
    const label = text(p.root, 'Used without authorization', 24, 424, 312, 'v-permission'); label.style.whiteSpace = 'nowrap'; reveal(p, label, c.a);
    const a = card(p.root, 'Credentials compromised', 24, 474, 312, 58, 'v-coral'); reveal(p, a, c.pass);
    const b = card(p.root, 'Account holder impersonated', 24, 544, 312, 58, 'v-coral'); b.style.padding = '13px 14px'; b.style.whiteSpace = 'nowrap'; b.style.letterSpacing = '-.3px'; reveal(p, b, c.pass + 2.8);
  },
  // A sensitive detail changes while everything else looks the same.
  smallchange(p, c) {
    header(p, 'One small change\nMoves the money');
    artwork(p, 'made/p109_small_change', 20, 146, 320, 226, p.a);
    const dest = card(p.root, 'Payment destination', 24, 394, 312, 58, 'v-teal v-decision'); dest.style.fontSize = '22px';
    const items = [['Administrative record', c.b], ['Authorization', c.c]];
    items.forEach(([l, at], i) => { const n = card(p.root, l, 24, 466 + i * 70, 312, 58, 'v-navy'); reveal(p, n, at); });
    p.moves.push(t => { const on = t >= c.a; dest.textContent = on ? 'Destination changed' : 'Payment destination'; dest.classList.toggle('v-coral', on); dest.classList.toggle('v-teal', !on); });
  },
  // Three things guard an account; each is a way in.
  account(p, c) {
    header(p, 'Protect the\nwhole account');
    artwork(p, 'made/p109_account', 10, 146, 340, 236, p.a);
    joined(p, [['Sign-in', c.a], ['Recovery', c.b], ['Sessions', c.c]], 404, 74);
  },
  // A timeline: the fix arrives after the attack starts.
  zeroday(p, c) {
    header(p, 'Zero-day\nAttacked before a fix');
    const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 360 640'); s.classList.add('v-wires'); p.root.append(s);
    s.innerHTML = '<path d="M36 300H324"/><path d="M36 288V312M324 288V312"/>';
    const flaw = card(p.root, 'Flaw exists', 24, 160, 150, 58, 'v-amber v-center'); flaw.style.padding = '13px 0';
    const known = text(p.root, 'Unknown to defenders', 24, 334, 312, 'v-permission'); reveal(p, known, c.unknown);
    const attack = card(p.root, 'Exploited', 96, 226, 150, 58, 'v-coral v-center'); attack.style.padding = '13px 0'; reveal(p, attack, c.exploit);
    const fix = card(p.root, 'Fix available', 186, 160, 150, 58, 'v-teal v-center'); fix.style.padding = '13px 0'; reveal(p, fix, c.fix);
    const dot = document.createElementNS(NS, 'circle'); dot.setAttribute('r', '9'); dot.setAttribute('fill', '#c6543b'); dot.setAttribute('stroke', '#fffdf8'); dot.setAttribute('stroke-width', '3'); dot.setAttribute('cy', '300'); s.append(dot);
    p.moves.push(t => dot.setAttribute('cx', 36 + 225 * ease((t - c.exploit + .6) / 2.4)));
    const art = artwork(p, 'made/server_rack', 40, 384, 280, 196, p.a); state(p, c.exploit, on => art.classList.toggle('v-fault', on));
    const note = text(p.root, 'Patching alone is not enough', 24, 596, 312, 'v-note'); note.style.whiteSpace = 'nowrap'; reveal(p, note, c.patch);
  },
  // A scale from people-directed to autonomous.
  autonomy(p, c) {
    header(p, 'How much is\nleft to the system?');
    artwork(p, 'made/robot_arm', 20, 150, 320, 226, p.a);
    const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 360 640'); s.classList.add('v-wires'); p.root.append(s);
    s.innerHTML = '<path d="M36 430H324"/>';
    const knob = document.createElementNS(NS, 'circle'); knob.setAttribute('r', '13'); knob.setAttribute('cy', '430'); knob.setAttribute('fill', '#e2a133'); knob.setAttribute('stroke', '#fffdf8'); knob.setAttribute('stroke-width', '3'); s.append(knob);
    const left = text(p.root, 'People approve', 24, 454, 170, 'v-label'), right = text(p.root, 'System acts', 196, 454, 140, 'v-label'); right.style.textAlign = 'right';
    const note = card(p.root, 'Within limits people set', 24, 508, 312, 58, 'v-navy'); reveal(p, note, c.auto + 1);
    p.moves.push(t => { const q = .18 + .64 * ease((t - c.auto) / 2.2); knob.setAttribute('cx', 36 + 288 * q); left.style.opacity = 1 - .6 * ease((t - c.auto) / 2.2); right.style.opacity = .4 + .6 * ease((t - c.auto) / 2.2); });
  },
  // The narrated decision: the three possible actions, then the right one stays.
  options(p, c) {
    header(p, 'Three ways\nto respond');
    artwork(p, 'made/p116_options', 20, 146, 320, 226, p.a);
    const list = [['Upload immediately', c.a], ['Reply to confirm', c.b], ['Verify: approved channels', c.c]].map(([l, at], i) => { const n = card(p.root, l, 24, 394 + i * 70, 312, 58, 'v-navy'); n.style.padding = '13px 14px'; n.style.whiteSpace = 'nowrap'; n.style.letterSpacing = '-.3px'; reveal(p, n, at); return n; });
    p.moves.push(t => { const on = t >= c.answer; list.forEach((n, i) => { n.classList.toggle('v-teal', on && i === 2); n.classList.toggle('v-navy', !on || i !== 2); if (on && i < 2) n.style.opacity = .3; }); });
  },
  question(p, c) {
    header(p, 'The practical\nquestion');
    artwork(p, 'made/p107_question', 20, 146, 320, 226, p.a);
    const a = card(p.root, 'Which services and information could be harmed?', 24, 386, 312, 106, 'v-navy'); reveal(p, a, c.a);
    const b = card(p.root, 'How do we protect them?', 24, 512, 312, 56, 'v-teal'); reveal(p, b, c.b); transfer(p, 'M180 492V512', c.b, .4);
  },
});
