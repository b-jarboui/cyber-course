// A trusted account can be misused. Rania receives the payment request and it is verified.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.2', serve: [[0, S(1)]],
  shots: ['hall', [S(4) - .1, 'staff']],
  rania: { walk: S(4) - .4 }, lena: { walk: S(6) - 2.6, nod: S(6) + .8 },
  plates: [
    [S(0) + .5, E(0) + .1, `Misused identity<br>${coral('No visible damage')}`],
    [S(4) + .1, E(4) + .1, `Rania · Finance<br>${coral('Change payment details?')}`],
    [S(5) + .1, E(5) + .1, `The account<br>${teal('Looks familiar')}`],
    [S(6) + .1, E(6) + .1, `Lina<br>${teal('Verify and approve')}`],
  ],
  pages: [
    { a: S(1) - .5, z: S(4) - .4, list: [
      { z: S(3) - .1, scene: 'stolen', cues: { a: S(1) + 1, pass: S(2) } },
      { a: S(3) - .1, scene: 'hero', cues: { title: 'It looks like\nsomeone trusted', art: 'made/p109_trusted_i', items: [['Colleague', S(3) + 3, 'v-amber'], ['Supplier', S(3) + 4, 'v-amber']] } },
    ] },
    { a: S(7) - .4, z: D.T + 1, list: [
      { z: S(8) - .2, scene: 'smallchange', cues: { a: S(7) + 2.8, b: S(7) + 4.6, c: S(7) + 6.4 } },
      { a: S(8) - .2, z: S(9) - .2, scene: 'account', cues: { a: S(8) + 2.4, b: S(8) + 4.6, c: S(8) + 5.8 } },
      { a: S(9) - .2, scene: 'hero', cues: { title: 'Unusual request?\nVerify both', art: 'made/p109_verify_e', lines: [['Who is asking?', S(9) + 3, 'v-navy'], ['Is the action permitted?', S(9) + 4.6, 'v-teal']] } },
    ] },
  ],
}));
