import { restoreTeachingTable } from './v1-set.js';
// Sample v2. 3D tells the story of Shaima, the applicant and Omar; 2D explains each idea with one graphic.
import { THREE, C, V, mesh, rbox, box, group, folder, ramp, pulse, lerp } from './kit.js';
import { createPerson, loadMotion } from './people.js';
import { atCounter, workplace, typing } from './sets.js';
import { frameShots, quietScreens } from './astra.js';
import { createBoard } from './board.js';
import { riskPages } from './pages2d-b.js';
import { readyPages, seekPages } from './library-pages.js';

export const texts = [];
export const cast = ['maya', 'citizen', 'omar'];

export default async function ({ stage, scene, b, createCounter, S, E, D, ui }) {
  await loadMotion(['m_idle_neutral_01', 'f_idle_neutral_01', 'm_sit_table_idle_neutral_01', 'm_turn_left_180_to_walk', 'm_walk_stop', 'm_turn_left_180', 'm_sit_down_chair_01', 'm_sit_chair_idle_waiting_01', 'm_sit_table_gestic_thoughtful']);
  document.getElementById('kicker').textContent = 'Lesson 1.1 · Version 4';
  document.getElementById('cap').style.fontSize = '21px';
  createCounter(scene);
  await restoreTeachingTable(scene);
  const maya = createPerson('maya', scene), applicant = createPerson('citizen', scene), omar = createPerson('omar', scene);
  for (const p of [maya,applicant,omar]) p.continuousMotion = true;
  const file = folder(scene, -2.42, 1.0553, -.12, 1.05); file.rotation.y = -Math.PI / 2; file.userData.open(1.2566); file.userData.cover.position.y = .008;
  file.name='Case folder';
  const OX = 3.2, OZ = -2.5, OROT = -1.45, w2 = workplace(scene, OX, OZ, OROT);
  const report = group(scene); mesh(rbox(.26, .17, .012, .006), C.paper, 0, 0, 0, report); mesh(box(.26, .05, .014), C.teal, 0, .06, 0, report);
  const SX = OX + w2.f.x * .95, SZ = OZ + w2.f.z * .95, screen = group(scene, SX, .78, SZ); screen.rotation.y = OROT + Math.PI;
  mesh(rbox(.6, .36, .03, .012), C.dark, 0, .3, 0, screen);
  mesh(rbox(.05, .13, .05, .01), C.metalD, 0, .06, 0, screen); mesh(rbox(.22, .012, .14, .005), C.metalD, 0, .006, 0, screen);
  const shown = new THREE.CanvasTexture(Object.assign(document.createElement('canvas'), { width: 512, height: 300 }));
  // The 3D screen carries no text. Technical facts belong to the 2D presentation.
  { const c=shown.image.getContext('2d'); c.fillStyle='#e4edf7'; c.fillRect(0,0,512,300); shown.colorSpace=THREE.SRGBColorSpace; shown.needsUpdate=true; }
  const lit = new THREE.Mesh(new THREE.PlaneGeometry(.56, .32), new THREE.MeshBasicMaterial({ map: shown, toneMapped: false })); lit.position.set(0, .3, .017); screen.add(lit);
  const notebook = mesh(rbox(.17, .018, .23, .006), C.navyL, 0, .79, 0, scene);
  // One waiting chair, close enough to stay in the same shot as the counter.
  const seat = b.group.children.find(o => o.isGroup && Math.abs(o.position.x - 3.2) < .01 && Math.abs(o.position.z - 2.2) < .01);
  const SEAT = V(-.07, 0, -1.43), SEATR = -Math.PI / 4;
  if (seat) { seat.position.set(SEAT.x, 0, SEAT.z); seat.rotation.y = SEATR; }
  b.group.children.forEach(o => { if (o.isGroup && Math.abs(o.position.x - 3.2) < .01 && Math.abs(o.position.z - 3.2) < .01) o.visible = false; });

  const B = createBoard(D.T), { tl } = B;
  riskPages({B,S,E,D}); B.end(); await readyPages(B);

  // ---------- the 3D story ----------
  const keys = V(-2.46, 1.121, -.45), screenAt = V(-2.1, 1.47, -.66), hand = V(0, 0, 0);
  // One recorded movement: he turns from the counter, walks, stops, turns round and sits.
  // The chair is placed from where the recording ends, so the seat is exactly under him.
  // Turn away from the counter into the clear public aisle. The old diagonal
  // route put his turning arm through the privacy pane and its stanchion.
  const route = applicant.plan(['m_turn_left_180_to_walk', 'm_walk_stop', 'm_turn_left_180', 'm_sit_down_chair_01', 'm_sit_chair_idle_waiting_01'], -1.3, -.3, -Math.PI / 2, S(13) + .4, .3, 'm_idle_neutral_01');
  // Omar stops at "does not mean the problem is fixed" and thinks, hand to chin, then returns to the keys.
  const think = omar.plan(['m_sit_table_gestic_thoughtful', 'm_sit_table_idle_neutral_01'], OX - w2.f.x * .1, OZ - w2.f.z * .1, OROT, S(19) + .3, .5, 'm_sit_table_idle_neutral_01');
  const facing = route.yaw;
  if (seat) { seat.position.set(route.end.x - Math.sin(facing) * .05, 0, route.end.z - Math.cos(facing) * .05); seat.rotation.y = facing; }
  const counter = { x: -1.95, y: 1.15, z: -.3, w: 3.1, e: .42 }, her = { x: -2.55, y: 1.36, z: -.45, w: 2.2, e: .42, f: .4 };
  const wide = { x: -2.05, y: 1.1, z: -.64, w: 3.4, e: .45, f: .44 }, follow = { x: -1.05, y: .95, z: -1.62, w: 3.5, e: .45, f: .44 }, desk = { x: OX - .4, y: 1.1, z: OZ + .05, w: 2.5, e: .42, f: .44 };

  return t => {
    tl.time(t, false);
    seekPages(B,t);
    stage.conceptPage=(t>=S(2)-.1 && t<S(13)-.5) || (t>=E(14)+.7 && t<S(18)-.5) || t>=E(19)+.7;
    quietScreens(ui, t);
    if (seat) seat.visible = true;
    stage.focus = null;

    // Shaima stops typing once, when she notices the setting. Later she sends the report once.
    atCounter(maya, applicant, t, 1);
    maya.play('f_idle_neutral_01', t, true); maya.sway = 0;
    const stop = S(1) + .1, press = S(13) + 2.2;
    const still = t > stop && t < S(13) || t > press + .5;
    if (still || t > S(13)) {
      const down = pulse(t, press - .3, press - .12, press + .05, press + .3);
      const hold={grip:.15,profile:'typing',time:still?stop:t,quaternion:new THREE.Quaternion().setFromAxisAngle(V(1,0,0),Math.PI),keyHeight:1.077};
      maya.reach('R', hand.copy(keys).add(V(0, -.003 * down, .095)), 1,null,hold);
      maya.reach('L', hand.copy(keys).add(V(0, 0, -.095)), 1,null,hold);
    }
    maya.bend = .05 + .08 * pulse(t, stop, stop + .6, S(13) - 2, S(13) - 1);
    maya.look(screenAt, 1); maya.smile = t > stop ? .05 : .25;

    // The applicant waits at the counter, then goes to sit while the case continues.
    applicant.sway = 0;
    if (t < route.t0) applicant.at(-1.3, -.3, -Math.PI/2).play('m_idle_neutral_01', t, true);
    else { applicant.reset(); applicant.idle(t); applicant.sway = 0; applicant.follow(route, t, true); }

    // The report leaves Shaima's screen once, and arrives on Omar's desk once.
    const sent = ramp(t, press + .15, press + 1.5), arrive = ramp(t, S(18) - .1, S(18) + .9);
    report.visible = t > press + .1 && (t < press + 1.6 || t > S(18) - .1 && arrive < 1);
    report.rotation.set(0, lerp(Math.PI / 4, OROT + Math.PI, arrive), 0); report.scale.setScalar(1 - .7 * arrive);
    lit.visible = arrive >= 1;
    if (t < S(18) - .1) report.position.set(lerp(-2.32, -.2, sent), lerp(1.55, 2.3, sent), lerp(-1.1, -2.2, sent));
    else report.position.set(lerp(SX + .5, SX, arrive), lerp(1.75, 1.08, arrive), lerp(SZ + .5, SZ, arrive));

    // Omar sets his notebook aside and starts reading: one change of task.
    omar.reset(); omar.at(OX - w2.f.x * .1, OZ - w2.f.z * .1, OROT); omar.idle(t, 2); omar.sway = 0;
    if (t < think.t0) omar.play('m_sit_table_idle_neutral_01', t, true); else omar.follow(think, t, true);
    const free = ramp(t, think.t0, think.t0 + .8) * (1 - ramp(t, S(21) - .8, S(21)));
    const turn = S(18) + .9, read = ramp(t, turn, turn + .9);
    const stopped = ramp(t, turn - .4, turn);
    typing(omar, w2, t, 1 - stopped);
    const slide = ramp(t, turn, turn + .7), touch = pulse(t, turn - .5, turn + .05, turn + .7, turn + 1.3);
    notebook.position.set(w2.keyL.x + w2.f.z * (.28 + .1 * slide), .79, w2.keyL.z - w2.f.x * (.28 + .1 * slide));
    if (stopped > 0 && free < 1) {
      omar.reach('R', w2.keyR, 1 - free);
      omar.reach('L', hand.copy(w2.keyL).lerp(notebook.position.clone().setY(.86), touch), 1 - free);
    }
    omar.gaze = .1; omar.smile = .08;
    if (report.visible && t>=S(18)-.1) omar.look(report.position, .7*Math.sin(Math.PI*arrive));
    omar.look(V(SX, 1.08, SZ), read);

    for(const p of [maya,applicant,omar]) p.g.visible=!stage.conceptPage;
    frameShots(stage, t, [
      counter,
      { t0: S(1) - .4, t1: S(1) + 1.2, ...her },
      { t0: S(13) - .52, t1: S(13) - .5, ...wide },
      { t0: S(13) + .9, t1: S(13) + 3, ...follow },
      { t0: S(18) - .52, t1: S(18) - .5, ...desk },
      { t0: S(18), t1: E(19), ...desk, w: 2 },
    ]);
  };
}
