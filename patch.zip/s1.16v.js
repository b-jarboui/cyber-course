// The first decision. Shaima gets an urgent AI request; the chapter closes in the hall.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.3', serve: [[S(12), D.T]],
  shots: ['counter', { t0: S(1) - .3, t1: S(1) + .6, shot: 'staff' }, [S(9) - .1, 'her'], [S(12) - .1, 'hall'], { t0: S(14), t1: S(15), shot: 'wide' }],
  plates: [
    [S(0) + .4, E(0) + .1, `Urgent request<br>${coral('A new AI service')}`],
    [S(1) + .1, E(1) + .1, `The message says<br>${coral('The director approved')}`],
    [S(2) + .1, E(2) + .1, `It looks<br>${coral('Professional and real')}`],
    [S(9) + .1, E(9) + .1, `Shaima<br>${teal('Verifies first')}`],
    [S(12) + .1, E(12) + .1, `Confidentiality, integrity<br>${teal('Availability')}`],
    [S(13) + .1, E(13) + .1, `AI changes<br>${coral('Speed and appearance')}`],
    [S(14) + .1, E(14) + .1, `Responsibilities, layers<br>${teal('Verification, reporting')}`],
    [S(15) + .1, D.T, `Next chapter<br>${teal('A convincing request')}`],
  ],
  pages: [
    { a: S(3) - .5, z: S(9) - .4, list: [
      { z: S(7) - .3, scene: 'hero', cues: { title: 'What matters\nhere?', art: 'made/p116_matters_e', lines: [['Sensitive information', S(4), 'v-amber'], ['Tool approval not established', S(5), 'v-amber'], ['Authority not verified', S(6), 'v-coral']] } },
      { a: S(7) - .3, scene: 'options', cues: { a: S(8) + .2, b: S(8) + 1.6, c: S(8) + 3, answer: S(9) - 1.6 } },
    ] },
    { a: S(10) - .4, z: S(12) - .4, list: [{ scene: 'hero', cues: { title: 'Verify through\napproved channels', art: 'made/p116_verify_e', lines: [['Check independently', S(10) + 2, 'v-teal'], ['Tool and use permitted', S(10) + 4.6, 'v-teal'], ['Report the request', S(10) + 7.4, 'v-teal']], note: ['Records stay where they are', S(11)] } }] },
  ],
}));
