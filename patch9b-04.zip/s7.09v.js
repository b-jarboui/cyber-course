// The sign-in nobody approved.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['omar', 'maya', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '7.2',
  actors: { omar: 'desk', maya: 'counter', official: 'door' },
  walks: { maya: [[S(1), E(1), 'beside'], [S(8), E(8), 'counter']] },
  enter: { official: S(14) },
  landline: true,
  handsets: { maya: [[S(9), S(14), 'megaphone']] },
  shots: [[0, 'display'], [S(1), 'pair'], [S(2), 'desk'], [S(7), 'display'], [S(9), 'counter'], [S(10), 'her'], [S(14), 'door'], [S(15), 'counter']],
  actions: {
    omar: [[0, S(1), 'read'], [S(1), S(7), 'talk', 'maya'], [S(7), S(9), 'type'], [S(9), D.T, 'read']],
    maya: [[0, S(1), 'read'], [S(2), S(8), 'listen', 'omar'], [S(9), S(14), 'call'], [S(14), S(15), 'extension'], [S(15), D.T, 'type']],
    official: [[S(14), S(15), 'call']],
  },
  displays: {
    desk: [
      [0, S(7), 'lock', 'Unknown device sign-in', 'alert', 'login'],
      [S(7), S(8), 'bell', 'Alert reported to IT', 'safe'],
      [S(8), D.T, 'shield', 'Sessions ended · Reset', 'safe'],
    ],
    counter: [
      [S(9), S(14), 'megaphone', 'Voice note · Urgent list', 'alert'],
      [S(14), D.T, 'bell', 'Verified · Fake voice reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Unknown device sign-in'],
    [S(7), E(7), 'Reported · IT ends sessions'],
    [S(9), E(9), 'Voice note sounding like Hamad'],
    [S(14), E(14), 'Directory call · Never sent'],
  ],
  pages: [
    hero(S(2), S(4), 'Stolen session', 'made/padlock_open+made/own_key', [
      ['A session token keeps an account signed in', S(2), 'v-amber'],
      ['Infostealers collect logins and session tokens', S(3), 'v-coral'],
    ]),
    hero(S(4), S(8), 'Account compromise', 'made/ransom_laptop+made/own_warning_beacon', [
      ['Stolen logins feed ransomware attacks', S(5), 'v-coral'],
      ['Clean device, change passwords, turn on MFA', S(6), 'v-teal'],
    ]),
    hero(S(11), S(14), 'Verify the voice', 'made/own_mobile+made/own_desk_phone', [
      ['AI voices impersonate officials with urgency', S(11), 'v-coral'],
      ['Verify through a known official number', S(12), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Report early', 'made/own_bell+made/own_shield', [
      ['Do not delete evidence; let IT check logs', S(14), 'v-navy'],
      ['Approved cloud, named sharing, verify requests', S(15), 'v-teal'],
    ]),
  ],
}));
