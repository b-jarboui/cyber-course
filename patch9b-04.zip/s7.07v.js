// The helpful stranger in the chat.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.2',
  actors: { maya: 'counter', omar: 'aisle' },
  walks: { omar: [[S(3), E(3), 'colleague']] },
  file: [[0, E(0), 0, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(3), 'hall'], [S(4), 'staff'], [S(9), 'her'], [S(12), 'counter'], [S(13), 'counterDisplay'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(3), 'read'], [S(3), S(4), 'talk', 'omar'], [S(4), S(12), 'listen', 'omar'], [S(12), S(13), 'extension'], [S(13), D.T, 'type']],
    omar: [[0, S(3), 'listen', 'maya'], [S(4), S(12), 'talk', 'maya'], [S(12), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'folder', 'Case 2048', 'neutral'],
      [S(1), S(13), 'chat', 'External · IT Service Desk', 'alert'],
      [S(13), D.T, 'bell', 'Account blocked · Reported', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'External label · IT Service Desk'],
    [S(2), E(2), 'Asks for remote support now'],
    [S(12), E(12), 'IT directory call · Not them'],
    [S(13), E(13), 'Reported · Account blocked'],
  ],
  pages: [
    hero(S(4), S(9), 'Collaboration platform', 'made/own_chat+made/headset', [
      ['External chats impersonate IT helpdesk', S(5), 'v-coral'],
      ['Short calls can lead to fast encryption', S(8), 'v-amber'],
    ]),
    hero(S(9), S(10), 'A name proves nothing', 'made/id_badge+made/own_warning_beacon', [
      ['Anyone can copy a display name or photo', S(9), 'v-coral'],
    ]),
    hero(S(10), S(12), 'Never grant remote access unasked', 'made/control_desk+made/own_lock', [
      ['IT starts sessions only after your ticket', S(10), 'v-teal'],
      ['Decline prompts; check group chat members', S(11), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Verify through a known contact', 'made/own_desk_phone+made/own_bell', [
      ['Check group members before posting cases', S(14), 'v-teal'],
      ['Gave access? Disconnect and report at once', S(15), 'v-coral'],
    ]),
  ],
}));
