// The update you keep postponing.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.1',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, E(1), 1, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(3), 'counterDisplay'], [S(4), 'staff'], [S(9), 'counterDisplay'], [S(11), 'counter'], [S(12), 'counterDisplay'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(1), 'extension'], [S(1), S(4), 'read'], [S(4), S(9), 'listen', 'omar'], [S(9), S(11), 'type'], [S(11), S(15), 'listen', 'omar'], [S(15), D.T, 'type']],
    omar: [[0, S(4), 'listen', 'maya'], [S(4), S(9), 'talk', 'maya'], [S(9), S(11), 'listen', 'maya'], [S(11), S(12), 'point'], [S(12), S(15), 'talk', 'maya'], [S(15), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'tick', 'Approved portal · File open', 'safe'],
      [S(2), S(9), 'clock', 'Updates waiting · 2 weeks', 'alert'],
      [S(9), S(12), 'setting', 'System update installed', 'safe'],
      [S(12), S(15), 'puzzle', 'Unapproved browser add-on', 'alert'],
      [S(15), D.T, 'shield', 'Approved list · Updated', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Authority software portal'],
    [S(2), E(2), 'Updates waiting · 2 weeks'],
    [S(9), E(9), 'Update installed from system'],
    [S(12), E(12), 'Unapproved browser add-on'],
  ],
  pages: [
    hero(S(4), S(9), 'Vulnerability', 'made/padlock_open+made/own_tools', [
      ['A software flaw that an update closes', S(4), 'v-coral'],
      ['Known flaws lead breaches; AI speeds attacks', S(5), 'v-amber'],
    ]),
    hero(S(9), S(10), 'Update when offered', 'made/own_setting+made/own_clock', [
      ['Save work, install updates and restart', S(9), 'v-teal'],
    ]),
    hero(S(10), S(12), 'Official source only', 'made/own_shield+made/laptop', [
      ['Authority system only, never pop-ups or links', S(10), 'v-teal'],
      ['Keep browser updated; check links first', S(11), 'v-navy'],
    ]),
    hero(S(13), D.T, 'Approved extensions only', 'made/own_puzzle+made/own_bell', [
      ['Add-ons can read pages, cookies and logins', S(13), 'v-amber'],
      ['Keep approved list only; report odd prompts', S(15), 'v-teal'],
    ]),
  ],
}));
