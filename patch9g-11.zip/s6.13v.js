// When agents trust each other.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '6.4',
  actors: { maya: 'counter', omar: 'colleague', official: 'director' },
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(3), 'staff'], [S(5), 'her'], [S(14), 'gathering'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(3), 'type'], [S(3), S(14), 'read'], [S(14), D.T, 'listen', 'official']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(14), 'paper'], [S(14), D.T, 'listen', 'official']],
    official: [[0, S(14), 'listen', 'omar'], [S(14), D.T, 'talk', 'omar']],
  },
  displays: {
    counter: [
      [0, S(1), 'computer', 'Two-agent pilot · Reminder draft', 'neutral'],
      [S(1), S(2), 'mail', 'Extra paragraph · Send ID copy', 'alert'],
      [S(2), S(14), 'bell', 'Draft blocked and reported', 'safe'],
      [S(14), D.T, 'file', 'Every agent handover logged', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Two agents · Check and draft'],
    [S(1), E(1), 'Paragraph nobody wrote'],
    [S(3), E(3), 'Tool reply passed to Agent 2'],
    [S(14), E(14), 'Every handover recorded in log'],
  ],
  screens: [
    [S(1), S(3), q => win('Reminder draft · Case 2048', reveal([
      row('Standard text', 'One document is still missing'),
      row('Extra paragraph', 'Send ID copy to new address', 'no'),
      row('New address', 'id-check@outside-mail.example', 'no'),
      row('Shaima', 'Not approved · Reported', 'ok'),
    ], q), 'alert')],
    [S(3), S(5), q => win('Two-agent handover log', reveal([
      row('Tool reply', 'Order hidden in tool output', 'no'),
      row('Agent 1 → Agent 2', 'Passed note along unchecked', 'warn'),
      row('Agent 2', 'Treated note as trusted order', 'no'),
    ], q), 'alert')],
  ],
  pages: [
    hero(S(5), S(8), "A tool's reply is information, not an order", 'made/own_link+made/own_file', [
      ['Hidden orders can sit in tool descriptions', S(6), 'v-coral'],
      ['Injection in an agent can trigger actions', S(7), 'v-amber'],
    ]),
    hero(S(8), S(12), 'One poisoned note can travel down the chain', 'made/own_chat+made/parcel+made/own_mail', [
      ['Agents are often built to trust other agents', S(10), 'v-coral'],
      ['One flaw can cascade across the chain', S(11), 'v-amber'],
    ]),
    hero(S(12), S(15), 'A message from another agent is information to check', 'made/key_cabinet+made/register_book', [
      ['Each agent gets only its own job access', S(12), 'v-teal'],
      ['Log every handover; humans approve critical steps', S(13), 'v-navy'],
    ]),
    hero(S(15), D.T, 'Do not approve unexpected orders', 'made/rubber_stamp+made/own_bell', [
      ['Odd line in draft, tool or agent note?', S(15), 'v-coral'],
      ['Stop, verify through official channel, report', (S(15) + E(15)) / 2, 'v-teal'],
    ]),
  ],
}));
