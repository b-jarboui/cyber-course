// On the list, or not.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar', 'priya', 'lena'];
export default chapterHall((S, E, D) => ({
  lesson: '5.3',
  actors: { official: 'director', maya: 'counter', omar: 'colleague', priya: 'team', lena: 'teamEnd' },
  shots: [[0, 'gathering'], [S(1), 'counterDisplay'], [S(2), 'staff'], [S(3), 'gathering'], [S(12), 'counterDisplay'], [S(13), 'her'], [S(14), 'gathering']],
  actions: {
    official: [[0, S(2), 'talk', 'maya'], [S(2), S(3), 'listen', 'omar'], [S(3), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'maya']],
    maya: [[0, S(13), 'listen', 'official'], [S(13), D.T, 'read']],
    omar: [[0, S(2), 'listen', 'official'], [S(2), S(3), 'talk', 'official'], [S(3), D.T, 'listen', 'official']],
    priya: [[0, D.T, 'listen', 'official']],
    lena: [[0, D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(12), 'tick', 'Approved AI assistant', 'safe'],
      [S(12), D.T, 'file-text', 'Approved AI list', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Before the doors open'],
    [S(1), E(1), 'Approved AI assistant'],
    [S(12), E(12), 'Stated purpose and levels'],
    [S(13), E(13), 'Approved AI list'],
  ],
  screens: [
    [S(1), S(3), win('Approved AI list', row('Tool', 'Sadeed AI Assistant', 'ok') + row('Purpose', 'Administrative work', 'ok') + row('Status', 'Approved by the Authority', 'ok') + note('First approved AI tool on the list.'), 'good')],
  ],
  pages: [
    hero(S(3), S(7), 'Approved AI tool', 'computer+shield+tick', [
      ['Reviewed, listed and given an owner', S(3), 'v-teal'],
      ['Recorded use under clear rules', S(5), 'v-navy'],
    ]),
    hero(S(7), S(12), 'Work account only', 'made/id_badge+made/register_book', [
      ['Keep an inventory of AI tools', S(7), 'v-teal'],
      ['Govern and monitor AI models', S(11), 'v-navy'],
    ]),
    hero(S(12), S(14), 'Check the level first', 'made/case_folder+zoom', [
      ['Approved for a stated purpose only', S(12), 'v-amber'],
      ['Read allowed levels before use', S(13), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Not on the list? Ask', 'made/signpost+bell', [
      ['Use approved list and work account', S(14), 'v-teal'],
      ['Unapproved tool in use? Report it', S(15), 'v-amber'],
    ]),
  ],
}));
