// A voice message that wants a reply elsewhere
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { phone, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["omar"];
export default chapterHall((S, E, D) => ({
  lesson: "3.1",
  actors: { omar: 'desk' },
  shots: [[0,'desk'], [S(2),'display'], [S(3),'desk'], [S(10),'pair'], [S(12),'desk']],
  actions: { omar: [[0,S(3),'text'], [S(3),S(11),'call'], [S(11),E(11),'dial'], [S(12),E(12),'call'], [S(13),D.T,'type']] },
  displays: { desk: [[0,S(11),'folder','Case 2048','neutral'], [S(11),S(13),'mobile','Official directory','safe'], [S(13),D.T,'bell','Report sent','safe']] },
  setupProps: evidence({
    surfaces: { 'phone:omar': [[0,S(2),'wave','Voice message'], [S(2),S(3),'message','Private messaging app'], [S(3),S(11),'call','Incoming call']] },
    inserts: [[(S(0)+E(0))/2,E(0),'phone:omar']],
  }),
  plates: [[S(2),E(2),'Case 2048'], [S(4),E(4),'Passport copy requested'], [S(10),E(10),'No reply from Omar']],
  screens: [
    [S(1), S(3), q => phone('Voice message', reveal([
      row('From', '+971 50 XXX 0418', 'warn'),
      row('Audio', '0:21 · Partner official', 'warn'),
      row('Topic', 'Case 2048 · Private app', 'no'),
      note('Asks to move to a private messaging app.', 'no'),
    ], q))],
    [S(3), S(5), q => phone('Incoming call', reveal([
      row('Caller', '+971 50 XXX 0418', 'warn'),
      row('Asks for', 'Applicant passport copy', 'no'),
      row('Condition', 'Today, and quietly', 'no'),
      note('Urgency plus secrecy on a live call.', 'no'),
    ], q))],
    [S(10), S(11), phone('No reply from Omar', row('Private app', 'No reply sent', 'ok') + row('Passport copy', 'Not sent', 'ok') + note('Verify via the official directory.'))],
  ],
  pages: [
    hero(S(5), S(6), "Voice messages and live calls can be faked", "mobile+made/headset", [
      ["Voice message", S(5), "v-amber"],
    ]),
    hero(S(6), S(10), "Never move to a private app on request", "mobile+chat", [
      ["Private messaging app", S(6), "v-amber"],
      ["Passport copy requested", S(7), "v-amber"],
    ]),
    hero(S(11), S(13), "Call back on a number you already know", "made/register_book+mobile", [
      ["Official directory", S(11), "v-teal"],
      ["No call from the office", S(12), "v-teal"],
    ]),
  ],
}));
