// The cast: ready-made rigged people (Microsoft Rocketbox, MIT licence) driven by simple scene commands.
// Rotations are written in the character's own axes: x to the character's left, y up, z forward.
import { THREE, V, lerp, clamp01, smooth, ramp } from './kit.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { LIBRARY, CONTEXTS } from './library.js';

const askedContext = window.__live?.context ?? new URLSearchParams(location.search).get('context');
export const context = CONTEXTS[askedContext] ? askedContext : 'arab';
const FACE = ['AK_09_EyeBlinkLeft', 'AK_10_EyeBlinkRight', 'AK_11_EyeLookDownLeft', 'AK_12_EyeLookDownRight', 'AK_44_MouthSmileLeft', 'AK_45_MouthSmileRight', 'AK_25_JawOpen'];
const templates = {}, live = [];
window.__people = live;
const texLoader = new THREE.TextureLoader();

async function tex(url, srgb) {
  const t = await texLoader.loadAsync(url);
  t.flipY = true; t.anisotropy = 8;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
async function load(role) {
  const item = LIBRARY[CONTEXTS[context].cast[role]], dir = `people/${item.model}/`;
  const gltf = await new GLTFLoader().loadAsync(dir + 'model.glb');
  const names = []; gltf.scene.traverse(c => { if (c.isSkinnedMesh) names.push(c.material.name); });
  const has = re => names.some(n => re.test(n));
  const [body, head, bodyN, headN, hair, glasses, scarf] = await Promise.all([
    tex(dir + (item.local ? 'body_local.jpg' : 'body_color.jpg'), true), tex(dir + (item.local ? 'head_local.jpg' : 'head_color.jpg'), true), tex(dir + 'body_normal.jpg'), tex(dir + 'head_normal.jpg'),
    // WebP copies of the hair/glasses textures: about a quarter of the PNG weight (2026-11-22 load-weight fix)
    has(/opacity/) ? tex(dir + (item.darkHair ? 'opacity_local.webp' : 'opacity_color.webp'), true) : null, has(/glasses/) ? tex(dir + 'glasses_opacity_color.webp', true) : null, has(/keffiyeh/) ? tex(dir + 'keffiyeh_color.jpg', true) : null,
  ]);
  const o = gltf.scene;
  o.userData.faces = [];
  o.traverse(c => {
    if (!c.isSkinnedMesh) return;
    c.castShadow = true; c.receiveShadow = true; c.frustumCulled = false;
    const m = c.material;
    if (/body/.test(m.name)) c.material = new THREE.MeshStandardMaterial({ map: body, normalMap: bodyN, roughness: 0.74, name: m.name, color: new THREE.Color(item.bright || 1, item.bright || 1, item.bright || 1) });
    else if (/head/.test(m.name)) c.material = new THREE.MeshStandardMaterial({ map: head, normalMap: headN, roughness: 0.58, name: m.name });
    else if (/keffiyeh/.test(m.name)) c.material = new THREE.MeshStandardMaterial({ map: scarf, roughness: 0.8, side: THREE.DoubleSide, name: m.name });
    else if (/glasses/.test(m.name)) c.material = new THREE.MeshStandardMaterial({ map: glasses, transparent: true, roughness: 0.3, name: m.name });
    else if (/opacity/.test(m.name)) c.material = new THREE.MeshStandardMaterial({ map: hair, transparent: true, alphaTest: 0.28, side: THREE.DoubleSide, roughness: 0.66, name: m.name });
    if (c.morphTargetInfluences) { c.morphTargetInfluences.fill(0); o.userData.faces.push(c); }
  });
  o.userData.item = item;
  templates[role] = o;
}
export const loadCast = names => Promise.all(names.filter(n => !templates[n]).map(load));
export const flushPeople = () => live.forEach(p => p.flush());

const Q = () => new THREE.Quaternion();
// Walking clips join where the legs match, so a blend never mixes a left step with a right step.
const STRIDE = ['Bip01_L_Thigh', 'Bip01_R_Thigh', 'Bip01_L_Calf', 'Bip01_R_Calf'];
function strideJoin(a, b, turnExit = false) {
  const fa = a.fps, fb = b.fps, qa = Q(), qb = Q();
  let best = [a.n - 1, 0], low = Infinity;
  const bones = turnExit ? [...STRIDE,'Bip01_L_Foot','Bip01_R_Foot'] : STRIDE;
  for (let e = a.n - 1; e >= Math.max(3, a.n - 1 - Math.round(fa * (turnExit ? .65 : .45))); e--) for (let s = 0; s <= Math.min(Math.round(fb * (turnExit ? .8 : .45)), b.n - 4); s++) {
    let c = (turnExit ? .001 : .02) * (a.n - 1 - e + s);
    for (const n of bones) {
      c += boneAt(a, n, e, qa).angleTo(boneAt(b, n, s, qb)) ** 2;
      // Same direction of swing: compare one step further on.
      const e2 = Math.min(a.n - 1, e + 2);
      if (e2 > e) c += .5 * boneAt(a, n, e2, qa).angleTo(boneAt(b, n, s + e2 - e, qb)) ** 2;
      else c += .5 * boneAt(a, n, e - 2, qa).angleTo(boneAt(b, n, Math.max(0, s - 2), qb)) ** 2;
    }
    if (c < low) { low = c; best = [e, s]; }
  }
  return best;
}
const qx = a => Q().setFromAxisAngle(V(1, 0, 0), a), qy = a => Q().setFromAxisAngle(V(0, 1, 0), a), qz = a => Q().setFromAxisAngle(V(0, 0, 1), a);
const JOINTS = ['Bip01', 'Bip01_Pelvis', 'Bip01_Spine', 'Bip01_Spine1', 'Bip01_Spine2', 'Bip01_Neck', 'Bip01_Head',
  'Bip01_L_Clavicle', 'Bip01_L_UpperArm', 'Bip01_L_Forearm', 'Bip01_R_Clavicle', 'Bip01_R_UpperArm', 'Bip01_R_Forearm',
  'Bip01_L_Thigh', 'Bip01_L_Calf', 'Bip01_L_Foot', 'Bip01_R_Thigh', 'Bip01_R_Calf', 'Bip01_R_Foot'];
const FINGERS = [0, 1, 2, 3, 4].flatMap(n => ['', '1', '2'].map(k => `Finger${n}${k}`));
const RELAX = { L: [V(0.13, -0.99, -0.01), V(0.05, -0.97, 0.2)], R: [V(-0.13, -0.99, -0.01), V(-0.05, -0.97, 0.2)] };
const HAND = 7.5;   // cm from wrist to palm

export function createPerson(name, parent) {
  const root = templates[name], g = new THREE.Group();
  g.scale.setScalar(0.01); g.add(root); parent.add(g);
  const o = Object.assign(Object.create(Proto), { name, g, root, faces: root.userData.faces, b: {}, R: {}, d: {}, T: {}, arm: {}, head: { rotation: { x: 0, y: 0 } } });
  g.updateMatrixWorld(true);
  root.traverse(c => { if (JOINTS.includes(c.name)) o.b[c.name] = c; });
  const inv = root.matrixWorld.clone().invert(), m = new THREE.Matrix4(), s = V(0, 0, 0), p = V(0, 0, 0), q = Q();
  o.P = {};
  for (const k of JOINTS) {
    m.multiplyMatrices(inv, o.b[k].matrixWorld).decompose(p, q, s);
    o.R[k] = q.clone(); o.P[k] = p.clone(); o.d[k] = Q(); o.T[k] = Q();
  }
  o.hipY = o.b.Bip01.position.y; o.q0 = o.b.Bip01.quaternion.clone(); o.p0 = o.b.Bip01.position.clone();
  o.b2 = {}; root.traverse(c => { if (/^Bip01_[LR]_(Hand|Toe0)$/.test(c.name)) o.b2[c.name] = c; });
  o.h0 = { Bip01_L_Hand: o.b2.Bip01_L_Hand.quaternion.clone(), Bip01_R_Hand: o.b2.Bip01_R_Hand.quaternion.clone() };
  o.eyes=['Bip01_LEye','Bip01_REye'].map(n=>root.getObjectByName(n)).filter(Boolean).map(b=>({b,q:b.quaternion.clone(),forward:V(0,0,1).applyQuaternion(b.getWorldQuaternion(Q()).invert())}));
  o.fingers = { L: [], R: [] };
  root.traverse(c => { for (const s2 of ['L', 'R']) if (FINGERS.some(f => c.name === `Bip01_${s2}_${f}`)) {
    const [,digit,joint] = c.name.match(/Finger(\d)(\d?)/);
    o.fingers[s2].push({ b:c, q:c.quaternion.clone(), digit:Number(digit), joint:joint?Number(joint):0 });
  } });
  for (const s2 of ['L', 'R']) {
    const a = o.P[`Bip01_${s2}_UpperArm`], e = o.P[`Bip01_${s2}_Forearm`];
    const w = root.getObjectByName(`Bip01_${s2}_Hand`);
    const hp = w.getWorldPosition(V(0, 0, 0)).applyMatrix4(inv);
    o.arm[s2] = { u0: e.clone().sub(a).normalize(), f0: hp.clone().sub(e).normalize(), L1: e.distanceTo(a), L2: hp.distanceTo(e) + HAND, wrist: w };
  }
  live.push(o);
  o.reset();
  return o;
}

const _a = V(0, 0, 0), _b = V(0, 0, 0), _c = V(0, 0, 0), _e = V(0, 0, 0), _f = V(0, 0, 0), _p = V(0, 0, 0);

// ---------- recorded motion: Microsoft Rocketbox motion capture, the same skeleton as the cast ----------
const clips = {}, KIMODO = new URLSearchParams(location.search).get('motion') === 'kimodo';
export const loadMotion = names => Promise.all(names.filter(n => !clips[n]).map(async n => {
  // ?motion=kimodo: movements generated with NVIDIA Kimodo, where one exists for this clip; otherwise the recorded one.
  const alt = KIMODO && await fetch(`assets/motion-kimodo/${n}.json`).then(r => r.ok ? r.json() : null, () => null);
  const m = alt || await (await fetch(`assets/motion/${n}.json`)).json();
  m.dur = (m.n - 1) / m.fps; m.stand = n[0] === 'f' ? 91.9 : 89.5;
  clips[n] = m;
}));
const POSE = [...JOINTS, 'Bip01_L_Hand', 'Bip01_R_Hand', 'Bip01_L_Toe0', 'Bip01_R_Toe0'];
const CHAIN = ['Bip01_Pelvis', 'Bip01_Spine', 'Bip01_Spine1', 'Bip01_Spine2', 'Bip01_Neck', 'Bip01_Head', 'Bip01_L_Clavicle', 'Bip01_R_Clavicle', 'Bip01_L_UpperArm', 'Bip01_R_UpperArm', 'Bip01_L_Forearm', 'Bip01_R_Forearm',
  'Bip01_L_Thigh', 'Bip01_R_Thigh', 'Bip01_L_Calf', 'Bip01_R_Calf', 'Bip01_L_Foot', 'Bip01_R_Foot'];
const _qa = Q(), _qb = Q(), _qc = Q(), _id = Q(), _x1 = V(1, 0, 0);
const frameOf = (m, time) => Math.min(m.n - 1, Math.max(0, time * m.fps));
function boneAt(m, k, x, out) {
  const a = m.q[k], i = Math.floor(x), j = Math.min(m.n - 1, i + 1);
  return out.fromArray(a, i * 4).normalize().slerp(_qb.fromArray(a, j * 4).normalize(), x - i);
}
function rootAt(m, x, out) {
  const i = Math.floor(x), j = Math.min(m.n - 1, i + 1), f = x - i, r = m.root;
  return out.set(lerp(r[i * 3], r[j * 3], f), lerp(r[i * 3 + 1], r[j * 3 + 1], f), lerp(r[i * 3 + 2], r[j * 3 + 2], f));
}
// Which way the body points, read from the root's turn about the vertical.
const heading = (m, x, ref) => { const q = boneAt(m, 'Bip01', x, Q()).multiply(Q().copy(ref).invert()); return 2 * Math.atan2(q.y, q.w); };
const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
const Proto = {
  reset() {
    for (const k of JOINTS) this.d[k].identity();
    this.layer = null; this.dy = 0; this.swing = { L: 0, R: 0 }; this.ik = { L: null, R: null }; this.over = { L: null, R: null }; this.looks=[];
    this.head.rotation.x = 0; this.head.rotation.y = 0; this.bend = 0; this.sway = 0;
    this.smile = 0.28; this.jaw = 0; this.gaze = 0; this.blink = 0; this.grip = { L: 0.32, R: 0.32 };
    this.gazeCheck=null; this._idleT = null; this._idleSeed = 0;
  },
  at(x, z, rotY = 0) { this.g.position.set(x, 0, z); this.g.rotation.y = rotY; return this; },
  leg(side, hip, knee) {
    this.d[`Bip01_${side}_Thigh`].copy(qx(hip)); this.d[`Bip01_${side}_Calf`].copy(qx(knee));
    this.d[`Bip01_${side}_Foot`].copy(qx(-(hip + knee) * 0.8));
  },
  walk(phase, amp = 0.46) {
    const s = Math.sin(phase);
    this.leg('L', s * amp, Math.max(0, -s) * amp * 1.3 + 0.06);
    this.leg('R', -s * amp, Math.max(0, s) * amp * 1.3 + 0.06);
    this.swing.L = -s * amp * 0.55; this.swing.R = s * amp * 0.55;
    this.dy = -0.012 * amp + Math.abs(Math.cos(phase)) * 0.016 * amp;
  },
  sit(k = 1) {
    this.dy = -0.36 * k;
    this.leg('L', -1.5 * k, 1.5 * k); this.leg('R', -1.5 * k, 1.5 * k);
  },
  idle(t, seed = 0) {
    this._idleT = t; this._idleSeed = seed;
    this.sway = Math.sin(t * 0.8 + seed) * 0.022;
    this.head.rotation.x += Math.sin(t * 0.7 + seed) * 0.016;
    const c = (t * 0.27 + seed * 0.31) % 1;      // a blink every few seconds
    this.blink = c < 0.035 ? Math.sin(c / 0.035 * Math.PI) : 0;
  },
  goPath(t, t0, t1, pts, r0, r1) {
    const dur = Math.max(0.05, t1 - t0), u = clamp01((t - t0) / dur);
    const segs = []; let L = 0;
    for (let i = 0; i < pts.length - 1; i++) {
      const dx = pts[i + 1][0] - pts[i][0], dz = pts[i + 1][1] - pts[i][1], d = Math.hypot(dx, dz);
      if (d > 1e-4) { segs.push({ ax: pts[i][0], az: pts[i][1], bx: pts[i + 1][0], bz: pts[i + 1][1], d, dir: Math.atan2(dx, dz), start: L }); L += d; }
    }
    const turn = (a, b, q) => a + wrap(b - a) * q;
    if (!segs.length || L < 1e-3) {
      const [px, pz] = pts[pts.length - 1];
      this.at(px, pz, turn(r0, r1, ramp(u, 0, 1)));
      return;
    }
    const e = u - 0.55 * Math.sin(2 * Math.PI * u) / (2 * Math.PI);
    const dedu = 1 - 0.55 * Math.cos(2 * Math.PI * u);
    const dist = e * L, v = (dedu * L) / dur;
    let idx = segs.length - 1;
    for (let i = 0; i < segs.length; i++) if (dist <= segs[i].start + segs[i].d || i === segs.length - 1) { idx = i; break; }
    const seg = segs[idx], f = clamp01((dist - seg.start) / seg.d);
    let h = seg.dir;
    // Smooth corner turning across chained waypoints (no snap or 180-degree flip).
    if (idx > 0) {
      const prev = segs[idx - 1], td = Math.min(0.45, seg.d * 0.45, prev.d * 0.45);
      if (dist - seg.start < td) h = turn(prev.dir, seg.dir, smooth(0.5 + 0.5 * (dist - seg.start) / td));
    }
    if (idx < segs.length - 1) {
      const next = segs[idx + 1], td = Math.min(0.45, seg.d * 0.45, next.d * 0.45);
      const rem = seg.start + seg.d - dist;
      if (rem < td) h = turn(seg.dir, next.dir, smooth(0.5 - 0.5 * rem / td));
    }
    const inSpan = Math.min(0.22, 0.45 / dur), outSpan = Math.min(0.22, 0.45 / dur);
    let rot = h;
    if (u < inSpan) rot = turn(r0, h, ramp(u, 0, inSpan));
    if (u > 1 - outSpan) rot = turn(rot, r1, ramp(u, 1 - outSpan, 1));
    this.at(lerp(seg.ax, seg.bx, f), lerp(seg.az, seg.bz, f), rot);
    if (u > 0 && u < 1) {
      // Stride amplitude and step length follow real ground speed (no foot sliding).
      const vRef = Math.min(1.4, Math.max(0.22, L / dur));
      const ampRef = 0.44 * Math.pow(Math.min(1.25, vRef / 1.25), 0.55);
      const stepLen = Math.max(0.20, 0.64 * (ampRef / 0.44));
      const endFade = Math.min(ramp(u, 0, 0.14), 1 - ramp(u, 0.86, 1));
      const amp = ampRef * Math.min(1.15, Math.pow(Math.max(0, v) / Math.max(0.08, vRef), 0.55)) * endFade;
      if (amp > 0.004) this.walk((dist / stepLen) * Math.PI, amp);
    }
  },
  go(t, t0, t1, ax, az, bx, bz, r0, r1) {
    this.goPath(t, t0, t1, [[ax, az], [bx, bz]], r0, r1);
  },
  // Plays one recorded clip at a given moment. The clip carries the whole body; reach, look and bend stay on top of it.
  play(name, time, loop = false) {
    const m = clips[name], lap = .4, period = m.dur - lap, at = loop ? ((time % period) + period) % period : time;
    this.layer = { m, x: frameOf(m, at), tail: loop && time >= period && at < lap ? { x: frameOf(m, at + period), u: at / lap } : null };
    return this;
  },
  // Crossfades from one recorded clip to another without a snap at clip boundaries.
  playBlend(fromName, fromTime, toName, toTime, u, loop = true) {
    const k = smooth(clamp01(u));
    if (k >= 1 || fromName === toName) return this.play(toName, toTime, loop);
    const fm = clips[fromName], m = clips[toName], lap = .4;
    const fPer = fm.dur - lap, tPer = m.dur - lap;
    const fAt = loop ? ((fromTime % fPer) + fPer) % fPer : fromTime;
    const tAt = loop ? ((toTime % tPer) + tPer) % tPer : toTime;
    this.layer = { m, x: frameOf(m, tAt), tail: { m: fm, x: frameOf(fm, fAt), u: k } };
    return this;
  },
  // Joins clips into one movement that starts at (x, z, rot). Each clip continues from where the last one ended,
  // so the feet stay planted, and a short blend hides the small differences in pose at the joins.
  plan(names, x, z, rot, t0, fade = .3, from = null) {
    const k = this.hipY / clips[names[0]].stand, segs = [], ref = Q().fromArray(clips[names[0]].q.Bip01, 0);
    let t = t0, ax = x, az = z, yaw = rot;
    names.forEach((n, i) => {
      const m = clips[n], last = segs[i - 1];
      let first = 0, e = last ? last.m.n - 1 : 0;
      // Scene opt-in: a turn that exits into a walk also needs a matching
      // leading leg at the stop. Preserve the established joins elsewhere.
      const moving = name => /_walk_/.test(name) || this.continuousMotion && /_to_walk$/.test(name);
      if (last && moving(n) && moving(names[i - 1])) {
        [e, first] = strideJoin(last.m, m, this.continuousMotion && /_to_walk$/.test(names[i - 1]));
        last.t1 -= (last.m.n - 1 - e) / last.m.fps; t = last.t1;
      }
      const skip = first / m.fps, r0 = rootAt(m, first, V(0, 0, 0)), seg = { m, t0: t, t1: t + m.dur - skip, off: null, fade, skip };
      if (last) {
        const re = rootAt(last.m, e, V(0, 0, 0));
        yaw = wrap(last.yaw + heading(last.m, e, ref) - heading(m, first, ref));
        const c = Math.cos(last.yaw), s = Math.sin(last.yaw), wx = last.x + k * (re.x * c + re.z * s) / 100, wz = last.z + k * (-re.x * s + re.z * c) / 100;
        const c2 = Math.cos(yaw), s2 = Math.sin(yaw);
        ax = wx - k * (r0.x * c2 + r0.z * s2) / 100; az = wz - k * (-r0.x * s2 + r0.z * c2) / 100;
        // What must be blended away: the last pose of the old clip, seen from the new clip's first pose.
        const turn = Q().setFromAxisAngle(V(0, 1, 0), last.yaw - yaw);
        seg.off = {}; seg.dy = re.y - r0.y;
        for (const b of POSE) {
          const from = boneAt(last.m, b, e, Q()), to = boneAt(m, b, first, Q());
          if (b === 'Bip01') from.premultiply(turn);
          seg.off[b] = to.invert().multiply(from);
        }
      }
      if (!last && from) {
        const prev = from.segs?.[from.segs.length - 1], f = prev ? prev.m : clips[from], at = frameOf(f, (prev ? t0 - prev.t0 : t0) % (f.dur - .4));
        seg.off = {}; seg.dy = rootAt(f, at, V(0, 0, 0)).y - r0.y;
        for (const b of POSE) seg.off[b] = boneAt(m, b, 0, Q()).invert().multiply(boneAt(f, b, at, Q()));
        if (this.continuousMotion) {
          const old = rootAt(f, at, V(0, 0, 0)), oldYaw = prev?.yaw ?? yaw;
          const c = Math.cos(oldYaw), s = Math.sin(oldYaw), c2 = Math.cos(yaw), s2 = Math.sin(yaw);
          seg.positionOffset = V((prev?.x ?? ax) + k * (old.x*c + old.z*s)/100 - ax - k*(r0.x*c2+r0.z*s2)/100, 0,
            (prev?.z ?? az) + k * (-old.x*s + old.z*c)/100 - az - k*(-r0.x*s2+r0.z*c2)/100);
          const turn = Q().setFromAxisAngle(V(0,1,0),oldYaw-yaw);
          seg.off.Bip01 = boneAt(m,'Bip01',0,Q()).invert().multiply(turn.multiply(boneAt(f,'Bip01',at,Q())));
        }
      }
      Object.assign(seg, { x: ax, z: az, yaw });
      segs.push(seg); t = seg.t1;
    });
    const end = segs[segs.length - 1], rf = rootAt(end.m, end.m.n - 1, V(0, 0, 0)), c = Math.cos(end.yaw), s = Math.sin(end.yaw);
    return { segs, k, t0, t1: t, end: V(end.x + k * (rf.x * c + rf.z * s) / 100, 0, end.z + k * (-rf.x * s + rf.z * c) / 100), yaw: wrap(end.yaw + heading(end.m, end.m.n - 1, ref) - heading(clips[names[0]], 0, ref)) };
  },
  planTo(names, x, z, yaw, t0, fade = .3, from = null) {
    const trial = this.plan(names, 0, 0, 0, t0, fade), rot = wrap(yaw - trial.yaw), c = Math.cos(rot), s = Math.sin(rot);
    return this.plan(names, x - (trial.end.x * c + trial.end.z * s), z - (-trial.end.x * s + trial.end.z * c), rot, t0, fade, from);
  },
  follow(p, t, loop = false) {
    const seg = p.segs.find(s => t < s.t1) || p.segs[p.segs.length - 1];
    this.at(seg.x, seg.z, seg.yaw);
    const time = t - seg.t0, u = seg.off ? Math.min(1, Math.max(0, time / seg.fade)) : 1, lap = .4, period = seg.m.dur - lap;
    if (seg.positionOffset) this.g.position.addScaledVector(seg.positionOffset,1-u*u*(3-2*u));
    if (loop && seg === p.segs[p.segs.length - 1] && time >= period) {
      const at = time % period;
      this.layer = { m: seg.m, x: frameOf(seg.m, at), tail: at < lap ? { x: frameOf(seg.m, at + period), u: at / lap } : null };
      return this;
    }
    this.layer = { m: seg.m, x: frameOf(seg.m, time + (seg.skip || 0)), off: u < 1 ? seg.off : null, u: u * u * (3 - 2 * u), dy: seg.dy };
    return this;
  },
  // The recorded pose as turns of each joint, in the form the rest of the body code uses.
  applyPose() {
    const { m, x, off, u, dy, tail } = this.layer, k = this.hipY / m.stand, O = this.O ??= {}, D = this.D ??= {}, P = this.Pq ??= {};
    for (const b of POSE) {
      P[b] ??= Q(); boneAt(m, b, x, P[b]);
      if (tail) P[b].copy(boneAt(tail.m || m, b, tail.x, _qc).slerp(P[b], tail.u));
      if (off) P[b].multiply(_qc.copy(_id).slerp(off[b], 1 - u));
    }
    rootAt(m, x, _c);
    if (tail) _c.lerpVectors(rootAt(tail.m || m, tail.x, _e), rootAt(m, x, _f), tail.u);
    // The shoes of the cast are a little thicker than the recorded ones.
    this.b.Bip01.position.set(k * _c.x, k * (_c.y + (off ? dy * (1 - u) : 0)) + 1.4, k * _c.z);
    this.b.Bip01.quaternion.copy(P.Bip01);
    O.Bip01 ??= Q(); O.Bip01.copy(this.R.Bip01).multiply(_qa.copy(this.q0).invert()).multiply(P.Bip01);
    const T = this.Tc ??= {}, turn = k2 => (T[k2] ??= Q()).copy(O[k2]).multiply(_qa.copy(this.R[k2]).invert());
    turn('Bip01');
    for (const b of CHAIN) {
      const up = this.b[b].parent.name;
      (O[b] ??= Q()).copy(O[up]).multiply(P[b]);
      turn(b);
      (D[b] ??= Q()).copy(T[up]).invert().multiply(T[b]);
    }
    for (const s of ['L', 'R']) {
      const h = `Bip01_${s}_Hand`, ik = this.ik[s], wrist = this.b2[h];
      wrist.quaternion.copy(P[h]);
      if (ik) { wrist.quaternion.slerp(this.h0[h], ik.w); if (ik.hold?.roll) wrist.quaternion.multiply(_qc.setFromAxisAngle(_x1, ik.hold.roll * ik.w)); }
      this.b2[`Bip01_${s}_Toe0`]?.quaternion.copy(P[`Bip01_${s}_Toe0`]);
    }
  },
  // Queue attention. Solve it in flush(), after the recording and body posture,
  // from the moving eyes rather than the standing skeleton's stored anchor.
  look(target, w = 1) {
    if(w>0) this.looks.push({target:target.clone(),w:clamp01(w)});
  },
  // Puts the palm on a world point, so handovers really touch.
  reach(side, target, w = 1, pole = null, hold = null) { if (w > 0) this.ik[side] = { t: target.clone(), w, pole, hold }; },
  // A surface-local pinch: the palm remains outside the edge, and the two
  // contact digits follow the prop's own frame, including a rotating cover.
  grasp(side, object, socket, inward, w = 1, thickness = .0003, inset = .012) {
    if(w<=0)return;
    this.flush();
    const wrist=this.arm[side].wrist,from=wrist.localToWorld(V(HAND,0,0)),fromQ=wrist.getWorldQuaternion(Q());
    object.updateWorldMatrix(true,false);
    const frame=object.getWorldQuaternion(Q()), normal=V(0,1,0).applyQuaternion(frame), dir=inward.clone().applyQuaternion(frame).normalize();
    const cross=V(0,0,0).crossVectors(dir,normal).normalize();
    const quaternion=Q().setFromRotationMatrix(new THREE.Matrix4().makeBasis(dir,normal,cross));
    const edge=object.localToWorld(socket.clone());
    const palm=edge.clone().addScaledVector(dir,-.025).addScaledVector(normal,.028);
    // Approach and withdraw on the back side of the surface. Blending the arm
    // alone takes a straight chord through a tilted sheet during the join.
    const clearance=.085*Math.sin(Math.PI*w);
    // An opened cover has a downward-facing normal. First leave its grip
    // edge, then lift: world-up alone crosses the cover; its normal alone
    // takes the withdrawing fingers down through the worktop.
    const clearanceAxis=this.continuousMotion && normal.y<.25 ? V(0,.7,0).addScaledVector(dir,-3.2) : normal;
    palm.lerpVectors(from,palm,w).addScaledVector(clearanceAxis,clearance);
    quaternion.copy(fromQ.slerp(quaternion,w));
    const contactEdge=edge.clone().addScaledVector(clearanceAxis,clearance);
    this.reach(side,palm,1,null,{grip:.32,profile:'pinch',quaternion,edge:contactEdge,surfaceEdge:edge,normal,dir,thickness,inset,blend:w});
  },
  wave(side, t, w = 1) {
    if (w <= 0) return;
    const s = side === 'L' ? 1 : -1;
    this.over[side] = { U: V(s * 0.72, 0.28, 0.12).normalize(), F: V(s * (0.12 + Math.sin(t * 8) * 0.28), 0.95, 0.14).normalize(), w };
  },
  // Open-hand gesture towards an object, used by the explainers.
  present(side, target, w = 1) {
    if (w <= 0) return;
    this.g.updateMatrixWorld(true);
    const s = side === 'L' ? 1 : -1, p = this.g.worldToLocal(_a.copy(target)).sub(this.P[`Bip01_${side}_UpperArm`]);
    p.y = Math.max(-30, Math.min(p.y, 2));
    const dir = p.normalize();
    this.over[side] = { U: V(dir.x * 0.75 + s * 0.2, -0.82, dir.z * 0.6 + 0.05).normalize(), F: V(dir.x, dir.y * 0.25 - 0.02, dir.z).normalize(), w };
    this.grip[side] = 0.12;
  },
  handPos(side, out = V(0, 0, 0)) {
    this.flush();
    const a = this.arm[side];
    a.wrist.getWorldPosition(out);
    const el = a.wrist.parent.getWorldPosition(_p);
    return out.addScaledVector(_b.copy(out).sub(el).normalize(), HAND * 0.01);
  },
  // Writes one joint: its total turn is its parent's turn plus its own.
  set(k, parent) {
    const T = this.T[k];
    T.copy(parent ? this.T[parent] : Q()).multiply(this.d[k]);
    const O = Q().copy(T).multiply(this.R[k]);
    const Op = parent ? Q().copy(this.T[parent]).multiply(this.R[parent]) : Q().copy(this.R.Bip01).multiply(this.b.Bip01.quaternion.clone().invert());
    this.b[k].quaternion.copy(Op.invert().multiply(O));
  },
  flush() {
    const { d, head } = this;
    for(const eye of this.eyes)eye.b.quaternion.copy(eye.q);
    if (!this.layer) { this.b.Bip01.position.y = this.hipY + this.dy * 100; this.b.Bip01.quaternion.copy(this.q0); }
    const breath = (this._idleT !== null && !this.continuousMotion) ? Math.sin(this._idleT * 1.45 + this._idleSeed) * 0.016 : 0;
    d.Bip01_Spine1.copy(qz(this.sway)).multiply(qx(this.bend * 0.5));
    d.Bip01_Spine2.copy(qx(this.bend * 0.5 + breath));
    // Build the body with neutral attention first. The gaze pass below changes
    // only neck/head, so the recording cannot move its own gaze origin later.
    const hy = this.looks.length?0:head.rotation.y, hx = this.looks.length?0:head.rotation.x;
    d.Bip01_Neck.copy(qy(hy * 0.45)).multiply(qx(hx * 0.45));
    d.Bip01_Head.copy(qy(hy * 0.55)).multiply(qx(hx * 0.55));
    const nInv = Q().copy(d.Bip01_Neck).invert();
    d.Bip01_L_Clavicle.copy(nInv).multiply(qz(breath * 0.45)); d.Bip01_R_Clavicle.copy(nInv).multiply(qz(-breath * 0.45));
    this.T.Bip01.identity();
    if (this.layer) {
      d.Bip01_Pelvis.identity(); d.Bip01_Spine.identity();
      this.applyPose();
      const D = this.D;
      this.T.Bip01.copy(this.Tc.Bip01);
      for (const b of CHAIN) if (!/UpperArm|Forearm/.test(b)) d[b].premultiply(D[b]);
      // Legs follow the recording alone; hand-made leg poses do not add to it.
      for (const b of ['L_Thigh', 'R_Thigh', 'L_Calf', 'R_Calf', 'L_Foot', 'R_Foot']) d[`Bip01_${b}`].copy(D[`Bip01_${b}`]);
    }
    for (const [k, p] of [['Bip01_Pelvis', 'Bip01'], ['Bip01_Spine', 'Bip01_Pelvis'], ['Bip01_Spine1', 'Bip01_Spine'], ['Bip01_Spine2', 'Bip01_Spine1'], ['Bip01_Neck', 'Bip01_Spine2'], ['Bip01_Head', 'Bip01_Neck'],
      ['Bip01_L_Clavicle', 'Bip01_Neck'], ['Bip01_R_Clavicle', 'Bip01_Neck'], ['Bip01_L_Thigh', 'Bip01_Spine'], ['Bip01_R_Thigh', 'Bip01_Spine'],
      ['Bip01_L_Calf', 'Bip01_L_Thigh'], ['Bip01_R_Calf', 'Bip01_R_Thigh'], ['Bip01_L_Foot', 'Bip01_L_Calf'], ['Bip01_R_Foot', 'Bip01_R_Calf']]) this.set(k, p);
    this.g.updateMatrixWorld(true);
    if(this.looks.length) this.solveGaze();
    if (this._idleT !== null && !this.continuousMotion) {
      const gt = this._idleT, gs = this._idleSeed;
      const gy = Math.sin(gt * 0.45 + gs * 1.7) * 0.065 + Math.sin(gt * 0.19 + gs * 3.1) * 0.04;
      const gp = Math.sin(gt * 1.35 + gs) * 0.018 + Math.sin(gt * 0.55 + gs * 2.3) * 0.02;
      const invRest = this.R.Bip01_Head.clone().invert();
      const micro = Q().setFromAxisAngle(V(0, 1, 0).applyQuaternion(invRest), gy)
        .multiply(Q().setFromAxisAngle(V(1, 0, 0).applyQuaternion(invRest), gp));
      this.b.Bip01_Head.quaternion.multiply(micro);
      this.g.updateMatrixWorld(true);
    }
    for (const s of ['L', 'R']) this.solveArm(s);
    this.g.updateMatrixWorld(true);
    this.poseFingers();
    for (const m of this.faces) {
      const inf = m.morphTargetInfluences;
      inf[0] = inf[1] = this.blink; inf[2] = inf[3] = this.gaze; inf[4] = inf[5] = this.smile; inf[6] = this.jaw;
    }
  },
  solveGaze() {
    const target=V(0,0,0);let total=0;
    for(const a of this.looks){target.lerp(a.target,a.w);total=lerp(total,1,a.w);}
    if(total<1e-6)return;target.multiplyScalar(1/total);
    const baseWorld=this.b.Bip01_Spine2.getWorldQuaternion(Q()).multiply(this.R.Bip01_Spine2.clone().invert()).multiply(this.R.Bip01_Head);
    // The Rocketbox head bone is not aligned to the face. Its rest matrix maps
    // the anatomical forward/up axes into the bone's local coordinates.
    const invRest=this.R.Bip01_Head.clone().invert();
    const up=V(0,1,0).applyQuaternion(invRest);
    const eyePosition=()=>{
      if(!this.eyes.length)return this.b.Bip01_Head.localToWorld(V(0,12,7).applyQuaternion(invRest));
      const p=V(0,0,0);for(const eye of this.eyes)p.add(eye.b.getWorldPosition(V(0,0,0)));return p.multiplyScalar(1/this.eyes.length);
    };
    let yaw=0,pitch=0,eyes=0;
    for(let iter=0;iter<3;iter++) {
      const eye=eyePosition();
      const delta=target.clone().sub(eye).applyQuaternion(baseWorld.clone().invert()).applyQuaternion(this.R.Bip01_Head);
      yaw=THREE.MathUtils.clamp(Math.atan2(delta.x,delta.z),-1.05,1.05)*total;
      const desired=-Math.atan2(delta.y,Math.hypot(delta.x,delta.z));
      pitch=THREE.MathUtils.clamp(desired,-.4,.55)*total;
      eyes=THREE.MathUtils.clamp(desired-pitch,0,.42)*total;
      const turn=Q().setFromAxisAngle(up,yaw).multiply(Q().setFromAxisAngle(V(1,0,0).applyQuaternion(invRest),pitch));
      const parentWorld=this.b.Bip01_Head.parent.getWorldQuaternion(Q());
      this.b.Bip01_Head.quaternion.copy(parentWorld.invert().multiply(baseWorld.clone().multiply(turn)));
      this.g.updateMatrixWorld(true);
    }
    this.head.rotation.x=pitch;this.head.rotation.y=yaw;
    const headFrame=this.b.Bip01_Head.getWorldQuaternion(Q()).multiply(invRest),direction=V(0,0,0);
    for(const eye of this.eyes) {
      const at=eye.b.getWorldPosition(V(0,0,0)),local=target.clone().sub(at).applyQuaternion(headFrame.clone().invert());
      const ey=THREE.MathUtils.clamp(Math.atan2(local.x,local.z),-.35,.35),ep=THREE.MathUtils.clamp(-Math.atan2(local.y,Math.hypot(local.x,local.z)),-.30,.42);
      const desired=V(Math.sin(ey)*Math.cos(ep),-Math.sin(ep),Math.cos(ey)*Math.cos(ep)).applyQuaternion(headFrame);
      const world=eye.b.getWorldQuaternion(Q()),from=eye.forward.clone().applyQuaternion(world);
      const correction=Q().setFromUnitVectors(from,desired);
      eye.b.quaternion.copy(eye.b.parent.getWorldQuaternion(Q()).invert().multiply(correction.multiply(world)));eye.b.updateWorldMatrix(false,true);
      direction.add(eye.forward.clone().applyQuaternion(eye.b.getWorldQuaternion(Q())));
    }
    // Eye bones provide the residual attention. Do not double it with the
    // independent eye-down morphs baked into the face meshes.
    this.gaze=this.eyes.length?0:eyes/.42;
    if(this.eyes.length)direction.normalize();else direction.set(0,-Math.sin(eyes),Math.cos(eyes)).applyQuaternion(headFrame);
    const eye=eyePosition();
    this.gazeCheck={eye,target:target.clone(),direction,error:THREE.MathUtils.radToDeg(direction.angleTo(target.clone().sub(eye)))};
  },
  poseFingers() {
    for(const side of ['L','R']) {
      const ik=this.ik[side],hold=ik?.hold,typing=hold?.profile==='typing',pinch=hold?.profile==='pinch';
      // A fitted grasp is rigid in the prop/hand frame. Reuse its joint pose
      // instead of solving the identical skin contact thousands of times.
      const settled=hold&&(hold.profile==='phone'||pinch&&(hold.blend??1)===1)&&this.arm[side].wrist.localToWorld(V(HAND,0,0)).distanceTo(ik.t)<.0001;
      const poseKey=settled?`${side}:${hold.profile}:${hold.thickness||0}:${hold.inset||0}`:null;
      this.fingerPoses??={};const fitted=poseKey&&this.fingerPoses[poseKey];
      if(fitted) {
        this.fingers[side].forEach((f,i)=>f.b.quaternion.copy(fitted[i]));
        if(hold.phone){const w=this.arm[side].wrist;hold.phone.position.copy(w.localToWorld(V(9,1.6,0)));hold.phone.quaternion.copy(w.getWorldQuaternion(Q())).multiply(Q().setFromAxisAngle(V(0,1,0),Math.PI/2));hold.phone.updateMatrixWorld(true);}
        this.g.updateMatrixWorld(true);continue;
      }
      for(const f of this.fingers[side]) {
        // Separate proximal/middle/distal bends, staggered by digit. The thumb
        // opposes the index; it does not receive the four-finger fist rotation.
        let bend=this.grip[side]*[.48,.82,.63][f.joint]*(1+.075*(f.digit-2));
        if(f.digit===0)bend*=.35;
        if(pinch)bend=(f.digit<2?[.10,.32,.25]:[.25,.46,.35])[f.joint];
        if(typing) {
          const phase=hold.time*(side==='R'?7.1:6.3)+f.digit*1.87;
          const press=Math.pow(Math.max(0,Math.sin(phase)),6);
          bend=([.08,.25,.16][f.joint]+press*[.12,.18,.1][f.joint])*(f.digit===0?.25:1);
        }
        f.b.quaternion.copy(f.q).multiply(qz(bend));
      }
      this.g.updateMatrixWorld(true);
      if(hold?.profile==='phone'&&hold.phone) {
        const phone=hold.phone,wrist=this.arm[side].wrist;
        phone.position.copy(wrist.localToWorld(V(9,1.6,0)));
        phone.quaternion.copy(wrist.getWorldQuaternion(Q())).multiply(Q().setFromAxisAngle(V(0,1,0),Math.PI/2));phone.updateMatrixWorld(true);
        const normal=V(0,-1,0).applyQuaternion(phone.quaternion),dir=V(0,0,1).applyQuaternion(phone.quaternion);
        // Four pads support the underside; the thumb rests on the near rim.
        for(const digit of [1,2,3,4,0]) {
          const x=digit===0?(side==='R'?-.052:.052):(side==='R'?1:-1)*(-.022+(digit-1)*.020),z=digit===0?-.035:[.06,.07,.055,.035][digit-1];
          const edge=phone.localToWorld(V(x,0,z-.01)),contact={edge,normal,dir,thickness:.012};
          const target=phone.localToWorld(V(x,digit===0?.01475:-.01475,z));
          this.fitFinger(side,digit,target,1);
          for(let pass=0;pass<8;pass++) {
            const gap=this.fingerGap(side,digit,contact);if(!Number.isFinite(gap)||Math.abs(gap-.00075)<.00008)break;
            target.addScaledVector(normal,(digit===0?1:-1)*THREE.MathUtils.clamp(gap-.00075,-.008,.008));this.fitFinger(side,digit,target,1);
          }
        }
      }
      if(typing&&hold.keyHeight)for(const digit of [1,2,3]) {
        const tip=this.fingers[side].find(f=>f.digit===digit&&f.joint===2)?.b;if(!tip)continue;
        const target=tip.localToWorld(V(1.6,0,0));
        const press=Math.pow(Math.max(0,Math.sin(hold.time*(side==='R'?7.1:6.3)+digit*1.87)),6);
        target.y=hold.keyHeight+.008+.009*(1-press);
        this.fitFinger(side,digit,target,ik.w);
      }
      if(pinch&&(hold.blend??1)>.65) {
        // Keep the remaining digits on the back of the material. A uniform
        // fist lets their middle joints cut through a thin reading sheet.
        const across=V(0,0,0).crossVectors(hold.dir,hold.normal);
        for(const digit of [2,3,4]) {
          const target=hold.edge.clone().addScaledVector(hold.dir,.09).addScaledVector(hold.normal,.034+hold.thickness/2).addScaledVector(across,(side==='R'?-1:1)*(digit-1)*.018);
          this.fitFinger(side,digit,target,ik.w);
        }
        // Fit the two contact pads separately. Targets sit on opposite sides of
        // the material and stay inside its edge throughout the opening arc.
        for(const digit of [0,1]) {
          const contactHold=digit===0?{...hold,edge:hold.surfaceEdge||hold.edge}:hold;
          const inset=digit===0?lerp(-.025,hold.inset,ramp(hold.blend??1,.97,1)):hold.inset;
          const target=contactHold.edge.clone().addScaledVector(hold.dir,inset).addScaledVector(hold.normal,(digit===0?-1:1)*(.008+hold.thickness/2));
          this.fitFinger(side,digit,target,ik.w);
          if(ik.w>.999)for(let pass=0;pass<16;pass++) {
            const gap=this.fingerGap(side,digit,contactHold);
            if(!Number.isFinite(gap)||Math.abs(gap-.00075)<.00005)break;
            const correction=THREE.MathUtils.clamp(gap-.00075,-.012,.012);
            target.addScaledVector(hold.normal,(digit===0?1:-1)*correction);
            this.fitFinger(side,digit,target,1);
          }
        }
      }
      if(poseKey)this.fingerPoses[poseKey]=this.fingers[side].map(f=>f.b.quaternion.clone());
    }
  },
  fitFinger(side,digit,target,weight) {
    const chain=this.fingers[side].filter(f=>f.digit===digit).sort((a,b)=>a.joint-b.joint),tip=chain[2]?.b;
    if(!tip)return;
    const end=V(digit===0?1.5:1.6,0,0),start=chain.map(f=>f.b.quaternion.clone());
    // Three-joint CCD in world space. A limited correction avoids flipping a
    // knuckle to satisfy a target beyond the digit's physical reach.
    for(let pass=0;pass<24;pass++){
      if(tip.localToWorld(end.clone()).distanceTo(target)<.00008)break;
      for(let i=2;i>=0;i--) {
      const b=chain[i].b,origin=b.getWorldPosition(V(0,0,0)),from=tip.localToWorld(end.clone()).sub(origin).normalize(),to=target.clone().sub(origin).normalize();
      const correction=Q().setFromUnitVectors(from,to),world=b.getWorldQuaternion(Q());
      correction.slerp(Q(),Math.max(0,1-.35/Math.max(.35,from.angleTo(to))));
      b.quaternion.copy(b.parent.getWorldQuaternion(Q()).invert().multiply(correction.multiply(world)));b.updateWorldMatrix(false,true);
      }
    }
    if(weight<1)chain.forEach((f,i)=>{const solved=f.b.quaternion.clone();f.b.quaternion.copy(start[i]).slerp(solved,weight);});
  },
  fingerGap(side,digit,hold) {
    this.fingerSkin??={};const key=side+digit;
    if(!this.fingerSkin[key]) {
      const entries=[];
      this.root.traverse(m=>{
        if(!m.isSkinnedMesh)return;
        const ids=m.geometry.attributes.skinIndex,weights=m.geometry.attributes.skinWeight,indices=[];
        const bones=new Set(m.skeleton.bones.map((b,i)=>b.name.startsWith(`Bip01_${side}_Finger${digit}`)?i:-1));bones.delete(-1);
        if(!bones.size)return;
        for(let i=0;i<ids.count;i++)for(let j=0;j<4;j++)if(bones.has(ids.getComponent(i,j))&&weights.getComponent(i,j)>.15){indices.push(i);break;}
        if(indices.length)entries.push({m,indices});
      });this.fingerSkin[key]=entries;
    }
    this.g.updateMatrixWorld(true);
    let nearest=Infinity;const p=V(0,0,0),tangent=V(0,0,0).crossVectors(hold.dir,hold.normal),sign=digit===0?-1:1;
    for(const {m,indices} of this.fingerSkin[key])for(const i of indices) {
      m.localToWorld(m.getVertexPosition(i,p));p.sub(hold.edge);
      const along=p.dot(hold.dir);
      if(along<0||along>.05||Math.abs(p.dot(tangent))>.025)continue;
      nearest=Math.min(nearest,sign*p.dot(hold.normal)-hold.thickness/2);
    }
    return nearest;
  },
  solveArm(s) {
    const a = this.arm[s], cl = `Bip01_${s}_Clavicle`, up = `Bip01_${s}_UpperArm`, fo = `Bip01_${s}_Forearm`, side = s === 'L' ? 1 : -1;
    const Dc = this.T[cl], DcI = Q().copy(Dc).invert();
    // Relaxed arms, with the walking swing.
    const sw = qx(this.swing[s]);
    const dirs = (U, F) => {
      const qU = Q().setFromUnitVectors(a.u0, _e.copy(U).applyQuaternion(DcI).normalize());
      const Dup = Q().copy(Dc).multiply(qU);
      const qF = Q().setFromUnitVectors(a.f0, _f.copy(F).applyQuaternion(Q().copy(Dup).invert()).normalize());
      return [qU, qF];
    };
    let [qU, qF] = dirs(_a.copy(RELAX[s][0]).applyQuaternion(sw).clone(), _b.copy(RELAX[s][1]).applyQuaternion(sw).clone());
    if (this.layer) { qU.copy(this.D[up]); qF.copy(this.D[fo]); }
    const ov = this.over[s];
    if (ov) { const [u, f] = dirs(ov.U, ov.F); qU.slerp(u, ov.w); qF.slerp(f, ov.w); }
    const ik = this.ik[s];
    if (ik) {
      const S = this.root.worldToLocal(this.b[up].getWorldPosition(_a)).clone();
      const oriented=ik.hold?.quaternion, target=ik.t.clone();
      if(oriented)target.sub(V(HAND*.01,0,0).applyQuaternion(oriented));
      const T = this.root.worldToLocal(target).clone(), L2=a.L2-(oriented?HAND:0);
      const dvec = T.clone().sub(S), dist = Math.min(dvec.length(), a.L1 + L2 - 0.1);
      dvec.normalize();
      const c = THREE.MathUtils.clamp((a.L1 * a.L1 + dist * dist - L2 * L2) / (2 * a.L1 * dist),-1,1), sn = Math.sqrt(Math.max(0, 1 - c * c));
      const pole = (ik.pole ? ik.pole.clone() : V(side * 0.7, -1, -0.5));
      pole.addScaledVector(dvec, -pole.dot(dvec)).normalize();
      const E = dvec.clone().multiplyScalar(c).addScaledVector(pole, sn);
      const F = dvec.clone().multiplyScalar(dist).addScaledVector(E, -a.L1).normalize();
      const [u, f] = dirs(E, F);
      qU.slerp(u, ik.w); qF.slerp(f, ik.w);
      this.grip[s] = lerp(this.grip[s], ik.hold?.grip ?? 0.6, ik.w);
    }
    this.d[up].copy(qU); this.d[fo].copy(qF);
    this.set(up, cl); this.set(fo, up);
    if(ik?.hold?.quaternion) {
      this.g.updateMatrixWorld(true);
      const desired=a.wrist.parent.getWorldQuaternion(Q()).invert().multiply(ik.hold.quaternion);
      a.wrist.quaternion.slerp(desired,ik.w);
    }
  },
};
