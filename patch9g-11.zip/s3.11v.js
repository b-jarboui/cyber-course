// The Director General announces a fee he never set
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, phone, row, note, reveal } from "./screens-tr.js";
import { AR } from "./i18n.js";

export const texts = [];
export const cast = ["omar", "maya", "citizen", "official"];
export default chapterHall((S, E, D) => ({
  lesson: "3.3",
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor', official: 'door' },
  enter: { official: D.T },
  shots: [[0,'counter'], [S(1),'staff'], [S(3),'counter'], [S(8),'staff'], [S(10),'counterDisplay'], [S(11),'counter'], [S(13),'her']],
  actions: { omar: [[0,S(1),'listen','citizen'], [S(1),S(9),'text'], [S(9),S(11),'listen','maya'], [S(11),S(13),'talk','citizen'], [S(13),D.T,'listen','maya']], maya: [[0,S(9),'listen','omar'], [S(9),S(11),'type'], [S(11),S(13),'talk','citizen'], [S(13),D.T,'type']], citizen: [[0,S(12),'listen','omar'], [S(12),E(12),'call'], [S(13),D.T,'listen','maya']] },
  setupProps: evidence({
    surfaces: { 'phone:omar': [[S(1),S(3),'broadcast','Processing fee claimed','official'], [S(3),S(9),'portal','Fee payment']] },
    inserts: [[S(1),E(1),'phone:omar'], [S(3),E(3),'phone:omar']],
  }),
  displays: { counter: [[S(10),S(13),'computer','No processing fee','safe'], [S(13),D.T,'folder','Video and link saved','safe']] },
  plates: [[S(2),E(2),'Processing fee claimed'], [S(3),E(3),'Look-alike website'], [S(12),E(12),'Number on the bank card']],
  screens: [
    [S(1), S(3), q => phone('Video message', reveal([
      row('Speaker', 'Looks like Director General', 'warn'),
      row('Claim', 'New refund processing fee', 'no'),
      row('Link', 'refund-sadeed.example', 'no'),
    ], q))],
    [S(3), S(4), win('refund-sadeed.example', row('Look-alike site', 'refund-sadeed.example', 'no') + row('Official site', 'sadeed.gov.example', 'ok') + note('Same colours and logo — wrong address.', 'no'), 'alert')],
    [S(13), S(15), q => win('Report sent', reveal([
      row('Evidence saved', 'Video, link and time', 'ok'),
      row('Forwarded', 'No', 'ok'),
      row('Official site', 'No processing fee', 'ok'),
    ], q), 'good')],
  ],
  pages: [
    hero(S(4), S(6), "Fake announcements can use real faces", "mobile+made/laptop", [
      ["Video of an official", S(4), "v-amber"],
    ]),
    hero(S(6), S(9), "A look-alike website is not the official one", "computer+link", [
      ["Reference number given — proves nothing", S(6), "v-amber"],
    ]),
    // The same English heading has a different approved translation in Chapter 2.
    hero(S(10), S(12), AR ? "اكتب العنوان الرسمي بنفسك" : "Type the official address yourself", "made/laptop+computer", [
      ["No processing fee", S(10), "v-teal"],
    ]),
  ],
}));
