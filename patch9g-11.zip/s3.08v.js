// A perfect document, a photo that proves nothing
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["maya", "omar", "citizen"];
export default chapterHall((S, E, D) => ({
  lesson: "3.2",
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor' },
  shots: [[0,'counter'], [S(1),'staff'], [S(2),'file'], [S(7),'counterDisplay'], [S(10),'counter'], [S(12),'gathering'], [S(13),'counterDisplay']],
  actions: { omar: [[0,S(1),'listen','citizen'], [S(1),S(7),'paper'], [S(7),S(10),'listen','maya'], [S(10),E(10),'paper'], [S(11),S(13),'talk','citizen'], [S(13),D.T,'listen','maya']], maya: [[0,S(7),'listen','omar'], [S(7),S(10),'type'], [S(10),S(13),'listen','citizen'], [S(13),D.T,'type']], citizen: [[0,E(0),'talk','omar'], [S(1),D.T,'listen','omar']] },
  setupProps: evidence({
    surfaces: { 'paper:omar': [[S(1),S(7),'identity','Submitted identity document','citizen'], [S(10),E(10),'shop','Storm-damaged shop photo']], counterPrint: [[0,D.T,'shop','Storm-damaged shop photo']] },
    inserts: [[S(1),E(1),'paper:omar'], [S(2),E(2),'counterPrint']],
  }),
  displays: { counter: [[0,S(8),'folder','Official record','neutral'], [S(8),S(13),'file-text','Name does not match','alert'], [S(13),D.T,'folder','Referred for review','safe']] },
  plates: [[S(0),E(0),'Compensation application'], [S(8),E(8),'Name does not match'], [S(10),E(10),'Inspection report requested']],
  screens: [
    [S(0), S(2), q => win('Compensation application', reveal([
      row('Attachment 1', 'Identity document', 'warn'),
      row('Attachment 2', 'Storm-damaged shop photo', 'warn'),
      note('Looks complete — check official record.', 'warn'),
    ], q))],
    [S(10), S(11), win('Official record', row('Identity number', 'Name does not match', 'no') + row('Storm photo', 'Unconfirmed', 'no') + row('Required', 'Official inspection report', 'ok'), 'alert')],
  ],
  pages: [
    hero(S(3), S(7), "AI can forge documents and evidence", "made/id_badge+file-text", [
      ["Submitted identity document", S(3), "v-amber"],
      ["Storm-damaged shop photo", S(5), "v-amber"],
    ]),
    hero(S(7), S(10), "Check against the official record", "made/register_book+made/id_badge", [
      ["Name does not match", S(8), "v-amber"],
    ]),
    hero(S(11), S(14), "Refer for review; don't accuse", "made/case_folder+file-text", [
      ["Keep the submitted files", S(13), "v-teal"],
    ]),
  ],
}));
