// A notice nobody approved.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '6.3',
  actors: { official: 'director', maya: 'counter', omar: 'desk' },
  shots: [[0, 'gathering'], [S(1), 'counter'], [S(2), 'counterDisplay'], [S(3), 'desk'], [S(4), 'display'], [S(5), 'her'], [S(13), 'counter'], [S(14), 'display']],
  actions: {
    official: [[0, S(2), 'paper'], [S(2), S(4), 'listen', 'maya'], [S(4), S(6), 'talk', 'maya'], [S(6), D.T, 'listen', 'maya']],
    maya: [[0, S(1), 'listen', 'official'], [S(1), S(13), 'read'], [S(13), D.T, 'type']],
    omar: [[0, S(3), 'read'], [S(3), S(5), 'type'], [S(5), D.T, 'read']],
  },
  displays: {
    counter: [
      [0, S(2), 'folder', 'New circulars folder', 'neutral'],
      [S(2), S(13), 'file', 'Unapproved notice cited', 'alert'],
      [S(13), D.T, 'bell', 'Unapproved file reported', 'safe'],
    ],
    desk: [
      [0, S(3), 'folder', 'Official register', 'neutral'],
      [S(3), S(13), 'file', 'Notice not in register', 'alert'],
      [S(13), D.T, 'folder', 'Official register followed', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'New circulars folder'],
    [S(2), E(2), 'Unfamiliar notice cited'],
    [S(3), E(3), 'Not in official register'],
    [S(13), E(13), 'Official register followed'],
  ],
  screens: [
    [S(1), S(3), q => win('Approved AI assistant', reveal([
      row('Question', 'Late requests · Case 2048'),
      row('Cited notice', 'Notice 09/2026 (Unfamiliar)', 'warn'),
      note('Shaima has never seen this notice.', 'warn'),
    ], q), 'alert')],
    [S(3), S(5), q => win('Official register of circulars', reveal([
      row('Notice 09/2026', 'Not in official register', 'no'),
      row('Policy owner', 'Nobody approved it', 'no'),
      row('Found in', 'Shared circulars folder', 'warn'),
      note('Unapproved file fed the knowledge base.', 'no'),
    ], q), 'alert')],
  ],
  pages: [
    hero(S(5), S(8), 'Poisoned data, poisoned answers', 'made/filing_cabinet+made/own_file', [
      ['An attack on the integrity of AI data', S(5), 'v-coral'],
      ['Affects training data or knowledge bases', S(6), 'v-amber'],
    ]),
    hero(S(8), S(11), '250 documents planted a backdoor at every size tested', 'made/own_folder+made/padlock_open', [
      ['Hidden triggers can evade ordinary tests', S(9), 'v-coral'],
      ['Five planted texts per question steered answers', S(10), 'v-amber'],
    ]),
    hero(S(11), S(14), 'Know who can write to the knowledge base', 'made/id_badge+made/register_book', [
      ['Named owners, every change recorded', S(12), 'v-teal'],
      ['Record source, date and every revision', (S(12) + E(12)) / 2, 'v-navy'],
    ]),
    hero(S(14), D.T, 'Check the source of answers that affect a person', 'made/register_book+made/own_bell', [
      ['Only named owners add knowledge-base files', S(14), 'v-teal'],
      ['Source missing from register? Stop and report', S(15), 'v-amber'],
    ]),
  ],
}));
