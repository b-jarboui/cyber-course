import { AR, tr } from './i18n.js';
// Readable workplace screens: what a person sees on their monitor or phone, large enough to read on a phone.
// A scene lists beats [from, to, html or q => html]; q runs 0 to 1 across the beat, so rows can appear with the voice.
import { ramp } from './kit.js';

const ICON = { ok: '✓', no: '✕', wait: '…', warn: '!', hi: AR ? '‹' : '›', q: AR ? '؟' : '?' };
export const mark = (kind, text = '') => `<span class="mk ${kind}">${ICON[kind] || ''}</span>${text}`;

// A row: label, value, state. State is ok, no, wait, warn or hi.
// Short labels never break ("Request\n2" looked broken, Gemini 2026-11-23).
const nbh = x => /</.test(String(x)) ? x : String(x).replace(/(\w)-(\w)/g, '$1‑$2'); // "sign-\nin?" -> keep words whole
export const row = (label, value = '', state = '') => `<div class="r ${state}"><span class="l${String(label).replace(/<[^>]*>/g,'').length <= 14 ? ' nw' : ''}">${nbh(label)}</span><span class="v">${nbh(value)}</span>${state ? `<span class="mk ${state}">${ICON[state]}</span>` : ''}</div>`;
export const win = (title, body, tone = '') => `<div class="win ${tone}"><div class="bar"><i></i><i></i><i></i><b>${title}</b></div><div class="body">${body}</div></div>`;
export const phone = (title, body) => `<div class="win phone"><div class="notch"></div><div class="body"><h4>${title}</h4>${body}</div></div>`;
export const note = (text, tone = '') => `<div class="note ${tone}">${text}</div>`;
export const head = (text, sub = '') => `<div class="hd">${text}${sub ? `<small>${sub}</small>` : ''}</div>`;
export const mail = (from, role, subject, body) => `<div class="mail"><div class="from"><span class="av">${from[0]}</span><div><b>${from}</b><small>${role}</small></div></div><div class="sub">${subject}</div><div class="txt">${body}</div></div>`;
export const chain = items => `<div class="chain">${items.map(([t, s, st]) => `<div class="c ${st || ''}"><b>${t}</b>${s ? `<small>${s}</small>` : ''}</div>`).join('<span class="ar">↓</span>')}</div>`;
export const cols = (a, b) => `<div class="cols"><div>${a}</div><div>${b}</div></div>`;
export const btn = (text, tone = '') => `<span class="btn ${tone}">${text}</span>`;
// A mouse pointer that travels towards a button as k goes from 0 to 1.
export const pointer = (html, k) => `<span class="pwrap">${html}<span class="ptr" style="${AR ? 'right' : 'left'}:${(130 - 70 * k).toFixed(0)}px;top:${(44 - 26 * k).toFixed(0)}px">➤</span></span>`;
// Rows that appear one at a time as q goes from 0 to 1.
export const reveal = (rows, q, lead = 0.04) => rows.slice(0, Math.min(rows.length, 1 + Math.floor((q + lead) * rows.length))).join('');

export const CSS = `
#screen{position:absolute;left:12px;right:12px;top:31%;bottom:150px;display:flex;align-items:flex-start;justify-content:center;pointer-events:none;opacity:0}
#screen .win{width:100%;max-width:430px;background:#fffdf8;border-radius:14px;box-shadow:0 14px 38px rgba(30,38,76,.28);overflow:hidden;font-size:clamp(13.5px,3.7vw,15.5px);line-height:1.3;color:#26305a}
#screen .bar{display:flex;gap:5px;align-items:center;background:#2f3a63;color:#fff;padding:7px 11px}
#screen .bar i{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.45);flex:none}
#screen .bar b{margin-left:6px;font-size:.92em;font-weight:650;min-width:0;overflow-wrap:anywhere}
#screen .win.alert .bar{background:#b4542f}
#screen .win.good .bar{background:#2f7477}
#screen .body{padding:10px 12px 14px}
#screen .body > :last-child{margin-bottom:0}
#screen .phone{max-width:300px;border:7px solid #23273a;border-radius:24px}
#screen .phone .body{padding:10px 14px 18px}
#screen .phone .notch{width:64px;height:8px;background:#23273a;border-radius:0 0 8px 8px;margin:0 auto}
#screen h4{margin:6px 0 8px;font-size:1.05em}
#screen .hd{font-weight:750;font-size:1.1em;margin-bottom:7px;overflow-wrap:anywhere}
#screen .hd small{display:block;font-weight:500;font-size:.82em;color:#5c6484;margin-top:1px;overflow-wrap:anywhere}
#screen .r{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:8px;margin-bottom:4px;background:#f3eee4}
#screen .r .l{flex:1;min-width:0;font-weight:600;overflow-wrap:break-word}
#screen .r .l.nw{white-space:nowrap;flex:0 0 auto}
#screen .r .l.nw + .v{flex:1}
#screen .r .v{color:#4b5476;text-align:right;min-width:0;overflow-wrap:anywhere;word-break:break-word}
#screen .r.ok{background:#e0f0ee}#screen .r.no{background:#f9e2dc}#screen .r.wait{background:#fbeed5}#screen .r.warn{background:#fbeed5}#screen .r.hi{background:#dfe7f6;outline:2px solid #2f3a63}
#screen .mk{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;color:#fff;font-weight:800;font-size:.8em;flex:none}
#screen .mk.ok{background:#2f7477}#screen .mk.no{background:#c6543b}#screen .mk.wait,#screen .mk.warn,#screen .mk.q{background:#d78c22}#screen .mk.hi{background:#2f3a63}
#screen .note{margin-top:7px;padding:7px 9px;border-left:4px solid #2f7477;background:#eef5f4;border-radius:6px;font-weight:600;overflow-wrap:anywhere}
#screen .note.warn{border-color:#d78c22;background:#fbf1de}#screen .note.no{border-color:#c6543b;background:#fae6e1}
#screen .mail .from{display:flex;gap:9px;align-items:center;margin-bottom:6px}
#screen .mail .from > div{min-width:0;flex:1}
#screen .mail small{display:block;color:#5c6484;font-size:.84em;overflow-wrap:anywhere;word-break:break-word}
#screen .av{width:32px;height:32px;border-radius:50%;background:#2f7477;color:#fff;display:grid;place-items:center;font-weight:750;flex:none}
#screen .sub{font-weight:750;margin-bottom:5px;overflow-wrap:anywhere}
#screen .txt{overflow-wrap:anywhere}
#screen .chain{display:flex;flex-direction:column;align-items:stretch}
#screen .c{background:#f3eee4;border-radius:8px;padding:6px 9px;overflow-wrap:anywhere}
#screen .c b{display:block}#screen .c small{color:#5c6484}
#screen .c.ok{background:#e0f0ee}#screen .c.wait{background:#fbeed5}#screen .c.no{background:#f9e2dc}
#screen .ar{text-align:center;color:#2f3a63;font-weight:800;line-height:1.05}
#screen .cols{display:grid;grid-template-columns:1fr 1fr;gap:8px}
#screen .btn{display:inline-block;margin-top:7px;padding:6px 11px;border-radius:8px;background:#2f3a63;color:#fff;font-weight:650}
#screen .ptr{position:absolute;font-size:22px;line-height:1;color:#111;filter:drop-shadow(0 1px 1px #fff)}
#screen .pwrap{position:relative;display:inline-block}
#screen .btn.ok{background:#2f7477}#screen .btn.no{background:#c6543b}#screen .btn.off{background:#cfc9bd;color:#6b6f80}
`;

const clamp = x => Math.min(1, Math.max(0, x));
const backOut = u => { const v = u - 1; return 1 + 2.7 * v * v * v + 1.7 * v * v; };
const pop = u => u <= 0 ? 0 : u >= 1 ? 1 : 1 - Math.pow(2, -9 * u) * Math.cos(u * 11);
const ITEMS = '.r,.c,.note,.btn,.mail,.hd,.ar';
const parse = html => { const d = document.createElement('div'); d.innerHTML = tr(html); return [...d.querySelectorAll(ITEMS)].map(n => n.textContent); };

export function createScreens(el) {
  if(AR)el.dir='rtl';
  let shown = null, items = [];
  const times = new Map();
  // When does each row first appear in this beat? Sampled once, so seeking gives the same result.
  // Row 0 is already visible when the card arrives (no blank white body); exit finishes 0.15 s before beat end.
  function firstSeen(id, a, b, h) {
    if (times.has(id)) return times.get(id);
    const m = new Map(), span = Math.max(0.1, b - a - 0.45);
    if (typeof h === 'function') {
      for (let i = 0; i <= 60; i++) {
        const q = i / 60;
        parse(h(q)).forEach((x, n) => {
          if (!m.has(x)) m.set(x, i === 0 ? (n === 0 ? a - 0.68 : a - 0.14 + n * 0.10) : a + q * span);
        });
      }
    } else parse(h).forEach((x, n) => m.set(x, n === 0 ? a - 0.68 : a - 0.14 + n * 0.10));
    times.set(id, m);
    return m;
  }
  return {
    active: false,
    play(t, beats) {
      let html = null, inn = 0, leave = 0, seen = null, start = 0;
      beats.forEach(([a0, b, h], id) => {
        const a = a0 + (this.lead || 0), bEnd = b - 0.15;
        if (t < a - 0.28 || t >= bEnd) return;
        const leaveStart = Math.max(a, bEnd - 0.26);
        inn = clamp((t - (a - 0.28)) / 0.36); leave = clamp((t - leaveStart) / Math.max(0.05, bEnd - leaveStart)); start = a;
        html = tr(typeof h === 'function' ? h(clamp((t - a) / Math.max(0.1, b - a - 0.45))) : h);
        seen = firstSeen(id, a, b, h);
      });
      if (html !== shown && html !== null) { el.innerHTML = html; shown = html; items = [...el.querySelectorAll(ITEMS)]; }
      const k = html === null ? 0 : Math.min(inn * 2, 1) * (1 - leave);
      const shake = el.querySelector('.alert') ? Math.sin((t - start) * 46) * 7 * clamp(1 - (t - start) / 0.5) * (t > start ? 1 : 0) : 0;
      el.style.opacity = k.toFixed(3);
      el.style.transform = `translateX(${((AR ? -1 : 1) * ((1 - backOut(inn)) * 90 - leave * 110 + shake)).toFixed(1)}px) rotate(${((1 - inn) * (AR ? -2.5 : 2.5)).toFixed(2)}deg)`;
      this.active = k > 0.02;
      if (!seen) return;
      for (const n of items) {
        const t0 = seen.get(n.textContent) ?? start, u = clamp((t - t0) / 0.28);
        n.style.opacity = clamp(u * 2.4).toFixed(3);
        n.style.transform = `translateX(${((1 - backOut(u)) * (AR ? 16 : -16)).toFixed(1)}px)`;
        const hit = clamp(1 - (t - t0 - 0.2) / 0.5);
        const glow = n.classList.contains('no') ? '198,84,59' : n.classList.contains('ok') ? '47,116,119' : n.classList.contains('hi') ? '47,58,99' : n.classList.contains('warn') || n.classList.contains('wait') ? '215,140,34' : '';
        n.style.boxShadow = glow && hit > 0 && u > 0.4 ? `0 0 0 ${(hit * 7).toFixed(1)}px rgba(${glow},${(hit * 0.4).toFixed(2)})` : '';
        const m = n.querySelector(':scope > .mk');
        if (m) m.style.transform = `scale(${pop(clamp((t - t0 - 0.22) / 0.5)).toFixed(3)})`;
      }
    },
  };
}
