// When a tool says "maybe"
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["admin", "maya", "lena", "official", "citizen"];
export default chapterHall((S, E, D) => ({
  lesson: "3.2",
  actors: { admin: 'desk', maya: 'beside', lena: 'aisle', official: 'office', citizen: 'door' },
  enter: { citizen: D.T },
  shots: [[0,'pair'], [S(1),'display'], [S(4),'pair'], [S(5),'display'], [S(7),'pair'], [S(12),'door']],
  actions: { admin: [[0,S(5),'read'], [S(5),S(7),'type'], [S(7),D.T,'listen','maya']], maya: [[0,S(7),'listen','admin'], [S(7),E(7),'talk','admin'], [S(12),D.T,'listen','official']], lena: [[0,S(12),'listen','admin'], [S(12),D.T,'listen','official']], official: [[0,S(12),'listen','admin'], [S(12),D.T,'talk','maya']] },
  setupProps: evidence({
    surfaces: { desk: [[0,S(5),'counterVideo','Possibly manipulated'], [S(5),D.T,'cameraLog','Video and camera footage']] },
    inserts: [[S(1),E(1),'desk'], [S(6),E(6),'desk']],
  }),
  plates: [[S(1),E(1),'Possibly manipulated'], [S(6),E(6),'Original camera footage'], [S(11),E(11),'Approved tools only']],
  screens: [
    [S(1), S(2), win('Detection tool', row('File', 'counter_clip.mp4', 'hi') + row('Result', 'Possibly manipulated', 'warn') + note('Uncertain result · Needs source check.', 'warn'))],
    [S(6), S(8), q => win('Original camera footage', reveal([
      row('Location', 'Hall counter · Camera 2', 'ok'),
      row('Record', 'Normal counter service', 'ok'),
      row('Envelope / visitor', 'None present', 'ok'),
      note('Original footage shows it never happened.'),
    ], q), 'good')],
  ],
  pages: [
    hero(S(2), S(5), "Detection tools can be wrong", "made/laptop+zoom", [
      ["Human review", S(4), "v-teal"],
    ]),
    hero(S(5), S(6), "Go back to the original source", "made/cctv_camera+made/register_book", [
      ["Original camera footage", S(5), "v-teal"],
    ]),
    hero(S(13), D.T, "Pause, verify, report", "made/cctv_camera+file-text+mobile", [
      ["Check the original", S(14), "v-teal"],
      ["Report early", S(15), "v-teal"],
    ]),
  ],
}));
