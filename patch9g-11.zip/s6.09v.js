// The part nobody checked.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'official', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '6.3',
  actors: { omar: 'colleague', official: 'director', maya: 'counter' },
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'gathering'], [S(3), 'her'], [S(13), 'counterDisplay'], [S(14), 'gathering']],
  actions: {
    omar: [[0, S(2), 'point'], [S(2), S(13), 'paper'], [S(13), S(14), 'listen', 'official'], [S(14), D.T, 'listen', 'maya']],
    official: [[0, S(2), 'listen', 'omar'], [S(2), S(4), 'talk', 'omar'], [S(4), S(13), 'listen', 'omar'], [S(13), D.T, 'talk', 'omar']],
    maya: [[0, S(2), 'read'], [S(2), S(13), 'listen', 'official'], [S(13), D.T, 'type']],
  },
  displays: {
    counter: [
      [0, S(13), 'link', 'Unfamiliar email add-on', 'alert'],
      [S(13), S(14), 'folder', 'Parts list · Owner and version', 'safe'],
      [S(14), D.T, 'bell', 'Add-on reported · Mail logs checked', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Unfamiliar email add-on'],
    [S(2), E(2), 'Who installed, published, approved it?'],
    [S(13), E(13), 'Add-on removed · Parts listed'],
    [S(14), E(14), 'Add-on reported · Mail logs checked'],
  ],
  screens: [
    [S(0), S(2), q => win('Assistant settings · Add-ons', reveal([
      row('Add-on', 'QuickMail Templates', 'warn'),
      row('Permission', 'Send emails from templates', 'no'),
      row('Who requested it', 'Nobody in the hall', 'no'),
      note('Unfamiliar add-on on counter laptop.', 'no'),
    ], q), 'alert')],
    [S(2), S(3), win('Add-on check', row('Who installed it?', 'Unknown', 'no') + row('Who published it?', 'Unknown', 'no') + row('Who approved it?', 'Not on approved list', 'no'), 'alert')],
  ],
  pages: [
    hero(S(3), S(6), 'Every part is a link in the chain', 'made/supplier_truck+made/own_link+made/own_computer', [
      ['Model, provider, add-ons and libraries', S(3), 'v-navy'],
      ['A weak outside link can weaken the Authority', S(4), 'v-amber'],
    ]),
    hero(S(6), S(10), 'Harmful add-ons and models', 'made/parcel+made/own_mail', [
      ['Look-alike add-on silently copied emails', S(7), 'v-coral'],
      ['Untrusted models can run hidden code', S(9), 'v-coral'],
    ]),
    hero(S(10), S(14), 'Add-ons and models: known source, approved, listed', 'made/register_book+made/rubber_stamp', [
      ['Only IT loads models in isolated tests', S(10), 'v-teal'],
      ['Keep a record of AI parts and owners', S(11), 'v-navy'],
    ]),
    hero(S(14), D.T, 'An add-on nobody asked for: stop and report', 'made/own_link+made/own_bell', [
      ['Report it; IT checks the logs', S(14), 'v-teal'],
      ['Never install unapproved tools or models', S(15), 'v-amber'],
    ]),
  ],
}));
