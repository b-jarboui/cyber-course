// A second lock that cannot be fooled.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.1',
  actors: { maya: 'desk', omar: 'beside' },
  handsets: { omar: [[0, S(8), 'chat'], [S(8), D.T, 'lock']] },
  shots: [[0, 'pair'], [S(1), 'desk'], [S(5), 'pair'], [S(8), 'display'], [S(9), 'desk'], [S(13), 'pair']],
  actions: {
    omar: [[0, S(4), 'text'], [S(4), S(8), 'talk', 'maya'], [S(8), D.T, 'listen', 'maya']],
    maya: [[0, S(8), 'listen', 'omar'], [S(8), S(11), 'type'], [S(11), S(13), 'read'], [S(13), D.T, 'talk', 'omar']],
  },
  displays: {
    desk: [[0, S(8), 'chat', 'Text-message code', 'neutral', 'login'], [S(8), S(13), 'key', 'Passkey sign-in', 'safe', 'login'], [S(13), D.T, 'shield', 'Official IT channel', 'safe']],
  },
  plates: [[S(0), E(0), 'Text-message code'], [S(8), E(8), 'Passkey sign-in'], [S(13), E(13), 'Official IT channel']],
  screens: [
    [S(0), S(1), phone('Text message', row('Sender', 'Sadeed Sign-in') + row('Code', '482 910', 'warn') + note('Do not share this code with anyone.', 'warn'))],
    [S(8), S(9), win('portal.sadeed.gov.example', row('Method', 'Passkey · Fingerprint', 'ok') + row('Site check', 'Genuine address matched', 'ok') + note('No password or code to type.'), 'good')],
  ],
  pages: [
    hero(S(1), S(5), 'Multi-factor authentication', 'lock+mobile+key', [
      ['Password plus a second check', S(2), 'v-teal'],
      ['Can stop over 99% of identity attacks', S(3), 'v-navy'],
    ]),
    hero(S(5), S(8), 'Never share a code', 'chat+mobile+lock', [
      ['Text codes are the weakest form', S(5), 'v-amber'],
      ['For you alone', S(7), 'v-teal'],
    ]),
    hero(S(9), S(13), 'Passkey: bound to the real site', 'made/laptop+key+shield', [
      ['Phishing-resistant sign-in', S(10), 'v-teal'],
      ['Faster and more reliable', S(12), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Report through the approved route', 'mobile+bell', [
      ['Refuse any request for a code', S(14), 'v-teal'],
    ]),
  ],
}));
