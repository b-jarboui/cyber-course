// One password, two accounts.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.1',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[S(0), E(0), 0, 1]],
  handsets: { omar: [[S(6), S(15), 'lock'], [S(15), D.T, 'key']] },
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(6), 'staff'], [S(9), 'her'], [S(12), 'staff'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(2), 'type'], [S(2), S(6), 'read'], [S(6), S(15), 'listen', 'omar'], [S(15), D.T, 'read']],
    omar: [[0, S(6), 'listen', 'maya'], [S(6), S(8), 'text'], [S(8), S(15), 'talk', 'maya'], [S(15), D.T, 'text']],
  },
  displays: {
    counter: [[0, S(2), 'lock', 'Sign in', 'neutral', 'login'], [S(2), S(15), 'folder', 'Case 2048', 'safe'], [S(15), D.T, 'key', 'Password manager', 'safe']],
  },
  plates: [[S(0), E(0), 'Case 2048'], [S(6), E(6), 'Same password reused'], [S(15), E(15), 'Change planned today']],
  screens: [
    [S(1), S(2), win('Sign in', row('Username', 'shaima@sadeed.gov.example') + row('Password', '••••••••••••', 'ok') + row('Second check', 'Approved', 'ok'), 'good')],
    [S(6), S(7), phone('Saved passwords', row('sadeed.gov.example', '••••••••', 'no') + row('shop-deals.example', '••••••••', 'no') + note('Same password used on both sites.', 'no'))],
    [S(15), E(15), win('Password manager', row('Work account', 'Reused password', 'warn') + row('Next step', 'Change today', 'wait'))],
  ],
  pages: [
    hero(S(2), S(6), 'Authentication: proving it is you', 'lock+made/id_badge', [
      ['Username, password and second check', S(2), 'v-teal'],
      ['Digital identity: a valuable asset', S(4), 'v-navy'],
    ]),
    hero(S(7), S(12), 'One account, one password', 'key+made/key_cabinet', [
      ['Long, unique passphrase', S(9), 'v-teal'],
      ['Checked against leaked passwords', S(11), 'v-navy'],
    ]),
    hero(S(12), S(14), 'Approved password manager', 'made/safe+key', [
      ['Different password for every account', S(12), 'v-teal'],
      ['Never share your password', S(13), 'v-amber'],
    ]),
    hero(S(14), S(15), 'Exposed? Change it and report it', 'lock+bell', [
      ['Change and report at once', S(14), 'v-teal'],
    ]),
  ],
}));
