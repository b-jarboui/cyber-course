// Old passwords, new attempts.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar', 'priya', 'lena'];
export default chapterHall((S, E, D) => ({
  lesson: '4.2',
  actors: { official: 'director', maya: 'counter', omar: 'colleague', priya: 'team', lena: 'teamEnd' },
  shots: [[0, 'gathering'], [S(1), 'counterDisplay'], [S(2), 'gathering'], [S(5), 'staff'], [S(9), 'gathering'], [S(13), 'counterDisplay'], [S(14), 'gathering']],
  actions: {
    official: [[0, S(5), 'talk', 'maya'], [S(5), S(6), 'listen', 'omar'], [S(6), D.T, 'talk', 'maya']],
    maya: [[0, S(1), 'listen', 'official'], [S(1), S(2), 'read'], [S(2), D.T, 'listen', 'official']],
    omar: [[0, S(5), 'listen', 'official'], [S(5), E(5), 'talk', 'official'], [S(6), D.T, 'listen', 'official']],
    priya: [[0, D.T, 'listen', 'official']],
    lena: [[0, D.T, 'listen', 'official']],
  },
  displays: {
    counter: [[0, S(10), 'bell', 'Failed sign-in attempts', 'alert'], [S(10), S(13), 'shield', 'Unique password and second check', 'safe'], [S(13), D.T, 'bell', 'Report odd sign-in alerts', 'safe']],
  },
  plates: [[S(0), E(0), 'Hamad · Manager'], [S(1), E(1), 'Failed sign-in attempts'], [S(5), E(5), 'Work password already changed'], [S(12), E(12), 'Approved work devices']],
  screens: [
    [S(1), S(2), win('IT Security Notice', row('Overnight activity', 'Thousands of failed sign-ins', 'no') + row('Target', 'Staff accounts', 'warn') + note('Report any odd alerts at once.', 'warn'), 'alert')],
  ],
  pages: [
    hero(S(2), S(4), 'Leaked passwords are tried everywhere', 'key+made/key_cabinet', [
      ['Credential stuffing', S(3), 'v-amber'],
    ]),
    hero(S(4), S(10), 'Common passwords tried on many accounts', 'lock+computer+bell', [
      ['Password spraying', S(4), 'v-amber'],
      ['Password-stealing malware', S(6), 'v-coral'],
    ]),
    hero(S(11), D.T, 'Odd sign-in alert? Report it', 'bell+shield', [
      ['Approved devices only', S(12), 'v-teal'],
      ['Authorized team investigates', S(14), 'v-teal'],
    ]),
  ],
}));
