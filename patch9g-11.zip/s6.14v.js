// The agent proposes, a person decides.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar', 'admin'];
export default chapterHall((S, E, D) => ({
  lesson: '6.4',
  actors: { official: 'director', maya: 'counter', omar: 'colleague', admin: 'team' },
  file: [[0, S(15), 1, 1], [S(15), E(15), 1, 0]],
  shots: [[0, 'gathering'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(3), 'staff'], [S(4), 'gathering'], [S(7), 'counter'], [S(10), 'counterDisplay'], [S(11), 'gathering'], [S(15), 'file']],
  actions: {
    official: [[0, S(7), 'paper'], [S(7), S(10), 'talk', 'maya'], [S(10), S(15), 'listen', 'admin'], [S(15), D.T, 'listen', 'maya']],
    maya: [[0, S(7), 'read'], [S(7), S(10), 'listen', 'official'], [S(10), S(15), 'read'], [S(15), D.T, 'file']],
    omar: [[0, S(10), 'listen', 'official'], [S(10), D.T, 'listen', 'admin']],
    admin: [[0, S(10), 'listen', 'official'], [S(10), S(15), 'talk', 'official'], [S(15), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'file', 'Pilot week 1 · Review log', 'neutral'],
      [S(1), S(2), 'folder', 'Mark Case 2048 complete', 'alert'],
      [S(2), S(10), 'key', 'Status change refused', 'safe'],
      [S(10), S(15), 'bell', 'Stop control · Cut access', 'safe'],
      [S(15), D.T, 'folder', 'Next case', 'neutral'],
    ],
  },
  plates: [
    [S(0), E(0), 'Pilot week 1 review'],
    [S(1), E(1), 'Tried to set file status to complete'],
    [S(2), E(2), 'Refused · Named staff approval required'],
    [S(10), E(10), 'Stop control cuts agent access'],
    [S(15), E(15), 'Next case'],
  ],
  screens: [
    [S(1), S(3), q => win('Pilot agent 1 · Week 1 log', reveal([
      row('Action tried', 'Mark Case 2048 complete', 'warn'),
      row('Missing document', '1 document still missing', 'no'),
      row('System check', 'Refused · Named staff approval required', 'ok'),
      row('Case 2048', 'Stayed open', 'ok'),
    ], q), 'alert')],
    [S(3), S(4), win('Log review · Cause', row('Hidden text', 'None found', 'ok') + row('Attacker', 'No sign of attack', 'ok') + row('Cause', 'Agent tried to go beyond its task', 'warn'))],
  ],
  pages: [
    hero(S(4), S(7), 'Unauthorized autonomous action', 'made/own_computer+made/padlock_open', [
      ['Agents can act beyond intent without attackers', S(5), 'v-coral'],
      ['Unsanctioned agent actions happen in practice', S(6), 'v-amber'],
    ]),
    hero(S(7), S(11), 'The agent proposes; a named person decides', 'made/rubber_stamp+made/register_book', [
      ['Staff approve send, pay, delete or status changes', S(7), 'v-teal'],
      ['Log it, watch it, be able to stop it', S(9), 'v-navy'],
    ]),
    hero(S(11), S(14), 'Three chapter habits', 'made/id_badge+made/key_cabinet+made/safe', [
      ['Outside content: check it, never obey it', S(11), 'v-teal'],
      ['Approved AI only, own account, least access', S(12), 'v-navy'],
      ['AI prepares; a named person decides', S(13), 'v-amber'],
    ]),
    hero(S(14), S(15), 'Stop, verify, report', 'made/own_bell+made/register_book', [
      ['Report unexpected AI behavior early', S(14), 'v-teal'],
      ['AI agents help only while people stay in charge', (S(14) + E(14)) / 2, 'v-teal'],
    ]),
  ],
}));
