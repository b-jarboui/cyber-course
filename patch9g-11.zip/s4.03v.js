// Ten requests he never made.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '4.1',
  actors: { omar: 'desk', maya: 'beside' },
  landline: 'desk',
  handsets: { omar: [[0, S(11), 'bell'], [S(11), S(12), 'shield']] },
  shots: [[0, 'desk'], [S(1), 'pair'], [S(2), 'desk'], [S(6), 'pair'], [S(11), 'desk'], [S(12), 'display'], [S(13), 'pair']],
  actions: {
    omar: [[0, S(4), 'text'], [S(4), S(11), 'read'], [S(11), S(12), 'text'], [S(12), S(14), 'extension'], [S(14), D.T, 'type']],
    maya: [[0, S(11), 'listen', 'omar'], [S(11), S(12), 'talk', 'omar'], [S(12), D.T, 'listen', 'omar']],
  },
  displays: {
    desk: [[0, S(11), 'bell', 'Sign-in approval request', 'alert'], [S(11), S(12), 'shield', 'Request denied', 'safe'], [S(12), D.T, 'mobile', 'Staff directory', 'safe']],
  },
  plates: [[S(0), E(0), 'Sign-in approval request'], [S(2), E(2), 'Repeated requests'], [S(11), E(11), 'Request denied'], [S(12), E(12), 'Staff directory']],
  screens: [
    [S(0), S(2), phone('Sign-in approval', row('Account', 'omar@sadeed.gov.example') + row('Action', 'Approve sign-in?', 'warn') + note('Omar is not signing in.', 'no'))],
    [S(2), S(3), q => phone('Sign-in approval', reveal([
      row('Request 2', 'Approve sign-in?', 'no'),
      row('Request 3', 'Approve sign-in?', 'no'),
      row('Request 10', 'Approve sign-in?', 'no'),
      note('Repeated unexpected prompts.', 'no'),
    ], q))],
    [S(11), S(13), q => win('Staff directory', reveal([
      row('Sign-in requests', 'All denied', 'ok'),
      row('IT service desk', 'Ext. 4100', 'ok'),
      note('Called from directory, not a message.'),
    ], q), 'good')],
  ],
  pages: [
    hero(S(3), S(5), "You didn't sign in? Don't approve", 'mobile+lock', [
      ['Password may be compromised', S(3), 'v-amber'],
    ]),
    hero(S(5), S(11), 'Many approval requests in a row', 'mobile+bell+clock', [
      ['Authentication fatigue', S(5), 'v-amber'],
      ['Number matching and passkeys help', S(9), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Choose deny, then report', 'shield+made/register_book+bell', [
      ['Call from the staff directory', S(13), 'v-teal'],
      ['Report immediately', S(14), 'v-teal'],
    ]),
  ],
}));
