// A sticker on the poster, an advert at the top.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'citizen', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { maya: 'counter', citizen: 'visitor', omar: 'desk' },
  poster: true,
  walks: { maya: [[S(1),E(1),'inspect'], [S(7),E(7),'counter']] },
  shots: [[0,'counter'], [S(1),'poster'], [S(3),'counter'], [S(5),'her'], [S(6),'poster'], [S(9),'desk'], [S(10),'display'], [S(12),'desk']],
  actions: {
    citizen: [[0,S(1),'talk','maya'], [S(1),E(2),'point'], [S(5),E(5),'listen','maya']],
    maya: [[0,S(2),'listen','citizen'], [S(2),S(5),'check'], [S(5),E(5),'paper'], [S(6),E(6),'photo']],
    omar: [[S(9),S(10),'type'], [S(10),S(13),'read'], [S(13),D.T,'type']],
  },
  displays: { desk: [[S(9),S(13),'zoom','Sponsored result','alert'], [S(13),D.T,'credit-card','Saved payment portal','safe']] },
  plates: [[S(1),E(1),'Fee payment'], [S(2),E(2),'Lifted corners'], [S(5),E(5),'Official payment address'], [S(10),E(10),'Sponsored result']],
  screens: [
    [S(5), S(6), win('Official payment address', row('Official address', 'pay.sadeed.gov.example', 'ok') + note('Type or save the official address.'), 'good')],
    [S(10), S(11), win('Web search', row('Ad · pay.sadeeed.gov.example', 'Sponsored', 'no') + row('pay.sadeed.gov.example', 'Official', 'ok') + note('One extra letter in the advert.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(3), S(5), 'A sticker over a code is a warning sign', 'file-text+zoom', [
      ['Lifted corners', S(3), 'v-amber'],
      ['Printed payment code', S(4), 'v-teal'],
    ]),
    hero(S(7), S(9), 'QR code by email? Verify first', 'mail+mobile+link', [
      ['Check before scanning', S(7), 'v-teal'],
    ]),
    hero(S(11), S(12), 'Adverts can copy official sites', 'computer+money', [
      ['Sponsored result', S(11), 'v-amber'],
    ]),
    hero(S(13), D.T, 'Use the saved official address', 'made/laptop+link', [
      ['Saved payment portal', S(13), 'v-teal'],
      ['Entered details? Report it', S(14), 'v-teal'],
    ]),
  ],
}));
