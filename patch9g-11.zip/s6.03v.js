// Not everything it reads is an instruction.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, mail, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '6.1',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[S(10), E(10), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'staff'], [S(3), 'her'], [S(10), 'counter'], [S(11), 'staff'], [S(14), 'counter']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(10), 'listen', 'omar'], [S(10), S(14), 'read'], [S(14), D.T, 'listen', 'omar']],
    omar: [[0, S(2), 'listen', 'maya'], [S(2), S(10), 'paper'], [S(10), S(14), 'listen', 'maya'], [S(14), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'mail', 'Outside email · Attachment', 'alert', 'inbox'],
      [S(1), S(10), 'computer', 'AI summary requested', 'neutral'],
      [S(10), D.T, 'file', 'Facts checked against case record', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Outside email · Attachment'],
    [S(2), E(2), 'Trust boundary'],
    [S(10), E(10), 'Draft checked against case record'],
    [S(14), E(14), 'Shared responsibility'],
  ],
  screens: [
    [S(0), S(1), win('Inbox', mail('External Sender', 'docs@external-mail.example', 'Case 2048 — Supporting file', 'Please find the attached note for Case 2048.'), 'alert')],
    [S(1), S(3), q => win('Trust boundary', reveal([
      row('Inside the line', 'Authority rules & approved tools', 'ok'),
      row('Outside the line', 'External email & attachment', 'warn'),
      note('Outside content is untrusted.', 'warn'),
    ], q))],
    [S(10), S(11), win('Case 2048 · Fact check', row('AI summary', 'Treated as draft', 'ok') + row('Official case record', 'Facts checked by Shaima', 'ok') + note('Key facts verified against the case record.'), 'good')],
  ],
  pages: [
    hero(S(3), S(7), 'Inside: Authority-controlled. Outside: untrusted', 'made/own_mail+made/case_folder+made/signpost', [
      ['Emails, attachments and web pages are outside', S(4), 'v-amber'],
      ['Untrusted means unchecked by the Authority', S(6), 'v-navy'],
    ]),
    hero(S(7), S(10), "A model can't reliably tell instructions from data", 'made/own_computer+made/own_file', [
      ['Hidden words in a page can steer the model', S(8), 'v-coral'],
      ['Controls limit what the assistant can do', S(9), 'v-teal'],
    ]),
    hero(S(11), S(14), 'Responsibility is shared, and you own your part', 'made/balance_scale+made/id_badge', [
      ['Authority stays responsible for data and accounts', S(11), 'v-teal'],
      ['63% had no AI policy, or were still writing one', S(13), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Your part every day', 'made/register_book+made/own_bell', [
      ['Treat outside content as untrusted; check drafts', S(14), 'v-teal'],
      ['Odd instruction? Stop, verify and report', S(15), 'v-amber'],
    ]),
  ],
}));
