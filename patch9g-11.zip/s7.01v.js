// A free viewer, a quiet thief.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.1',
  actors: { maya: 'counter', omar: 'aisle' },
  walks: { omar: [[S(3), E(3), 'colleague']] },
  file: [[0, E(0), 0, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(3), 'hall'], [S(4), 'staff'], [S(5), 'her'], [S(14), 'counter'], [S(15), 'counterDisplay']],
  actions: {
    maya: [[0, S(1), 'file'], [S(1), S(3), 'read'], [S(3), S(4), 'talk', 'omar'], [S(4), S(14), 'listen', 'omar'], [S(14), S(15), 'extension'], [S(15), D.T, 'type']],
    omar: [[0, S(3), 'listen', 'maya'], [S(4), S(14), 'talk', 'maya'], [S(14), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'file', 'Case 2048 · Cannot open', 'neutral'],
      [S(2), S(14), 'link', 'Free viewer · Copy command', 'alert'],
      [S(14), D.T, 'bell', 'Pages closed · IT asked', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048'],
    [S(2), E(2), 'Free viewer · Fake check'],
    [S(14), E(14), 'Pages closed · IT asked'],
    [S(15), E(15), 'Stop and report'],
  ],
  screens: [
    [S(1), S(2), win('Case 2048', row('Scanned page', 'Cannot open on this laptop', 'warn') + note('Needs an approved file viewer.'))],
    [S(2), S(4), q => win('free-doc-viewer.example', reveal([row('Page 1', 'Download free viewer', 'warn'), row('Page 2', 'Prove you are not a robot', 'warn'), row('Paste line', '••••••', 'no'), note('Asks to paste into a system window.', 'no')], q), 'alert')],
    [S(14), S(15), win('IT Service Desk · Directory', row('Contact', 'Known IT extension · 4100', 'ok') + row('Web pages', 'Closed · Nothing clicked', 'ok') + row('Request', 'Approved viewer for Case 2048', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(5), 'Malware', 'made/ransom_laptop+made/own_warning_beacon', [
      ['Software made to harm devices or data', S(4), 'v-coral'],
    ]),
    hero(S(5), S(11), 'Information stealer', 'made/own_key+made/own_file+made/ransom_laptop', [
      ['Quietly steals logins, passwords and files', S(5), 'v-coral'],
      ['Spreads via email, fake checks, fake software', S(8), 'v-amber'],
    ]),
    hero(S(11), S(14), 'Approved software only', 'made/rubber_stamp+made/laptop', [
      ['Over 85% of fake apps copy known ones', S(11), 'v-amber'],
      ['Install approved software; never paste commands', S(13), 'v-teal'],
    ]),
    hero(S(15), D.T, 'Stop and report', 'made/own_desk_phone+made/own_bell', [
      ['Ask IT via a known contact for tools', S(15), 'v-teal'],
      ['Clicked or installed? Report at once', (S(15) + E(15)) / 2, 'v-coral'],
    ]),
  ],
}));
