// Chapter 2 uses the same building, cast library, camera and bilingual hero pages as Chapter 1.
import { THREE, C, V, mesh, rbox, group, laptop, folder, canvasTex, ramp } from './kit.js';
import { createPerson, loadMotion } from './people.js';
import { workplace, typing } from './sets.js';
import { SHOTS } from './story.js';
import { frameShots, quietScreens } from './astra.js';
import { restoreTeachingTable } from './v1-set.js';
import { createBoard } from './board.js';
import { concept, readyPages, seekPages } from './library-pages.js';
import { AR, tr, trTemplate } from './i18n.js';
import { iconSrc } from './own-art.js';
import './pages-l2.js';

// A place gives the actor's feet and facing direction. The work desk is Omar's usual desk.
const places = {
  inspect: [-2.68, -.10, 1.5], signer: [-1.38, -.15, -1.55], counterEnd: [-1.38, -1.12, 1.5],
  counter: [-2.82, -.42, 1.55], colleague: [-3.22, .27, 2.18], visitor: [-1.28, -.14, -1.67],
  deskGuest: [1.83, -2.08, 1.93],
  desk: [3.2, -2.5, -1.45], beside: [3.05, -1.12, -2.69] /* was 2.76,-1.68: inside the desk top (Bassem 2026-11-22) */, aisle: [1.44, -.98, 2.45],
  door: [1.48, -3.78, .24], office: [1.05, -3.07, 2.57], exit: [.48, -.44, 1.55],
  director: [-3.52, -.88, .95], team: [-1.38, .67, -1.96], teamEnd: [-.57, -.59, -1.22],
};
const shots = { ...SHOTS,
  desk: { x: 2.9, y: 1.03, z: -2.4, w: 2.05, e: .48, f: .47 },
  finance: { x: 2.74, y: 1.42, z: -1.66, w: 1.54, e: .44, f: .50 },
  counterDisplay: { x: -2.30, y: 1.26, z: -.62, w: 1.03, e: .57, f: .51 },
  pair: { x: 2.62, y: 1.14, z: -2.06, w: 2.68, e: .5, f: .47 },
  display: { x: 2.64, y: .97, z: -2.43, w: 1.05, e: .65, f: .49 },
  file: { x: -2.17, y: 1.1, z: -.08, w: 1.52, e: .82, f: .51 },
  poster: { x: -1.92, y: 1.32, z: -.05, w: 1.35, e: .55, f: .48 },
  door: { x: 1.32, y: 1.19, z: -3.4, w: 2.8, e: .48, f: .47 },
  gathering: { x: -2.18, y: 1.2, z: -.32, w: 4.55, e: .54, f: .47 },
  habits: { x: -4.82, y: 1.92, z: -.57, w: 2.35, e: .32, f: .5 },
};
const active = (rows, t) => rows?.find(([a,z]) => a <= t && t < z);
const female = role => role === 'maya' || role === 'finance' || role === 'priya' || role === 'lena' || role === 'comms';
const neutral = role => (female(role) ? 'f' : 'm') + '_idle_neutral_01';
const seated = role => (female(role) ? 'f' : 'm') + '_sit_table_idle_neutral_01';

export const hero = (a, z, title, art, lines) => ({ a, z, scene: 'hero', cues: { title, art, lines } });

function putInk(parent, w, h, x, y, z, tex) {
  const ink = new THREE.Mesh(new THREE.PlaneGeometry(w,h), new THREE.MeshBasicMaterial({map:tex, toneMapped:false}));
  ink.position.set(x,y,z); parent.add(ink);
  return ink;
}
const swatch = { alert:'#b8503c', safe:'#28746e', neutral:'#34466a' };
// In-world screens carry the message being discussed. Use the same short label on the plate.
function displayTexture(icon, label, tone, type) {
  return canvasTex(640,360,(g,w,h) => {
    const colour = swatch[tone] || swatch.neutral;
    g.fillStyle = '#faf7ef'; g.fillRect(0,0,w,h);
    g.fillStyle = colour; g.fillRect(0,0,w,41);
    g.fillStyle = '#fff'; for (const x of [19,37,55]) { g.beginPath(); g.arc(AR?w-x:x,21,4,0,Math.PI*2); g.fill(); }
    g.drawImage(icon, AR?456:20,64,158,158);
    g.direction = AR?'rtl':'ltr'; g.textAlign = AR?'right':'left'; g.fillStyle = '#26305a';
    g.font='bold 34px "Segoe UI",Arial,sans-serif'; g.fillText(tr(label),AR?446:194,126,420);
    const left=AR?44:194;
    g.fillStyle='#bbc7ca'; g.fillRect(left,153,388,8); g.fillRect(left,176,278,8);
    if(type==='login') {
      g.strokeStyle=colour; g.lineWidth=4;
      for(const y of [218,275]) { g.strokeRect(left,y,300,34); g.fillStyle='#b2bfca'; g.fillRect(left+18,y+14,144,6); }
    } else if(type==='inbox') {
      for(let i=0;i<4;i++){g.fillStyle=i%2?'#cbd7dc':'#e2e8e6';g.fillRect(22,214+i*32,596,24);}
    } else {
      g.fillStyle=colour; g.fillRect(left,225,230,54); g.fillStyle='#fff'; g.fillRect(left+22,249,146,7);
    }
  });
}
async function iconImage(name) {
  const image = new Image(); image.src = new URL('./assets/2d/'+iconSrc(name)+(iconSrc(name).startsWith('made/')?'.webp':'.png'),import.meta.url).href;
  await image.decode(); return image;
}

function paymentPoster(scene) {
  const g=group(scene,-2.04,1.055,-.05); g.rotation.y=.85;
  mesh(rbox(.46,.025,.24),C.navy,0,.013,0,g);
  mesh(rbox(.44,.50,.026),C.paper,0,.25,0,g);
  // Two non-scannable printed motifs. The raised corner casts a separate shadow.
  function code(seed) {
    return canvasTex(168,168,ctx=>{
      ctx.fillStyle='#fff'; ctx.fillRect(0,0,168,168); ctx.fillStyle='#253457';
      for(let y=1;y<20;y++) for(let x=1;x<20;x++) if((x*11+y*7+x*y+seed)%9<4)ctx.fillRect(x*8,y*8,8,8);
      for(const [x,y] of [[8,8],[112,8],[8,112]]) {ctx.fillStyle='#253457';ctx.fillRect(x,y,48,48);ctx.fillStyle='#fff';ctx.fillRect(x+8,y+8,32,32);ctx.fillStyle='#253457';ctx.fillRect(x+16,y+16,16,16);}
    });
  }
  putInk(g,.31,.31,0,.26,.014,code(1));
  const sticker=group(g,.017,.27,.018);sticker.rotation.z=-.075;
  mesh(rbox(.295,.295,.006,.002),C.paper,0,0,0,sticker);
  putInk(sticker,.282,.282,0,0,.004,code(4));
  const curl=mesh(rbox(.069,.055,.004,.001),'#e1d5b6',.113,.124,.022,sticker);
  curl.rotation.x=.67;
}
async function habitsBoard(scene) {
  const images=await Promise.all(['zoom','lock','computer','bell'].map(iconImage));
  const g=group(scene,-4.96,1.99,-.58); g.rotation.y=Math.PI/2;
  mesh(rbox(2.0,.53,.05),C.navy,0,0,0,g);
  const texture=canvasTex(1000,250,ctx=>{
    ctx.fillStyle='#fffdf8';ctx.fillRect(0,0,1000,250);
    const origin=i=>(AR?4-i:i)*194+26;
    ctx.fillStyle='#315866';
    for(const dx of [45,92]) ctx.fillRect(origin(0)+dx,73,27,92);
    images.forEach((img,i)=>ctx.drawImage(img,origin(i+1),38,164,164));
  });
  putInk(g,1.94,.47,0,0,.027,texture);
}
function mobile(scene) {
  const p=group(scene);
  mesh(rbox(.079,.154,.012,.007),C.dark,0,0,0,p);
  p.userData.screen=putInk(p,.069,.133,0,.002,.007,null);
  p.userData.screen.material.color.set('#adcbd5');
  return p;
}

function deskPhone(scene) {
  const dock=group(scene,-2.38,1.055,.34); dock.rotation.y=-.65;
  mesh(rbox(.21,.037,.17,.012),C.dark,0,.023,0,dock);
  for(const x of [-.022,.009,.04]) for(const z of [-.038,-.01,.018,.046])
    mesh(rbox(.022,.005,.018,.003),C.metal, x,.044,z,dock);
  const receiver=group(scene);
  mesh(rbox(.035,.16,.023,.012),C.navy,0,0,0,receiver);
  for(const y of [-.073,.073]) mesh(rbox(.06,.047,.042,.013),C.dark,0,y,.012,receiver);
  return {dock,receiver};
}
function restReceiver(phone) {
  const {dock,receiver}=phone;
  receiver.position.copy(dock.localToWorld(V(-.074,.059,0)));
  receiver.rotation.set(Math.PI/2,dock.rotation.y,0,'YXZ');
}

export function chapterHall(describe) {
  return async ({stage,scene,createCounter,S,E,D,ui})=>{
    const c=describe(S,E,D), roles=Object.keys(c.actors);
    const motions=new Set(roles.flatMap(r=>[neutral(r),seated(r)]));
    for(const [role,rows] of Object.entries(c.actions||{})) for(const [, , action] of rows) {
      if(action==='talk') motions.add((female(role)?'f':'m')+'_gestic_talk_neutral_01');
    }
    await loadMotion([...motions]);
    createCounter(scene,false); await restoreTeachingTable(scene);
    const counterLaptop=laptop(scene,-2.34,1.055,-.52,-.45,1.17);
    const work=workplace(scene,...places.desk);
    const devices={counter:counterLaptop.userData.screen,desk:work.laptop.userData.screen};
    const record=folder(scene,c.signing ? -2.03 : -2.30,1.057,.04,.88); record.visible=!!c.file;
    const inkPen=mesh(rbox(.012,.012,.15,.005),C.navy,-2.15,1.09,.06,scene);
    inkPen.visible=false;
    if(c.poster) paymentPoster(scene);
    if(c.habits) await habitsBoard(scene);
    const states=[];
    for(const [device,rows] of Object.entries(c.displays||{})) {
      const screen=devices[device], idle=screen.material.clone();
      const views=await Promise.all(rows.map(async ([a,z,icon,label,tone,type])=>{
        const map=displayTexture(await iconImage(icon),label,tone,type);
        return [a,z,new THREE.MeshBasicMaterial({map,toneMapped:false})];
      }));
      states.push(t=>{screen.material=active(views,t)?.[2]||idle;});
    }
    const landline=c.landline ? deskPhone(scene) : null;
    if (c.landline === 'desk') {
      landline.dock.position.copy(work.desk.localToWorld(V(.47,.78,-.07)));
      landline.dock.rotation.y = work.desk.rotation.y;
    }
    const actors={}, phones={}, sheets={};
    for(const role of roles) {
      actors[role]=createPerson(role,scene);
      const actions=c.actions?.[role]||[];
      if(actions.some(x=>['call','text','photo','dial'].includes(x[2]))) phones[role]=mobile(scene);
      if(actions.some(x=>x[2]==='paper')) {
        const page=group(scene);
        mesh(rbox(.22,.003,.29,.001),C.paper,0,0,0,page);
        for(let i=0;i<6;i++) mesh(rbox(i? .16:.11,.001,.005,.0004),i?C.metalD:C.teal,-.01,.0025,-.10+i*.029,page);
        sheets[role]=page;
      }
    }
    for(const [role,rows] of Object.entries(c.handsets||{})) {
      const screen=phones[role].userData.screen, idle=screen.material;
      const views=await Promise.all(rows.map(async ([a,z,name])=>{
        const image=await iconImage(name);
        const texture=canvasTex(136,264,ctx=>{
          ctx.fillStyle='#f5f3ea';ctx.fillRect(0,0,136,264);
          ctx.fillStyle='#315866';ctx.fillRect(0,0,136,26);
          ctx.drawImage(image,7,48,122,122);
          ctx.fillStyle='#93b6b4';ctx.fillRect(18,184,100,8);ctx.fillRect(18,204,72,6);
        });
        return [a,z,new THREE.MeshBasicMaterial({map:texture,toneMapped:false})];
      }));
      states.push(t=>{screen.material=active(views,t)?.[2]||idle;});
    }
    const updateProps = c.setupProps && await c.setupProps({ stage, scene, actors, devices, phones, sheets, work, counterLaptop, landline, record });
    const deskRest=work.laptop.position.clone();
    const bankCard=c.bankCard && group(scene);
    if(bankCard) {
      mesh(rbox(.086,.055,.003,.002),C.teal,0,0,0,bankCard);
      mesh(rbox(.081,.01,.001,.0004),C.navy,0,.013,.002,bankCard);
      for(const x of [-.022,-.005,.012])mesh(rbox(.01,.003,.001,.0004),C.paper,x,-.005,.002,bankCard);
    }
    const head=document.getElementById('head'), kicker=document.getElementById('kicker');
    kicker.textContent=trTemplate('Lesson {lesson} · Version 4',{lesson:c.lesson});
    const plate=document.createElement('span');
    plate.style.cssText='display:inline-block;padding:3px 9px;margin-top:5px;border-radius:6px;color:#fff;background:#315866;font-size:clamp(15px,2.7vw,18px);font-weight:700';
    head.append(plate);
    const B=createBoard(D.T);
    for(let i=0;i<c.pages.length;i++){
      const p=c.pages[i]; if(c.pages[i-1]?.z!==p.a) B.open(p.a);
      concept(B,p.a,p.z,p);
      if(p.z<D.T && c.pages[i+1]?.a!==p.z) B.close(p.z);
    }
    // The longer bilingual headings get their own bounded region above the illustration.
    for(const page of B.libraryCanvas.children) {
      const h=page.querySelector('.v-heading');
      Object.assign(h.style,{fontSize:AR?'26px':'27px',lineHeight:AR?'1.29':'1.13',height:'122px',maxHeight:'122px'});
      page.querySelector('.v-art').style.top='177px';
      for(const line of page.querySelectorAll('.v-card')) {
        Object.assign(line.style,{whiteSpace:'normal',display:'flex',alignItems:'center',lineHeight:'1.2',height:'64px',padding:'4px 12px'});
        line.style.top=(parseFloat(line.style.top)+28)+'px';
      }
    }
    B.end(); await readyPages(B);
    // Table and counter tops (flat meshes 0.6-1.2 m high), each grown by 0.32 m: walking routes go around them.
    scene.updateMatrixWorld(true);
    const blocks=[];
    scene.traverse(o=>{
      if(!o.isMesh||o.isSkinnedMesh||!o.geometry) return;
      if(!o.geometry.boundingBox) o.geometry.computeBoundingBox();
      const bb=o.geometry.boundingBox.clone().applyMatrix4(o.matrixWorld);
      const dx=bb.max.x-bb.min.x, dy=bb.max.y-bb.min.y, dz=bb.max.z-bb.min.z;
      if(dy<.12 && bb.max.y>.6 && bb.max.y<1.2 && dx>.35 && dz>.35 && dx<6 && dz<6) blocks.push([bb.min.x-.32,bb.max.x+.32,bb.min.z-.32,bb.max.z+.32]);
    });
    const crosses=(p,q,[x0,x1,z0,z1])=>{   // does segment p-q pass through the rectangle (sampled)
      // samples near either end are ignored: staff places (behind a counter, at a desk) sit inside the grown rectangle
      const L=Math.hypot(q[0]-p[0],q[1]-p[1]);
      for(let i=1;i<40;i++){ const f=i/40, x=p[0]+(q[0]-p[0])*f, z=p[1]+(q[1]-p[1])*f;
        if(f*L<.45||(1-f)*L<.45) continue;
        if(x>x0+.2&&x<x1-.2&&z>z0+.2&&z<z1-.2) return true; }
      return false;
    };
    const clear=(p,q)=>!blocks.some(b=>crosses(p,q,b));
    const inside=p=>blocks.some(([x0,x1,z0,z1])=>p[0]>x0&&p[0]<x1&&p[1]>z0&&p[1]<z1);
    function route(p,q){
      if(clear(p,q)) return [p,q];
      const corners=blocks.flatMap(([x0,x1,z0,z1])=>[[x0,z0],[x0,z1],[x1,z0],[x1,z1]]).filter(cn=>!inside(cn));
      const d=(u,v)=>Math.hypot(u[0]-v[0],u[1]-v[1]); let best=null, bl=1e9;
      for(const cn of corners) if(clear(p,cn)&&clear(cn,q)&&d(p,cn)+d(cn,q)<bl){ best=[p,cn,q]; bl=d(p,cn)+d(cn,q); }
      if(!best) for(const c1 of corners) for(const c2 of corners) if(c1!==c2&&clear(p,c1)&&clear(c1,c2)&&clear(c2,q)){
        const l=d(p,c1)+d(c1,c2)+d(c2,q); if(l<bl){ best=[p,c1,c2,q]; bl=l; } }
      return best||[p,q];
    }
    const frames=c.shots.map(([a,name],i)=>i?{t0:a-.02,t1:a,...shots[name]}:shots[name]);
    return t=>{
      // c.screens (optional): readable close-ups of the message being discussed (screens.js beats), as in Chapter 1 (audit 2026-11-22).
      B.tl.time(t,false); seekPages(B,t); if(c.screens) ui.play(t,c.screens); else quietScreens(ui,t);
      stage.conceptPage=c.pages.some(({a,z})=>t>=a && t<z);
      stage.focus=null; stage.outage=0;
      const label=active(c.plates,t)?.[2];
      plate.style.display=label?'inline-block':'none';
      const plateText=label ? tr(label) : '';
      if(plate.textContent!==plateText) plate.textContent=plateText;
      states.forEach(update=>update(t));
      if(landline) restReceiver(landline);
      if(bankCard) bankCard.visible=false;
      if(c.carryLaptop) work.laptop.position.copy(deskRest);
      let open=0;
      for(const [a,z,from,to] of c.file||[]) if(t>=a) open=from+(to-from)*ramp(t,a,z);
      record.userData.open(open);
      inkPen.visible=false;
      for(const role of roles) {
        const person=actors[role], beat=active(c.actions?.[role],t), action=beat?.[2];
        let place=c.actors[role], walking=false;
        person.reset(); person.idle(t,roles.indexOf(role)+1);
        for(const [a,z,to] of c.walks?.[role]||[]){
          if(t<a) break;
          if(t>=z){place=to;continue;}
          const [x0,z0,r0]=places[place], [x1,z1,r1]=places[to];
          // Walk around tables and counters, never through them (Bassem 2026-11-22).
          const pts=route([x0,z0],[x1,z1]);
          if(pts.length===2) person.go(t,a,z,x0,z0,x1,z1,r0,r1);
          else {
            const len=[]; let L=0;
            for(let k=0;k<pts.length-1;k++){ const d=Math.hypot(pts[k+1][0]-pts[k][0],pts[k+1][1]-pts[k][1]); len.push(d); L+=d; }
            let s=a;
            for(let k=0;k<len.length;k++){
              const e=a+(z-a)*len.slice(0,k+1).reduce((p,q)=>p+q,0)/L;
              if(t<e||k===len.length-1){
                const [px,pz]=pts[k],[qx,qz]=pts[k+1], dir=Math.atan2(qx-px,qz-pz);
                person.go(t,s,e,px,pz,qx,qz,k===0?r0:dir,k===len.length-1?r1:dir); break;
              }
              s=e;
            }
          }
          walking=true; break;
        }
        const sat=place==='desk' && !walking;
        if(!walking){
          person.at(...places[place]); person.play(sat?seated(role):action==='talk'?(female(role)?'f':'m')+'_gestic_talk_neutral_01':neutral(role),action==='talk'?t-beat[0]:t,true);
        }
        person.g.visible=!(c.leave?.[role]!==undefined && t>=c.leave[role]) && !(c.enter?.[role]!==undefined && t<c.enter[role]);
        if(phones[role]) phones[role].visible=false;
        if(sheets[role]) sheets[role].visible=false;
        if(!person.g.visible)continue;
        if(c.carryLaptop?.[0]===role && t<c.carryLaptop[2]) {
          const [,a,z]=c.carryLaptop, k=ramp(t,a,z);
          const hand=person.g.localToWorld(V(0,101,28));
          work.laptop.position.copy(hand).lerp(deskRest,k);
          for(const [side,x] of [['L',.20],['R',-.20]]) person.reach(side,work.laptop.localToWorld(V(x,.012,.04)),1-k);
        }
        if(bankCard && role===c.bankCard[0] && t>=c.bankCard[1] && t<c.bankCard[2]) {
          bankCard.visible=true; bankCard.position.copy(person.g.localToWorld(V(15,132,25)));
          bankCard.rotation.set(-.35,person.g.rotation.y+Math.PI,-.12,'YXZ');
          person.reach('L',bankCard.localToWorld(V(.035,-.018,0)),1);person.look(bankCard.position,1);
        }
        const lap=place==='counter'?counterLaptop:work.laptop;
        if(action==='read'||action==='type'){
          person.look(lap.userData.screen.getWorldPosition(V(0,0,0)),1);
          if(action==='type') {
            if(sat) typing(person,work,t,1);
            else for(const [side,x] of [['L',-.09],['R',.09]]) person.reach(side,lap.localToWorld(V(x,.035,.06)),1,null,{profile:'typing',time:t});
          }
        } else if(action==='extension'){
          person.flush();
          const headAt=person.b.Bip01_Head.getWorldPosition(V(0,0,0)), yaw=person.g.rotation.y;
          const phone=landline.receiver;
          phone.position.copy(headAt).add(V(-.14*Math.cos(yaw),-.035,.14*Math.sin(yaw)));
          phone.rotation.set(0,yaw-Math.PI/2,-.12,'YXZ');
          person.reach('R',phone.position,1);
        } else if(action==='call'||action==='text'||action==='photo'||action==='dial'){
          person.flush();
          const phone=phones[role], yaw=person.g.rotation.y;
          const headAt=person.b.Bip01_Head.getWorldPosition(V(0,0,0));
          const ear=action==='call', x=ear?-.135:-.10, z=ear ? .035 : .29;
          phone.position.copy(headAt).add(V(x*Math.cos(yaw)+z*Math.sin(yaw),ear?-.015:-.25,-x*Math.sin(yaw)+z*Math.cos(yaw)));
          phone.rotation.set(ear?0:-.36,yaw+(ear?-Math.PI/2:Math.PI),ear ? .13 : 0,'YXZ');
          phone.visible=true;
          person.reach('R',phone.localToWorld(V(.027,-.038,-.01)),1);
          if(!ear)person.look(action==='photo'?V(-1.93,1.35,-.05):phone.position,1);
          if(action==='text'||action==='dial')person.reach('L',phone.localToWorld(V(-.02,0,.014)),.86);
        } else if(action==='paper'){
          const sheet=sheets[role], yaw=person.g.rotation.y;
          sheet.visible=true;sheet.position.copy(person.g.localToWorld(V(0,sat?100:117,29)));sheet.rotation.set(-.64,yaw,0,'YXZ');
          person.grasp('L',sheet,V(.102,0,.05),V(-1,0,0));
          person.grasp('R',sheet,V(-.102,0,.08),V(1,0,0));person.look(sheet.position,1);
        } else if(['point','check','sign','file'].includes(action)){
          const target=record.position.clone().add(V(action==='sign' ? .15 : -.13,.04,0));
          if(action==='check') target.set(-2.13,1.39,.055);
          if(action==='point') target.set(-1.95,1.39,-.14);
          if(action==='sign'){
            target.x+=.065*Math.sin((t-beat[0])*5);inkPen.visible=true;
            inkPen.rotation.set(.88,0,.22);inkPen.position.copy(target);inkPen.position.y+=.045;
          }
          person.look(target,1);person.reach('R',target,.98);
        } else if(beat?.[3] && actors[beat[3]]){
          let targetPlace=c.actors[beat[3]];
          for(const [,end,destination] of c.walks?.[beat[3]]||[]) if(end<=t) targetPlace=destination;
          const [x,z]=places[targetPlace]; person.look(V(x,targetPlace==='desk'?1.13:1.5,z),.92);
        }
      }
      frameShots(stage,t,frames);
      updateProps?.(t);
    };
  };
}
