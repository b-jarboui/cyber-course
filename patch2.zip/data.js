export default {
 "0.cast2": {
  "title": "Cast check",
  "texts": [],
  "sentences": [
   "Cast check."
  ],
  "timing": [
   [
    0.5,
    1.5
   ]
  ],
  "T": 3
 },
 "0.face": {
  "title": "Faces",
  "texts": [],
  "sentences": [
   "Faces."
  ],
  "timing": [
   [
    0.5,
    1.5
   ]
  ],
  "T": 3
 },
 "0.cast": {
  "title": "Cast check",
  "texts": [],
  "sentences": [
   "Cast check."
  ],
  "timing": [
   [
    0.5,
    1.5
   ]
  ],
  "T": 3
 },
 "1.01": {
  "title": "A service starts with trust",
  "texts": [
   "Cybersecurity in the Age of Artificial Intelligence",
   "Sadeed Service Authority",
   "Protect people. Protect public services."
  ],
  "sentences": [
   "Someone has submitted an application.",
   "They are waiting for a decision that matters to them.",
   "At the Sadeed Service Authority, Shaima opens the record and begins her work.",
   "For the applicant, this is a public service.",
   "For Shaima, it is a responsibility.",
   "Behind both are information, identities, software, suppliers, and decisions that need protection.",
   "Cybersecurity helps keep that service trustworthy and working.",
   "Sadeed and everyone you meet in this course are fictional.",
   "The situations reflect decisions that real public-sector staff may face.",
   "We will follow those decisions from the service counter into the systems behind it, including the growing role of artificial intelligence.",
   "Start with the person waiting for the service.",
   "That is who this protection is for."
  ],
  "timing": [
   [
    0.76,
    2.9
   ],
   [
    3.28,
    6.4
   ],
   [
    6.78,
    11.7
   ],
   [
    12.08,
    15.08
   ],
   [
    15.46,
    18.1
   ],
   [
    18.48,
    25.18
   ],
   [
    25.56,
    29.62
   ],
   [
    30,
    33.65
   ],
   [
    34.03,
    39.26
   ],
   [
    39.64,
    47.8
   ],
   [
    48.18,
    51.37
   ],
   [
    51.75,
    53.84
   ]
  ],
  "T": 55.22
 },
 "1.02": {
  "title": "What are we protecting?",
  "texts": [
   "Information assets",
   "Digital identities",
   "Critical dependencies"
  ],
  "sentences": [
   "What needs protection?",
   "An information asset is something valuable to the institution’s work.",
   "It can include an applicant's record, an employee file, a device, an application, or the systems that process and store information.",
   "Digital identities also matter.",
   "A person, a device, an application, or an AI agent may have an identity that a system uses when deciding whether to allow access.",
   "These services depend on other services.",
   "Identity checks, payment processing, communications, and electricity may be provided elsewhere.",
   "Some dependencies support critical infrastructure: systems whose disruption can seriously affect society.",
   "Sadeed does not operate every system in this model.",
   "It still needs to understand what it relies on.",
   "Protecting the counter means understanding the information, access, and infrastructure beneath it."
  ],
  "timing": [
   [
    0.76,
    2.63
   ],
   [
    3.01,
    7.71
   ],
   [
    8.09,
    16.66
   ],
   [
    17.04,
    19.37
   ],
   [
    19.75,
    29.09
   ],
   [
    29.47,
    31.97
   ],
   [
    32.35,
    39.38
   ],
   [
    39.76,
    46.34
   ],
   [
    46.72,
    49.98
   ],
   [
    50.36,
    53.26
   ],
   [
    53.64,
    59.81
   ]
  ],
  "T": 61.19
 },
 "1.03": {
  "title": "Three promises",
  "texts": [
   "Confidentiality — authorized access",
   "Integrity — protected from improper change",
   "Availability — usable when needed"
  ],
  "sentences": [
   "Cybersecurity protects three connected qualities.",
   "Confidentiality means information is available only to people and systems authorized to access it.",
   "An applicant’s private details should not become visible simply because someone has a link.",
   "Integrity means protecting information from unauthorized or improper change or destruction.",
   "A decision, payment detail, or supporting record must not be silently altered.",
   "Legitimate changes need appropriate control and accountability.",
   "Availability means authorized people and systems can use information and services when they need them.",
   "These qualities work together.",
   "A private record is not useful if the service cannot retrieve it.",
   "A service that is always online can still cause harm if its information is wrong.",
   "Even a public announcement needs integrity and availability.",
   "Ask three questions: who may see it, who may change it, and can the right people use it when needed?"
  ],
  "timing": [
   [
    0.76,
    4.62
   ],
   [
    5,
    11.91
   ],
   [
    12.29,
    17.93
   ],
   [
    18.31,
    24.45
   ],
   [
    24.83,
    30.33
   ],
   [
    30.71,
    35.49
   ],
   [
    35.87,
    42.47
   ],
   [
    42.85,
    44.72
   ],
   [
    45.1,
    49.47
   ],
   [
    49.85,
    55.27
   ],
   [
    55.65,
    59.49
   ],
   [
    59.87,
    66.88
   ]
  ],
  "T": 68.26
 },
 "1.04": {
  "title": "Six different words",
  "texts": [
   "Threat — potential cause of harm",
   "Vulnerability — a weakness",
   "Risk — likelihood and potential impact",
   "Incident — security compromised or threatened",
   "An alert needs assessment"
  ],
  "sentences": [
   "These words describe different things.",
   "A threat is a potential cause of harm.",
   "An unauthorized person seeking confidential information is one example.",
   "A vulnerability is a weakness that could allow harm.",
   "Here, a confidential folder has been shared too broadly.",
   "Risk considers how likely harmful circumstances are and how serious their consequences could be.",
   "The sensitivity of the records, the exposure, and existing protections all affect that judgment.",
   "An incident occurs when security is compromised, or threatened in a way that requires a response.",
   "In this example, evidence shows that an unauthorized person accessed the folder.",
   "An event is simply something that happened.",
   "An alert draws attention to something that needs assessment; it is not automatically proof of an incident.",
   "You do not have to settle the classification yourself.",
   "Report a reasonable concern through the approved route."
  ],
  "timing": [
   [
    0.76,
    3.16
   ],
   [
    3.54,
    5.89
   ],
   [
    6.27,
    11.12
   ],
   [
    11.5,
    15.22
   ],
   [
    15.6,
    19.18
   ],
   [
    19.56,
    25.3
   ],
   [
    25.68,
    32.47
   ],
   [
    32.85,
    39.16
   ],
   [
    39.54,
    44.99
   ],
   [
    45.37,
    47.99
   ],
   [
    48.37,
    55.04
   ],
   [
    55.42,
    58.42
   ],
   [
    58.8,
    62.26
   ]
  ],
  "T": 63.64
 },
 "1.05": {
  "title": "Where weaknesses live",
  "texts": [
   "People",
   "Technology",
   "Organization",
   "Make the safer action practical"
  ],
  "sentences": [
   "Weaknesses can appear in people’s decisions, in technology, and in the way an organization works.",
   "A person under pressure may accept an unusual request without checking it.",
   "A device may contain an unresolved software weakness.",
   "A process may leave nobody clearly responsible for approving a sensitive change.",
   "These weaknesses can reinforce each other.",
   "A warning is less useful when staff cannot understand it.",
   "A policy is less effective when the approved process is difficult to find or too slow to use.",
   "Effective protection combines training, usable processes, maintained technology, clear responsibilities, and enough support to act safely.",
   "Staff should follow the approved process and raise concerns.",
   "Managers should make that process workable.",
   "When something goes wrong, examine the conditions and controls as well as the individual action."
  ],
  "timing": [
   [
    0.76,
    7.05
   ],
   [
    7.43,
    12.85
   ],
   [
    13.23,
    17.12
   ],
   [
    17.5,
    23.55
   ],
   [
    23.93,
    26.64
   ],
   [
    27.02,
    31.15
   ],
   [
    31.53,
    37.75
   ],
   [
    38.13,
    48.21
   ],
   [
    48.59,
    52.55
   ],
   [
    52.93,
    55.88
   ],
   [
    56.26,
    62.31
   ]
  ],
  "T": 63.69
 },
 "1.06": {
  "title": "Protection has owners and layers",
  "texts": [
   "Clear ownership",
   "Defence in depth",
   "Prevent • Detect • Respond • Recover"
  ],
  "sentences": [
   "Cybersecurity is a shared institutional responsibility, with different duties for different roles.",
   "Leaders set direction, assign accountability, and provide resources.",
   "Service and information owners make decisions about their risks and requirements.",
   "Security and technology teams operate and improve protections.",
   "Privacy, procurement, and other functions contribute their expertise.",
   "Staff use approved tools, protect access and information, follow procedures, and report concerns promptly.",
   "Governance connects these responsibilities through policy, oversight, and decisions about risk.",
   "Defence in depth combines several protections.",
   "Access controls, maintained software, restricted connections, monitoring, and recovery capabilities address different ways harm can occur.",
   "A failure in one control should not leave the institution relying on nothing else.",
   "No single product or person can guarantee safety.",
   "The protections need clear owners, regular review, and practice working together."
  ],
  "timing": [
   [
    0.76,
    7.46
   ],
   [
    7.84,
    12.86
   ],
   [
    13.24,
    18.26
   ],
   [
    18.64,
    23.3
   ],
   [
    23.68,
    28.77
   ],
   [
    29.15,
    36.93
   ],
   [
    37.31,
    43.6
   ],
   [
    43.98,
    47.58
   ],
   [
    47.96,
    57.49
   ],
   [
    57.87,
    63.58
   ],
   [
    63.96,
    67.39
   ],
   [
    67.77,
    73.39
   ]
  ],
  "T": 74.77
 },
 "1.07": {
  "title": "Different actors, overlapping motives",
  "texts": [
   "Profit",
   "Intelligence",
   "Political disruption",
   "Motives and methods can overlap"
  ],
  "sentences": [
   "Public institutions face different kinds of hostile activity.",
   "Cybercriminals seek profit through fraud, stolen information, extortion, and other crimes.",
   "Organized networks may divide the work among different specialists.",
   "State-sponsored activity may seek sensitive information, strategic advantage, or disruption.",
   "Cyberespionage can remain hidden because the objective may be to collect information while systems continue operating.",
   "Hacktivists and other politically motivated actors may seek attention, disruption, or exposure of information.",
   "These categories overlap.",
   "A claimed political motive does not prove who is responsible, and similar methods can be used by very different actors.",
   "Employees should recognize suspicious activity and its possible impact.",
   "Identifying the actor is specialist work.",
   "For the institution, the practical question remains: which services and information could be harmed, and how do we protect them?"
  ],
  "timing": [
   [
    0.76,
    4.91
   ],
   [
    5.29,
    12.2
   ],
   [
    12.58,
    17
   ],
   [
    17.38,
    23.91
   ],
   [
    24.29,
    32.07
   ],
   [
    32.45,
    39.91
   ],
   [
    40.29,
    42.21
   ],
   [
    42.59,
    50.44
   ],
   [
    50.82,
    55.91
   ],
   [
    56.29,
    59.31
   ],
   [
    59.69,
    67.61
   ]
  ],
  "T": 68.99
 },
 "1.08": {
  "title": "Locked, copied, destroyed",
  "texts": [
   "Encryption can deny access",
   "Stolen data can enable extortion",
   "Destruction can prevent recovery",
   "Report. Follow the response plan."
  ],
  "sentences": [
   "Ransomware can make files or systems unusable, often through encryption, while criminals demand payment.",
   "An extortion incident may also involve stolen information.",
   "Criminals can threaten to publish it or use it to pressure the institution and the people affected.",
   "Data theft can occur with or without encryption.",
   "Destructive attacks aim to damage or erase information and systems.",
   "A demand for money does not guarantee that recovery is possible, and a working backup does not undo a disclosure.",
   "These examples show different kinds of harm.",
   "An incident may combine several of them.",
   "If you see a ransom demand, unexpected loss of access, or signs that information has been stolen, report it immediately through the approved route.",
   "Follow the response plan.",
   "Decisions about containment, recovery, external communication, and extortion demands belong to the authorized response structure."
  ],
  "timing": [
   [
    0.76,
    8.44
   ],
   [
    8.82,
    12.68
   ],
   [
    13.06,
    19.04
   ],
   [
    19.42,
    22.32
   ],
   [
    22.7,
    27.6
   ],
   [
    27.98,
    35.16
   ],
   [
    35.54,
    38.28
   ],
   [
    38.66,
    40.94
   ],
   [
    41.32,
    50.37
   ],
   [
    50.75,
    52.62
   ],
   [
    53,
    61.86
   ]
  ],
  "T": 63.24
 },
 "1.09": {
  "title": "A trusted account can be misused",
  "texts": [
   "A familiar account is not enough",
   "Verify unusual instructions",
   "Protect credentials and sessions"
  ],
  "sentences": [
   "An attacker may misuse an identity instead of visibly damaging a system.",
   "Identity theft involves using someone’s identity without authorization.",
   "Credential compromise can give an unauthorized person access to an account or help them impersonate its holder.",
   "A compromised account may send messages that appear to come from a trusted colleague or supplier.",
   "Here, Rania sees a request to change payment information.",
   "The account looks familiar.",
   "The instruction still needs the required verification and approval.",
   "Financial fraud may depend on one apparently small change: a payment destination, an administrative record, or an authorization.",
   "Protecting an account includes its passwords and other authenticators, its recovery process, and its signed-in sessions.",
   "When a request is unusual or sensitive, verify both who is asking and whether the action is permitted."
  ],
  "timing": [
   [
    0.76,
    6.11
   ],
   [
    6.49,
    11.84
   ],
   [
    12.22,
    18.77
   ],
   [
    19.15,
    24.98
   ],
   [
    25.36,
    29.15
   ],
   [
    29.53,
    31.4
   ],
   [
    31.78,
    36.22
   ],
   [
    36.6,
    45.48
   ],
   [
    45.86,
    53.95
   ],
   [
    54.33,
    61.48
   ]
  ],
  "T": 62.86
 },
 "1.10": {
  "title": "The weakness in the software",
  "texts": [
   "Software can contain vulnerabilities",
   "Apply approved updates",
   "Zero-day exploitation",
   "Keep other protections active"
  ],
  "sentences": [
   "Software can contain weaknesses in its design, code, or configuration.",
   "Suppliers and security teams identify many vulnerabilities and provide fixes or other protective measures.",
   "Delaying an approved update can leave a known weakness exposed.",
   "Zero-day exploitation takes advantage of a flaw before a security fix is available.",
   "The weakness may initially be unknown to the supplier or to defenders.",
   "This is one reason security cannot rely entirely on patching.",
   "Restricted access, monitoring, secure configuration, and response readiness also matter.",
   "Staff should use approved software, allow required updates, and report problems that prevent them from completing.",
   "Technical teams assess the risk and manage deployment safely, especially where an update could affect a critical service.",
   "Do not attempt an unofficial repair from an unexpected message or website.",
   "Use the institution’s established support process."
  ],
  "timing": [
   [
    0.76,
    5.87
   ],
   [
    6.25,
    14
   ],
   [
    14.38,
    18.53
   ],
   [
    18.91,
    25.03
   ],
   [
    25.41,
    30.14
   ],
   [
    30.52,
    34.94
   ],
   [
    35.32,
    41.85
   ],
   [
    42.23,
    48.76
   ],
   [
    49.14,
    56.65
   ],
   [
    57.03,
    61.95
   ],
   [
    62.33,
    65.91
   ]
  ],
  "T": 67.29
 },
 "1.11": {
  "title": "Trust arrives through other people",
  "texts": [
   "Supplier access needs controls",
   "Insider harm may be deliberate or accidental",
   "Access is limited to an authorized purpose"
  ],
  "sentences": [
   "Institutions rely on suppliers, contractors, software, and connected services.",
   "If one of those is compromised, the consequences may reach the institution through an update, a dependency, a service connection, or authorized access.",
   "This is a supply-chain risk.",
   "Trust in a supplier still needs defined responsibilities, appropriate access, monitoring, and review.",
   "Harm can also arise from inside the institution’s boundary.",
   "Someone may deliberately misuse legitimate access.",
   "An employee may also cause harm unintentionally, for example by sharing information with the wrong audience.",
   "These situations require different investigations, but both show why access should fit an authorized purpose.",
   "Report suspicious behavior or an accidental exposure through the approved route.",
   "Describe what you observed.",
   "Avoid unsupported accusations.",
   "Authorized teams need the facts to protect information and assess what happened."
  ],
  "timing": [
   [
    0.76,
    6.9
   ],
   [
    7.28,
    17.84
   ],
   [
    18.22,
    20.12
   ],
   [
    20.5,
    27.17
   ],
   [
    27.55,
    31.34
   ],
   [
    31.72,
    35.1
   ],
   [
    35.48,
    42.34
   ],
   [
    42.72,
    50.09
   ],
   [
    50.47,
    55.44
   ],
   [
    55.82,
    57.69
   ],
   [
    58.07,
    60.42
   ],
   [
    60.8,
    65.77
   ]
  ],
  "T": 67.15
 },
 "1.12": {
  "title": "When a digital problem becomes a public problem",
  "texts": [
   "Services depend on other services",
   "Digital disruption has human consequences",
   "Prepare safe alternatives"
  ],
  "sentences": [
   "A digital incident can become a public-service problem very quickly.",
   "If an identity service is unavailable, an applicant may be unable to complete an application.",
   "If a payment service is disrupted, money may not reach its intended recipient on time.",
   "A problem in a shared provider can affect several institutions at once.",
   "Attacks against essential services can have operational, financial, and societal consequences.",
   "Some can also affect safety.",
   "The impact depends on the service, its dependencies, the duration of disruption, and the alternatives available.",
   "That is why institutions identify critical services, prepare continuity arrangements, and test recovery.",
   "Staff contribute by protecting their part of the process, reporting early, and following approved alternative procedures.",
   "Return to the applicant at the counter.",
   "A system’s availability, integrity, and confidentiality all affect the service they receive."
  ],
  "timing": [
   [
    0.76,
    4.96
   ],
   [
    5.34,
    11.92
   ],
   [
    12.3,
    17.7
   ],
   [
    18.08,
    22.9
   ],
   [
    23.28,
    29.78
   ],
   [
    30.16,
    32.03
   ],
   [
    32.41,
    39.39
   ],
   [
    39.77,
    46.92
   ],
   [
    47.3,
    55.53
   ],
   [
    55.91,
    58.21
   ],
   [
    58.59,
    65
   ]
  ],
  "T": 66.38
 },
 "1.13": {
  "title": "AI makes deception more convincing",
  "texts": [
   "Personalized does not prove authentic",
   "AI can improve convincing deception",
   "Verify the request through a known route"
  ],
  "sentences": [
   "Artificial intelligence can help an attacker make sense of public information about an institution, its staff, and its activities.",
   "That can support reconnaissance: gathering information to understand possible targets.",
   "AI can also help identify relevant people and generate messages that fit their work, language, and circumstances.",
   "A phishing message may be polished, specific, and free of obvious mistakes.",
   "It may refer to a real project or imitate a familiar style.",
   "Those details can make a request feel credible.",
   "They do not establish who sent it or whether it is authorized.",
   "Here, Shaima recognizes the subject of the message.",
   "She still checks the unusual request through an established route.",
   "You do not need to prove that AI wrote a message before treating it cautiously.",
   "Focus on the requested action, the information involved, and the evidence of authority."
  ],
  "timing": [
   [
    0.76,
    9.16
   ],
   [
    9.54,
    14.94
   ],
   [
    15.32,
    22.95
   ],
   [
    23.33,
    28.54
   ],
   [
    28.92,
    33.58
   ],
   [
    33.96,
    37.13
   ],
   [
    37.51,
    41.09
   ],
   [
    41.47,
    45.02
   ],
   [
    45.4,
    49.43
   ],
   [
    49.81,
    54.47
   ],
   [
    54.85,
    60.08
   ]
  ],
  "T": 61.46
 },
 "1.14": {
  "title": "AI increases operational speed",
  "texts": [
   "AI can accelerate parts of cyber operations",
   "Human-directed • Supervised • More autonomous",
   "Capability and reliability vary"
  ],
  "sentences": [
   "AI can also assist more technical parts of hostile activity.",
   "It can help analyze software weaknesses, support attempts to exploit them, and generate or modify malicious code.",
   "Automation can help coordinate repeated tasks and increase the speed or scale of an operation.",
   "In a semi-autonomous process, people still direct or approve important parts of the work.",
   "A more autonomous system can select and carry out more actions within the goals and capabilities delegated to it.",
   "These capabilities vary.",
   "Generated code can fail, conclusions can be wrong, and human operators often remain important.",
   "Claims that an attack was fully autonomous need evidence.",
   "For defenders, the practical implication is pressure to maintain protections and respond promptly.",
   "Restrict unnecessary access, keep approved systems maintained, and escalate concerns.",
   "Do not assume that either a dramatic claim or a reassuring label tells the whole story."
  ],
  "timing": [
   [
    0.76,
    4.98
   ],
   [
    5.36,
    12.58
   ],
   [
    12.96,
    19.3
   ],
   [
    19.68,
    25.97
   ],
   [
    26.35,
    33.45
   ],
   [
    33.83,
    35.61
   ],
   [
    35.99,
    42.45
   ],
   [
    42.83,
    46.67
   ],
   [
    47.05,
    53.87
   ],
   [
    54.25,
    60.75
   ],
   [
    61.13,
    66.31
   ]
  ],
  "T": 67.69
 },
 "1.15": {
  "title": "AI can help the defenders",
  "texts": [
   "AI can connect observations",
   "An alert is a lead",
   "Check evidence and consequences",
   "Keep oversight and control"
  ],
  "sentences": [
   "AI can help defenders work with large amounts of security information.",
   "It can connect observations across accounts, devices, cloud services, and applications, and highlight patterns that deserve attention.",
   "It can also help summarize an incident or suggest priorities for review.",
   "But a convincing explanation is not the same as verified evidence.",
   "AI may mistake normal behavior for a threat, miss an important event, or produce an incorrect analysis.",
   "Poorly controlled automation can also interrupt legitimate work or take actions beyond what was intended.",
   "Here, Omar checks the underlying observations before approving a significant response.",
   "Effective defensive use needs suitable information, evaluation, monitoring, clear permissions, and human oversight.",
   "Your role remains important.",
   "An early report from a person who notices something unusual can provide context that automated monitoring does not have."
  ],
  "timing": [
   [
    0.76,
    5.3
   ],
   [
    5.68,
    14.25
   ],
   [
    14.63,
    18.81
   ],
   [
    19.19,
    24.13
   ],
   [
    24.51,
    31.64
   ],
   [
    32.02,
    38.43
   ],
   [
    38.81,
    45.03
   ],
   [
    45.41,
    53.71
   ],
   [
    54.09,
    55.96
   ],
   [
    56.34,
    64.07
   ]
  ],
  "T": 65.45
 },
 "1.16": {
  "title": "The first decision",
  "texts": [],
  "sentences": [
   "Shaima receives an urgent request to use a new AI service with applicant records.",
   "The message claims that the director has approved it.",
   "The request looks professional and refers to real work.",
   "Think about what matters here.",
   "The information may be sensitive.",
   "The tool’s approval and permitted use have not been established.",
   "The message’s claim of authority has not been independently verified.",
   "What should Shaima do?",
   "Upload immediately, reply to confirm, or verify through approved channels?",
   "Shaima should verify through approved channels.",
   "That means checking the request independently, establishing that the tool and the proposed use are permitted, and reporting the unusual request through the known security reporting route.",
   "The records remain in the approved environment while those checks happen.",
   "Cybersecurity protects confidentiality, integrity, and availability so that public services remain trustworthy.",
   "AI can change the speed and appearance of a threat.",
   "Clear responsibilities, layered protection, careful verification, and early reporting remain essential.",
   "In the next chapter, we follow a convincing request across email, websites, telephone calls, and workplace messages."
  ],
  "timing": [
   [
    0.76,
    6.59
   ],
   [
    6.97,
    9.83
   ],
   [
    10.21,
    13.88
   ],
   [
    14.26,
    16.13
   ],
   [
    16.51,
    19.1
   ],
   [
    19.48,
    23.7
   ],
   [
    24.08,
    28.54
   ],
   [
    28.92,
    30.79
   ],
   [
    31.17,
    37.07
   ],
   [
    37.45,
    40.83
   ],
   [
    41.21,
    52.03
   ],
   [
    52.41,
    56.35
   ],
   [
    56.73,
    64.84
   ],
   [
    65.22,
    68.53
   ],
   [
    68.91,
    76.04
   ],
   [
    76.42,
    84.48
   ]
  ],
  "T": 85.86
 },
 "1.04s": {
  "title": "Threat, vulnerability, risk",
  "texts": [],
  "sentences": [
   "These words describe different things.",
   "A threat is a potential cause of harm.",
   "An unauthorized person seeking confidential information is one example.",
   "A vulnerability is a weakness that could allow harm.",
   "Here, a confidential folder has been shared too broadly.",
   "Risk considers how likely harmful circumstances are and how serious their consequences could be.",
   "The sensitivity of the records, the exposure, and existing protections all affect that judgment.",
   "The folder is open to 340 people, but nobody has misused it yet. Is this a threat, a vulnerability, or an incident?",
   "It is a vulnerability. The weakness is there, even though no harm has happened yet."
  ],
  "timing": [
   [
    0.8,
    3.2
   ],
   [
    4.2,
    6.55
   ],
   [
    7.05,
    11.9
   ],
   [
    13.4,
    17.12
   ],
   [
    18.02,
    21.6
   ],
   [
    23.1,
    28.83
   ],
   [
    29.73,
    36.52
   ],
   [
    38.12,
    46.98
   ],
   [
    50.48,
    55.54
   ]
  ],
  "T": 56.74
 },
 "1.04v": {
  "title": "Threat, vulnerability, risk",
  "texts": [],
  "sentences": [
   "At the fictional Sadeed Service Authority, Shaima is working on this applicant’s record.",
   "She notices the sharing setting.",
   "Only five caseworkers are permitted to use this record.",
   "The setting gives all 340 staff accounts access.",
   "That excessive permission is a vulnerability: a weakness that could allow harm.",
   "A threat is a potential cause of harm.",
   "Here, someone could deliberately misuse access, or a colleague could accidentally share private details.",
   "A threat can come from inside the authority.",
   "Risk considers how likely a threat is to exploit a weakness, and how serious the harm could be.",
   "Broad permissions create more opportunities for someone outside the case team to see the record.",
   "The record contains identity and contact details.",
   "Disclosure could expose the applicant to fraud or unwanted contact.",
   "These possible consequences matter when judging risk.",
   "Shaima reports the sharing problem through Sadeed’s approved reporting route.",
   "She describes the setting she found, without accusing anyone.",
   "She does not need proof of misuse before reporting.",
   "Excessive access is a weakness, and it may also be an incident if someone used it without authorization.",
   "The responsible team assesses what happened and what response is needed.",
   "Omar receives her report and starts checking the permissions.",
   "Receiving a report does not mean the problem is fixed.",
   "If access is restricted to the five permitted caseworkers, that reduces opportunities for unauthorized access.",
   "It does not make the record less sensitive, undo any earlier exposure, or remove the need to assess what happened."
  ],
  "timing": [
   [
    0.8,
    5.91
   ],
   [
    6.31,
    8.38
   ],
   [
    9.38,
    12.76
   ],
   [
    13.56,
    17.93
   ],
   [
    18.73,
    23.58
   ],
   [
    25.58,
    27.93
   ],
   [
    28.53,
    35.18
   ],
   [
    35.88,
    38.71
   ],
   [
    40.71,
    46.71
   ],
   [
    47.51,
    53.08
   ],
   [
    54.48,
    58.27
   ],
   [
    58.87,
    63.69
   ],
   [
    64.29,
    68.01
   ],
   [
    69.61,
    74.2
   ],
   [
    74.6,
    78.99
   ],
   [
    81.59,
    84.73
   ],
   [
    85.33,
    91.83
   ],
   [
    92.43,
    96.77
   ],
   [
    98.07,
    101.72
   ],
   [
    102.12,
    105.67
   ],
   [
    106.77,
    114.38
   ],
   [
    115.18,
    122.86
   ]
  ],
  "T": 124.39,
  "phrases": [
   [
    0.8,
    3.3,
    "At the fictional Sadeed Service Authority,"
   ],
   [
    3.3,
    6.26,
    "Shaima is working on this applicant’s record."
   ],
   [
    6.31,
    8.73,
    "She notices the sharing setting."
   ],
   [
    9.38,
    11.59,
    "Only five caseworkers are permitted"
   ],
   [
    11.59,
    13.11,
    "to use this record."
   ],
   [
    13.56,
    15.93,
    "The setting gives all 340"
   ],
   [
    15.93,
    18.28,
    "staff accounts access."
   ],
   [
    18.73,
    21.55,
    "That excessive permission is a vulnerability:"
   ],
   [
    21.55,
    23.93,
    "a weakness that could allow harm."
   ],
   [
    25.58,
    28.28,
    "A threat is a potential cause of harm."
   ],
   [
    28.53,
    31.09,
    "Here, someone could deliberately misuse"
   ],
   [
    31.09,
    33.77,
    "access, or a colleague could accidentally"
   ],
   [
    33.77,
    35.53,
    "share private details."
   ],
   [
    35.88,
    39.06,
    "A threat can come from inside the authority."
   ],
   [
    40.71,
    42.71,
    "Risk considers how likely a threat"
   ],
   [
    42.71,
    44.71,
    "is to exploit a weakness, and"
   ],
   [
    44.71,
    46.71,
    "how serious the harm could be."
   ],
   [
    47.51,
    50.06,
    "Broad permissions create more opportunities"
   ],
   [
    50.06,
    52.04,
    "for someone outside the case team"
   ],
   [
    52.04,
    53.43,
    "to see the record."
   ],
   [
    54.48,
    56.72,
    "The record contains identity"
   ],
   [
    56.72,
    58.62,
    "and contact details."
   ],
   [
    58.87,
    61.6,
    "Disclosure could expose the applicant"
   ],
   [
    61.6,
    64.04,
    "to fraud or unwanted contact."
   ],
   [
    64.29,
    66.26,
    "These possible consequences"
   ],
   [
    66.26,
    68.36,
    "matter when judging risk."
   ],
   [
    69.61,
    72.17,
    "Shaima reports the sharing problem through"
   ],
   [
    72.17,
    74.55,
    "Sadeed’s approved reporting route."
   ],
   [
    74.6,
    77.26,
    "She describes the setting she found,"
   ],
   [
    77.26,
    79.34,
    "without accusing anyone."
   ],
   [
    81.59,
    83.25,
    "She does not need proof of"
   ],
   [
    83.25,
    85.08,
    "misuse before reporting."
   ],
   [
    85.33,
    87.5,
    "Excessive access is a weakness, and"
   ],
   [
    87.5,
    89.66,
    "it may also be an incident"
   ],
   [
    89.66,
    91.83,
    "if someone used it without authorization."
   ],
   [
    92.43,
    95.08,
    "The responsible team assesses what happened"
   ],
   [
    95.08,
    97.12,
    "and what response is needed."
   ],
   [
    98.07,
    100.22,
    "Omar receives her report and starts"
   ],
   [
    100.22,
    102.07,
    "checking the permissions."
   ],
   [
    102.12,
    103.96,
    "Receiving a report does not"
   ],
   [
    103.96,
    106.02,
    "mean the problem is fixed."
   ],
   [
    106.77,
    109.95,
    "If access is restricted to the five permitted"
   ],
   [
    109.95,
    112.72,
    "caseworkers, that reduces opportunities"
   ],
   [
    112.72,
    114.73,
    "for unauthorized access."
   ],
   [
    115.18,
    118.14,
    "It does not make the record less sensitive,"
   ],
   [
    118.14,
    120.91,
    "undo any earlier exposure, or remove the"
   ],
   [
    120.91,
    123.21,
    "need to assess what happened."
   ]
  ]
 },
 "1.01v": {
  "title": "A service starts with trust",
  "texts": [],
  "sentences": [
   "Someone has submitted an application.",
   "They are waiting for a decision that matters to them.",
   "At Sadeed Service Authority, Shaima opens Case 2048 and begins her work.",
   "Sadeed and everyone you meet in this course are fictional.",
   "Cybersecurity helps keep public services trustworthy and working.",
   "An information asset is something valuable to the institution’s work.",
   "Case 2048 is one example.",
   "Assets also include employee files, devices, applications, and the systems that process and store information.",
   "Each supports work that people rely on.",
   "A digital identity represents a person, device, application or AI agent in a digital system.",
   "Authentication checks that whoever uses that identity is genuine.",
   "Authorization is a separate decision: even a checked identity needs permission to open Case 2048.",
   "The service that verifies the applicant’s identity has stopped responding.",
   "The applicant’s case has to wait.",
   "Public services rely on other services, called dependencies.",
   "Sadeed relies on identity checks, payment processing, communications and electricity.",
   "Some are provided by other organizations.",
   "Sadeed does not operate every system, but still needs to understand what it relies on.",
   "Some dependencies support critical infrastructure: essential assets, systems and services whose disruption could seriously affect society.",
   "Electricity, for example, supports many essential services at once.",
   "Confidentiality means preventing information from being disclosed to people or systems that are not authorized to receive it.",
   "Case 2048 contains private identity and contact details.",
   "Having a link does not give someone permission to see them.",
   "Sending them to the wrong person would break confidentiality.",
   "The service that verifies the applicant’s identity is working again.",
   "Shaima finds a wrong decision in Case 2048 and checks the approved decision before correcting it.",
   "Integrity means protecting information from unauthorized or improper change or destruction.",
   "An unapproved change from Approved to Refused could give this applicant a wrong decision.",
   "Legitimate corrections need the right checks and a record of who changed what.",
   "Shaima saves the checked correction.",
   "Availability means authorized people and systems can use information and services when they need them.",
   "Earlier, Shaima had access to Case 2048, but the applicant’s identity could not be verified.",
   "That dependency delayed the service.",
   "Even a public announcement needs integrity and availability.",
   "The public needs the correct opening hours, available when they need them.",
   "These protections work together.",
   "A private record is not useful if the service cannot retrieve it.",
   "A service that is always online can still cause harm if its information is wrong."
  ],
  "timing": [
   [
    1.0,
    3.14
   ],
   [
    3.64,
    6.76
   ],
   [
    7.26,
    12.68
   ],
   [
    14.68,
    18.86
   ],
   [
    19.56,
    24.33
   ],
   [
    26.33,
    31.04
   ],
   [
    31.64,
    34.44
   ],
   [
    34.94,
    42.34
   ],
   [
    42.94,
    45.79
   ],
   [
    47.79,
    55.64
   ],
   [
    56.24,
    60.97
   ],
   [
    61.57,
    68.96
   ],
   [
    70.96,
    75.25
   ],
   [
    75.75,
    77.82
   ],
   [
    79.82,
    84.0
   ],
   [
    84.6,
    90.8
   ],
   [
    91.4,
    94.02
   ],
   [
    94.62,
    100.69
   ],
   [
    102.69,
    111.52
   ],
   [
    112.22,
    117.47
   ],
   [
    119.47,
    127.1
   ],
   [
    127.7,
    132.82
   ],
   [
    133.42,
    136.66
   ],
   [
    137.36,
    140.96
   ],
   [
    142.96,
    147.35
   ],
   [
    147.85,
    154.79
   ],
   [
    156.79,
    162.93
   ],
   [
    163.53,
    169.07
   ],
   [
    169.87,
    174.91
   ],
   [
    175.51,
    178.03
   ],
   [
    180.03,
    186.63
   ],
   [
    187.23,
    194.53
   ],
   [
    195.13,
    197.7
   ],
   [
    200.7,
    204.54
   ],
   [
    205.14,
    209.67
   ],
   [
    211.67,
    213.88
   ],
   [
    214.48,
    218.85
   ],
   [
    219.45,
    224.87
   ]
  ],
  "T": 227.47,
  "phrases": [
   [
    1,
    3.49,
    "Someone has submitted an application."
   ],
   [
    3.64,
    5.52,
    "They are waiting for a decision"
   ],
   [
    5.52,
    7.11,
    "that matters to them."
   ],
   [
    7.26,
    10.42,
    "At Sadeed Service Authority, Shaima opens"
   ],
   [
    10.42,
    13.03,
    "Case 2048 and begins her work."
   ],
   [
    14.68,
    16.98,
    "Sadeed and everyone you meet in"
   ],
   [
    16.98,
    19.21,
    "this course are fictional."
   ],
   [
    19.56,
    22.57,
    "Cybersecurity helps keep public services"
   ],
   [
    22.57,
    24.68,
    "trustworthy and working."
   ],
   [
    26.33,
    29.26,
    "An information asset is something valuable"
   ],
   [
    29.26,
    31.39,
    "to the institution’s work."
   ],
   [
    31.64,
    34.79,
    "Case 2048 is one example."
   ],
   [
    34.94,
    37.36,
    "Assets also include employee files,"
   ],
   [
    37.36,
    39.98,
    "devices, applications, and the systems"
   ],
   [
    39.98,
    42.69,
    "that process and store information."
   ],
   [
    42.94,
    46.14,
    "Each supports work that people rely on."
   ],
   [
    47.79,
    50.93,
    "A digital identity represents a person,"
   ],
   [
    50.93,
    54.07,
    "device, application or AI agent in"
   ],
   [
    54.07,
    55.64,
    "a digital system."
   ],
   [
    56.24,
    59.39,
    "Authentication checks that whoever uses that"
   ],
   [
    59.39,
    60.97,
    "identity is genuine."
   ],
   [
    61.57,
    64.53,
    "Authorization is a separate decision: even"
   ],
   [
    64.53,
    67.48,
    "a checked identity needs permission to"
   ],
   [
    67.48,
    68.96,
    "open Case 2048."
   ],
   [
    70.96,
    73.4,
    "The service that verifies the applicant’s"
   ],
   [
    73.4,
    75.6,
    "identity has stopped responding."
   ],
   [
    75.75,
    78.17,
    "The applicant’s case has to wait."
   ],
   [
    79.82,
    82.95,
    "Public services rely on other services,"
   ],
   [
    82.95,
    84.0,
    "called dependencies."
   ],
   [
    84.6,
    88.54,
    "Sadeed relies on identity checks, payment processing,"
   ],
   [
    88.54,
    91.15,
    "communications and electricity."
   ],
   [
    91.4,
    94.02,
    "Some are provided by other organizations."
   ],
   [
    94.62,
    98.01,
    "Sadeed does not operate every system, but still"
   ],
   [
    98.01,
    101.04,
    "needs to understand what it relies on."
   ],
   [
    102.69,
    106.0,
    "Some dependencies support critical infrastructure: essential"
   ],
   [
    106.0,
    109.31,
    "assets, systems and services whose disruption"
   ],
   [
    109.31,
    111.52,
    "could seriously affect society."
   ],
   [
    112.22,
    114.96,
    "Electricity, for example, supports"
   ],
   [
    114.96,
    117.82,
    "many essential services at once."
   ],
   [
    119.47,
    122.01,
    "Confidentiality means preventing information from being"
   ],
   [
    122.01,
    124.56,
    "disclosed to people or systems that"
   ],
   [
    124.56,
    127.1,
    "are not authorized to receive it."
   ],
   [
    127.7,
    130.99,
    "Case 2048 contains private identity"
   ],
   [
    130.99,
    133.17,
    "and contact details."
   ],
   [
    133.42,
    135.39,
    "Having a link does not give someone"
   ],
   [
    135.39,
    137.01,
    "permission to see them."
   ],
   [
    137.36,
    139.3,
    "Sending them to the wrong person"
   ],
   [
    139.3,
    141.31,
    "would break confidentiality."
   ],
   [
    142.96,
    145.67,
    "The service that verifies the applicant’s"
   ],
   [
    145.67,
    147.7,
    "identity is working again."
   ],
   [
    147.85,
    150.45,
    "Shaima finds a wrong decision in"
   ],
   [
    150.45,
    153.06,
    "Case 2048 and checks the approved"
   ],
   [
    153.06,
    154.79,
    "decision before correcting it."
   ],
   [
    156.79,
    160.14,
    "Integrity means protecting information from unauthorized"
   ],
   [
    160.14,
    162.93,
    "or improper change or destruction."
   ],
   [
    163.53,
    166.4,
    "An unapproved change from Approved to Refused"
   ],
   [
    166.4,
    169.42,
    "could give this applicant a wrong decision."
   ],
   [
    169.87,
    172.78,
    "Legitimate corrections need the right checks"
   ],
   [
    172.78,
    175.26,
    "and a record of who changed what."
   ],
   [
    175.51,
    178.38,
    "Shaima saves the checked correction."
   ],
   [
    180.03,
    182.43,
    "Availability means authorized people"
   ],
   [
    182.43,
    184.76,
    "and systems can use information and"
   ],
   [
    184.76,
    186.98,
    "services when they need them."
   ],
   [
    187.23,
    191.12,
    "Earlier, Shaima had access to Case 2048, but the"
   ],
   [
    191.12,
    194.88,
    "applicant’s identity could not be verified."
   ],
   [
    195.13,
    198.05,
    "That dependency delayed the service."
   ],
   [
    200.7,
    202.81,
    "Even a public announcement needs"
   ],
   [
    202.81,
    204.89,
    "integrity and availability."
   ],
   [
    205.14,
    207.84,
    "The public needs the correct opening hours,"
   ],
   [
    207.84,
    210.02,
    "available when they need them."
   ],
   [
    211.67,
    214.23,
    "These protections work together."
   ],
   [
    214.48,
    216.77,
    "A private record is not useful if"
   ],
   [
    216.77,
    219.2,
    "the service cannot retrieve it."
   ],
   [
    219.45,
    222.26,
    "A service that is always online can still"
   ],
   [
    222.26,
    225.22,
    "cause harm if its information is wrong."
   ]
  ]
 },
 "1.05v": {
  "title": "Where weaknesses live",
  "texts": [],
  "sentences": [
   "Weaknesses can appear in people’s decisions, in technology, and in the way an organization works.",
   "A person under pressure may accept an unusual request without checking it.",
   "A device may contain an unresolved software weakness.",
   "A process may leave nobody clearly responsible for approving a sensitive change.",
   "These weaknesses can reinforce each other.",
   "A warning is less useful when staff cannot understand it.",
   "A policy is less effective when the approved process is difficult to find or too slow to use.",
   "Effective protection needs several things together: clear training, practical processes, maintained technology, named responsibilities, and enough support to act safely.",
   "Staff should follow the approved process and raise concerns.",
   "Managers should make that process workable.",
   "When something goes wrong, examine the conditions and controls as well as the individual action."
  ],
  "timing": [
   [
    0.76,
    7.05
   ],
   [
    7.43,
    12.85
   ],
   [
    13.23,
    17.12
   ],
   [
    17.5,
    23.55
   ],
   [
    23.93,
    26.64
   ],
   [
    27.02,
    31.15
   ],
   [
    31.53,
    37.75
   ],
   [
    38.13,
    49.79
   ],
   [
    50.17,
    54.13
   ],
   [
    54.51,
    57.46
   ],
   [
    57.84,
    63.89
   ]
  ],
  "T": 65.27
 },
 "1.06v": {
  "title": "Protection has owners and layers",
  "texts": [],
  "sentences": [
   "Cybersecurity is a shared institutional responsibility, with different duties for different roles.",
   "Leaders set direction, assign accountability, and provide resources.",
   "Service and information owners make decisions about their risks and requirements.",
   "Security and technology teams operate and improve protections.",
   "Privacy, procurement, and other functions contribute their expertise.",
   "Staff use approved tools, protect access and information, follow procedures, and report concerns promptly.",
   "Governance is how the institution sets policy, assigns responsibility, oversees the work, and makes decisions about risk.",
   "Defence in depth combines several protections.",
   "Access controls, maintained software, restricted connections, monitoring, and recovery capabilities address different ways harm can occur.",
   "A failure in one control should not leave the institution relying on nothing else.",
   "No single product or person can guarantee safety.",
   "The protections need clear owners, regular review, and practice working together."
  ],
  "timing": [
   [
    0.76,
    7.46
   ],
   [
    7.84,
    12.86
   ],
   [
    13.24,
    18.26
   ],
   [
    18.64,
    23.3
   ],
   [
    23.68,
    28.77
   ],
   [
    29.15,
    36.93
   ],
   [
    37.31,
    45.93
   ],
   [
    46.31,
    49.91
   ],
   [
    50.29,
    59.82
   ],
   [
    60.2,
    65.91
   ],
   [
    66.29,
    69.72
   ],
   [
    70.1,
    75.72
   ]
  ],
  "T": 77.1
 },
 "1.07v": {
  "title": "Different actors, overlapping motives",
  "texts": [],
  "sentences": [
   "Public institutions face different kinds of hostile activity.",
   "Cybercriminals seek profit through fraud, stolen information, extortion, and other crimes.",
   "Organized networks may divide the work among different specialists.",
   "State-sponsored activity may seek sensitive information, strategic advantage, or disruption.",
   "Espionage may remain hidden, because the objective is to collect information while systems continue operating.",
   "Hacktivists and other politically motivated actors may seek attention, disruption, or exposure of information.",
   "These categories overlap.",
   "A claimed political motive does not prove who is responsible, and similar methods can be used by very different actors.",
   "Employees should recognize suspicious activity and its possible impact.",
   "Identifying who is responsible, called attribution, is specialist work.",
   "For the institution, the practical question remains: which services and information could be harmed, and how do we protect them?"
  ],
  "timing": [
   [
    0.76,
    4.91
   ],
   [
    5.29,
    12.2
   ],
   [
    12.58,
    17.0
   ],
   [
    17.38,
    23.91
   ],
   [
    24.29,
    31.39
   ],
   [
    31.77,
    39.23
   ],
   [
    39.61,
    41.53
   ],
   [
    41.91,
    49.76
   ],
   [
    50.14,
    55.23
   ],
   [
    55.61,
    60.91
   ],
   [
    61.29,
    69.21
   ]
  ],
  "T": 70.59
 },
 "1.08v": {
  "title": "Locked, copied, destroyed",
  "texts": [],
  "sentences": [
   "Ransomware can make files or systems unusable, often through encryption, while criminals demand payment.",
   "An extortion incident may also involve stolen information.",
   "Criminals can threaten to publish it or use it to pressure the institution and the people affected.",
   "Data theft can occur with or without encryption.",
   "Destructive attacks aim to damage or erase information and systems.",
   "Paying does not guarantee recovery, and restoring from a backup does not undo the theft or disclosure of information.",
   "These examples show different kinds of harm.",
   "An incident may combine several of them.",
   "If you see a ransom demand, unexpected loss of access, or signs that information has been stolen, report it immediately through the approved route.",
   "Follow the response plan.",
   "The authorized incident response team decides on containment, recovery, external communication, and any extortion demand."
  ],
  "timing": [
   [
    0.76,
    8.44
   ],
   [
    8.82,
    12.68
   ],
   [
    13.06,
    19.04
   ],
   [
    19.42,
    22.32
   ],
   [
    22.7,
    27.6
   ],
   [
    27.98,
    35.9
   ],
   [
    36.28,
    39.02
   ],
   [
    39.4,
    41.68
   ],
   [
    42.06,
    51.11
   ],
   [
    51.49,
    53.36
   ],
   [
    53.74,
    62.09
   ]
  ],
  "T": 63.47
 },
 "1.09v": {
  "title": "A trusted account can be misused",
  "texts": [],
  "sentences": [
   "An attacker may misuse an identity instead of visibly damaging a system.",
   "Identity theft or misuse means obtaining or using another person's identity information without authorization.",
   "Credential compromise can give an unauthorized person access to an account or help them impersonate its holder.",
   "A compromised account may send messages that appear to come from a trusted colleague or supplier.",
   "Here, Rania sees a request to change payment information.",
   "The account looks familiar.",
   "The instruction still needs the required verification and approval.",
   "Financial fraud may depend on one apparently small change: a payment destination, an administrative record, or an authorization.",
   "Protecting an account includes its password and other sign-in methods, its recovery process, and its active sessions.",
   "When a request is unusual or sensitive, verify both who is asking and whether the action is permitted."
  ],
  "timing": [
   [
    0.76,
    6.11
   ],
   [
    6.49,
    14.29
   ],
   [
    14.67,
    21.22
   ],
   [
    21.6,
    27.43
   ],
   [
    27.81,
    31.6
   ],
   [
    31.98,
    33.85
   ],
   [
    34.23,
    38.67
   ],
   [
    39.05,
    47.93
   ],
   [
    48.31,
    56.06
   ],
   [
    56.44,
    63.59
   ]
  ],
  "T": 64.97
 },
 "1.10v": {
  "title": "The weakness in the software",
  "texts": [],
  "sentences": [
   "Software can contain weaknesses in its design, code, or configuration.",
   "Suppliers and security teams identify many vulnerabilities and provide fixes or other protective measures.",
   "Delaying an approved update can leave a known weakness exposed.",
   "Zero-day exploitation uses a flaw that was previously unknown to the supplier or to defenders.",
   "At that point, an effective security fix may not yet be available.",
   "This is one reason security cannot rely entirely on patching.",
   "Limiting access, monitoring systems, using secure settings, and being ready to respond also matter.",
   "Staff should use approved software, allow required updates, and report any problem that stops an update from completing.",
   "Technical teams assess the risk and manage deployment safely, especially where an update could affect a critical service.",
   "Do not attempt an unofficial repair from an unexpected message or website.",
   "Use the institution’s established support process."
  ],
  "timing": [
   [
    0.76,
    5.87
   ],
   [
    6.25,
    14.0
   ],
   [
    14.38,
    18.53
   ],
   [
    18.91,
    25.51
   ],
   [
    25.89,
    30.81
   ],
   [
    31.19,
    35.61
   ],
   [
    35.99,
    42.97
   ],
   [
    43.35,
    50.79
   ],
   [
    51.17,
    58.68
   ],
   [
    59.06,
    63.98
   ],
   [
    64.36,
    67.94
   ]
  ],
  "T": 69.32
 },
 "1.11v": {
  "title": "Trust arrives through other people",
  "texts": [],
  "sentences": [
   "Institutions rely on suppliers, contractors, software, and connected services.",
   "If one of those is compromised, the consequences may reach the institution through an update, a dependency, a service connection, or authorized access.",
   "This is a supply-chain risk.",
   "Trust in a supplier still needs defined responsibilities, appropriate access, monitoring, and review.",
   "Harm can also begin inside the institution.",
   "Someone may deliberately misuse legitimate access.",
   "An employee may also cause harm unintentionally, for example by sharing information with the wrong audience.",
   "These situations require different investigations, but both show why access should fit an authorized purpose.",
   "Report suspicious behavior or an accidental exposure through the approved route.",
   "Describe what you observed.",
   "Avoid unsupported accusations.",
   "Authorized teams need the facts to protect information and assess what happened."
  ],
  "timing": [
   [
    0.76,
    6.9
   ],
   [
    7.28,
    17.84
   ],
   [
    18.22,
    20.12
   ],
   [
    20.5,
    27.17
   ],
   [
    27.55,
    30.41
   ],
   [
    30.79,
    34.17
   ],
   [
    34.55,
    41.41
   ],
   [
    41.79,
    49.16
   ],
   [
    49.54,
    54.51
   ],
   [
    54.89,
    56.76
   ],
   [
    57.14,
    59.49
   ],
   [
    59.87,
    64.84
   ]
  ],
  "T": 66.22
 },
 "1.12v": {
  "title": "When a digital problem becomes a public problem",
  "texts": [],
  "sentences": [
   "A digital incident can become a public-service problem very quickly.",
   "If an identity service is unavailable, an applicant may be unable to complete an application.",
   "If a payment service is disrupted, money may not reach its intended recipient on time.",
   "A problem in a shared provider can affect several institutions at once.",
   "Attacks against essential services can have operational, financial, and societal consequences.",
   "Some can also affect safety.",
   "The impact depends on the service, its dependencies, the duration of disruption, and the alternatives available.",
   "That is why institutions identify critical services, prepare safe ways to keep essential work going, and test recovery.",
   "Staff contribute by protecting their part of the process, reporting early, and following approved alternative procedures.",
   "Return to the applicant at the counter.",
   "A system’s availability, integrity, and confidentiality all affect the service they receive."
  ],
  "timing": [
   [
    0.76,
    4.96
   ],
   [
    5.34,
    11.92
   ],
   [
    12.3,
    17.7
   ],
   [
    18.08,
    22.9
   ],
   [
    23.28,
    29.78
   ],
   [
    30.16,
    32.03
   ],
   [
    32.41,
    39.39
   ],
   [
    39.77,
    48.24
   ],
   [
    48.62,
    56.85
   ],
   [
    57.23,
    59.53
   ],
   [
    59.91,
    66.32
   ]
  ],
  "T": 67.7
 },
 "1.13v": {
  "title": "AI makes deception more convincing",
  "texts": [],
  "sentences": [
   "An attacker can use AI tools to analyze public information about an institution, its staff, and its activities.",
   "This information gathering is called reconnaissance: it helps an attacker understand possible targets.",
   "AI can also help identify relevant people and generate messages that fit their work, language, and circumstances.",
   "A phishing message may be polished, specific, and free of obvious mistakes.",
   "It may refer to a real project or imitate a familiar style.",
   "Those details can make a request feel credible.",
   "They do not establish who sent it or whether it is authorized.",
   "Here, Shaima recognizes the subject of the message.",
   "She still checks the unusual request through an established route.",
   "You do not need to prove that AI wrote a message before treating it cautiously.",
   "Focus on the requested action, the information involved, and the evidence of authority."
  ],
  "timing": [
   [
    0.76,
    8.34
   ],
   [
    8.72,
    14.82
   ],
   [
    15.2,
    22.83
   ],
   [
    23.21,
    28.42
   ],
   [
    28.8,
    33.46
   ],
   [
    33.84,
    37.01
   ],
   [
    37.39,
    40.97
   ],
   [
    41.35,
    44.9
   ],
   [
    45.28,
    49.31
   ],
   [
    49.69,
    54.35
   ],
   [
    54.73,
    59.96
   ]
  ],
  "T": 61.34
 },
 "1.14v": {
  "title": "AI increases operational speed",
  "texts": [],
  "sentences": [
   "AI can also assist more technical parts of hostile activity.",
   "It can help analyze software weaknesses, support attempts to exploit them, and generate or modify malicious code.",
   "Automation can help coordinate repeated tasks and increase the speed or scale of an operation.",
   "In a semi-autonomous process, people still choose, direct or approve the important actions.",
   "A more autonomous system is allowed to choose and carry out more actions, within the limits, access and goals given to it.",
   "These capabilities vary.",
   "Generated code can fail, conclusions can be wrong, and human operators often remain important.",
   "Claims that an attack was fully autonomous need evidence.",
   "For defenders, the practical implication is pressure to maintain protections and respond promptly.",
   "Restrict unnecessary access, keep approved systems maintained, and escalate concerns.",
   "Do not assume that either a dramatic claim or a reassuring label tells the whole story."
  ],
  "timing": [
   [
    0.76,
    4.98
   ],
   [
    5.36,
    12.58
   ],
   [
    12.96,
    19.3
   ],
   [
    19.68,
    26.28
   ],
   [
    26.66,
    35.01
   ],
   [
    35.39,
    37.17
   ],
   [
    37.55,
    44.01
   ],
   [
    44.39,
    48.23
   ],
   [
    48.61,
    55.43
   ],
   [
    55.81,
    62.31
   ],
   [
    62.69,
    67.87
   ]
  ],
  "T": 69.25
 },
 "1.15v": {
  "title": "AI can help the defenders",
  "texts": [],
  "sentences": [
   "AI can help defenders work with large amounts of security information.",
   "It can connect observations from accounts, devices, cloud services and applications, then highlight patterns that need attention.",
   "It can also help summarize an incident or suggest priorities for review.",
   "But a convincing explanation is not the same as verified evidence.",
   "AI may mistake normal behavior for a threat, miss an important event, or produce an incorrect analysis.",
   "Poorly controlled automation can also interrupt legitimate work or take actions beyond what was intended.",
   "Here, Omar checks the underlying observations before approving a significant response.",
   "Effective defensive use needs suitable information, evaluation, monitoring, clear permissions, and human oversight.",
   "Your role remains important.",
   "An early report from a person who notices something unusual can provide context that automated monitoring does not have."
  ],
  "timing": [
   [
    0.76,
    5.3
   ],
   [
    5.68,
    13.72
   ],
   [
    14.1,
    18.28
   ],
   [
    18.66,
    23.6
   ],
   [
    23.98,
    31.11
   ],
   [
    31.49,
    37.9
   ],
   [
    38.28,
    44.5
   ],
   [
    44.88,
    53.18
   ],
   [
    53.56,
    55.43
   ],
   [
    55.81,
    63.54
   ]
  ],
  "T": 64.92
 },
 "1.16v": {
  "title": "The first decision",
  "texts": [],
  "sentences": [
   "Shaima receives an urgent request to use a new AI service with applicant records.",
   "The message claims that the director has approved it.",
   "The request looks professional and refers to real work.",
   "Think about what matters here.",
   "The information may be sensitive.",
   "The tool’s approval and permitted use have not been established.",
   "The message’s claim of authority has not been independently verified.",
   "What should Shaima do?",
   "Upload immediately, reply to confirm, or verify through approved channels?",
   "Shaima should verify through approved channels.",
   "That means checking the claimed authority independently, confirming whether the tool and its use are permitted, and reporting the unusual request through the approved reporting route.",
   "The records remain in the approved environment while those checks happen.",
   "Cybersecurity protects confidentiality, integrity, and availability so that public services remain trustworthy.",
   "AI can change the speed and appearance of a threat.",
   "Clear responsibilities, layered protection, careful verification, and early reporting remain essential.",
   "In the next chapter, we follow a convincing request across email, websites, telephone calls, and workplace messages."
  ],
  "timing": [
   [
    0.76,
    6.59
   ],
   [
    6.97,
    9.83
   ],
   [
    10.21,
    13.88
   ],
   [
    14.26,
    16.13
   ],
   [
    16.51,
    19.1
   ],
   [
    19.48,
    23.7
   ],
   [
    24.08,
    28.54
   ],
   [
    28.92,
    30.79
   ],
   [
    31.17,
    37.07
   ],
   [
    37.45,
    40.83
   ],
   [
    41.21,
    51.82
   ],
   [
    52.2,
    56.14
   ],
   [
    56.52,
    64.63
   ],
   [
    65.01,
    68.32
   ],
   [
    68.7,
    75.83
   ],
   [
    76.21,
    84.27
   ]
  ],
  "T": 85.65
 }
};
