// When the supplier is the one attacked.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, mail, row } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.3',
  actors: { official: 'director', maya: 'counter', omar: 'desk' },
  file: [[0, D.T, 1, 1]],
  landline: 'desk',
  shots: [[0, 'gathering'], [S(2), 'desk'], [S(4), 'display'], [S(5), 'file'], [S(6), 'her'], [S(12), 'gathering'], [S(15), 'display'], [S(16), 'gathering']],
  actions: {
    official: [[0, S(3), 'paper'], [S(3), S(5), 'talk', 'omar'], [S(5), S(12), 'listen', 'maya'], [S(12), S(15), 'talk', 'maya'], [S(15), D.T, 'listen', 'omar']],
    maya: [[0, S(5), 'listen', 'official'], [S(5), S(12), 'file'], [S(12), D.T, 'listen', 'official']],
    omar: [[0, S(4), 'read'], [S(4), S(5), 'type'], [S(5), S(15), 'read'], [S(15), S(16), 'extension'], [S(16), D.T, 'type']],
  },
  displays: {
    desk: [
      [0, S(4), 'mail', 'Contractor cyber incident', 'alert'],
      [S(4), S(15), 'lock', 'Accounts suspended · Log checked', 'safe'],
      [S(15), D.T, 'key', 'Restored · New credentials', 'safe'],
    ],
    counter: [
      [0, S(15), 'folder', 'Case 2048 · Paper work', 'neutral'],
      [S(15), D.T, 'tick', 'Contained · Access restored', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Scanning contractor incident'],
    [S(4), E(4), 'Accounts suspended · Logs checked'],
    [S(5), E(5), 'Paper file · No shortcuts'],
    [S(15), E(15), 'Contained · New credentials'],
  ],
  screens: [
    [S(0), S(2), win('Inbox', mail('DocScan Contractor', 'notice@docscan-vendor.example', 'Cyber incident on our systems', 'We had a cyber incident on our systems.'), 'alert')],
    [S(4), S(5), win('IT action · Contractor access', row('Accounts', 'Suspended immediately', 'ok') + row('Access log', 'Checked for activity', 'ok') + row('Verification', 'Called contract contact', 'ok'), 'good')],
  ],
  pages: [
    hero(S(6), S(12), 'Compromised service provider', 'show:monitor:Service provider alert|Attackers target outside|help desks too|A supplier breach can disrupt|care for the public', [
      ['Attackers target contracted help desks too', S(7), 'v-coral'],
      ['One supplier attack can disrupt public care', S(10), 'v-amber'],
    ]),
    hero(S(12), S(14), 'Named accounts, least access', 'show:paper:Your Work Account|Use your own account|Never share your login|Limit access to the task|End access when the job ends', [
      ['One named account each, never shared logins', S(12), 'v-teal'],
      ['Only the access and time the job needs', S(13), 'v-navy'],
    ]),
    hero(S(14), S(16), 'Let IT call back on the contract number', 'show:paper:Supplier Calls|Caller asks for a reset?|Do not reset or give a code|IT calls the contract number', [
      ['Never grant resets or codes on incoming calls', S(14), 'v-coral'],
      ['Let IT verify on the number in the contract', S(15), 'v-teal'],
    ]),
    hero(S(16), D.T, 'Report supplier incidents', 'show:clipboard:Supplier Incident Form|Describe the incident|Include any unusual request|Report early', [
      ['Report supplier incidents or odd requests early', S(16), 'v-teal'],
    ]),
  ],
}));
