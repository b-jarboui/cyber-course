// The parts inside, the visitor with a laptop.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'omar', 'maya', 'supplier'];
export default chapterHall((S, E, D) => ({
  lesson: '7.3',
  actors: { official: 'director', omar: 'colleague', maya: 'counter', supplier: 'visitor' },
  enter: { supplier: S(9) },
  file: [[0, E(0), 0, 1]],
  landline: true,
  shots: [[0, 'gathering'], [S(2), 'staff'], [S(4), 'counterDisplay'], [S(9), 'counter'], [S(10), 'her'], [S(13), 'counter'], [S(16), 'counterDisplay'], [S(18), 'gathering']],
  actions: {
    official: [[0, S(2), 'talk', 'maya'], [S(2), S(6), 'listen', 'omar'], [S(6), S(9), 'paper'], [S(9), D.T, 'listen', 'maya']],
    omar: [[0, S(2), 'listen', 'official'], [S(2), S(6), 'talk', 'maya'], [S(6), S(11), 'listen', 'official'], [S(11), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'maya']],
    maya: [[0, S(9), 'listen', 'official'], [S(9), S(11), 'listen', 'supplier'], [S(11), S(12), 'listen', 'omar'], [S(12), S(13), 'talk', 'supplier'], [S(13), S(14), 'extension'], [S(14), D.T, 'read']],
    supplier: [[S(9), S(11), 'talk', 'maya'], [S(11), S(16), 'listen', 'maya'], [S(16), S(17), 'paper'], [S(17), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(9), 'file', 'Case system · Components list', 'neutral'],
      [S(9), S(13), 'key', 'Visitor asks for staff login', 'alert', 'login'],
      [S(13), S(16), 'folder', 'Contract check · IT verified', 'neutral'],
      [S(16), D.T, 'tick', 'Named temp account · Logged', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case system · Many parts'],
    [S(9), E(9), 'Supplier technician at counter'],
    [S(13), E(13), 'Visit checked against contract'],
    [S(16), E(16), 'Named account · Afternoon only'],
  ],
  screens: [
    [S(0), S(2), win('Case system · Components', row('Core system', 'CaseSys Vendor', 'hi') + row('Report engine', 'Third-party library', 'warn') + row('PDF module', 'External code library', 'warn'))],
    [S(9), S(11), win('Sign-in · Counter terminal', row('Visitor', 'Supplier technician', 'warn') + row('Request', "Use Shaima's staff login", 'no') + note('Never share your own account.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(2), S(4), 'Dependencies', 'show:monitor:What Our System Uses|Code from other sources|Services from other providers|One flaw can harm the system', [
      ['External code libraries and services inside', S(2), 'v-navy'],
      ['One flawed part can put the system at risk', S(3), 'v-coral'],
    ]),
    hero(S(4), S(9), 'Software components list', 'show:paper:Software Parts List|Lists every part of the tool|Adding a tool or code library?|Ask IT first', [
      ['Lists every part inside the software', S(5), 'v-teal'],
      ['Ask IT before adding tools or libraries', S(8), 'v-navy'],
    ]),
    hero(S(11), S(14), 'Never share your login', 'show:notice:Never Share Your Login|Every action carries your name|Contractor visit at your desk?|Call IT to verify the contract', [
      ['Actions under your login carry your name', S(12), 'v-coral'],
      ['Call IT to verify visits against the contract', S(13), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Named account, least privilege', 'show:clipboard:Temporary Access Log|One server only|One afternoon only|Log every action|Afterward: close the account', [
      ['One server, one afternoon, every action logged', S(16), 'v-teal'],
      ['Account closed and log reviewed after work', S(17), 'v-navy'],
    ]),
  ],
}));
