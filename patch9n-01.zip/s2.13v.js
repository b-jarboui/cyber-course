// An invoice nobody ordered, a record nobody asked to change.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, mail } from './screens-tr.js';

export const texts = [];
export const cast = ['finance', 'admin', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '2.3',
  actors: { finance: 'beside', admin: 'desk', maya: 'counter' },
  shots: [[0,'pair'], [S(1),'finance'], [S(3),'desk'], [S(4),'display'], [S(6),'finance'], [S(7),'counterDisplay'], [S(8),'her'], [S(10),'file'], [S(11),'her'], [S(12),'her'], [S(14),'hall']],
  file: [[S(10),(S(10)+E(10))/2,0,1]],
  actions: {
    finance: [[0,S(3),'paper'], [S(3),S(6),'talk','admin'], [S(6),E(6),'call'], [S(7),D.T,'listen','admin']],
    admin: [[S(3),S(5),'type'], [S(5),S(7),'talk','finance'], [S(14),D.T,'type']],
    maya: [[S(7),S(10),'read'], [S(10),(S(10)+E(10))/2,'file'], [(S(10)+E(10))/2,E(11),'call'], [S(14),D.T,'type']],
  },
  displays: {
    desk: [[0,S(3),'mail','Workshop invoice','neutral','inbox'], [S(3),D.T,'folder','No matching order','alert']],
    counter: [[S(7),D.T,'mail','Refund account change','alert','inbox']],
  },
  plates: [[S(0),E(0),'Workshop invoice'], [S(1),E(1),'Due today'], [S(3),E(3),'Purchase order search'], [S(7),E(7),'Refund account change'], [S(10),E(10),'Number in the case file'], [S(14),E(14),'Two requests reported']],
  screens: [
    [S(0), S(2), win('Inbox', mail('Executive Training', 'billing@exec-workshop.example', 'Workshop invoice — Due today', 'Approved by Hamad. Please pay today.'), 'alert')],
    [S(3), S(4), win('Procurement system', row('Search', 'Executive Training', 'wait') + row('Purchase order', 'No matching order', 'no') + row('Supplier record', 'None on file', 'no'), 'alert')],
    [S(7), S(8), win('Inbox', mail('Case 2048 Refund', 'refund-update@mail-share.example', 'Case 2048 — Refund account change', 'Please send the refund to account ending 7305.'), 'alert')],
  ],
  pages: [
    hero(S(4), S(5), 'No purchase order, no payment', 'show:paper:Payment check|Invoice received|No matching purchase order|Payment blocked', [
      ['No matching order', S(4), 'v-amber'],
    ]),
    hero(S(5), S(6), 'Check the invoice against the record', 'show:clipboard:Invoice check|Compare invoice with record|Match the approved purchase', [
      ['Approved purchase', S(5), 'v-teal'],
    ]),
    hero(S(12), S(13), 'Record changes need verification', 'show:paper:Record change form|Verify the requested change|Get approval before editing', [
      ['Verify and authorise', S(12), 'v-teal'],
    ]),
    hero(S(13), S(14), 'Unexpected change alert? Report it', 'show:monitor:Account change alert|Your account details changed|Did you request this?|If you did not, report it', [
      ['Unrequested account change', S(13), 'v-amber'],
    ]),
  ],
}));
