// A sign-in page that only looks right.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, mail } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { omar: 'desk', maya: 'beside' },
  shots: [[0,'pair'], [S(1),'desk'], [S(2),'display'], [S(6),'desk'], [S(8),'display'], [S(9),'pair'], [S(13),'desk']],
  actions: {
    omar: [[0,S(7),'read'], [S(7),S(8),'type'], [S(8),S(9),'read'], [S(9),S(13),'talk','maya'], [S(13),D.T,'type']],
    maya: [[0,S(9),'listen','omar'], [S(9),E(9),'talk','omar'], [S(10),D.T,'listen','omar']],
  },
  displays: { desk: [[0,S(2),'mail','Mailbox suspension','alert','inbox'], [S(2),S(7),'lock','Sign in','alert','login'], [S(7),D.T,'mail','Official mailbox','safe','inbox']] },
  plates: [[S(1),E(1),'Mailbox suspension'], [S(2),E(2),'Sign in'], [S(6),E(6),'Page closed'], [S(9),E(9),'One password']],
  // Readable close-ups of what Omar sees (audit round 1: the address and the message must be legible). Fictional .example addresses.
  screens: [
    [S(1), S(2), win('Inbox', mail('IT Service Desk', 'it-support@sadeed-gov.example', 'Your mailbox will be suspended today', 'Sign in within 2 hours to keep your mailbox active.'), 'alert')],
    [S(2), S(3), win('portal.sadeed-gov.example', row('Address', 'sadeed-gov.example', 'no') + row('Username', '') + row('Password', '') + note('Looks exactly like the real page.', 'warn'), 'alert')],
    [S(6), S(7), win('Two addresses', row('Real portal', 'portal.sadeed.gov.example', 'ok') + row('Link in the email', 'portal.sadeed-gov.example', 'no') + note('One dash makes it a different website.', 'no'))],
  ],
  pages: [
    hero(S(3), S(6), 'Fake sign-in pages steal credentials', 'show:monitor:Fake sign-in page|At risk: username and password|Check the web address', [
      ['Username and password', S(3), 'v-amber'],
      ['Check the web address', S(4), 'v-teal'],
    ]),
    hero(S(7), S(9), 'Type the official address yourself', 'show:monitor:Official mailbox|Type the official web address', [
      ['Official mailbox', S(8), 'v-teal'],
    ]),
    hero(S(11), S(13), 'Business email compromise', 'show:monitor:Work email alert|Someone misused a work account|The email asks for money', [
      ['Requests for money', S(11), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Entered your password? Report now', 'show:deskphone:IT Security Desk|Entered password? Report now', [
      ['Report immediately', S(14), 'v-teal'],
    ]),
  ],
}));
