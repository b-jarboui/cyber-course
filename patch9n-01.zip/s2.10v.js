// A fix you should never run.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, head, btn } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.2',
  cable: { device: 'desk' },
  actors: { maya: 'counter', omar: 'desk' },
  shots: [[0,'counter'], [S(1),'counterDisplay'], [S(3),'her'], [S(9),'her'], [S(11),'desk'], [S(12),'her']],
  actions: {
    maya: [[0,S(1),'type'], [S(1),S(10),'read'], [S(10),S(11),'type'], [S(11),S(12),'listen','omar'], [S(12),D.T,'type']],
    omar: [[S(11),D.T,'type']],
  },
  displays: {
    counter: [[0,S(1),'file','Blank case form','neutral'], [S(1),S(2),'tick','Human verification','neutral'], [S(2),S(10),'tools','Unexpected system prompt','alert'], [S(10),D.T,'computer','Page closed','safe']],
    desk: [[S(11),D.T,'folder','Internal document library','safe']],
  },
  plates: [[S(0),E(0),'Blank case form'], [S(1),E(1),'Human verification'], [S(2),E(2),'Unexpected system prompt'], [S(10),E(10),'Page closed'], [S(11),E(11),'Internal document library']],
  screens: [
    [S(1), S(2), win('forms-download.example', head('Human verification', 'Confirm you are not a robot') + btn('Verify I am human'))],
    [S(2), S(3), win('Verification steps', row('Step 1', 'Open system run window', 'no') + row('Step 2', 'Paste •••••• and press Enter', 'no') + note('A real check never leaves the browser.', 'no'), 'alert')],
    [S(11), S(12), win('Internal document library', row('Source', 'docs.sadeed.gov.example', 'ok') + row('Form', 'Case 2048 blank form', 'ok') + note('Official source for Authority forms.'), 'good')],
  ],
  pages: [
    hero(S(3), S(9), 'ClickFix: a fake fix', 'show:monitor:Fake document error|Unexpected system prompt|The suggested fix is a trick', [
      ['Unexpected system prompt', S(3), 'v-amber'],
      ['A false document error', S(7), 'v-amber'],
    ]),
    hero(S(9), S(10), 'A real check stays in the browser', 'show:monitor:Browser check|Confirm you are human|Stay on this page', [
      ['Browser check', S(9), 'v-teal'],
    ]),
    hero(S(13), S(14), 'Never paste and run from a web page', 'show:notice:Web page rule|Never paste commands from web|Never run fixes copied online|Close the window immediately', [
      ['Close the window', S(13), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Ran it? Disconnect and report', 'show:clipboard:Ran the command?|Disconnect from the network|Report it immediately', [
      ['Report immediately', S(14), 'v-teal'],
    ]),
  ],
}));
