// Remove the cause, restore with care.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'admin', 'maya', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '9.3',
  set: [[0, S(15), 'ops'], [S(15), D.T, 'hall']],
  actorSets: { omar: 'ops', admin: 'ops', citizen: 'hall' },
  actors: { omar: 'signer', admin: 'desk', maya: { ops: 'beside', hall: 'counter' }, citizen: 'visitor' },
  file: [[0, D.T, 1, 1]],
  signing: true,
  shots: [[0, 'gathering'], [S(4), 'display'], [S(6), 'desk'], [S(8), 'staff'], [S(11), 'file'], [S(12), 'file'], [S(14), 'display'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(12), 'read'], [S(12), S(14), 'listen', 'omar'], [S(14), S(15), 'read'], [S(15), D.T, 'talk', 'citizen']],
    omar: [[0, S(12), 'listen', 'maya'], [S(12), S(14), 'sign'], [S(14), S(15), 'listen', 'maya']],
    admin: [[0, S(8), 'type'], [S(8), S(12), 'read'], [S(12), D.T, 'type']],
    citizen: [[S(15), D.T, 'listen', 'maya']],
  },
  displays: {
    desk: [
      [0, S(4), 'lock', 'Systems offline · Team removing the cause', 'alert'],
      [S(4), S(14), 'tools', 'Checking clean backups · 2048', 'neutral'],
      [S(14), D.T, 'tick', 'Services checked and cleared for use', 'safe'],
    ],
    counter: [
      [0, S(4), 'lock', 'Case 2048 · Held for recovery', 'alert'],
      [S(4), S(14), 'tools', 'Restoring critical services', 'neutral'],
      [S(14), D.T, 'tick', 'Counter open · Clean system', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Contain · Remove · Recover'],
    [S(5), E(5), 'Restored on a clean network'],
    [S(12), E(12), 'Laptop sealed · Handover signed'],
    [S(15), E(15), 'Counter reopened · Clean system'],
  ],
  screens: [
    [S(15), E(15), win('Recovery status · Counter open', row('Core systems', 'Restored on clean network', 'ok') + row('Backups', 'Checked before restore', 'ok') + row('Case 2048', 'Active on clean system', 'ok'), 'good')],
  ],
  pages: [
    hero(S(1), S(4), 'Contain · Remove · Recover', 'show:whiteboard:Incident Response|Stop the spread|Remove the cause|End misused access|Close any way back in', [
      ['Contain spread, then remove the root cause', S(1), 'v-navy'],
      ['Remove misused access and any way back in', S(2), 'v-coral'],
      ['Recover services safely for the public', S(3), 'v-teal'],
    ]),
    hero(S(4), S(8), 'Critical services first, from clean backups', 'show:clipboard:Service Recovery Plan|Check that backups are clean|Rebuild on a clean network|Restore key services in order|Backups cannot undo data theft', [
      ['Restore critical services in planned order', S(4), 'v-teal'],
      ['Check backups first; rebuild on clean network', S(5), 'v-navy'],
      ['Backups cannot undo data already stolen', S(7), 'v-amber'],
    ]),
    hero(S(8), S(15), 'Evidence: recorded, sealed, handed over', 'show:paper:Evidence Handover Form|Device or log: __________|Keep the evidence untouched|Give only to authorized staff|Sign the handover record', [
      ['Forensics examines devices and logs', S(8), 'v-navy'],
      ['Hand the device to authorised staff and sign the custody record', S(12), 'v-teal'],
      ['Hand over untouched to authorized team only', S(13), 'v-coral'],
    ]),
  ],
}));
