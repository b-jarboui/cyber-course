// Locked, and copied too.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, mail } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '8.1',
  actors: { maya: 'counter', omar: 'colleague', official: 'director' },
  file: [[0, D.T, 1, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(3), 'staff'], [S(7), 'gathering'], [S(9), 'her'], [S(12), 'her'], [(S(12) + E(12)) / 2, 'counter'], [S(13), 'her']],
  actions: {
    maya: [[0, S(3), 'read'], [S(3), S(9), 'listen', 'omar'], [S(9), S(10), 'read'], [S(10), S(12), 'type'], [S(12), S(13), 'extension'], [S(13), D.T, 'read']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(8), 'talk', 'maya'], [S(8), D.T, 'listen', 'maya']],
    official: [[0, S(8), 'paper'], [S(8), S(9), 'talk', 'maya'], [S(9), D.T, 'paper']],
  },
  displays: {
    counter: [
      [0, S(1), 'mail', 'General mailbox · New email', 'neutral', 'inbox'],
      [S(1), S(10), 'mail', 'Threat to publish files', 'alert', 'inbox'],
      [S(10), D.T, 'bell', 'Reported · Kept as evidence', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'General mailbox · New email'],
    [S(2), E(2), 'Threat to publish files'],
    [S(10), E(10), 'Reported · Kept as evidence'],
    [S(12), E(12), 'Official channel only'],
  ],
  screens: [
    [S(1), S(3), win('General mailbox', mail('Unknown Sender', 'extort@outside-mail.example', 'Sender claims Case 2048 files were copied', 'We copied your files. Pay or we publish them.'), 'alert')],
    [S(12), S(13), phone('Desk call · Applicant', row('Caller asks', 'Status of Case 2048', 'wait') + row('Incident details', 'Unconfirmed', 'ok') + row('Next step', 'Official channel contact', 'ok'))],
  ],
  pages: [
    hero(S(3), S(7), 'Double extortion: lock and threaten to publish', 'show:monitor:Two Ransom Threats|Criminals may lock files|They threaten to publish data|Some skip locking the files|Microsoft saw data collection', [
      ['Lock files and threaten to release data', S(3), 'v-coral'],
      ['Some criminals skip encryption and only extort', S(4), 'v-amber'],
      ['Microsoft observed data collection in 79.5% of reactive investigations', S(6), 'v-coral'],
    ]),
    hero(S(7), S(9), 'A backup does not undo the theft', 'show:monitor:Restoring Files|A backup can restore files|Stolen copies still exist|Applicants are still at risk', [
      ['Backups restore files, not confidentiality', S(7), 'v-amber'],
      ['Personal data theft puts applicants at risk', S(8), 'v-coral'],
    ]),
    hero(S(9), S(12), 'Do not reply, negotiate or forward', 'show:notice:Extortion Messages|Do not reply or negotiate|Do not forward the message|Keep the original untouched|The authorized team decides', [
      ['Keep the message untouched as evidence', S(10), 'v-navy'],
      ['Authorised team decides all response steps', S(11), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Report through the approved route', 'show:clipboard:Report an Incident|Keep the original message|Use the approved report route|Updates for applicants:|Share only approved wording', [
      ['Keep the original and report through the approved route', S(13), 'v-coral'],
      ['Give applicants only the approved update', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
