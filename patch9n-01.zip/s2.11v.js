// The manager's voice, but not the manager.
import { chapterHall, hero } from './chapter2-hall.js';
import { phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['finance', 'maya', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '2.3',
  set: [[0, S(11) + .45 * (E(11) - S(11)), 'hall'], [S(11) + .45 * (E(11) - S(11)), D.T, 'office']],
  actorSets: { maya: 'hall', official: 'office' },
  actors: { finance: { hall: 'beside', office: 'door' }, maya: 'counter', official: 'desk' },
  landline: 'desk',
  handsets: { finance: [[S(1),S(4),'chat'], [S(4),S(11),'mobile'], [S(14),D.T,'bell']] },
  shots: [[0,'hall'], [S(1),'finance'], [S(3),'finance'], [S(7),'pair'], [S(10),'finance'], [S(11),'finance'], [S(11)+.45*(E(11)-S(11)),'pair'], [S(14),'pair']],
  walks: { finance: [[S(11)+.45*(E(11)-S(11)),E(11),'beside']] },
  actions: {
    finance: [[S(1),S(2),'text'], [S(2),S(4),'call'], [S(4),S(11),'text'], [S(11),S(11)+.45*(E(11)-S(11)),'call'], [E(11),S(14),'listen','official'], [S(14),D.T,'text']],
    official: [[S(11)+.45*(E(11)-S(11)),E(11),'extension'], [S(12),D.T,'talk','finance']],
    maya: [[0,S(10),'type'], [S(10),D.T,'listen','finance']],
  },
  plates: [[S(1),E(1),'Voice message'], [S(3),E(3),'Private payment request'], [S(7),E(7),'Another messaging app'], [S(10),E(10),'No reply'], [S(12),E(12),'No payment requested'], [S(14),E(14),'Message retained']],
  screens: [
    [S(1), S(2), phone('Voice message', row('From', '+971 50 000 0634', 'warn') + row('Audio', '0:18 · Sounds like Hamad', 'warn') + note('Number not in contacts.', 'warn'))],
    [S(3), S(4), phone('Voice message', row('Request', 'Urgent, confidential payment', 'no') + row('Channel', 'Move to private chat app', 'no') + note('Pressure plus secrecy.', 'no'))],
    [S(10), S(11), phone('No reply', row('Private chat', 'Not opened', 'ok') + row('Next step', 'Call Hamad on Ext. 4102', 'ok') + note('Verify through the internal directory.'))],
  ],
  pages: [
    hero(S(2), S(3), 'A familiar voice is not proof', 'show:phone:Incoming call|Sounds like Hamad|A familiar voice is not proof', [
      ['Hamad’s voice', S(2), 'v-amber'],
    ]),
    hero(S(4), S(7), 'Deepfakes copy voices and faces', 'show:monitor:Faces and voices|A face on screen can be faked|So can a manager’s voice', [
      ['An imitation of the manager’s voice', S(4), 'v-amber'],
    ]),
    hero(S(8), S(10), 'Do not move to a private channel', 'show:phone:Private chat request|Use a private app for payment|Keep this quiet|Stay on work channels', [
      ['Private payment request', S(8), 'v-amber'],
      ['Request for secrecy', S(9), 'v-amber'],
    ]),
    hero(S(13), S(14), 'Call back on the known number', 'show:deskphone:Call Hamad back|Use his internal extension', [
      ['Hamad’s internal extension', S(13), 'v-teal'],
    ]),
  ],
}));
