// A fake payment request and unusual access to records.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '8.2',
  tablet: { title: 'IT alert · Night access' },
  actors: { maya: 'counter', omar: 'colleague', official: 'director', citizen: 'visitor' },
  handsets: { citizen: [[0, S(8), 'credit-card']] },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'counter'], [S(2), 'her'], [S(3), 'staff'], [S(7), 'counterDisplay'], [S(8), 'gathering'], [S(9), 'staff'], [S(12), 'gathering'], [S(13), 'counter']],
  actions: {
    maya: [[0, S(2), 'listen', 'citizen'], [S(2), S(3), 'talk', 'citizen'], [S(3), S(7), 'listen', 'omar'], [S(7), S(8), 'type'], [S(8), S(9), 'listen', 'official'], [S(9), S(11), 'listen', 'omar'], [S(11), S(12), 'listen', 'official'], [S(12), D.T, 'listen', 'omar']],
    omar: [[0, S(3), 'listen', 'citizen'], [S(3), S(7), 'talk', 'maya'], [S(7), S(9), 'listen', 'official'], [S(9), S(11), 'talk', 'maya'], [S(11), S(12), 'listen', 'official'], [S(12), D.T, 'paper']],
    official: [[0, S(8), 'listen', 'citizen'], [S(8), S(11), 'tablet'], [S(11), S(12), 'talk', 'maya'], [S(12), D.T, 'tablet']],
    citizen: [[0, S(2), 'text'], [S(2), S(8), 'listen', 'maya'], [S(8), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(7), 'credit-card', 'Text link · Fake fee request', 'alert'],
      [S(7), S(8), 'bell', 'Fake payment link reported', 'safe'],
      [S(8), S(12), 'zoom', 'Alert · Night access to records', 'alert'],
      [S(12), D.T, 'shield', 'Approval request declined · Reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Text message · Fake payment link'],
    [S(7), E(7), 'Reported · Official warning'],
    [S(8), E(8), 'Unusual night record access'],
    [S(12), E(12), 'Sign-in approval declined · Reported'],
  ],
  screens: [
    [S(0), S(2), phone('Text message · Sadeed Fee', row('From', '+971 50 000 0183', 'no') + row('Request', 'Pay Case 2048 fee now', 'no') + row('Link', 'pay.sadeed-fees.example', 'no') + note('Do not open payment links in texts.', 'no'))],
    [S(2), S(3), win('Official payment channels', row('Online', 'portal.sadeed.gov.example', 'ok') + row('In person', 'Sadeed hall counter', 'ok') + row('Text links', 'Never used for fees', 'no'), 'good')],
    [S(8), S(9), win('IT alert · Night access', row('Time', '02:35 · Outside hours', 'no') + row('Activity', 'Many applicant records read', 'no') + row('Assigned case', 'None matching', 'no'), 'alert')],
  ],
  pages: [
    hero(S(3), S(7), 'Digital identity is a valuable asset', 'show:notice:Protect Your Work Login|Use more than one way|to confirm your identity|Median in phone tests: 2%|Median in email tests: 1.4%', [
      ['Protect digital identity with multi-factor authentication', S(5), 'v-coral'],
      ['Simulation medians · Phone-based 2%, email 1.4%', S(6), 'v-amber'],
    ]),
    hero(S(9), S(11), 'Espionage: quiet theft of sensitive information', 'show:tv:Digital Spying|Attackers stay out of sight|They copy sensitive data|The UAE council tracks|several types of threat groups', [
      ['Attackers stay hidden and copy data quietly', S(9), 'v-coral'],
      ['UAE Council tracks several kinds of threat groups', S(10), 'v-navy'],
    ]),
    hero(S(11), S(13), 'Report unusual access or requests', 'show:phone:Unusual Sign-In Alert|Did not start this sign-in?|Refuse it and report at once|Flag odd case requests too', [
      ['Watch for odd sign-in alerts or case requests', S(11), 'v-amber'],
      ['Refuse unstarted sign-ins and report at once', S(12), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Pay only through the official channel', 'show:notice:Official Payments Only|Use official payment channels|Direct applicants there|Open only records needed|for the case you are handling', [
      ['Open only the records your own case needs', S(13), 'v-navy'],
      ['Guide applicants to official payment channels', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
