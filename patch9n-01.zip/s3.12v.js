// A letter on our letterhead that we never sent
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, phone, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["lena", "citizen"];
export default chapterHall((S, E, D) => ({
  lesson: "3.3",
  actors: { lena: 'counter', citizen: 'visitor' },
  shots: [[0,'counter'], [S(1),'file'], [S(3),'counter'], [S(10),'her'], [S(11),'counterDisplay'], [S(12),'counter'], [S(14),'her']],
  actions: { lena: [[0,S(1),'listen','citizen'], [S(1),S(11),'paper'], [S(11),S(12),'type'], [S(12),S(13),'talk','citizen'], [S(13),E(13),'paper'], [S(14),D.T,'type']], citizen: [[0,S(3),'talk','lena'], [S(3),S(12),'listen','lena'], [S(12),E(12),'text'], [S(13),D.T,'listen','lena']] },
  setupProps: evidence({ surfaces: { 'paper:lena': [[0,D.T,'letter','Penalty notice']], counter: [[S(11),S(14),'lookup','Reference not found']] }, inserts: [[S(1),E(2),'paper:lena'], [S(11),E(11),'counter']] }),
  displays: { counter: [[0,S(11),'folder','Official record','neutral'], [S(11),S(14),'zoom','Reference not found','alert'], [S(14),D.T,'bell','Report sent','safe']] },
  plates: [[S(0),E(0),'Enquiries desk'], [S(2),E(2),'Pay within 48 hours'], [S(3),E(3),'Request for secrecy'], [S(11),E(11),'Reference not found']],
  screens: [
    [S(1), S(3), q => win('Penalty notice', reveal([
      row('Reference', 'Ref. 317', 'warn'),
      row('Claim', 'Unpaid penalty due', 'no'),
      row('Deadline', 'Pay within 48 hours', 'no'),
      note('Logo, stamp and signature can be forged.', 'warn'),
    ], q), 'alert')],
    [S(3), S(4), phone('Follow-up call', row('Caller', '+971 50 XXX 0529', 'warn') + row('Claim', 'Sadeed Authority', 'no') + row('Instruction', 'Keep the matter private', 'no'))],
    [S(13), S(15), q => win('Report sent', reveal([
      row('Ref. 317', 'Reference not found', 'no'),
      row('Letter copy', 'Kept with consent', 'ok'),
      row('Caller number', '+971 50 XXX 0529 · Noted', 'ok'),
    ], q), 'good')],
  ],
  pages: [
    hero(S(4), S(8), "Criminals impersonate public institutions", "show:paper:Penalty notice check|Looks like a government notice|The sender may be an impostor", [
      ["Penalty notice", S(4), "v-amber"],
    ]),
    hero(S(8), S(10), "Logo, stamp and signature can be forged", "show:paper:Official-looking letter|Logo and stamp can be copied|A printed signature can be fake", [
      ["Printed signature", S(8), "v-amber"],
    ]),
    hero(S(11), S(13), "Check the reference in our own system", "show:monitor:Reference number search|Checked our own system|Reference not found", [
      ["Reference not found", S(11), "v-teal"],
    ]),
  ],
}));
