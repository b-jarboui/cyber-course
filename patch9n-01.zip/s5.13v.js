// Polished is not proven.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '5.3',
  actors: { omar: 'desk', maya: 'beside', official: 'deskGuest' },
  enter: { official: S(12) },
  shots: [[0, 'desk'], [S(2), 'display'], [S(3), 'pair'], [S(8), 'display'], [S(9), 'pair'], [S(12), 'pair'], [S(14), 'desk']],
  actions: {
    omar: [[0, S(2), 'type'], [S(2), S(3), 'read'], [S(3), S(8), 'listen', 'maya'], [S(8), S(11), 'read'], [S(11), S(12), 'type'], [S(12), D.T, 'listen', 'official']],
    maya: [[0, S(3), 'listen', 'omar'], [S(3), S(4), 'talk', 'omar'], [S(4), S(8), 'listen', 'omar'], [S(8), S(11), 'read'], [S(11), S(12), 'listen', 'omar'], [S(12), D.T, 'listen', 'official']],
    official: [[S(12), S(14), 'paper'], [S(14), D.T, 'talk', 'omar']],
  },
  displays: {
    desk: [
      [0, S(2), 'computer', 'Pending requests table', 'neutral'],
      [S(2), S(9), 'file-text', 'AI summary report', 'neutral'],
      [S(9), S(11), 'zoom', 'Figures do not match', 'alert'],
      [S(11), D.T, 'tick', 'Figures verified', 'safe'],
    ],
  },
  plates: [
    [S(2), E(2), 'One-page AI report'],
    [S(9), E(9), 'Figures do not match'],
    [S(11), E(11), 'AI assistance noted'],
    [S(12), E(12), 'Reviewed by Hamad'],
  ],
  screens: [
    [S(2), S(4), win('AI summary report', row('Headline', 'Waiting times fell sharply', 'warn') + row('Reason given', 'Faster counter intake', 'warn') + row('Recommendations', '3 recommendations') + note('Fluent report — figures unchecked.', 'warn'))],
    [S(8), S(9), win('Case system · Recount', row('Source', 'Official case records') + row('Checking', '3 main figures', 'wait') + row('Status', 'Comparing against AI report', 'wait'))],
    [S(12), S(13), win('Management report · Final', row('Figures', 'Verified against case system', 'ok') + row('AI note', 'AI helped draft · Staff checked', 'ok') + row('Reviewer', 'Hamad · Signed', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(6), 'Check the input data', 'show:monitor:Check the input data|Wrong data gives wrong results|A quick review may find errors', [
      ['Wrong input leads to wrong results', S(4), 'v-amber'],
      ['A quick review can catch hidden errors', S(5), 'v-teal'],
    ]),
    hero(S(6), S(8), 'A second person reviews', 'show:paper:Official work review|Prepared by: __________|Second reviewer: __________|Review before release', [
      ['Human review for official work', S(7), 'v-teal'],
    ]),
    hero(S(9), S(12), 'Recalculate key figures', 'show:tablet:Check key figures|Recalculate the totals|Check against the source|A reason without proof|is still a guess', [
      ['Check arithmetic against the source', S(9), 'v-coral'],
      ['Unsupported reasons are guesses', S(10), 'v-amber'],
    ]),
    hero(S(13), D.T, 'Say that AI helped', 'show:paper:AI use disclosure|Note: Drafted with AI help|Every claim traced to source|Strange results? Stop & report', [
      ['Trace every claim to evidence', S(13), 'v-teal'],
      ['Strange results? Stop and report', S(16), 'v-amber'],
    ]),
  ],
}));
