// Tested before it is trusted.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['admin', 'official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '6.3',
  actors: { admin: 'team', official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[S(14), E(14), 0, 1]],
  shots: [[0, 'gathering'], [S(1), 'counter'], [S(2), 'staff'], [S(3), 'her'], [S(13), 'gathering'], [S(14), 'counterDisplay'], [S(15), 'gathering']],
  actions: {
    admin: [[0, S(2), 'talk', 'official'], [S(2), S(14), 'paper'], [S(14), D.T, 'listen', 'official']],
    official: [[0, S(2), 'listen', 'admin'], [S(2), S(3), 'talk', 'admin'], [S(3), S(14), 'listen', 'admin'], [S(14), D.T, 'talk', 'admin']],
    maya: [[0, S(1), 'listen', 'admin'], [S(1), S(2), 'talk', 'admin'], [S(2), S(14), 'read'], [S(14), D.T, 'listen', 'official']],
    omar: [[0, S(13), 'listen', 'admin'], [S(13), S(14), 'talk', 'admin'], [S(14), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(2), 'computer', 'New assistant version', 'neutral'],
      [S(2), S(14), 'file', 'Sample test record · Pass / Fail', 'neutral'],
      [S(14), D.T, 'file', 'Reviewed and signed · Approved', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'New assistant version'],
    [S(2), E(2), 'Test record · Sample cases'],
    [S(13), E(13), 'Real incidents added to tests'],
    [S(14), E(14), 'Results reviewed · Signed by Hamad'],
  ],
  screens: [
    [S(0), S(2), q => win('Release request · Model v4.2', reveal([
      row('Status', 'Ready to switch on', 'wait'),
      row('Tested by', 'Check test record', 'warn'),
      row('Test method', 'Answers and security both tested?', 'warn'),
    ], q))],
    [S(2), S(3), win('Test record · Sample cases', row('Hidden prompt test', 'Pass', 'ok') + row('Data leak test', 'Pass', 'ok') + row('Tool limit test', 'Failed · Fixed and retested', 'warn') + note('Sample cases only — no real files.'))],
  ],
  pages: [
    hero(S(3), S(6), 'Test the answers, and test what can go wrong', 'show:clipboard:AI safety test checklist|Check for hidden instructions|Test for leaks and tool limits|Use sample cases only|Keep real files out of tests', [
      ['Check hidden instructions, leaks and tool limits', S(4), 'v-amber'],
      ['Sample cases only, never real files', S(5), 'v-teal'],
    ]),
    hero(S(6), S(9), 'Find attacks before attackers do', 'show:tv:Regular AI safety tests|Test AI tools and agents often|Find flaws before attackers do|Update tests for new attacks', [
      ['Ongoing risk and agent evaluations', S(6), 'v-navy'],
      ['New attacks require new test methods', S(8), 'v-amber'],
    ]),
    hero(S(9), S(12), 'National AI test lab · Certification mark', 'show:paper:National AI test lab|Check for hidden orders|Check for leaks and tool risks|Check the supply chain|Test safety before approval', [
      ['Checks injection, leaks, supply chain, tools', S(10), 'v-teal'],
      ['Operational safety needs thorough validation', S(11), 'v-navy'],
    ]),
    hero(S(12), D.T, 'Every change, a new test', 'show:clipboard:Post-update AI test|Re-test after every change|Result signed by named owner|Behavior changed after update?|Stop and report to IT', [
      ['A named person signs the result', S(14), 'v-teal'],
      ['Changed behavior after update? Stop and report', S(15), 'v-amber'],
    ]),
  ],
}));
