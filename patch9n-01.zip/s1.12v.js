// A digital problem becomes a public problem. The lesson returns to the applicant.
import { hallScene, CAST_APPLICANT, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST_APPLICANT;
export default hallScene((S, E, D) => ({
  lesson: '1.2', front: 'citizen', serve: [[S(9), D.T]],
  shots: ['hall', { t0: S(1) - .6, t1: S(1) + .6, shot: 'queue' }, [S(3) - .1, 'counter'], [S(5) - .1, 'desk'], [S(7) - .1, 'counter'], [S(8) - .1, 'her'], [S(9) - .1, 'queue'], { t0: S(10) + 1, t1: S(10) + 4, shot: 'hall' }],
  young: { walk: S(1) }, tint: [[S(1), S(2), .12]],
  plates: [
    [S(0) + .5, E(0) + .1, `A digital incident<br>${coral('A public-service problem')}`],
    [S(1) + .1, E(1) + .1, `Identity service down<br>${coral('Application may be delayed')}`],
    [S(8) + .1, E(8) + .1, `Staff<br>${teal('Report and use approved alternatives')}`, 205],
    [S(9) + .1, E(9) + .1, `The applicant<br>${teal('At the counter')}`],
    [S(10) + .1, E(10) + .4, `Available, correct, private<br>${teal('One service')}`],
  ],
  pages: [{ a: S(2) - .5, z: S(8) - .4, list: [
    { z: S(3) - .2, scene: 'hero', cues: { title: 'Payment disrupted\nMoney arrives late', art: 'show:phone:Payment status|Transfer delayed|Recipient still waiting', lines: [['Intended recipient waits', S(2) + 2.6, 'v-coral']] } },
    { a: S(3) - .2, z: S(4) - .2, scene: 'hero', cues: { title: 'One provider\nSeveral institutions', art: 'show:whiteboard:Shared provider outage|Health services affected|Water services affected|Financial services affected', items: [['Health', S(3) + 2.2, 'v-coral'], ['Water', S(3) + 2.6, 'v-coral'], ['Finance', S(3) + 3, 'v-coral']] } },
    { a: S(4) - .2, z: S(6) - .2, scene: 'hero', cues: { title: 'Essential services\nReal consequences', art: 'show:paper:When services stop|People may lose services|Payments may be disrupted|Daily life may be affected|Safety may be at risk', items: [['Service', S(4) + 2.4, 'v-coral'], ['Finance', S(4) + 3.4, 'v-coral'], ['Society', S(4) + 4.4, 'v-coral']], lines: [['Some affect safety', S(5), 'v-amber']] } },
    { a: S(6) - .2, z: S(7) - .2, scene: 'hero', cues: { title: 'What decides\nthe impact', art: 'show:clipboard:What is the impact?|Which service stopped?|For how long?|Is there another way?', items: [['Service', S(6) + 1.8, 'v-navy'], ['Duration', S(6) + 3.2, 'v-navy'], ['Alternatives', S(6) + 5, 'v-navy']] } },
    { a: S(7) - .2, scene: 'hero', cues: { title: 'Prepare before\nit happens', art: 'show:binder:Service continuity plan|List essential services|Plan how to keep them running|Test how to restore them', live: S(7) + 5, lines: [['Identify critical services', S(7) + 2, 'v-teal'], ['Continuity arrangements', S(7) + 4, 'v-teal'], ['Test recovery', S(7) + 5.6, 'v-teal']] } },
  ] }],
}));
