// Changed files and an unusual download.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '9.1',
  actors: { omar: 'desk', maya: 'counter' },
  file: [[0, D.T, 1, 1]],
  landline: true,
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(7), 'counterDisplay'], [S(8), 'her'], [S(12), 'desk'], [S(14), 'counter'], [S(15), 'her']],
  actions: {
    omar: [[0, S(1), 'type'], [S(1), S(12), 'read'], [S(12), D.T, 'listen', 'maya']],
    maya: [[0, S(7), 'type'], [S(7), S(14), 'read'], [S(14), D.T, 'extension']],
  },
  displays: {
    desk: [
      [0, S(1), 'folder', 'Case 2048 · Shared folder', 'neutral'],
      [S(1), S(12), 'lock', 'Files won’t open · Names changed', 'alert'],
      [S(12), D.T, 'shield', 'Use stopped · Isolation requested', 'safe'],
    ],
    counter: [
      [0, S(7), 'folder', 'Cloud records · Case 2048', 'neutral'],
      [S(7), S(14), 'zoom', 'Alert · Overnight download', 'alert'],
      [S(14), D.T, 'bell', 'Both signs reported', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Files won’t open · Names changed'],
    [S(7), E(7), 'Overnight bulk download'],
    [S(12), E(12), 'Stop use · Follow the plan for immediate isolation'],
    [S(14), E(14), 'Both signs reported'],
  ],
  screens: [
    [S(1), S(2), win('Shared folder · Case 2048', row('Case2048_01.locked', 'Will not open', 'no') + row('Case2048_02.locked', 'Will not open', 'no') + row('ID_scan.locked', 'Will not open', 'no') + note('File names changed unexpectedly.', 'no'), 'alert')],
    [S(7), S(8), win('Cloud records · Alert', row('Activity', 'Bulk download · 3,420 records', 'no') + row('Time', '02:40 · Overnight', 'no') + row('Status', 'Outside working hours', 'warn'), 'alert')],
    [S(14), S(15), win('Incident report · Sent', row('Sign 1', 'Unreadable files · Case 2048 folder', 'warn') + row('Sign 2', 'Overnight download · Cloud records', 'warn') + row('Route', 'Approved service desk', 'ok') + note('Waiting for response team instructions.', ''), 'good')],
  ],
  pages: [
    hero(S(2), S(7), "Files won't open · names changed", 'show:monitor:Files Will Not Open|Some file names have changed|Files can no longer be read|Possible ransomware warning|Attackers may threaten', [
      ['Changed names and unreadable files can be ransomware warnings', S(2), 'v-coral'],
      ['Attackers steal data to threaten publication', S(4), 'v-amber'],
      ['UAE · 58% more active ransomware groups in 2024', S(6), 'v-coral'],
    ]),
    hero(S(8), S(12), 'Unusual download reported', 'show:monitor:Cloud Activity Alert|Unusual download detected|Unexpected link or new user?|Check what work was approved', [
      ['Verify unusual downloads against authorised work', S(8), 'v-coral'],
      ['Watch for unexpected sharing links, settings or users', S(10), 'v-amber'],
      ['Microsoft reported 87% more destructive campaigns targeting Azure customers', S(11), 'v-coral'],
    ]),
    hero(S(12), S(14), "Don't fix, delete or pay. Report.", 'show:clipboard:If Files Are Locked|Stop work and report at once|Do not rename, copy or delete|Do not pay|Follow team advice on power', [
      ['Stop working; do not rename, copy or delete files', S(12), 'v-coral'],
      ['Follow the team’s power instructions to preserve evidence', S(13), 'v-teal'],
    ]),
    hero(S(15), D.T, 'Only the response team decides', 'show:notice:Report and wait|Report every warning sign|Use the approved channel|Wait for the response team|Follow its instructions', [
      ['Report every warning sign through the route', S(15), 'v-teal'],
      ['Wait for authorized team instructions', (S(15) + E(15)) / 2, 'v-navy'],
    ]),
  ],
}));
