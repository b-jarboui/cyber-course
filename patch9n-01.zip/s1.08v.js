// Locked, copied, destroyed. Omar sees it first; staff report; decisions belong to the response structure.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.2', serve: [[0, 3]],
  shots: ['desk', [S(0) + 4.2, 'counter'], [S(2) - .1, 'her'], [S(4) - .1, 'desk'], [S(5) - .1, 'counter'], [S(7) - .1, 'deskClose'], [S(8) - .1, 'her'], [S(9) - .1, 'staff'], [S(10) - .1, 'counter']],
  screen: [[S(0) + .6, S(1), '#d9765e']], tint: [[S(0) + 4, S(1), .1]], omarWatch: [[S(0) + .6, S(1)]],
  plates: [
    [S(0) + .8, S(0) + 4, `Ransomware<br>${coral('Files unusable')}`],
    [S(0) + 4.3, E(0), `Criminals<br>${coral('Demand payment')}`],
    [S(8) + .1, E(8), `See something wrong?<br>${teal('Report immediately')}`, 205],
    [S(9) + .1, E(9) + .1, `Lina<br>${teal('Follow the response plan')}`],
  ],
  lena: { walk: S(9) - 3.2, nod: S(9) + .3 },
  pages: [
    { a: S(1) - .5, z: S(8) - .4, list: [
      { z: S(4) - .3, scene: 'hero', cues: { title: 'Locked and\ncopied', art: 'show:monitor:Files locked and copied|Work files are locked|Someone took a copy|A leak could hurt people|Unlocked files can be stolen', live: 1e9, items: [['Locked', S(1) - .2, 'v-coral'], ['Copied', S(1) + 2, 'v-coral'], ['Exposed?', S(2) + 1, 'v-amber']], lines: [['Pressure on people affected', S(2) + 3.2, 'v-navy'], ['Theft needs no encryption', S(3), 'v-coral']] } },
      { a: S(4) - .3, z: S(5) - .3, scene: 'hero', cues: { title: 'Destroyed\nNo ransom needed', art: 'show:monitor:System damage report|Information erased|Systems damaged|No ransom needed', lines: [['Information erased', S(4) + 1.6, 'v-coral'], ['Systems damaged', S(4) + 2.8, 'v-coral']] } },
      { a: S(5) - .3, scene: 'hero', cues: { title: 'What payment and\nbackups do not do', art: 'show:tv:After a ransom demand|Paying may not get files back|Backups cannot undo a leak|An outage and leak can overlap', lines: [['Paying: no recovery promise', S(5) + .6, 'v-amber'], ['Backup: disclosure remains', S(5) + 3.8, 'v-amber'], ['Harms can combine', S(7), 'v-coral']] } },
    ] },
    { a: S(10) - .4, z: D.T + 1, list: [{ scene: 'hero', cues: { title: 'Authorized\nresponse decides', art: 'screen:Incident response plan|Response team: contain and recover|Spokesperson: approved updates only|Leaders: assess any demand', lines: [['Response team coordinates containment and recovery', S(10) + 1.6, 'v-navy'], ['Designated spokesperson gives approved updates', S(10) + 3.4, 'v-navy'], ['Leadership and responsible authorities assess demands', S(10) + 5, 'v-coral']] } }] },
  ],
}));
