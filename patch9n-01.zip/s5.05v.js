// The helper nobody approved.
import { chapterHall, hero } from './chapter2-hall.js';
import { phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '5.2',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, E(0), 0, 1]],
  handsets: { omar: [[0, S(13), 'chat']] },
  shots: [[0, 'counter'], [S(1), 'staff'], [S(3), 'counter'], [S(8), 'staff'], [S(13), 'counter'], [S(14), 'her']],
  actions: {
    maya: [[0, S(13), 'listen', 'omar'], [S(13), S(15), 'talk', 'omar'], [S(15), D.T, 'read']],
    omar: [[0, S(13), 'text'], [S(13), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(13), 'folder', 'Case 2048', 'neutral'],
      [S(13), D.T, 'shield', 'Unapproved app closed', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Free AI chat app'],
    [S(1), E(1), 'Case 2048 summary'],
    [S(13), E(13), 'Stopped before sending'],
  ],
  screens: [
    [S(1), S(3), phone('Free AI chat app', row('Prompt', 'Case 2048 summary · About to paste', 'no') + row('Task', 'Write a reply letter') + row('Approved list', 'Not listed · Unreviewed', 'no') + note('Not approved by the Authority.', 'no'))],
    [S(13), S(14), phone('Free AI chat app', row('Draft prompt', 'Cleared · Not sent', 'ok') + row('App status', 'Closed', 'ok') + note('Stopped before pressing send.'))],
  ],
  pages: [
    hero(S(3), S(7), 'Unapproved AI tools', 'show:phone:Unapproved AI app|This tool has not been checked|A personal account bypasses|work security checks', [
      ['Shadow AI: unreviewed tools', S(3), 'v-coral'],
      ['Personal accounts bypass controls', S(6), 'v-amber'],
    ]),
    hero(S(7), S(8), 'What you type leaves our control', 'show:monitor:Public AI prompt box|Typed text leaves our control|Cannot be taken back once sent|Think before pasting work text', [
      ['Cannot be taken back once sent', S(7), 'v-coral'],
    ]),
    hero(S(8), S(13), 'Personal data stays out', 'show:notice:Keep personal data out|No names or ID numbers|Keep health details out of AI|Some AI tools collect data', [
      ['No names, IDs or health details', S(8), 'v-coral'],
      ['Some AI tools found online harvest data', S(11), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Ask first, report early', 'show:clipboard:Before using an AI tool|Unsure if approved? Ask first|Wait for approval before use|Already pasted? Report at once', [
      ['Unsure if approved? Ask first', S(15), 'v-teal'],
      ['Already pasted? Report at once', S(16), 'v-amber'],
    ]),
  ],
}));
