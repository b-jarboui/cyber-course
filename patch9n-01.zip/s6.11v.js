// An assistant answers, an agent acts.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['admin', 'official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '6.4',
  tablet: { title: 'Answers · Acts' },
  actors: { admin: 'team', official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'gathering'], [S(1), 'counter'], [S(2), 'staff'], [S(3), 'her'], [S(9), 'counterDisplay'], [S(10), 'gathering'], [S(14), 'counter']],
  actions: {
    admin: [[0, S(2), 'talk', 'maya'], [S(2), D.T, 'listen', 'official']],
    official: [[0, S(2), 'listen', 'admin'], [S(2), S(10), 'tablet'], [S(10), D.T, 'talk', 'maya']],
    maya: [[0, S(1), 'listen', 'admin'], [S(1), S(2), 'talk', 'official'], [S(2), S(10), 'listen', 'official'], [S(10), D.T, 'read']],
    omar: [[0, S(10), 'listen', 'official'], [S(10), S(14), 'paper'], [S(14), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(2), 'folder', 'Pilot · Check case files', 'neutral'],
      [S(2), S(9), 'computer', 'Answers vs. Acts', 'neutral'],
      [S(9), D.T, 'key', 'Pilot files only · Shaima approves', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Small AI agent pilot'],
    [S(2), E(2), 'Two boxes: Answers · Acts'],
    [S(9), E(9), 'Hamad owns pilot · Shaima approves'],
    [S(10), E(10), 'Cannot send, pay or delete'],
  ],
  screens: [
    [S(0), S(2), win('AI agent pilot · Scope', row('Single job', 'Check documents are complete', 'ok') + row('Example file', 'Case 2048') + row('Limits', 'Cannot send, pay or delete', 'ok'), 'good')],
    [S(2), S(3), win('Assistant vs. Agent', row('Assistant · Answers', 'Replies to a question, then waits', 'hi') + row('Agent · Acts', 'Plans steps & uses tools', 'warn'))],
  ],
  pages: [
    hero(S(3), S(6), 'An assistant answers; an agent acts', 'show:whiteboard:AI assistants and agents|An assistant answers questions|An agent plans the steps|It uses tools to reach a goal', [
      ['Given a goal, plans steps and uses tools', S(3), 'v-navy'],
      ['Tool use turns words into actions', S(5), 'v-amber'],
    ]),
    hero(S(6), S(9), 'More autonomy, more impact if it goes wrong', 'show:binder:AI control guide|More freedom can magnify harm|Match checks to that freedom|Some actions need approval|Others need watching', [
      ['Match controls to the level of autonomy', S(6), 'v-teal'],
      ['Approve each action, watch, or no review', S(7), 'v-amber'],
    ]),
    hero(S(9), S(14), 'Human leads, AI enables', 'show:whiteboard:People lead the work|Choose clear, low-risk tasks|Keep people in charge|Plan how to stop the agent', [
      ['Start with low-risk, well-defined tasks', S(11), 'v-teal'],
      ['Plan for an agent that misbehaves', S(13), 'v-coral'],
    ]),
    hero(S(14), D.T, 'Know its limits before use', 'show:clipboard:Before using an AI agent|Check its approved tasks|Get approval before linking it|Unexpected action?|Stop, verify and report', [
      ['Never link an agent without approval', S(14), 'v-coral'],
      ['Unexpected action? Stop, verify and report', S(15), 'v-amber'],
    ]),
  ],
}));
