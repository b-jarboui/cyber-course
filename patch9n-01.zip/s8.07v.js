// The portal that will not load, and the attack that aims to destroy.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '8.2',
  actors: { maya: 'counter', omar: 'colleague', official: 'director', citizen: 'visitor' },
  handsets: { official: [[S(1), S(10), 'bell']] },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'counterDisplay'], [S(1), 'gathering'], [S(2), 'staff'], [S(7), 'hall'], [S(10), 'counter'], [S(11), 'her'], [S(12), 'staff'], [S(13), 'counter']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(10), 'listen', 'omar'], [S(10), S(11), 'sign'], [S(11), S(12), 'talk', 'citizen'], [S(12), D.T, 'listen', 'omar']],
    omar: [[0, S(2), 'listen', 'official'], [S(2), S(5), 'talk', 'maya'], [S(5), S(7), 'listen', 'official'], [S(7), S(10), 'talk', 'maya'], [S(10), S(12), 'listen', 'maya'], [S(12), D.T, 'talk', 'maya']],
    official: [[0, S(1), 'listen', 'maya'], [S(1), S(5), 'text'], [S(5), S(7), 'talk', 'maya'], [S(7), S(10), 'text'], [S(10), D.T, 'listen', 'maya']],
    citizen: [[0, S(11), 'listen', 'maya'], [S(11), S(12), 'listen', 'maya'], [S(12), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(10), 'wifi', 'Public portal · Loading error', 'alert'],
      [S(10), D.T, 'file', 'Approved paper form · Case 2048', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Public portal · Loading error'],
    [S(1), E(1), 'Official IT notice · DDoS attack'],
    [S(10), E(10), 'Approved outage form'],
    [S(11), E(11), 'Share only the update approved for applicants'],
  ],
  screens: [
    [S(0), S(1), win('portal.sadeed.gov.example', row('Status', 'Service unavailable', 'no') + row('Applicants', 'Page will not load', 'no') + note('Public portal is not responding.', 'warn'), 'alert')],
    [S(1), S(2), win('Official IT notice', row('From', 'IT Security Operations', 'hi') + row('Affected', 'Public portal', 'warn') + row('Cause', 'Service overloaded by traffic', 'no') + note('Use updates approved for applicants.', 'warn'), 'alert')],
    [S(10), S(11), win('Approved outage form', row('Case file', 'Case 2048', 'ok') + row('Method', 'Recorded by hand', 'ok') + row('Status', 'Service continues safely', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(7), 'DDoS: traffic from many sources disrupts access', 'show:monitor:Portal Access Disrupted|Traffic from many sources|File access is unconfirmed|Cloudflare blocked 47.1M|such attacks in 2025', [
      ['Cloudflare blocked 47.1 million DDoS attacks in 2025', S(3), 'v-amber'],
      ['Portal access disrupted · File access unconfirmed', S(5), 'v-coral'],
    ]),
    hero(S(7), S(10), 'Destructive attacks aim to erase or damage', 'show:monitor:Destructive Attacks|Attackers aim to erase or harm|They do not seek a ransom|Targets include water and|energy control devices', [
      ['Aim to destroy systems, not demand money', S(7), 'v-coral'],
      ['Control devices in water and energy targeted', S(8), 'v-amber'],
    ]),
    hero(S(11), S(13), 'Use updates approved for applicants', 'show:paper:Approved Public Update|Share only approved wording|Do not guess who attacked|Never post incidents or rumors', [
      ['Do not guess who is behind an attack', S(11), 'v-navy'],
      ['Never post incidents or rumours online', S(12), 'v-coral'],
    ]),
    hero(S(13), D.T, 'Use the approved alternative procedure', 'show:clipboard:Outage Procedure|Report via approved route|Use approved outage forms|Give approved public updates', [
      ['Report the outage through the approved route', S(13), 'v-teal'],
      ['Use approved outage forms and public updates', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
