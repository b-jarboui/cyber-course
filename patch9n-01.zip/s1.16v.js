// The first decision. Shaima gets an urgent AI request; the chapter closes in the hall.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.3', serve: [[S(12), D.T]],
  shots: ['counter', { t0: S(1) - .3, t1: S(1) + .6, shot: 'staff' }, [S(4) - .1, 'her'], [S(6) - .1, 'counter'], [S(7) - .1, 'staff'], [S(9) - .1, 'her'], [S(10) - .1, 'counter'], [S(12) - .1, 'hall'], [S(13) - .1, 'desk'], [S(14) - .1, 'counter'], { t0: S(15) - .3, t1: S(15) + .9, shot: 'wide' }],
  plates: [
    [S(0) + .4, E(0) + .1, `Urgent request<br>${coral('A new AI service')}`],
    [S(1) + .1, E(1) + .1, `The message says<br>${coral('The director approved')}`],
    [S(2) + .1, E(2) + .1, `It looks<br>${coral('Professional wording, familiar work')}`],
    [S(9) + .1, E(9) + .1, `Shaima<br>${teal('Verifies first')}`],
    [S(12) + .1, E(12) + .1, `Confidentiality, integrity<br>${teal('Availability')}`],
    [S(13) + .1, E(13) + .1, `AI changes<br>${coral('Speed and appearance')}`],
    [S(14) + .1, E(14) + .1, `Responsibilities, layers<br>${teal('Verification, reporting')}`],
    [S(15) + .1, D.T, `Next chapter<br>${teal('A convincing request')}`],
  ],
  pages: [
    { a: S(3) - .5, z: S(9) - .4, list: [
      { z: S(7) - .3, scene: 'hero', cues: { title: 'What matters\nhere?', art: 'show:paper:Request risk flags|Data: sensitive records|Tool: approval not established|Director approval: unverified', lines: [['Sensitive information', S(4), 'v-amber'], ['Tool approval not established', S(5), 'v-amber'], ['Director’s approval unverified', S(6), 'v-coral']] } },
      { a: S(7) - .3, scene: 'options', cues: { a: S(8) + .2, b: S(8) + 1.6, c: S(8) + 3, answer: S(9) - 1.6 } },
    ] },
    { a: S(10) - .4, z: S(12) - .4, list: [{ scene: 'hero', cues: { title: 'Verify through\napproved channels', art: 'show:clipboard:Check the request|Find director in the directory|Call the listed number|Check approval for record use|Report the request', lines: [['Call the director on the directory number', S(10) + 2, 'v-teal'], ['Check approval for applicant records', S(10) + 4.6, 'v-teal'], ['Report the request', S(10) + 7.4, 'v-teal']], note: ['Keep records in the approved environment', S(11)] } }] },
  ],
}));
