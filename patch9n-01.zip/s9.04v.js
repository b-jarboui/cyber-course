// When the assistant follows the wrong instructions.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '9.1',
  actors: { maya: 'counter', citizen: 'visitor' },
  file: [[0, D.T, 1, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(3), 'counter'], [S(7), 'her'], [S(11), 'counterDisplay'], [S(13), 'her'], [S(14), 'counter'], [S(15), 'her']],
  actions: {
    maya: [[0, S(1), 'type'], [S(1), S(13), 'read'], [S(13), S(14), 'extension'], [S(14), S(15), 'talk', 'citizen'], [S(15), D.T, 'read']],
    citizen: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'computer', 'AI summary · Case 2048', 'neutral'],
      [S(1), S(11), 'mail', 'AI proposes outside send', 'alert'],
      [S(11), S(13), 'shield', 'Transfer declined · Proposal recorded', 'safe'],
      [S(13), D.T, 'bell', 'Unexpected AI proposal reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'AI summary · Case 2048'],
    [S(1), E(1), 'Unasked outside send'],
    [S(11), E(11), 'Nothing sent · Details recorded'],
    [S(14), E(14), 'Short review before moving on'],
  ],
  screens: [
    [S(1), S(3), win('AI agent · Case 2048 summary', row('Recommendation', 'Approve immediately', 'warn') + row('Proposed send', 'Whole file → external address', 'no') + row('Destination', 'drop@outside-mail.example', 'no') + note('Neither action was requested.', 'no'), 'alert')],
    [S(13), S(14), win('AI behaviour report', row('Proposed action', 'Approve & send file outside', 'warn') + row('Action taken', 'Stopped · Not approved', 'ok') + row('Evidence', 'Proposed action and time recorded', 'ok') + row('Route', 'Approved security route', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(7), 'Instructions in a document can influence an AI tool', 'show:monitor:File Opened by AI|A file may hide instructions|They can steer the AI tool|It can mistake text for orders', [
      ['Hidden prompts in files can steer AI tools', S(3), 'v-coral'],
      ['AI cannot reliably split rules from data', S(5), 'v-amber'],
    ]),
    hero(S(7), S(11), "Odd action → stop, don't approve", 'show:monitor:AI Requests an Action|Unexpected task or transfer?|Stop and withhold approval|Limit what the tool can do|People stay in control', [
      ['Watch for unexpected tasks, access requests or transfers', S(7), 'v-amber'],
      ['Limit agent powers; keep people in control', S(9), 'v-teal'],
      ['IBM breach study · 13% reported an AI model or application breach', S(10), 'v-coral'],
    ]),
    hero(S(11), S(13), 'Stop, record, do not test the agent', 'show:clipboard:Odd AI Agent Checklist|[x] Stop - do not approve|[x] Do not send the file|[x] Do not test new prompts|[x] Record what happened', [
      ['Do not approve the action or send the file', S(11), 'v-coral'],
      ['Do not probe the agent with new prompts', S(12), 'v-amber'],
    ]),
    hero(S(15), D.T, 'Report unusual AI behaviour for assessment', 'show:paper:AI Incident Report|When did it happen?|What did the tool propose?|Report via the approved route', [
      ['Record what the agent proposed and when', S(15), 'v-navy'],
      ['Report through the approved security route', (S(15) + E(15)) / 2, 'v-teal'],
    ]),
  ],
}));
