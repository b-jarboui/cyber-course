// Sent to the wrong place.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '5.1',
  actors: { maya: 'counter', omar: 'colleague' },
  landline: true,
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(4), 'counter'], [S(11), 'her'], [S(12), 'staff'], [S(14), 'counter']],
  actions: {
    maya: [[0, S(2), 'type'], [S(2), S(12), 'read'], [S(12), S(14), 'extension'], [S(14), D.T, 'type']],
    omar: [[0, S(11), 'listen', 'maya'], [S(11), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'mail', 'Pending cases list', 'neutral', 'inbox'],
      [S(2), S(12), 'mail', 'Outside address · Sent', 'alert', 'inbox'],
      [S(12), D.T, 'bell', 'Incident reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Pending cases list'],
    [S(2), E(2), 'Outside address · Sent'],
    [S(11), E(11), 'Do not hide the error'],
    [S(12), E(12), 'Incident reported'],
  ],
  screens: [
    [S(1), S(2), win('New email', row('To', 'finance@sadeed-group.example', 'warn') + row('Subject', 'Pending cases list') + row('Attachment', 'Pending_Cases_List.xlsx') + note('Auto-completed address · Sent.', 'warn'))],
    [S(2), S(4), win('Sent mail', row('Sent to', 'finance@sadeed-group.example', 'no') + row('Expected', 'finance@sadeed.gov.example', 'ok') + row('Inside file', 'Names, ID numbers, case status', 'no') + note('Outside organisation with similar name.', 'no'), 'alert')],
    [S(11), S(12), win('Sent mail · Kept as record', row('Delete quietly', 'No', 'ok') + row('Hide the error', 'No', 'ok') + row('Next step', 'Report via approved route', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(8), 'Leakage', 'show:monitor:Data leakage alert|File sent to wrong recipient|Or shared via an open link|Data left Authority control', [
      ['Information leaves Authority control', S(4), 'v-coral'],
      ['Wrong recipient or open link', S(5), 'v-amber'],
    ]),
    hero(S(8), S(11), 'Data breach', 'show:paper:Data breach assessment|Was data disclosed?|By accident or on purpose?|Response team rates the impact', [
      ['Intentional or accidental disclosure', S(8), 'v-coral'],
      ['Response team assesses severity', S(10), 'v-navy'],
    ]),
    hero(S(12), S(13), 'Report at once', 'show:clipboard:Incident report form|Report immediately|Do not hide or delete quietly|Include: What, to whom, when', [
      ['Do not hide or delete quietly', S(12), 'v-teal'],
      ['Say what, to whom and when', S(12), 'v-navy'],
    ]),
    hero(S(13), D.T, 'Access by duty', 'show:binder:Access by work duty|Collect and keep only what’s needed|Check level and sharing method|Check how long to keep it', [
      ['Collect and keep only what is needed', S(13), 'v-teal'],
      ['Check level, channel and retention', S(16), 'v-teal'],
    ]),
  ],
}));
