// Where the files live now, and who holds the key.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.2',
  actors: { official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, E(1), 0, 1]],
  shots: [[0, 'gathering'], [S(1), 'counter'], [S(2), 'staff'], [S(9), 'counterDisplay'], [S(10), 'her'], [S(14), 'gathering'], [S(15), 'counterDisplay']],
  actions: {
    official: [[0, S(2), 'talk', 'maya'], [S(2), S(14), 'listen', 'omar'], [S(14), D.T, 'talk', 'maya']],
    maya: [[0, S(1), 'listen', 'official'], [S(1), S(2), 'talk', 'official'], [S(2), S(9), 'listen', 'omar'], [S(9), S(14), 'type'], [S(14), D.T, 'listen', 'official']],
    omar: [[0, S(2), 'listen', 'official'], [S(2), S(9), 'talk', 'maya'], [S(9), S(10), 'point'], [S(10), S(14), 'talk', 'maya'], [S(14), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(9), 'folder', 'Approved cloud workspace', 'neutral'],
      [S(9), S(14), 'key', 'Sign in · Security key', 'neutral', 'login'],
      [S(14), D.T, 'shield', 'Assigned cases only', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Approved cloud workspace'],
    [S(9), E(9), 'Electronic account sign-in'],
    [S(14), E(14), 'Assigned cases only'],
    [S(15), E(15), 'Unknown prompt? Stop and report'],
  ],
  screens: [
    [S(0), S(2), win('Approved cloud workspace', row('Address', 'cloud.sadeed.gov.example', 'ok') + row('Files', 'Case 2048 · Authority records', 'ok') + row('Status', 'Approved by Authority', 'ok'), 'good')],
    [S(9), S(10), win('cloud.sadeed.gov.example', row('Account', 'shaima@sadeed.gov.example', 'hi') + row('Sign-in', 'Password + security key', 'ok') + note('Your account unlocks everything inside.'))],
  ],
  pages: [
    hero(S(2), S(5), 'Cloud services', 'show:monitor:Cloud storage|Hosted on provider servers|Reached over the internet|Check folder access settings|Wrong settings cause breaches', [
      ['Provider computers reached over the internet', S(2), 'v-navy'],
      ['Wrong cloud settings have led to breaches', S(4), 'v-coral'],
    ]),
    hero(S(5), S(9), 'Approved services only', 'show:binder:Approved cloud services|Use approved work services|Know where data is handled|and where it is stored|No cases in personal accounts', [
      ['Know where data is stored and handled', S(7), 'v-teal'],
      ['Never put case files in personal accounts', S(8), 'v-coral'],
    ]),
    hero(S(10), S(14), 'Multi-factor authentication', 'show:phone:Authority sign-in|Use more than a password|Use sign-in protection|that resists fake login sites', [
      ['Phishing-resistant MFA blocks up to 99%', S(11), 'v-teal'],
      ['Use the Authority\'s method; never approve unstarted prompts', S(12), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Least privilege', 'show:monitor:Account Permissions|[x] Assigned case files only|[ ] Unrelated department cases|Unexpected sign-in prompt?|Deny, stop, and report to IT', [
      ['Access only the cases your job needs', S(14), 'v-teal'],
      ['Unstarted sign-in prompt? Stop and report', S(15), 'v-amber'],
    ]),
  ],
}));
