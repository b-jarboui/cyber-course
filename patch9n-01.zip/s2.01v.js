// A message that knows your name.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, mail } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { maya: 'counter', omar: 'colleague' },
  shots: [[0,'counter'], [S(1),'counterDisplay'], [S(3),'her'], [S(9),'file'], [S(11),'staff'], [S(12),'her'], [S(13),'her']],
  file: [[S(10), E(10), 0, 1]],
  actions: {
    maya: [[0,S(9),'read'], [S(9),S(10),'listen','omar'], [S(10),S(11),'file'], [S(11),E(12),'call'], [S(13),D.T,'type']],
    omar: [[0,S(11),'listen','maya'], [S(11),E(11),'talk','maya']],
  },
  displays: { counter: [[0,S(13),'mail','Case 2048','neutral','inbox'], [S(13),D.T,'bell','Report sent','safe']] },
  plates: [[S(1),E(1),'Case 2048'], [S(2),E(2),'Updated documents'], [S(10),E(10),'Number in the case file'], [S(12),E(12),'No email sent']],
  screens: [
    [S(1), S(3), win('Inbox', mail('Applicant (case 2048)', 'case2048.docs@mail-share.example', 'Case 2048 — Updated documents', 'Open the link before noon to view files.'), 'alert')],
    [S(10), S(11), win('Case 2048', row('Applicant', 'Name on file') + row('Recorded phone', '+971 50 000 0147', 'ok') + note('Verify using the number on file.'), 'good')],
  ],
  pages: [
    hero(S(5), S(6), 'Spear phishing: aimed at you', 'show:monitor:Re: Case 2048|Please review Case 2048', [
      ['Case 2048', S(5), 'v-amber'],
    ]),
    hero(S(6), S(9), 'Fluent is not genuine', 'show:monitor:Case update|The wording sounds natural|The case number is familiar|Who sent it is still unclear', [
      ['A familiar case number', S(8), 'v-amber'],
    ]),
    hero(S(11), S(12), 'Verify through a known contact', 'show:paper:Case contact record|Call the number in the file', [
      ['Number in the case file', S(11), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Report through the approved route', 'show:monitor:Report suspicious email|Use the approved route|Help warn other staff', [
      ['Warn other staff', S(13), 'v-teal'],
    ]),
  ],
}));
