// A new phone, the same person?
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'comms', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '4.1',
  actors: { maya: 'counter', comms: 'visitor', official: 'colleague' },
  enter: { official: S(13) },
  file: [[S(5), E(5), 0, 1], [S(13), E(13), 1, 1]],
  habits: true,
  handsets: { comms: [[0, S(5), 'mobile']] },
  shots: [[0, 'counter'], [S(1), 'hall'], [S(2), 'counter'], [S(5), 'counterDisplay'], [S(8), 'her'], [S(13), 'staff'], [S(14), 'habits']],
  actions: {
    comms: [[0, S(2), 'text'], [S(2), S(5), 'talk', 'maya'], [S(5), S(8), 'idCard', 'maya'], [S(8), D.T, 'listen', 'maya']],
    maya: [[0, S(5), 'listen', 'comms'], [S(5), S(6), 'file'], [S(6), S(13), 'read'], [S(13), S(14), 'type'], [S(14), D.T, 'listen', 'official']],
    official: [[S(13), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [[0, S(5), 'mobile', 'Change of mobile number', 'neutral'], [S(5), S(13), 'file-text', 'Official record', 'neutral'], [S(13), D.T, 'tick', 'Identity verified', 'safe']],
  },
  plates: [[S(0), E(0), 'Case 2048'], [S(2), E(2), 'Change of mobile number'], [S(5), E(5), 'Original identity document'], [S(13), E(13), 'Supervisor approval']],
  screens: [
    [S(1), S(3), win('Case 2048 · Request', row('Reason', 'Lost phone · No codes', 'warn') + row('Old mobile', '+971 50 000 0147') + row('New mobile', '+971 50 000 0284', 'wait'))],
    [S(5), S(6), win('Identity verification', row('Original ID', 'Checked in person', 'ok') + row('Official record', 'Matches applicant', 'ok') + note('Verified by the official procedure.'), 'good')],
    [S(13), S(14), win('Case 2048 · Updated', row('Identity check', 'Matched', 'ok') + row('Supervisor approval', 'Approved', 'ok') + row('Mobile number', '+971 50 000 0284', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(5), 'Account recovery: a target for criminals', 'show:monitor:Account recovery|Controls password reset|Controls account sign-in|Key target for criminals', [
      ['Controls reset and sign-in', S(4), 'v-amber'],
    ]),
    hero(S(6), S(10), 'Verify identity by the procedure', 'show:clipboard:ID check procedure|Basic details: not enough|Check original ID document|Match to official record', [
      ['Basic details are not enough', S(6), 'v-amber'],
      ['Original document against official record', S(8), 'v-teal'],
    ]),
    hero(S(10), S(13), 'Helpdesk: call back on the number on file', 'show:notice:IT account recovery|Call back on the listed number|Lost phone or key? Report now|Use the official IT channel', [
      ['Lost phone or key? Report at once', S(11), 'v-teal'],
      ['Official IT channel', S(12), 'v-teal'],
    ]),
  ],
}));
