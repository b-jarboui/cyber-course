// One report, the right route.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['helpdesk', 'official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '9.2',
  actors: { helpdesk: 'desk', official: 'beside', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 1, 1]],
  landline: 'desk',
  shots: [[0, 'pair'], [S(1), 'display'], [S(2), 'counter'], [S(5), 'file'], [S(8), 'pair'], [S(11), 'desk'], [S(12), 'gathering'], [S(15), 'her']],
  actions: {
    helpdesk: [[0, S(5), 'type'], [S(5), S(11), 'read'], [S(11), D.T, 'type']],
    official: [[0, S(11), 'listen', 'helpdesk'], [S(11), S(15), 'extension'], [S(15), D.T, 'listen', 'maya']],
    maya: [[0, S(5), 'read'], [S(5), S(8), 'paper'], [S(8), S(15), 'file'], [S(15), D.T, 'paper']],
    omar: [[0, S(8), 'listen', 'maya'], [S(8), D.T, 'listen', 'official']],
  },
  displays: {
    desk: [
      [0, S(1), 'file', '4 hall reports received', 'neutral'],
      [S(1), S(11), 'folder', 'Grouped in one ticket for review', 'alert'],
      [S(11), D.T, 'shield', 'Escalated to response team', 'safe'],
    ],
    counter: [
      [0, S(5), 'file', 'Official report form · 2048', 'neutral'],
      [S(5), D.T, 'tick', 'Times and facts recorded', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Four reports · One ticket for review'],
    [S(5), E(5), 'Official report form · Case 2048'],
    [S(11), E(11), 'Manager joins · Team leads'],
    [S(14), E(14), 'Internal route only'],
  ],
  screens: [
    [S(0), S(2), win('Service desk · Ticket #904', row('Report 1 · 08:25', 'Shaima · Night sign-in alert', 'warn') + row('Report 2 · 09:10', 'Omar · Unexpected approval', 'warn') + row('Report 3 · 10:45', 'Locked files & cloud download', 'no') + note('Report 4 · Shaima reported the AI proposal to send the file outside.', 'warn'), 'alert')],
    [S(11), S(12), win('Escalation · Ticket #904', row('Technical lead', 'Incident response team', 'ok') + row('Management', 'Informed on call', 'hi') + row('Hall staff', 'Follow team instructions', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(5), 'Report early, even if unsure', 'show:notice:Unsure? Report Anyway|Small signs link across teams|Note just what you observed|Early reports help spot links|Report even if unsure', [
      ['Review the reports together for possible links', S(2), 'v-amber'],
      ['Report what you observed, even when unsure', S(3), 'v-teal'],
    ]),
    hero(S(5), S(8), 'What · When · Where · Who', 'show:clipboard:Incident Report Form|What happened? When?|Where? Who was involved?|Use the known number and form|Keep details out of group chat', [
      ['Use the known number and official form', S(6), 'v-teal'],
      ['Keep incident details out of group chats and applicant conversations', S(7), 'v-coral'],
    ]),
    hero(S(8), S(11), 'Escalate by severity and role', 'show:binder:Who to Notify|Staff alert the service desk|The desk alerts the team|The team informs management|Follow the plan for severity', [
      ['Response plans set escalation and severity', S(9), 'v-teal'],
      ['Service desk alerts response team · Team informs management', S(10), 'v-navy'],
    ]),
    hero(S(12), D.T, 'National reporting: the designated team', 'show:paper:National Incident Report|Staff report internally|Only the designated team|notifies the national authority', [
      ['National bodies receive official entity reports', S(12), 'v-navy'],
      ['Staff report inside; designated team notifies', S(14), 'v-teal'],
    ]),
  ],
}));
