// Which services must resume first?.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar', 'finance', 'comms'];
export default chapterHall((S, E, D) => ({
  lesson: '8.3',
  actors: { official: 'director', maya: 'counter', omar: 'colleague', finance: 'team', comms: 'teamEnd' },
  file: [[0, D.T, 0, 0]],
  shots: [[0, 'gathering'], [S(1), 'staff'], [S(3), 'gathering'], [S(5), 'counterDisplay'], [S(8), 'gathering'], [S(11), 'her'], [S(12), 'gathering']],
  actions: {
    official: [[0, S(3), 'paper'], [S(3), S(5), 'listen', 'omar'], [S(5), S(8), 'paper'], [S(8), S(11), 'talk', 'maya'], [S(11), S(12), 'listen', 'maya'], [S(12), D.T, 'talk', 'maya']],
    maya: [[0, S(3), 'listen', 'official'], [S(3), S(5), 'listen', 'omar'], [S(5), S(11), 'listen', 'official'], [S(11), S(12), 'talk', 'official'], [S(12), D.T, 'listen', 'official']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), S(5), 'talk', 'maya'], [S(5), D.T, 'listen', 'official']],
    finance: [[0, S(3), 'listen', 'official'], [S(3), S(5), 'listen', 'omar'], [S(5), D.T, 'listen', 'official']],
    comms: [[0, S(3), 'listen', 'official'], [S(3), S(5), 'listen', 'omar'], [S(5), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(5), 'file', 'Business continuity plan', 'neutral'],
      [S(5), S(10), 'folder', 'Critical services · Ranked list', 'neutral'],
      [S(10), D.T, 'shield', 'Plan ready · Printed copy', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Printed business continuity plan'],
    [S(6), E(6), 'Critical services · Ranked list'],
    [S(10), E(10), 'Ready to work without IT'],
    [S(12), E(12), 'Know your role in the plan'],
  ],
  screens: [
    [S(1), S(3), win('Business continuity plan · Print', row('Format', 'Printed hall copy', 'ok') + row('Purpose', 'Keep key services running', 'ok') + row('Kept at', 'Counter binder', 'hi'), 'good')],
  ],
  pages: [
    hero(S(3), S(5), 'Business continuity: keep serving during disruption', 'show:binder:Business Continuity Plan|Keep key services running|Plan ahead for disruption|Cyber, response and recovery', [
      ['Plan ahead to keep key services running', S(3), 'v-teal'],
      ['Covers cybersecurity, response and recovery', S(4), 'v-navy'],
    ]),
    hero(S(5), S(8), 'Know the critical services first', 'show:paper:Service Priorities|Verify identity|Handle urgent cases|Process payments|Retrieve records', [
      ['Verify identity · Handle urgent cases · Process payments · Retrieve records', S(6), 'v-navy'],
      ['Rank services by how much harm a stop causes', S(7), 'v-teal'],
    ]),
    hero(S(8), S(10), 'How long can each service stop?', 'show:whiteboard:If a Service Stops|Which systems does it need?|How long can it stay down|before serious harm occurs?', [
      ['Business impact analysis maps system reliance', S(8), 'v-navy'],
      ['Sets how long a stop causes serious harm', S(9), 'v-amber'],
    ]),
    hero(S(10), D.T, 'Plan to work without IT', 'show:binder:Working Without IT|Keep serving applicants|Know your role|Locate the printed plan|Report steps that are outdated', [
      ['Prepare to keep serving without IT systems', S(10), 'v-teal'],
      ['Know your role and where the printed copy is', S(12), 'v-navy'],
      ['Report any plan step that no longer fits', S(13), 'v-teal'],
    ]),
  ],
}));
