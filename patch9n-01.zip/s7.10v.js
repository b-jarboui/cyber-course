// The update from a trusted supplier.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.3',
  actors: { official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'gathering'], [S(1), 'counter'], [S(2), 'staff'], [S(3), 'her'], [S(11), 'gathering'], [S(12), 'counterDisplay'], [S(13), 'staff']],
  actions: {
    official: [[0, S(3), 'paper'], [S(3), S(11), 'listen', 'omar'], [S(11), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'omar']],
    maya: [[0, S(2), 'listen', 'official'], [S(2), S(3), 'talk', 'omar'], [S(3), S(12), 'listen', 'omar'], [S(12), S(13), 'read'], [S(13), D.T, 'listen', 'omar']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), S(11), 'talk', 'maya'], [S(11), S(13), 'listen', 'official'], [S(13), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(12), 'setting', 'Supplier update notice', 'neutral'],
      [S(12), D.T, 'tick', 'Verified by IT · Case 2048 open', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Supplier update notice'],
    [S(11), E(11), 'IT checks via contract contact'],
    [S(12), E(12), 'Verified update · Case 2048 open'],
    [S(14), E(14), 'Trust is not verification'],
  ],
  screens: [
    [S(1), S(3), win('Supplier update notice', row('From', 'updates@casesys-vendor.example', 'warn') + row('System', 'Case system · New version ready', 'hi') + note('Do not install until IT verifies it.', 'warn'))],
  ],
  pages: [
    hero(S(3), S(8), 'Supply chain', 'show:monitor:Software update notice|A trusted update may carry|harmful code from a supplier|Other software may be affected', [
      ['Harm arrives through a trusted update', S(4), 'v-coral'],
      ['Poisoned code spreads across hundreds of packages', S(6), 'v-amber'],
    ]),
    hero(S(8), S(11), 'Trusted does not mean safe', 'show:tv:Supplier risk|Trusted suppliers face attacks|One incident can hit thousands|Third parties were involved|in 48% of breaches', [
      ['One supplier incident can hit thousands', S(8), 'v-amber'],
      ['Third parties featured in 48% of breaches', S(9), 'v-coral'],
    ]),
    hero(S(11), S(13), 'IT verifies the supplier', 'show:monitor:Supplier update check|IT confirms with the supplier|IT checks and installs updates|Leave installation to IT', [
      ['Staff do not install supplier updates directly', S(11), 'v-teal'],
      ['IT confirms with supplier, checks, installs', S(12), 'v-navy'],
    ]),
    hero(S(13), D.T, 'Report anything odd', 'show:monitor:Unexpected app change|New access or odd behavior?|Stop and report to IT|IT checks with the supplier', [
      ['Odd behaviour or new permission? Warning sign', S(13), 'v-amber'],
      ['Stop and report; let IT check with supplier', S(15), 'v-teal'],
    ]),
  ],
}));
