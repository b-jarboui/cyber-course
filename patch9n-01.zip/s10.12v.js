// Everyone is part of the defence.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen', 'citizenYoung'];
export default chapterHall((S, E, D) => ({
  lesson: '10.4',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor', citizenYoung: 'counterEnd' },
  file: [[0, S(14), 0, 0], [S(14), E(14), 0, 1]],
  shots: [[0, 'hall'], [S(1), 'counter'], [S(2), 'her'], [S(3), 'staff'], [S(8), 'counter'], [S(13), 'counter'], [S(14), 'file'], [S(15), 'counterDisplay']],
  actions: {
    maya: [[0, S(2), 'listen', 'citizen'], [S(2), S(13), 'read'], [S(13), S(14), 'talk', 'citizen'], [S(14), S(15), 'file'], [S(15), D.T, 'type']],
    citizen: [[0, S(2), 'talk', 'maya'], [S(2), D.T, 'listen', 'maya']],
    omar: [[0, D.T, 'listen', 'maya']],
    citizenYoung: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(13), 'lock', 'Identity check · Required', 'alert'],
      [S(13), S(15), 'shield', 'Official identity check done', 'safe'],
      [S(15), D.T, 'tick', 'Sent to registered file contact', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Busy hall · Applicant in a hurry'],
    [S(1), E(1), 'Asked to skip identity check'],
    [S(13), E(13), 'Took a beat · Identity verified'],
    [S(15), E(15), 'Recipient matched to verified case contact'],
  ],
  screens: [
    [S(0), S(2), win('Counter · Case 2048', row('Identity check', 'Verify identity before releasing the status', 'warn') + row('Visitor request', 'Skip check — in a hurry', 'no') + row('Registered contact', 'Check file before sending', 'hi') + note('Pressure pushes toward shortcuts.', 'warn'), 'alert')],
    [S(2), S(3), win('Counter · Paused', row('Action', 'Paused above keyboard', 'hi') + row('Identity check', 'Not skipped', 'ok') + note('Pause before acting under pressure.'), 'good')],
  ],
  pages: [
    hero(S(3), S(8), 'Cybersecurity is a shared responsibility', 'show:notice:Security Is Shared|Security involves every team|Every staff action matters|Keep good habits even when|no one is checking', [
      ['Not only the work of the IT team', S(3), 'v-navy'],
      ['Every action matters in a shared mission', S(4), 'v-teal'],
      ['Culture is habit, even when no one checks', S(6), 'v-teal'],
    ]),
    hero(S(8), S(13), 'Pressure is a warning sign', 'show:monitor:Before You Send|Pressure can lead to mistakes|Is this the right recipient?|Check before sending', [
      ['Human element in 62% of breaches (2026 report)', S(8), 'v-coral'],
      ['Public administration · Human element 69% · Leading error: wrong recipient', S(10), 'v-coral'],
      ['Pressure pushes people toward shortcuts', S(11), 'v-amber'],
    ]),
    hero(S(13), D.T, 'Take a beat, then verify', 'show:paper:Verified Case Contact|Use the contact in the file|Match the recipient to it|Pause and check before sending', [
      ['Resist pressure and verify via procedure', S(13), 'v-teal'],
      ['Use only the contact already in the file', S(14), 'v-navy'],
      ['Match the recipient to the verified case contact', S(15), 'v-teal'],
    ]),
  ],
}));
