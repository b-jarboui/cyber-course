// An alert is not yet an incident.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '9.1',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, E(0), 0, 1]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'staff'], [S(3), 'her'], [S(9), 'staff'], [S(11), 'counter'], [S(13), 'her']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(3), 'listen', 'omar'], [S(3), S(9), 'read'], [S(9), S(11), 'listen', 'omar'], [S(11), S(13), 'file'], [S(13), D.T, 'extension']],
    omar: [[0, S(2), 'listen', 'maya'], [S(2), S(3), 'talk', 'maya'], [S(3), S(9), 'listen', 'maya'], [S(9), S(11), 'talk', 'maya'], [S(11), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'folder', 'Case 2048', 'neutral'],
      [S(1), S(13), 'lock', 'Sign-in alert · Last night', 'alert', 'login'],
      [S(13), D.T, 'bell', 'Service desk called', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048'],
    [S(1), E(1), 'Sign-in alert · Last night'],
    [S(13), E(13), 'Service desk · Known number'],
  ],
  screens: [
    [S(1), S(3), win('Security alert · Sign-in', row('Account', 'shaima@sadeed.gov.example', 'warn') + row('Time', '02:18 · Last night', 'no') + row('Device', 'Unknown device', 'no') + note('Shaima was at home asleep.', 'warn'), 'alert')],
    [S(13), S(14), win('Service desk · Known number', row('Number', 'Ext. 4100 · Approved route', 'ok') + row('Report', 'Last night sign-in · 02:18', 'ok') + row('Action', 'No link clicked · Reported', 'ok'), 'good')],
  ],
  pages: [
    hero(S(3), S(9), 'Events, alerts and incidents', 'show:whiteboard:Event, Alert, Incident|Event: something seen in IT|Alert: warning to check|Incident: harm now or soon,|or a broken security rule', [
      ['Event: anything observable in a system', S(4), 'v-navy'],
      ['Alert: warning about activity that needs checking', S(5), 'v-amber'],
      ['Incident: actual or imminent harm or security-rule violation', S(6), 'v-coral'],
    ]),
    hero(S(9), S(11), 'The response team decides', 'show:notice:Who Confirms Incidents|You do not need proof|Report any suspicious sign|Authorized team confirms|Response team takes action', [
      ['You do not need to prove an incident', S(9), 'v-navy'],
      ['Authorized team confirms and responds', S(10), 'v-teal'],
    ]),
    hero(S(11), S(13), 'Notice. Record. Report.', 'show:clipboard:When You See an Alert|Note what you saw and when|Do not click inside the alert|Do not try to fix the issue|Report what you saw', [
      ['Write down what you saw and when', S(11), 'v-teal'],
      ['Do not click inside or try to fix it', S(12), 'v-coral'],
    ]),
    hero(S(14), D.T, 'Early reports give the team evidence to check', 'show:notice:Report Early|Mandiant’s 2025 cases|Over half first found in-house|Early reports provide evidence|Call the known desk number', [
      ['Mandiant’s 2025 investigations · Over half detected internally first', S(14), 'v-teal'],
      ['Call the service desk on its known number', S(15), 'v-navy'],
    ]),
  ],
}));
