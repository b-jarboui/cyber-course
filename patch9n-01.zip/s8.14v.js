// Restore carefully, return stronger.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'citizen', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '8.3',
  actors: { maya: 'counter', citizen: 'signer', omar: 'colleague', official: 'director' },
  file: [[0, S(13), 1, 1], [S(13), E(13), 1, 0]],
  signing: true,
  shots: [[0, 'counter'], [S(1), 'file'], [S(2), 'staff'], [S(5), 'gathering'], [S(8), 'counterDisplay'], [S(9), 'gathering'], [S(13), 'file']],
  actions: {
    maya: [[0, S(1), 'read'], [S(1), S(2), 'listen', 'citizen'], [S(2), S(5), 'listen', 'omar'], [S(5), S(8), 'listen', 'official'], [S(8), S(9), 'type'], [S(9), S(13), 'listen', 'official'], [S(13), D.T, 'file']],
    citizen: [[0, S(1), 'listen', 'maya'], [S(1), E(1), 'sign'], [S(2), D.T, 'listen', 'official']],
    omar: [[0, S(2), 'paper'], [S(2), S(5), 'talk', 'maya'], [S(5), D.T, 'paper']],
    official: [[0, S(5), 'listen', 'omar'], [S(5), S(8), 'paper'], [S(8), S(9), 'listen', 'maya'], [S(9), S(13), 'talk', 'maya'], [S(13), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(8), 'tick', 'Case 2048 · Restored and verified', 'safe'],
      [S(8), S(13), 'file', 'Paper requests entered once', 'safe'],
      [S(13), D.T, 'folder', 'Next case', 'neutral'],
    ],
  },
  plates: [
    [S(0), E(0), 'Counter systems cleared for use · Case 2048'],
    [S(6), E(6), 'Lessons added to the plan'],
    [S(9), E(9), 'Chapter 8 · Three habits'],
    [S(13), E(13), 'Next case'],
  ],
  screens: [
    [S(0), S(2), win('Case 2048 · Verified', row('Restored files', 'All documents present', 'ok') + row('Payment', 'Checked and correct', 'ok') + row('Status', 'Ready to complete', 'ok'), 'good')],
    [S(13), E(13), win('Counter queue · Hall open', row('Case 2048', 'Completed and closed', 'ok') + row('Next case', 'Opened for service', 'hi'), 'good')],
  ],
  pages: [
    hero(S(2), S(5), 'Restore critical services first', 'show:clipboard:Restore Services Safely|Check systems before recovery|Restore critical systems first|Watch for signs of a repeat', [
      ['Restore checked critical systems in order', S(3), 'v-teal'],
      ['Watch for signs the incident could return', (S(3) + E(3)) / 2, 'v-amber'],
    ]),
    hero(S(5), S(8), 'Record lessons and improve the plan', 'show:paper:Review After an Incident|Log actions and needed fixes|Assign a person to each fix|Check that each fix works|Update the plan', [
      ['Response team documents actions and improvements', S(5), 'v-navy'],
      ['Assign each correction and check that it works', S(7), 'v-teal'],
    ]),
    hero(S(8), S(9), 'Verify before normal work resumes', 'show:clipboard:Before Work Resumes|Check that systems are ready|Match actual requests once|Leave out practice forms', [
      ['Reconcile live requests once · Exclude exercise forms', S(8), 'v-teal'],
    ]),
    hero(S(9), S(13), 'Verify, report, keep serving', 'show:notice:Keep Services Running|Odd request? Verify and report|Outage? Use the approved plan|Save work in approved places|Practice your role', [
      ['Unexpected request? Verify and report early', S(10), 'v-teal'],
      ['Service down? Use the approved alternative', S(11), 'v-navy'],
      ['Save in approved storage and practise your role', S(12), 'v-teal'],
    ]),
  ],
}));
