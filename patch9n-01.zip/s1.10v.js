// The weakness in the software. Omar and Shaima each do their part.
import { hallScene, CAST, teal, coral } from './story.js';
import './pages-l2.js';

export const texts = [];
export const cast = CAST;
export default hallScene((S, E, D) => ({
  lesson: '1.2', serve: [[S(7), S(7) + 1]],
  shots: ['desk', [S(2) - .1, 'counter'], [S(4) - .1, 'deskClose'], [S(6) - .1, 'counter'], [S(7) - .3, 'her'], [S(8) - .1, 'desk'], [S(9) - .1, 'her']],
  screen: [[S(8), S(9) + .2, '#bfe0d6']], omarWatch: [[S(8), S(9) + .2]],
  plates: [
    [S(0) + .5, E(0) + .1, `Software<br>${coral('Design, code, configuration')}`],
    [S(7) + .1, E(7) + .1, `Staff<br>${teal('Use the approved update process')}`],
    [S(8) + .1, E(8) + .1, `Technical teams<br>${teal('Assess and deploy safely')}`],
  ],
  pages: [
    { a: S(1) - .5, z: S(7) - .5, list: [
      { z: S(3) - .3, scene: 'hero', cues: { title: 'Known weakness\nLater: fix available', art: 'show:monitor:Security update overdue|Known software flaw|Fix available|Update still pending|The flaw is still a risk', items: [['Found', S(1) + 1, 'v-amber'], ['Fix released', S(1) + 4, 'v-teal']], lines: [['Update delayed: still exposed', S(2) + .4, 'v-coral']] } },
      { a: S(3) - .3, z: S(6) - .2, scene: 'zeroday', cues: { exploit: S(3) + 1.4, fix: S(3) + 4.6, unknown: S(4), patch: S(5) } },
      { a: S(6) - .2, scene: 'hero', cues: { title: 'Other protections\nalso matter', art: 'show:binder:Security guide|Check who has access|Watch for unusual activity|Review system settings|Practice the response plan', live: S(6) + 5.6, items: [['Access', S(6) + .6], ['Monitor', S(6) + 1.8], ['Config', S(6) + 3]], lines: [['Response readiness', S(6) + 4.6, 'v-teal']] } },
    ] },
    { a: S(9) - .4, z: D.T + 1, list: [{ scene: 'hero', cues: { title: 'Unexpected\n"fix"?', art: 'show:notice:Unexpected fix?|Avoid unofficial fixes|Use your usual support channel', lines: [['No unofficial repair', S(9) + 1, 'v-coral'], ['Use established support', S(10), 'v-teal']] } }] },
  ],
}));
