// Read the label first.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '5.1',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'teamEnd' },
  file: [[S(0), E(0), 0, 1]],
  shots: [[0, 'hall'], [S(1), 'counter'], [S(2), 'counterDisplay'], [S(3), 'her'], [S(8), 'counter'], [S(13), 'staff'], [S(14), 'her']],
  actions: {
    maya: [[0, S(1), 'file'], [S(1), S(2), 'listen', 'omar'], [S(2), S(13), 'read'], [S(13), S(15), 'talk', 'omar'], [S(15), D.T, 'read']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(2), 'paper'], [S(2), S(13), 'listen', 'maya'], [S(13), D.T, 'listen', 'maya']],
    citizen: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'folder', 'Case 2048', 'neutral'],
      [S(2), S(14), 'lock', 'Case 2048 · Restricted', 'alert'],
      [S(14), D.T, 'shield', 'Refer to record owner', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048'],
    [S(2), E(2), 'Case 2048 · Restricted'],
    [S(13), E(13), 'Need to know not met'],
    [S(14), E(14), 'Refer to record owner'],
  ],
  screens: [
    [S(2), S(3), win('Case 2048 · Summary', row('Document', 'Case 2048 summary') + row('Sensitivity level', 'Restricted', 'warn') + row('Request from', 'Colleague · Another office', 'wait') + note('Read the label before sharing.', 'warn'), 'alert')],
    [S(13), S(14), win('Access check', row('Sensitivity level', 'Restricted', 'warn') + row('Role in case', 'None · Another office', 'no') + row('Need to know', 'Not met', 'no') + note('Refer request to the record owner.'))],
  ],
  pages: [
    hero(S(3), S(8), 'Check the level first', 'show:notice:Check data level first|Top secret · Secret|Restricted · Public|Mixed data takes highest level', [
      ['Top secret · Secret · Restricted · Public', S(5), 'v-navy'],
      ['Mixed data takes the highest level', S(7), 'v-amber'],
    ]),
    hero(S(8), S(10), 'Personal data', 'show:paper:Personal data record|Can you identify the person|from this detail alone|or with other details?', [
      ['Identifies a person directly or indirectly', S(9), 'v-teal'],
    ]),
    hero(S(10), S(13), 'Sensitive personal data', 'show:binder:Sensitive personal data|Family, ethnic origin, faith|Health or criminal records|Every record set has an owner', [
      ['Family, ethnic origin, health, religion or criminal record', S(10), 'v-coral'],
      ['Each record set has an owner', S(11), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Need to know', 'show:clipboard:Before you share|Share only as needed for work|Unsure of level? Ask the owner|Shared by mistake? Report now', [
      ['Unclear level? Ask the record owner', S(15), 'v-teal'],
      ['Shared by mistake? Report at once', S(16), 'v-amber'],
    ]),
  ],
}));
