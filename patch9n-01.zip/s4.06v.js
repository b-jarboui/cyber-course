// The real page behind a fake one.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, mail, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['priya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.2',
  set: 'office',
  actors: { priya: 'desk', omar: 'beside' },
  landline: 'desk',
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(9), 'pair'], [S(11), 'display'], [S(12), 'desk'], [S(13), 'pair']],
  actions: {
    priya: [[0, S(11), 'read'], [S(11), S(12), 'type'], [S(12), S(13), 'read'], [S(13), S(14), 'extension'], [S(14), D.T, 'type']],
    omar: [[0, S(12), 'listen', 'priya'], [S(12), S(13), 'talk', 'priya'], [S(13), D.T, 'listen', 'priya']],
  },
  displays: {
    desk: [[0, S(1), 'mail', 'Shared payment file', 'neutral', 'inbox'], [S(1), S(11), 'lock', 'Sign in', 'alert', 'login'], [S(11), S(13), 'computer', 'Official sign-in', 'safe', 'login'], [S(13), D.T, 'bell', 'Report sent', 'safe']],
  },
  plates: [[S(0), E(0), 'Rania · Finance'], [S(1), E(1), 'Shared payment file'], [S(11), E(11), 'Address typed directly'], [S(12), E(12), 'No shared file found']],
  screens: [
    [S(0), S(1), win('Inbox', mail('Finance Share', 'docs@sadeed-payments.example', 'Shared payment file', 'Open the link to view the payment file.'), 'alert')],
    [S(1), S(2), win('login.sadeed-payments.example', row('Address', 'sadeed-payments.example', 'no') + row('Username', '') + row('Password', '') + note('Looks exactly like the real page.', 'warn'), 'alert')],
    [S(13), S(14), win('Security report', row('Message', 'Suspicious email & link', 'ok') + row('Forwarded to staff', 'No', 'ok') + note('Sent through the approved route.'), 'good')],
  ],
  pages: [
    hero(S(2), S(4), 'A familiar page is not proof', 'show:monitor:Familiar sign-in page?|It looks like the real page|Someone may be intercepting|your sign-in details', [
      ['Adversary-in-the-middle', S(3), 'v-amber'],
    ]),
    hero(S(4), S(10), 'Codes can be relayed live', 'show:monitor:Stolen sign-in|A code can be passed on live|Someone can use your sign-in|without your password or code', [
      ['Session token stolen', S(5), 'v-coral'],
      ['Works without password or code', S(6), 'v-amber'],
    ]),
    hero(S(10), S(13), 'Type the address yourself', 'show:monitor:Safe sign-in|Type official address|Passkeys check real site|Do not forward the email', [
      ['Passkeys check the real address', S(10), 'v-teal'],
      ['Do not forward the email', S(12), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Entered details? Report at once', 'show:deskphone:Entered sign-in details?|Report it right away', [
      ['End active sessions', S(15), 'v-teal'],
    ]),
  ],
}));
