// The director's voice, the finance rules
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, phone, row, note, reveal } from "./screens-tr.js";

export const texts = [];
export const cast = ["priya", "official"];
export default chapterHall((S, E, D) => ({
  lesson: "3.1",
  set: 'office',
  actors: { priya: 'desk', official: 'door' },
  landline: 'desk',
  enter: { official: S(11) }, walks: { official: [[S(11),E(11),'beside']] },
  shots: [[0,'desk'], [S(2),'display'], [S(3),'desk'], [S(8),'display'], [S(9),'desk'], [S(11),'pair']],
  actions: { priya: [[0,S(7),'extension'], [S(7),S(8),'read'], [S(8),S(10),'extension'], [S(10),S(12),'type'], [S(12),D.T,'listen','official']], official: [[S(11),D.T,'talk','priya']] },
  displays: { desk: [[0,S(8),'money','No payment made','alert'], [S(8),S(10),'mobile','Official directory','safe'], [S(10),D.T,'file-text','No payment requested','safe']] },
  setupProps: evidence({ surfaces: { deskPaper: [[0,D.T,'form','Payment approval']] }, inserts: [[S(7),E(7),'deskPaper']] }),
  plates: [[S(0),E(0),'Rania · Finance'], [S(2),E(2),'Before the banks close'], [S(3),E(3),'Request for secrecy'], [S(11),E(11),'Report sent'],
    [S(13),E(13),'Pause when pressured'], [S(14),E(14),'Verify through a known contact'], [S(15),E(15),'Report early']],
  screens: [
    [S(1), S(3), q => phone('Incoming call', reveal([
      row('Caller', 'Sounds like Director General', 'warn'),
      row('Request', 'Payment under confidential agreement', 'no'),
      row('Deadline', 'Before banks close today', 'no'),
    ], q))],
    [S(3), S(5), win('No payment made', row('Instruction', 'Do not discuss with anyone', 'no') + row('Approval form', 'Unsigned', 'no') + note('Authority, urgency and secrecy together.', 'no'), 'alert')],
    [S(7), S(8), win('Payment approval', row('Phone request', 'Not acted on', 'ok') + row('Next step', 'Check official directory', 'ok') + note('Verify through a known number.'), 'good')],
  ],
  pages: [
    hero(S(5), S(7), "Senior voices can be cloned", "show:phone:Call from the director?|Caller claims to be in charge|The voice could be a copy", [
      ["Claimed authority", S(6), "v-amber"],
    ]),
    hero(S(8), S(10), "Call back through the official directory", "show:clipboard:Call back and check|Use the official directory|No payment was requested", [
      ["No payment requested", S(9), "v-teal"],
    ]),
    hero(S(10), S(11), "No payment without approval", "show:paper:Payment approval form|Required sign-off: Missing|Policy: No approval, no pay|Result: No payment made", [
      ["No payment made", S(10), "v-teal"],
    ]),
  ],
}));
