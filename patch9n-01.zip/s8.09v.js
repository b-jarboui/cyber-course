// When one service stops, many people feel it.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '8.2',
  set: 'meeting',
  whiteboard: { title: 'Linked services', items: ['Sadeed Authority', 'Partner entities', 'Suppliers & payments', 'Applicants'] },
  actors: { official: 'board', maya: 'seat1', omar: 'seat2' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'gathering'], [S(1), 'file'], [S(2), 'board'], [S(3), 'table'], [S(6), 'board'], [S(11), 'table'], [S(12), 'gathering'], [S(13), 'board']],
  actions: {
    official: [[0, S(2), 'paper'], [S(2), S(3), 'point'], [S(3), S(6), 'listen', 'omar'], [S(6), S(11), 'talk', 'maya'], [S(11), D.T, 'paper']],
    maya: [[0, S(3), 'listen', 'official'], [S(3), S(6), 'listen', 'omar'], [S(6), S(11), 'listen', 'official'], [S(11), S(12), 'file'], [S(12), D.T, 'listen', 'omar']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), S(6), 'talk', 'maya'], [S(6), S(12), 'listen', 'official'], [S(12), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(6), 'calendar', 'Postponed appointments · Case 2048', 'alert'],
      [S(6), S(12), 'link', 'Authority · Partners · Applicants', 'neutral'],
      [S(12), D.T, 'shield', 'Reports helped the team warn partners', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Postponed appointments list'],
    [S(2), E(2), 'Authority · Partners · Suppliers'],
    [S(11), E(11), 'People waiting · Public trust'],
    [S(13), E(13), 'Shared services can be affected'],
  ],
  screens: [
    [S(0), S(2), win('Postponed appointments · Week', row('Case 2048', 'Postponed', 'warn') + row('Other applicants', 'Dozens waiting', 'warn') + note('Service outage delayed real people.', 'warn'), 'alert')],
    [S(2), S(3), win('Whiteboard · Linked services', row('Sadeed Authority', 'Core service', 'hi') + row('Connected to', 'Partners and suppliers', 'hi') + row('Shared services', 'Payments and applicants', 'hi'))],
  ],
  pages: [
    hero(S(3), S(6), 'Linked entities share risk', 'show:whiteboard:Partners Share Risk|A weakness here can affect|a partner’s service|Misused access can harm|other connected services', [
      ['A weakness may affect a partner’s service', S(3), 'v-amber'],
      ['Misused access may affect connected services', S(5), 'v-coral'],
    ]),
    hero(S(6), S(11), 'Harm reaches people, money and trust', 'show:tv:How Cyberattacks Hurt|Care and travel are disrupted|Co-op’s 2025 sales loss|Estimated at £285 million|UK: 80 major incidents', [
      ['Disrupts care, schools, transport and travel', S(7), 'v-coral'],
      ['Co-op estimated £285m in lost 2025 sales', S(9), 'v-amber'],
      ['UK · 80 nationally significant incidents in year to Aug 2026', S(10), 'v-navy'],
    ]),
    hero(S(11), S(13), 'One staff report can protect many', 'show:notice:Report Early, Help Many|Behind every delay is a person|One early staff report helps|Protects applicants & partners', [
      ['Behind every delay is a person waiting', S(11), 'v-navy'],
      ['Early reports protect applicants and partners', S(12), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Verify, report and use the approved alternative procedure', 'show:clipboard:Keep Serving Safely|Verify unexpected requests|Check with a known contact|Report concerns early|Use the approved backup plan', [
      ['Verify unexpected requests through a known contact', S(13), 'v-amber'],
      ['Verify, report early, keep serving safely', (S(13) + E(13)) / 2, 'v-teal'],
    ]),
  ],
}));
