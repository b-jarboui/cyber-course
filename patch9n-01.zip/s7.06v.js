// Anyone with the link.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '7.2',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'staff'], [S(3), 'her'], [S(8), 'counterDisplay'], [S(10), 'counter'], [S(11), 'counterDisplay'], [S(14), 'her']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(3), 'talk', 'omar'], [S(3), S(8), 'listen', 'omar'], [S(8), S(10), 'type'], [S(10), S(11), 'listen', 'omar'], [S(11), S(14), 'type'], [S(14), D.T, 'read']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(8), 'talk', 'maya'], [S(8), S(10), 'listen', 'maya'], [S(10), S(11), 'point'], [S(11), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'folder', 'Case 2048 · Cloud folder', 'neutral'],
      [S(1), S(8), 'link', 'Anyone with the link?', 'alert'],
      [S(8), S(10), 'tick', 'Specific people · View only', 'safe'],
      [S(10), S(11), 'link', 'Old link still open', 'alert'],
      [S(11), D.T, 'lock', 'Old link removed · Checked', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Specific people or public link?'],
    [S(8), E(8), 'Specific people · View only'],
    [S(10), E(10), 'Old link from last month'],
    [S(11), E(11), 'Old link removed'],
  ],
  screens: [
    [S(1), S(3), win('Share · Case 2048', row('Specific people', 'Named directory users only', 'ok') + row('Anyone with the link', 'Public · Can be forwarded', 'no') + note('Quickest choice is not the safest.', 'warn'), 'alert')],
    [S(10), S(12), q => win('Folder sharing list', reveal([row('Old link', 'Created last month · Open', 'no'), row('Needed now', 'No', 'warn'), row('Action', 'Link off · Sharing removed', 'ok')], q))],
  ],
  pages: [
    hero(S(3), S(6), 'No public links for sensitive files', 'show:monitor:Share File Settings|[ ] Anyone with link (BLOCKED)|Public links can be forwarded|Sensitive data: never public', [
      ['A public link can be forwarded to anyone', S(3), 'v-coral'],
      ['25% of public files hold sensitive personal data', S(4), 'v-amber'],
    ]),
    hero(S(6), S(8), 'Encryption', 'show:binder:Encryption Policy|Cloud alone is not enough|Encrypt files in storage|Encrypt data in transit', [
      ['Cloud storage alone is not automatic safety', S(6), 'v-amber'],
      ['Policy: encryption in storage and transit', S(7), 'v-teal'],
    ]),
    hero(S(8), S(10), 'Share with named people', 'show:monitor:Share: Case Folder|Pick user from staff directory|Access level: View only|Grant only the access needed', [
      ['Pick from the directory; give view-only', S(8), 'v-teal'],
      ['Least privilege: only the access needed', S(9), 'v-navy'],
    ]),
    hero(S(12), D.T, 'Review permissions', 'show:clipboard:Access Review Checklist|[ ] Check folder sharing list|[ ] Delete old sharing links|[ ] Remove extra access|Over-shared? Remove and report', [
      ['Review sharing lists; delete old links', S(12), 'v-teal'],
      ['Found over-shared files? Remove and report', S(14), 'v-amber'],
    ]),
  ],
}));
