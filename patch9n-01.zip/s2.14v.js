// Case 2048 closes safely.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'citizen', 'official', 'omar', 'finance', 'admin'];
export default chapterHall((S, E, D) => ({
  lesson: '2.3',
  actors: { maya: 'counter', citizen: 'signer', official: 'director', omar: 'colleague', finance: 'team', admin: 'teamEnd' },
  shots: [[0,'counter'], [S(1),'file'], [S(2),'gathering'], [S(3),'habits'], [S(5),'gathering'], [S(10),'staff'], [S(14),'file']],
  file: [[0,S(1),1,1], [S(14),E(14),1,0]],
  habits: true,
  signing: true,
  enter: { official: S(2), finance: S(2), admin: S(2) },
  actions: {
    maya: [[0,S(2),'listen','citizen'], [S(2),S(14),'listen','official'], [S(14),D.T,'file']],
    citizen: [[0,S(1),'listen','maya'], [S(1),E(1),'sign'], [S(2),D.T,'listen','official']],
    official: [[S(2),E(13),'talk','maya']],
    omar: [[S(2),D.T,'listen','official']], finance: [[S(2),D.T,'listen','official']], admin: [[S(2),D.T,'listen','official']],
  },
  plates: [[S(0),E(0),'Case 2048'], [S(1),E(1),'Final signature'], [S(2),E(2),'Hamad · Department manager'], [S(5),E(5),'No money lost'], [S(14),E(14),'Case 2048 closed']],
  pages: [
    hero(S(6), S(7), 'Pause when pressured', 'show:notice:Pause when pressured|Urgency: Act right now|Authority: An order from above|Secrecy: Tell no one', [
      ['Urgency, authority or secrecy', S(6), 'v-amber'],
    ]),
    hero(S(7), S(8), 'Verify through a known contact', 'show:deskphone:Verify before acting|Call the number on file', [
      ['Number already on file', S(7), 'v-teal'],
    ]),
    hero(S(8), S(10), 'Never share passwords or codes', 'show:phone:Sign-in safety|Never share passwords or codes|Did you start this sign-in?|Only approve it if you did|Use the official web address', [
      ['Only approve a sign-in you started', S(8), 'v-teal'],
      ['Use the official address', S(9), 'v-teal'],
    ]),
    hero(S(10), S(14), 'Report early, through the approved route', 'show:clipboard:Report early|Unsure? Report it anyway|Use the approved report route|Money sent? Call the bank now', [
      ['Report even if unsure', S(10), 'v-teal'],
      ['Money sent? Call the bank', S(12), 'v-teal'],
    ]),
  ],
}));
