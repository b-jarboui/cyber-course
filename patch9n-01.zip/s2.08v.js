// The help desk that came from outside.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, btn } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '2.2',
  cable: { device: 'desk' },
  actors: { omar: 'desk', maya: 'counter' },
  shots: [[0,'desk'], [S(1),'display'], [S(3),'desk'], [S(9),'display'], [S(10),'desk'], [S(12),'desk'], [S(13),'desk']],
  actions: {
    omar: [[0,S(10),'read'], [S(10),S(11),'type'], [S(11),E(12),'call'], [S(13),D.T,'type']],
    maya: [[0,S(3),'type'], [S(3),D.T,'listen','omar']],
  },
  displays: { desk: [[0,S(1),'mail','Sudden email flood','alert','inbox'], [S(1),S(2),'chat','Help Desk · External','neutral'], [S(2),S(9),'computer','Remote session request','alert'], [S(9),S(10),'chat','External','alert'], [S(10),S(11),'computer','Remote session declined','safe'], [S(11),D.T,'mobile','Internal directory','safe']] },
  plates: [[S(0),E(0),'Sudden email flood'], [S(1),E(1),'Help Desk · External'], [S(2),E(2),'Remote session request'], [S(13),E(13),'Confirmed support contact']],
  screens: [
    [S(0), S(1), win('Inbox', row('Newsletter alert', 'Unread (18)', 'warn') + row('Subscription confirm', 'Unread (24)', 'warn') + note('Sudden flood of unwanted emails.', 'warn'), 'alert')],
    [S(1), S(2), win('Work chat', row('Help Desk', 'External', 'no') + note('We see your email flood. Let us fix it now.', 'warn'), 'alert')],
    [S(2), S(3), win('Remote session request', row('From', 'Help Desk · External', 'no') + row('Permission', 'Control this laptop', 'no') + btn('Approve remote session', 'no'), 'alert')],
  ],
  pages: [
    hero(S(4), S(9), 'Fake technical support', 'show:monitor:Support chat|External account|Please allow remote access|Is this really support?', [
      ['Outside support account', S(4), 'v-amber'],
      ['Remote access', S(5), 'v-amber'],
    ]),
    hero(S(9), S(10), 'Check the External label in chat', 'show:monitor:Help desk chat|Account label: External|Look for the external label', [
      ['External', S(9), 'v-amber'],
    ]),
    hero(S(10), S(11), 'Never approve an unexpected remote session', 'show:monitor:Remote access request|Unexpected support session|Request declined', [
      ['Remote session declined', S(10), 'v-teal'],
    ]),
    hero((S(11)+E(11))/2, S(13), 'Call the help desk on the known number', 'show:paper:Internal IT directory|Call the listed help desk|Report the suspicious chat', [
      ['Internal directory', S(11), 'v-teal'],
      ['Report the chat', S(12), 'v-teal'],
    ]),
  ],
}));
