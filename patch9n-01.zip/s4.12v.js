// Trusted yesterday, checked today.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.3',
  set: 'meeting',
  actors: { maya: 'seat2', omar: 'seat1' },
  handsets: { maya: [[S(12), S(13), 'shield']] },
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(4), 'table'], [S(12), 'display'], [S(13), 'desk'], [S(14), 'table']],
  actions: {
    maya: [[0, S(1), 'type'], [S(1), S(12), 'read'], [S(12), S(13), 'text'], [S(13), D.T, 'type']],
    omar: [[0, S(13), 'listen', 'maya'], [S(13), D.T, 'talk', 'maya']],
  },
  displays: {
    desk: [[0, S(1), 'folder', 'Case 2048', 'neutral'], [S(1), S(12), 'lock', 'Verify identity again', 'alert', 'login'], [S(12), D.T, 'tick', 'Case 2048 · Limited access', 'safe']],
  },
  plates: [[S(0), E(0), 'Meeting-room laptop'], [S(1), E(1), 'Different device and context'], [S(2), E(2), 'Verify identity again'], [S(12), E(12), 'Case 2048 · Limited access']],
  screens: [
    [S(1), S(3), win('Verify identity again', row('Device', 'Meeting-room laptop', 'warn') + row('Context', 'Different from counter', 'warn') + row('Action', 'Extra verification required', 'wait'), 'alert')],
    [S(12), S(13), win('Case 2048 · Limited access', row('Additional check', 'Completed', 'ok') + row('Scope', 'Case 2048 only', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(5), 'Never trust automatically', 'show:binder:Zero Trust principle|Never trust automatically|Verify every user and device|Grant minimum access needed', [
      ['Zero Trust principle', S(4), 'v-teal'],
    ]),
    hero(S(5), S(6), 'Verify every access request', 'show:monitor:Access check|On the office network?|We still check every request|Confirm your identity', [
      ['No automatic inside trust', S(5), 'v-teal'],
    ]),
    hero(S(6), S(10), 'Check identity, device and context', 'show:tablet:Access check|Check who is asking and why|An unsafe device may be denied|Allow only the approved task', [
      ['Unknown or unsafe device may be denied', S(6), 'v-amber'],
      ['Scoped to the approved task', S(8), 'v-teal'],
    ]),
    hero(S(10), S(12), 'Limit access and monitor continuously', 'show:monitor:Access during use|Watch for changes in risk|Check again or limit access|End access if needed', [
      ['Session risk can change', S(10), 'v-amber'],
      ['Re-verify, restrict or end session', S(11), 'v-teal'],
    ]),
  ],
}));
