// AI helps watch the signals.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['priya', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '9.4',
  set: 'ops',
  actors: { priya: 'desk', maya: 'beside', omar: 'deskGuest' },
  shots: [[0, 'pair'], [S(1), 'display'], [S(2), 'desk'], [S(4), 'pair'], [S(8), 'display'], [S(11), 'desk'], [S(12), 'pair'], [S(15), 'desk']],
  actions: {
    priya: [[0, S(2), 'read'], [S(2), S(4), 'talk', 'maya'], [S(4), S(12), 'read'], [S(12), S(15), 'type'], [S(15), D.T, 'talk', 'maya']],
    maya: [[0, D.T, 'listen', 'priya']],
    omar: [[0, D.T, 'listen', 'priya']],
  },
  displays: {
    desk: [
      [0, S(8), 'computer', 'Monitoring · Thousands of events', 'neutral'],
      [S(8), S(12), 'zoom', 'Unusual activity · Bulk case download', 'alert'],
      [S(12), D.T, 'shield', 'Analyst checking evidence', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Security monitoring · Rania'],
    [S(1), E(1), 'Thousands of routine signals'],
    [S(8), E(8), 'Unusual download · Multiple case records'],
    [S(12), E(12), 'Analyst checks context first'],
  ],
  screens: [
    [S(1), S(2), win('Security monitoring · Live feed', row('Routine sign-ins', '4,812 today · Within normal range', 'ok') + row('Case file opens', '1,290 today · Within normal range', 'ok') + row('Unusual activity', '3 flagged for review', 'warn'))],
  ],
  pages: [
    hero(S(2), S(4), 'AI can find patterns at scale', 'show:monitor:Security Alerts|AI checks many signals quickly|Related alerts are grouped|Ready for an analyst to review', [
      ['Scans large volumes of security signals fast', S(2), 'v-navy'],
      ['Groups related alerts for analyst review', S(3), 'v-teal'],
    ]),
    hero(S(4), S(11), 'Unusual account activity can reveal misuse without malware', 'show:monitor:Unusual Account Activity|Large download at an odd hour|A valid login can be misused|Even without harmful software', [
      ['CrowdStrike · 82% of its detections involved no malware', S(6), 'v-coral'],
      ['CrowdStrike · Valid-account abuse in 35% of its cloud incidents', S(7), 'v-amber'],
      ['Spots unusual download volume and timing', S(8), 'v-navy'],
    ]),
    hero(S(11), D.T, 'Alert → analyst → decision', 'show:monitor:Analyst Review Screen|AI note: Unusual login time|Check: Evidence & work context|Verdict: Harmless/Odd/Incident|People make the final call', [
      ['AI adds context; it does not prove an incident', S(11), 'v-amber'],
      ['Analysts check evidence and business context', S(12), 'v-teal'],
      ['People decide: harmless, odd or incident', S(15), 'v-navy'],
    ]),
  ],
}));
