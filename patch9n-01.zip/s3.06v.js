// A face that belongs to two people
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";
import { win, row, note } from "./screens-tr.js";

export const texts = [];
export const cast = ["maya", "omar", "citizenYoung"];
export default chapterHall((S, E, D) => ({
  lesson: "3.2",
  actors: { maya: 'counter', omar: 'colleague', citizenYoung: 'exit' },
  enter: { citizenYoung: S(9) }, walks: { citizenYoung: [[S(9),E(9),'visitor']] },
  shots: [[0,'her'], [S(1),'counterDisplay'], [S(5),'counter'], [S(9),'gathering'], [S(10),'counter'], [S(11),'counterDisplay'], [S(12),'counter']],
  actions: { maya: [[0,S(9),'read'], [S(9),S(10),'type'], [S(10),S(11),'listen','citizenYoung'], [S(11),S(12),'read'], [S(12),S(13),'talk','citizenYoung'], [S(13),D.T,'type']], citizenYoung: [[S(9),S(10),'listen','maya'], [S(10),E(10),'paper'], [S(11),D.T,'listen','maya']], omar: [[0,S(11),'listen','maya'], [S(12),D.T,'listen','citizenYoung']] },
  setupProps: evidence({
    camera: true,
    surfaces: { counter: [[0,S(9),'portrait','Uploaded photo','citizenYoung'], [S(9),S(13),'compare','Uploaded and counter photos','citizenYoung']], 'paper:citizenYoung': [[S(10),E(10),'identity','Original identity document','citizenYoung']] },
    inserts: [[S(1),E(1),'counter'], [S(11),E(11),'counter']],
    pointAt: [[S(11),E(11),'omar','counter']],
  }),
  displays: { counter: [[S(13),D.T,'folder','Referred for review','safe']] },
  plates: [[S(1),E(1),'Uploaded photo'], [S(10),E(10),'Original identity document'], [S(13),E(13),'Referred for review']],
  screens: [
    [S(0), S(2), win('Online application', row('Source', 'Applicant upload', 'warn') + row('Uploaded photo', 'Clear and ordinary', 'warn') + note('Self-submitted · Needs counter check.', 'warn'))],
    [S(11), S(12), win('Photo comparison', row('Uploaded photo', 'Online submission', 'warn') + row('Counter camera', 'Taken in person', 'ok') + row('Match', 'Does not quite match', 'no'), 'alert')],
    [S(13), S(14), win('Referred for review', row('Application', 'Paused', 'ok') + row('Review', 'Sent via approved route', 'ok') + note('Trained reviewers investigate.'), 'good')],
  ],
  pages: [
    hero(S(2), S(5), "Face swap and morphing", "show:monitor:Altered ID photo|One face can replace another|Two faces can be blended", [
      ["Two faces in one photo", S(3), "v-amber"],
    ]),
    hero(S(6), S(9), "Synthetic identity: real and invented data combined", "show:paper:Applicant record check|Some real details are stolen|Other details are made up|Together they form a false ID", [
      ["Stolen or invented details", S(6), "v-amber"],
    ]),
    hero(S(9), S(11), "Trust the photo taken here", "show:clipboard:Identity check|Use the photo taken here|Compare with the original ID", [
      ["Original identity document", S(10), "v-teal"],
    ]),
  ],
}));
