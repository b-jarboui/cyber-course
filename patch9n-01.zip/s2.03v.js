// A file that hides a link.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, mail, head, btn } from './screens-tr.js';

export const texts = [];
export const cast = ['admin', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { admin: 'desk', omar: 'counterEnd' },
  shots: [[0,'desk'], [S(2),'display'], [S(7),'desk'], [S(9),'pair'], [S(10),'desk'], [S(12),'pair']],
  walks: { omar: [[S(8),E(8),'beside']] },
  actions: {
    admin: [[0,S(8),'read'], [S(8),S(10),'listen','omar'], [S(10),E(11),'call'], [S(13),D.T,'type']],
    omar: [[S(9),E(9),'talk','admin'], [S(10),D.T,'listen','admin']],
  },
  displays: { desk: [[0,S(2),'file-text','Supplier price list','neutral','inbox'], [S(2),S(10),'folder','Open shared folder','alert'], [S(10),D.T,'mobile','Supplier record','safe']] },
  plates: [[S(0),E(0),'Khalid · Procurement'], [S(1),E(1),'Supplier price list'], [S(2),E(2),'Open shared folder'], [S(11),E(11),'Nothing sent today']],
  screens: [
    [S(1), S(2), win('Inbox', mail('Al-Noor Supplies', 'sales@alnoor-pricing.example', 'Updated price list', 'Please review the attached file.') + row('Attachment', 'Updated_Price_List.pdf', 'warn'), 'alert')],
    [S(2), S(3), win('Updated_Price_List.pdf', head('Updated price list', 'No prices shown') + btn('Open shared folder', 'no') + note('Button hides an external link.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(3), S(7), 'Links hide inside documents', 'show:monitor:Document link|Open shared folder|Files can hide unsafe links', [
      ['Open shared folder', S(3), 'v-amber'],
    ]),
    hero(S(8), S(9), 'Unexpected attachment? Pause', 'show:monitor:Unexpected attachment|Supplier price list|Pause before opening', [
      ['Supplier price list', S(8), 'v-amber'],
    ]),
    hero(S(10), S(11), 'Verify the sender through a known contact', 'show:paper:Supplier contact record|Use the contact on file|Check who sent the attachment', [
      ['Supplier record', S(10), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Report, do not forward', 'show:monitor:Report an attachment|Report it without forwarding|List any file you opened', [
      ['Mention any file you opened', S(14), 'v-teal'],
    ]),
  ],
}));
