// Where does my question go?
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '6.1',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'hall'], [S(1), 'counter'], [S(2), 'staff'], [S(3), 'counterDisplay'], [S(4), 'her'], [S(14), 'counter']],
  actions: {
    maya: [[0, S(1), 'file'], [S(1), S(2), 'read'], [S(2), S(4), 'listen', 'omar'], [S(4), S(14), 'read'], [S(14), D.T, 'listen', 'omar']],
    omar: [[0, S(2), 'listen', 'maya'], [S(2), S(3), 'talk', 'maya'], [S(3), S(14), 'paper'], [S(14), D.T, 'talk', 'maya']],
    citizen: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'folder', 'Case 2048', 'neutral'],
      [S(1), S(14), 'computer', 'Approved AI assistant', 'neutral'],
      [S(14), D.T, 'bell', 'Check before you type', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048'],
    [S(1), E(1), 'Approved AI assistant'],
    [S(2), E(2), 'Where does my question go?'],
    [S(14), E(14), 'Know the tool before you type'],
  ],
  screens: [
    [S(1), S(2), win('Approved AI assistant', row('File open', 'Case 2048') + row('Prompt box', 'Empty · Paused', 'wait') + note('Paused before typing applicant details.', 'warn'))],
    [S(2), S(4), q => win('Where does the prompt go?', reveal([
      row('Hosted where?', 'Unknown', 'warn'),
      row('Who can see it?', 'Unknown', 'warn'),
      row('Tools connected', 'Unknown', 'warn'),
      note('Check before pressing Enter.', 'warn'),
    ], q))],
  ],
  pages: [
    hero(S(4), S(7), 'Generative AI and the model', 'show:monitor:How AI answers|Predicts likely next words|Does not understand meaning|Can sound sure & be wrong', [
      ['Predicts next words; not human understanding', S(5), 'v-amber'],
      ['Can sound sure and still be wrong', S(6), 'v-coral'],
    ]),
    hero(S(7), S(10), 'More than the model', 'show:whiteboard:Inside an AI system|Model + instructions|Connected data + tools|Every link can leak data', [
      ['Model, instructions, information, tools', S(8), 'v-teal'],
      ['Every connection can leak information', S(9), 'v-amber'],
    ]),
    hero(S(10), S(14), 'Where your information goes', 'show:binder:Where AI data goes|Hosted here or by others|Confidential or personal data?|Use only with approval', [
      ['Hosted inside or by a third party', S(10), 'v-navy'],
      ['No confidential or personal data unless approved', S(11), 'v-coral'],
    ]),
    hero(S(14), D.T, 'Know the tool before you type', 'show:clipboard:Before you type|[ ] What is this AI tool?|[ ] What data can it reach?|[ ] Who approved it?|Unsure? Stop, verify, report', [
      ['What is it, what can it reach, who approved it?', S(14), 'v-teal'],
      ['Unsure? Stop, verify and report', S(15), 'v-amber'],
    ]),
  ],
}));
