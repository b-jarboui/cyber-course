// Contain first, keep the evidence.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'helpdesk', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '9.2',
  cable: { device: 'desk', unplugAt: S(3) },
  actors: { omar: 'desk', helpdesk: 'beside', maya: 'counter' },
  file: [[0, D.T, 1, 1]],
  landline: 'desk',
  shots: [[0, 'pair'], [S(3), 'desk'], [S(4), 'display'], [S(7), 'her'], [S(8), 'file'], [S(10), 'counterDisplay'], [S(12), 'counter'], [S(15), 'pair']],
  actions: {
    omar: [[0, S(3), 'read'], [S(3), S(4), 'handsOff'], [S(4), D.T, 'listen', 'helpdesk']],
    helpdesk: [[0, S(4), 'extension'], [S(4), S(10), 'talk', 'omar'], [S(10), D.T, 'paper']],
    maya: [[0, S(8), 'listen', 'omar'], [S(8), S(10), 'paper'], [S(10), S(13), 'type'], [S(13), D.T, 'read']],
  },
  displays: {
    desk: [
      [0, S(3), 'wifi', 'Network connected · Alert', 'alert'],
      [S(3), D.T, 'shield', 'All network connections disconnected · Left on', 'safe'],
    ],
    counter: [
      [0, S(10), 'file', 'Report form · Case 2048', 'neutral'],
      [S(10), S(12), 'lock', 'Official portal · Password reset', 'safe', 'login'],
      [S(12), D.T, 'tick', 'Password changed · Sessions ended', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Containment · Stop the spread'],
    [S(3), E(3), 'Cable and Wi-Fi disconnected · Device left on'],
    [S(8), E(8), 'Times recorded · Case 2048'],
    [S(10), E(10), 'Separate computer · Official portal'],
  ],
  screens: [
    [S(3), S(4), win('Containment · Omar laptop', row('Cable and Wi-Fi', 'Cable unplugged · Wi-Fi off', 'ok') + row('Power', 'Left switched on', 'ok') + row('Files & alerts', 'Untouched for evidence', 'ok'), 'good')],
    [S(10), S(11), win('portal.sadeed.gov.example', row('Device', 'Separate trusted computer', 'ok') + row('Account', 'shaima@sadeed.gov.example', 'hi') + row('Action', 'Password reset · Official portal', 'ok'), 'good')],
  ],
  pages: [
    hero(S(1), S(3), 'Containment stops the spread', 'show:monitor:Stop the Spread|CrowdStrike saw attacks reach|another system in 29 minutes|on average|Follow the team’s instructions', [
      ['Follow the response team step by step', S(1), 'v-teal'],
      ['CrowdStrike observed a 29-minute average to reach another system', S(2), 'v-coral'],
    ]),
    hero(S(4), S(7), 'Follow the incident plan and the response team’s instructions', 'show:binder:Limit the Spread|Isolate the device as directed|Follow the team’s power advice|Turning it off can erase|evidence held in memory', [
      ['Isolate as directed · Follow the team’s power instructions', S(4), 'v-teal'],
      ['Powering off erases live memory evidence', S(5), 'v-amber'],
    ]),
    hero(S(7), S(10), "Don't delete · write it down", 'show:clipboard:Preserve Evidence|[x] Do not delete or clean|[x] Do not run extra scans|[x] Record exact clock times|[x] Note what screen showed', [
      ['Do not delete, clean files or run scans', S(7), 'v-coral'],
      ['Record exact times and what screens showed', S(8), 'v-teal'],
    ]),
    hero(S(11), D.T, 'New password · official channel only', 'show:monitor:Official Password Reset|Use a clean device only|Reset via official portal|Team ends active sessions|Report any reused passwords', [
      ['Reset from a clean device via official portal', S(11), 'v-teal'],
      ['Team ends sessions · Report password reuse', S(12), 'v-navy'],
    ]),
  ],
}));
