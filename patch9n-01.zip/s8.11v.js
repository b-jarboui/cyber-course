// How long, and how much.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '8.3',
  set: 'meeting',
  whiteboard: { title: 'Recovery targets', items: ['1. How long? (RTO)', '2. How much? (RPO)', 'Save in approved folders'] },
  actors: { official: 'board', maya: 'seat1', omar: 'seat2' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'board'], [S(1), 'table'], [S(4), 'board'], [S(9), 'desk'], [S(10), 'table'], [S(11), 'board'], [S(12), 'desk']],
  actions: {
    official: [[0, S(1), 'point'], [S(1), S(4), 'listen', 'omar'], [S(4), S(9), 'point'], [S(9), S(11), 'listen', 'omar'], [S(11), D.T, 'paper']],
    maya: [[0, S(1), 'listen', 'official'], [S(1), S(4), 'listen', 'omar'], [S(4), S(9), 'listen', 'official'], [S(9), S(10), 'file'], [S(10), S(11), 'listen', 'omar'], [S(11), S(12), 'listen', 'official'], [S(12), D.T, 'type']],
    omar: [[0, S(1), 'listen', 'official'], [S(1), S(4), 'talk', 'maya'], [S(4), S(10), 'listen', 'official'], [S(10), S(11), 'talk', 'maya'], [S(11), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(9), 'clock', 'How long? · How much data?', 'neutral'],
      [S(9), S(12), 'file', 'Desktop notes · Not backed up', 'alert'],
      [S(12), D.T, 'folder', 'Approved folder · Backed up', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'How long? · How much data?'],
    [S(5), E(5), 'Recovery time objective'],
    [S(8), E(8), 'Recovery point objective'],
    [S(10), E(10), 'Sadeed backs up the approved case folder'],
  ],
  screens: [
    [S(0), S(1), win('Whiteboard · Recovery targets', row('Question 1', 'When should the system be restored?', 'hi') + row('Question 2', 'How much recent work can the service afford to lose?', 'hi'))],
    [S(9), S(11), win('File storage · Case 2048', row('Approved folder', 'Case 2048 · Restored', 'ok') + row('Local desktop', 'Morning notes · Lost', 'no') + note('These desktop notes were outside Sadeed’s backup.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(1), S(4), 'Cyber resilience: withstand, then recover', 'show:whiteboard:During and After Attacks|Keep key services running|while the attack is underway|Then restore systems and data', [
      ['Keep critical services going during an attack', S(1), 'v-teal'],
      ['Disaster recovery restores systems and data', S(2), 'v-navy'],
    ]),
    hero(S(4), S(7), 'Recovery time objective: how long', 'show:tv:Recovery Time Target|Set a time to restore systems|Leave time to restart service|within the allowed outage', [
      ['Target time to restore the system', S(5), 'v-navy'],
      ['Allow time to resume service within the maximum tolerable outage', S(6), 'v-amber'],
    ]),
    hero(S(7), S(9), 'Recovery point objective: how much data', 'show:monitor:Data Recovery Point|How far back must we go?|Work saved after that point|could be lost', [
      ['Point in time to which data is restored', S(8), 'v-navy'],
      ['Shows how much recent work could be lost', (S(8) + E(8)) / 2, 'v-amber'],
    ]),
    hero(S(12), D.T, 'Save work only in approved locations', 'show:monitor:Save in Approved Folders|These desktop notes are outside|the central backup at Sadeed|Report lost data', [
      ['Sadeed’s central backups exclude these desktop notes', S(12), 'v-coral'],
      ['Save in approved folders; report lost data', S(13), 'v-teal'],
    ]),
  ],
}));
