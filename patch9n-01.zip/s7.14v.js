// Same name, new bank account.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, mail, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'finance'];
export default chapterHall((S, E, D) => ({
  lesson: '7.3',
  actors: { maya: 'counter', omar: 'colleague', official: 'director', finance: 'team' },
  file: [[0, S(18), 1, 1], [S(18), E(18), 1, 0]],
  landline: true,
  shots: [[0, 'gathering'], [S(1), 'counterDisplay'], [S(3), 'staff'], [S(8), 'counter'], [S(9), 'her'], [S(10), 'counterDisplay'], [S(11), 'gathering'], [S(14), 'gathering'], [S(18), 'file']],
  actions: {
    maya: [[0, S(3), 'read'], [S(3), S(9), 'listen', 'omar'], [S(9), S(10), 'extension'], [S(10), S(11), 'type'], [S(11), S(18), 'listen', 'official'], [S(18), D.T, 'file']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(9), 'talk', 'maya'], [S(9), S(11), 'listen', 'maya'], [S(11), D.T, 'listen', 'official']],
    official: [[0, S(11), 'listen', 'maya'], [S(11), S(18), 'talk', 'maya'], [S(18), D.T, 'listen', 'maya']],
    finance: [[0, S(10), 'listen', 'maya'], [S(10), S(11), 'paper'], [S(11), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(1), 'mail', 'Finance mailbox · Invoice', 'neutral', 'inbox'],
      [S(1), S(10), 'money', 'New bank account today', 'alert', 'inbox'],
      [S(10), S(18), 'bell', 'Payment held · Reported', 'safe'],
      [S(18), D.T, 'folder', 'The next case', 'neutral'],
    ],
  },
  plates: [
    [S(1), E(1), 'Request for new bank account'],
    [S(9), E(9), 'Contract call · No change asked'],
    [S(10), E(10), 'Payment held · Mailbox checked'],
    [S(14), E(14), 'Chapter 7 · Three habits'],
    [S(18), E(18), 'The next case'],
  ],
  screens: [
    [S(0), S(2), win('Finance mailbox', mail('DocScan Billing', 'billing@docscan-pay.example', 'Updated bank details for invoice', 'Pay invoice to new account ending 9042.'), 'alert')],
    [S(2), S(3), win('Payment check · DocScan', row('Account on file', 'Bank account ending 4821', 'ok') + row('Email request', 'New account ending 9042', 'no') + note('Name and logo match, but verify first.', 'warn'), 'alert')],
  ],
  pages: [
    hero(S(3), S(8), 'Supplier impersonation', 'show:monitor:Supplier Payment Email|Please use our new account|Good writing proves nothing|Verify before paying', [
      ['Fake or stolen supplier mail redirects payment', S(3), 'v-coral'],
      ['Polished writing proves nothing; verify first', S(5), 'v-amber'],
    ]),
    hero(S(8), S(11), 'Verify the bank change', 'show:paper:Verify Bank Changes|Ignore numbers in the email|Call the contract contact|If unsure, hold payment', [
      ['Never use phone numbers inside the email', S(8), 'v-coral'],
      ['Confirm via contract contact; hold if unsure', S(9), 'v-teal'],
    ]),
    hero(S(11), S(14), 'Third-party governance', 'show:binder:Supplier Register|Rank by service importance|Name the owner|List the contract contact|State who reports incidents', [
      ['Policy: supplier register by criticality', S(12), 'v-navy'],
      ['Named owner, contract contact, incident duty', S(13), 'v-teal'],
    ]),
    hero(S(14), S(18), 'Chapter 7: three habits', 'show:notice:Daily Security Habits|Use approved devices and apps|Use approved cloud services|Update and report problems|Share only with named people', [
      ['Approved devices, apps, cloud; update & report', S(15), 'v-teal'],
      ['Named sharing, least access, no shared logins', S(16), 'v-navy'],
      ['Verify supplier requests; report early', S(17), 'v-teal'],
    ]),
  ],
}));
