// Approved use, early reports, regular review.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '10.2',
  actors: { omar: 'beside', maya: 'desk' },
  walks: {
    omar: [[S(14), E(14), 'office']], /* swapped with Maya: her route to the office ran through Omar at the door */
    maya: [[S(14), E(14), 'door']],
  },
  shots: [[0, 'pair'], [S(1), 'desk'], [S(2), 'pair'], [S(7), 'display'], [S(10), 'pair'], [S(14), 'door']],
  actions: {
    omar: [[0, S(2), 'text'], [S(2), S(7), 'listen', 'maya'], [S(7), S(10), 'talk', 'maya'], [S(10), S(14), 'listen', 'maya']],
    maya: [[0, S(2), 'listen', 'omar'], [S(2), S(7), 'talk', 'omar'], [S(7), S(10), 'type'], [S(10), S(14), 'read']],
  },
  handsets: {
    omar: [
      [0, S(7), 'chat'],
      [S(7), D.T, 'bell'],
    ],
  },
  displays: {
    desk: [
      [0, S(7), 'folder', 'Case 2048 · Personal phone AI', 'alert'],
      [S(7), S(10), 'bell', 'Early report submitted', 'safe'],
      [S(10), D.T, 'calendar', 'AI tools · Ongoing review', 'neutral'],
    ],
  },
  plates: [
    [S(0), E(0), 'Public AI chat on personal phone'],
    [S(1), E(1), 'Going together to report'],
    [S(14), E(14), 'Approved tools · Report · Review'],
  ],
  screens: [
    [S(0), S(1), phone('Public AI chat · Personal', row('Website', 'open-chat-ai.example', 'no') + row('Account', 'Personal phone account', 'no') + row('Pasted text', 'Lines from Case 2048 note', 'no') + note('Outside Authority control.', 'no'))],
    [S(1), S(2), win('Early report · Approved route', row('What happened', 'Case 2048 note entered in a public AI chat', 'warn') + row('Action', 'Report early · Do not delete', 'ok') + note('Report early so the team can act.'), 'good')],
  ],
  pages: [
    hero(S(2), S(7), 'Approved tools only', 'made/own_mobile+made/own_policy_binder', [
      ['Work devices · 45% regular AI users · 67% of AI users used non-corporate accounts', S(3), 'v-coral'],
      ['Personal accounts can reduce institutional control', S(5), 'v-amber'],
      ['Never put applicant data in unapproved AI', S(6), 'v-coral'],
    ]),
    hero(S(7), S(10), 'Report early, without blame', 'made/own_bell+made/own_incident_binder', [
      ['Report the tool, account, time and affected file', S(7), 'v-teal'],
      ['Do not delete or try to fix it yourself', S(8), 'v-coral'],
      ['Early reports help us act and learn', S(9), 'v-teal'],
    ]),
    hero(S(10), S(14), 'Every approval is reviewed again', 'made/supplier_truck+made/own_calendar', [
      ['Third-party AI adds supply-chain risk', S(10), 'v-amber'],
      ['Updates and new uses change risk over time', S(12), 'v-navy'],
      ['Monitor AI systems throughout their life', S(13), 'v-teal'],
    ]),
  ],
}));
