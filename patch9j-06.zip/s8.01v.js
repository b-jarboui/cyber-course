// The files that will not open.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '8.1',
  actors: { maya: 'counter', omar: 'colleague', official: 'director', citizen: 'visitor' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'staff'], [S(3), 'gathering'], [S(4), 'her'], [S(10), 'gathering'], [S(13), 'counterDisplay'], [S(14), 'counter'], [S(15), 'her']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(3), 'listen', 'omar'], [S(3), S(4), 'listen', 'official'], [S(4), S(10), 'listen', 'omar'], [S(10), S(14), 'listen', 'official'], [S(14), S(15), 'talk', 'citizen'], [S(15), D.T, 'listen', 'omar']],
    omar: [[0, S(2), 'listen', 'maya'], [S(2), S(3), 'talk', 'maya'], [S(3), S(4), 'listen', 'official'], [S(4), S(10), 'talk', 'maya'], [S(10), D.T, 'listen', 'official']],
    official: [[0, S(3), 'listen', 'maya'], [S(3), S(4), 'call'], [S(4), S(10), 'listen', 'omar'], [S(10), S(14), 'talk', 'maya'], [S(14), D.T, 'listen', 'maya']],
    citizen: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'folder', 'Case 2048 · Scanned files', 'neutral'],
      [S(1), S(13), 'lock', 'Ransom note · Files locked', 'alert'],
      [S(13), D.T, 'shield', 'Device isolated · Response team leads', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048'],
    [S(1), E(1), 'Ransom note · Files locked'],
    [S(3), E(3), 'Hands off · IT called'],
    [S(13), E(13), 'Device isolated · Response team'],
  ],
  screens: [
    [S(0), S(1), win('Case 2048 · Scanned files', row('ID_scan.pdf', 'Will not open', 'no') + row('Application.pdf', 'Will not open', 'no') + note('Scanned documents will not open.', 'warn'), 'alert')],
    [S(1), S(3), win('READ_ME_NOW.txt', row('Files', 'Case2048_01.locked · Renamed', 'no') + row('Demand', 'Pay ransom to unlock files', 'no') + note('Do not click anything on this screen.', 'no'), 'alert')],
    [S(13), S(14), win('IT action · Counter computer', row('Network', 'Disconnected · Isolated', 'ok') + row('Handler', 'Incident response team', 'ok') + row('Ransom demand', 'No payment · No reply', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(6), 'Ransomware: files locked, payment demanded', 'made/ransom_laptop+made/own_money', [
      ['Encrypted files can disrupt services', S(4), 'v-coral'],
      ['Criminals demand payment to unlock them', S(5), 'v-amber'],
    ]),
    hero(S(6), S(10), 'Email is a leading way in', 'made/own_mail+made/own_key', [
      ['Sophos survey · Malicious email 26%, phishing 24%', S(7), 'v-coral'],
      ['Sophos survey · Compromised credentials 23%', S(8), 'v-amber'],
      ['Ransomware operators may damage backups', S(9), 'v-coral'],
    ]),
    hero(S(10), S(13), 'Ransomware is sold as a service', 'made/ransom_laptop+made/own_warning_beacon', [
      ['One group builds it, others rent it', S(10), 'v-navy'],
      ['Over 120 active brands counted in 2025', S(11), 'v-amber'],
      ['UAE · 58% more active ransomware groups in 2024', S(12), 'v-coral'],
    ]),
    hero(S(15), D.T, 'Stop. Do not pay. Report.', 'made/own_bell+made/own_shield', [
      ['Stop working; do not pay or reply', S(15), 'v-coral'],
      ['Report at once through the approved route', (S(15) + E(15)) / 2, 'v-teal'],
    ]),
  ],
}));
