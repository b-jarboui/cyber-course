import { AR, arabicPlate, tr } from './i18n.js';
import { restoreTeachingTable } from './v1-set.js';
// Where weaknesses occur. The story stays in the hall with the same people; each idea moves to a 2D page.
import { THREE, C, V, mesh, rbox, group, lerp, ramp, pulse } from './kit.js';
import { createPerson, loadMotion } from './people.js';
import { workplace, typing, counterTyping } from './sets.js';
import { frameShots, quietScreens } from './astra.js';
import { createBoard } from './board.js';
import { weaknessPages } from './pages2d-b.js';
import { readyPages, seekPages } from './library-pages.js';

export const texts = [];
export const cast = ['maya', 'comms', 'citizenYoung', 'priya', 'omar', 'lena'];

export default async function ({ stage, scene, b, createCounter, S, E, D, ui }) {
  await loadMotion(['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop', 'm_idle_neutral_01', 'm_idle_neutral_02', 'm_idle_neutral_03', 'm_idle_waiting_01', 'm_idle_look_around_01', 'm_sit_table_idle_neutral_01', 'm_sit_table_gestic_thoughtful', 'f_idle_neutral_01', 'f_idle_neutral_02', 'f_idle_waiting_01', 'f_idle_look_around_01',
    'f_walk_start', 'f_walk_neutral_01', 'f_walk_stop', 'f_turn_left_180', 'f_gestic_listen_deny_01', 'f_gestic_listen_accept_01']);
  document.getElementById('kicker').textContent = tr('Lesson 1.1 · Version 4');
  document.getElementById('cap').style.fontSize = '21px';
  createCounter(scene);
  await restoreTeachingTable(scene);
  const maya = createPerson('maya', scene), woman = createPerson('comms', scene), young = createPerson('citizenYoung', scene), rania = createPerson('priya', scene), omar = createPerson('omar', scene), lena = createPerson('lena', scene);

  // Omar's workstation, with the same monitor as the previous scene.
  const OX = 3.2, OZ = -2.5, OROT = -1.45, w2 = workplace(scene, OX, OZ, OROT);
  const SX = OX + w2.f.x * .95, SZ = OZ + w2.f.z * .95, monitor = group(scene, SX, .78, SZ); monitor.rotation.y = OROT + Math.PI;
  mesh(rbox(.6, .36, .03, .012), C.dark, 0, .3, 0, monitor);
  mesh(rbox(.05, .13, .05, .01), C.metalD, 0, .06, 0, monitor); mesh(rbox(.22, .012, .14, .005), C.metalD, 0, .006, 0, monitor);
  const glow = new THREE.MeshBasicMaterial({ color: '#e4edf7', toneMapped: false }), lit = new THREE.Mesh(new THREE.PlaneGeometry(.56, .32), glow);
  lit.position.set(0, .3, .017); monitor.add(lit);
  const calm = new THREE.Color('#e4edf7'), warn = new THREE.Color('#efc46c');

  // The unusual request is a real sheet, carried in both hands.
  const request = group(scene); request.rotation.order = 'YZX';
  mesh(rbox(.3, .0003, .21, .0001), C.paper, 0, 0, 0, request);
  for (const x of [.08, .04, 0, -.04, -.08]) mesh(rbox(.012, .00005, .16, .00002), C.powderD, x, .000175, 0, request);

  // Routes. Only recorded motion: arrive, wait, refuse, leave.
  // Clearances: Rania starts at (-3.82, 0.22) (>= 0.39 m clear of cabinets, ends 0.77 m clear of Maya);
  // Lena walks along the open staff aisle to (-3.60, -1.00) (>= 0.39 m clear of glass, >= 0.45 m of cabinets, 0.97 m beside Maya).
  const rot = -Math.PI / 2, walkM = ['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop'];
  const yRoute = young.planTo([...walkM, 'm_idle_neutral_03'], .5, -.3, rot, S(1) - 3.4);
  const yWait = young.plan(['m_idle_waiting_01', 'm_idle_look_around_01', 'm_idle_neutral_02', 'm_idle_neutral_03', 'm_idle_waiting_01'], .5, -.3, rot, yRoute.segs.at(-1).t0 + 4.0, .6, yRoute);
  const R0 = [-3.82, .22], r1 = rania.plan(['f_turn_left_180', 'f_walk_stop', 'f_idle_neutral_02', 'f_idle_waiting_01'], R0[0], R0[1], rot, S(0) + 3.6, .45, 'f_idle_neutral_02');
  const deny = maya.plan(['f_gestic_listen_deny_01', 'f_idle_neutral_01', 'f_idle_neutral_02', 'f_idle_waiting_01'], -2.8, -.45, 1.8, S(8) + .2, .4, 'f_idle_neutral_01');
  const r2 = rania.plan(['f_gestic_listen_accept_01', 'f_turn_left_180', 'f_walk_stop', 'f_idle_neutral_02', 'f_idle_waiting_01'], r1.end.x, r1.end.z, r1.yaw, deny.t0 + 2.2, .4, r1);
  const LZ = [-3.60, -1.00], lYaw = .25;
  const lRoute = lena.planTo(['f_walk_stop', 'f_idle_neutral_02'], LZ[0], LZ[1], lYaw, S(9) - 1.3);
  const lNod = lena.plan(['f_gestic_listen_accept_01', 'f_idle_neutral_02', 'f_idle_waiting_01', 'f_idle_neutral_01'], LZ[0], LZ[1], lYaw, S(9) + .8, .4, lRoute);
  const omarThink = omar.plan(['m_sit_table_gestic_thoughtful', 'm_sit_table_idle_neutral_01'], OX - w2.f.x * .1, OZ - w2.f.z * .1, OROT, S(2) + 1.2, .5, 'm_sit_table_idle_neutral_01');
  const omarThinkEnd = S(2) + 4.0;

  const mayaIdles = ['f_idle_neutral_01', 'f_idle_neutral_02', 'f_idle_waiting_01'];
  const womanIdles = ['f_idle_neutral_02', 'f_idle_waiting_01', 'f_idle_look_around_01', 'f_idle_neutral_01'];
  const playCycle = (p, list, t, span = 9.0, fade = 1.0) => {
    const ct = Math.max(0, t), idx = Math.floor(ct / span), rem = ct - idx * span;
    const cur = list[idx % list.length], prev = list[(idx + list.length - 1) % list.length];
    if (idx > 0 && rem < fade && cur !== prev) p.playBlend(prev, t, cur, t, rem / fade, true);
    else p.play(cur, t, true);
  };

  // ---------- 2D ----------
  const B = createBoard(D.T), { tl } = B;
  const say = (a, z, html, bottom = 170) => {
    const plate = document.createElement('div');
    plate.style.cssText = `position:absolute;left:16px;bottom:${bottom}px;padding:8px 14px;border-radius:12px;background:#fffdf8;color:#26305a;font:800 22px/1.2 "Segoe UI",Arial;box-shadow:0 4px 14px rgba(38,48,90,.18);opacity:0;pointer-events:none`;
    plate.innerHTML = tr(html);
    if (AR) arabicPlate(plate);
    document.getElementById('stage').after(plate);
    tl.fromTo(plate, { opacity: 0 }, { opacity: 1, duration: .3, immediateRender: false }, a);
    tl.to(plate, { opacity: 0, duration: .25 }, z);
  };
  say(S(0) + 1.9, E(0) + .1, 'People', 258);
  say(S(0) + 3.4, E(0) + .1, 'Technology', 214);
  say(S(0) + 4.6, E(0) + .1, 'Organization');
  say(S(1) + .2, E(1) + .2, 'Under pressure<br><span style="color:#c6543b">Unusual request</span>');
  say(S(2) + .2, S(3) - .7, 'Software weakness<br><span style="color:#c6543b">Unresolved</span>');
  say(deny.t0 + .1, E(8) + .1, 'Shaima<br><span style="color:#2f7477">Follows the process</span>');
  say(S(9) + .2, E(9) + .1, 'Lina, manager<br><span style="color:#2f7477">Makes it workable</span>');
  const open1 = S(3) - .5, close1 = S(8) - .5, open2 = S(10) - .4;
  weaknessPages({ B, S, E, D, open1, close1, open2 }); B.end(); await readyPages(B);

  // ---------- the 3D story ----------
  const screenAt = V(-2.1, 1.47, -.66), keys = V(-2.46, 1.111, -.45), keyR = keys.clone().add(V(0, .006, .1)), keyL = keys.clone().add(V(0, 0, -.1));
  const faceOf = (p, h = 1.5) => p.g.position.clone().setY(h), body = V(0, 0, 0), keyFocus = V(w2.keyL.x, .88, w2.keyL.z);
  const hall = { x: -1.75, y: 1.18, z: -.25, w: 3.0, e: .46, f: .45 };
  const counter = { x: -2.15, y: 1.20, z: -.32, w: 2.8, e: .44, f: .44 };
  const her = { x: -2.35, y: 1.28, z: -.42, w: 2.35, e: .42, f: .43 };
  const desk = { x: OX - .4, y: 1.12, z: OZ + .05, w: 2.2, e: .42, f: .44 };
  const deskClose = { x: OX - .45, y: 1.15, z: OZ + .02, w: 1.85, e: .40, f: .44 };
  const staff = { x: -3.15, y: 1.25, z: -.55, w: 2.65, e: .42, f: .44 };
  const cutTo = (x, shot) => ({ t0: x - .02, t1: x, ...shot });

  return t => {
    tl.time(t, false);
    seekPages(B, t);
    stage.conceptPage = (t >= open1 + .4 && t < close1) || t >= open2 + .4;
    quietScreens(ui, t);
    stage.focus = null;

    for (const p of [maya, woman, young, rania, omar]) p.g.visible = true;

    // Shaima works; she glances up when Rania comes, and refuses later.
    maya.reset(); maya.at(-2.8, -.45, 1.8); maya.idle(t, 2); maya.bend = .08;
    if (t < deny.t0) playCycle(maya, mayaIdles, t, 9.5, 1.0); else maya.follow(deny, t, true);
    const free = pulse(t, deny.t0 - .35, deny.t0 + .05, deny.t0 + 2.6, deny.t0 + 3.2);
    if (free > 0) { maya.ik.R = maya.ik.L = null; if (free < 1) { maya.reach('R', keyR, 1 - free); maya.reach('L', keyL, 1 - free); } }
    if (free < .001) counterTyping(maya, t, 1);
    const glance = pulse(t, S(1) + .6, S(1) + 1.1, E(1) - .6, E(1));
    maya.look(screenAt, 1); maya.look(faceOf(woman), glance); maya.look(faceOf(rania), free);
    const mayaGlance = pulse(t % 6.8, 4.4, 4.9, 5.8, 6.3) * (1 - free);
    if (mayaGlance > .01) maya.look(faceOf(woman), .55 * mayaGlance);
    maya.look(faceOf(lena), pulse(t, S(9) + .2, S(9) + .7, E(9), E(9) + .4));
    maya.smile = t > S(9) ? .3 : .08;

    // The queue: one waits at the counter (>= 0.37 m clear), another arrives.
    woman.reset(); woman.idle(t, 3); woman.at(-1.25, -.3, rot); playCycle(woman, womanIdles, t, 8.5, 1.0);
    young.reset(); young.idle(t, 4); young.g.visible = t >= yRoute.t0 - .1;
    if (t < yWait.t0) young.follow(yRoute, t, true); else young.follow(yWait, t, true);
    woman.smile = young.smile = .1; woman.look(V(-2.5, 1.5, -.5), .6); young.look(V(-2.5, 1.5, -.5), .5);
    const womanGlance = pulse(t % 8.4, 5.4, 6.0, 7.0, 7.6);
    if (womanGlance > .01) woman.look(screenAt, .4 * womanGlance);

    // Rania brings the request, waits, is refused and goes back with it.
    rania.reset(); rania.idle(t, 5); rania.smile = .15;
    if (t < r1.t0) rania.at(R0[0], R0[1], rot).play('f_idle_neutral_02', t, true); else if (t < r2.t0) rania.follow(r1, t, true); else rania.follow(r2, t, true);
    rania.flush(); rania.b.Bip01.getWorldPosition(body);
    const yaw = rania.g.rotation.y;
    request.position.copy(body).add(V(Math.sin(yaw) * .25, 0, Math.cos(yaw) * .25)).setY(1.07 + .006 * Math.sin(t * 1.4));
    request.rotation.set(0, yaw - Math.PI / 2, .5); request.updateMatrixWorld(true);
    rania.look(request.position, .7);
    rania.look(faceOf(maya), pulse(t, r1.t0 + 2.2, r1.t0 + 2.9, r2.t0 + 1.2, r2.t0 + 1.8));
    rania.grasp('L', request, V(-.145, 0, -.095), V(1, 0, 0), 1);
    rania.grasp('R', request, V(-.145, 0, .095), V(1, 0, 0), 1);

    // Omar's screen shows that something is waiting to be fixed.
    const alert = ramp(t, S(2) + .2, S(2) + .9), reading = ramp(t, S(2) + .5, S(2) + 1.2);
    omar.reset(); omar.at(OX - w2.f.x * .1, OZ - w2.f.z * .1, OROT); omar.idle(t, 2);
    omar.bend = .035 + .02 * Math.sin(t * .42);
    const chin = pulse(t, omarThink.t0, omarThink.t0 + .6, omarThinkEnd - .7, omarThinkEnd);
    if (t >= omarThink.t0 && t < omarThinkEnd) omar.follow(omarThink, t, true); else omar.play('m_sit_table_idle_neutral_01', t, true);
    typing(omar, w2, t, 1 - reading); if (reading > 0 && chin < 1) { omar.reach('R', w2.keyR, reading * (1 - chin)); omar.reach('L', w2.keyL, reading * (1 - chin)); }
    omar.gaze = .1; omar.smile = .06; omar.look(V(SX, 1.08, SZ), 1);
    const omarGlance = .26 * (.5 + .5 * Math.sin(t * .55 + .6));
    if (omarGlance > .02) omar.look(keyFocus, omarGlance);
    glow.color.copy(calm).lerp(warn, alert);

    // Lina, the manager, comes to Shaima along the open staff aisle and agrees.
    lena.reset(); lena.idle(t, 6); lena.smile = .25; lena.g.visible = t >= lRoute.t0 - .1;
    if (t < lRoute.t0) { const start = lRoute.segs[0]; lena.at(start.x, start.z, start.yaw).play('f_idle_neutral_02', t, true); }
    else if (t < lNod.t0) lena.follow(lRoute, t, true); else lena.follow(lNod, t, true);
    lena.look(faceOf(maya), ramp(t, S(9) - .6, S(9)));

    for (const p of [maya, woman, young, rania, omar, lena]) p.g.visible = p.g.visible && !stage.conceptPage;
    request.visible = !stage.conceptPage;
    stage.outage = .1 * pulse(t, S(1), S(1) + 1, E(1), S(2));
    frameShots(stage, t, [
      hall,
      { t0: S(1) - 1.2, t1: S(1) + .4, ...counter },
      cutTo(S(2), desk),
      cutTo(S(4), counter),
      cutTo(S(5), deskClose),
      cutTo(S(6), her),
      cutTo(S(7), desk),
      cutTo(close1 + .3, staff),
      cutTo(S(10), counter),
    ]);
  };
}
