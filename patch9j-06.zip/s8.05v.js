// Report early to limit damage.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['helpdesk', 'official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '8.1',
  actors: { helpdesk: 'visitor', official: 'director', maya: 'counter', omar: 'colleague' },
  leave: { helpdesk: S(4) },
  file: [[0, S(14), 0, 0], [S(14), E(14), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'gathering'], [S(4), 'staff'], [S(9), 'her'], [S(11), 'gathering'], [S(14), 'file']],
  actions: {
    helpdesk: [[0, S(2), 'talk', 'maya'], [S(2), S(4), 'listen', 'official']],
    official: [[0, S(2), 'listen', 'helpdesk'], [S(2), S(4), 'paper'], [S(4), S(10), 'talk', 'maya'], [S(10), S(11), 'listen', 'omar'], [S(11), S(14), 'paper'], [S(14), D.T, 'listen', 'maya']],
    maya: [[0, S(2), 'read'], [S(2), S(10), 'listen', 'official'], [S(10), S(11), 'listen', 'omar'], [S(11), S(14), 'listen', 'official'], [S(14), D.T, 'file']],
    omar: [[0, S(2), 'listen', 'helpdesk'], [S(2), S(10), 'listen', 'official'], [S(10), S(11), 'talk', 'maya'], [S(11), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(1), 'computer', 'Cleaned computer returned', 'safe'],
      [S(1), S(14), 'tick', 'Case 2048 · Restored from backup', 'safe'],
      [S(14), D.T, 'folder', 'Case 2048 · Back in service', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Cleaned computer returned'],
    [S(2), E(2), 'One-page printed checklist'],
    [S(11), E(11), 'Stop · Do not pay · Report'],
    [S(14), E(14), 'Case 2048 · Back in service'],
  ],
  screens: [
    [S(0), S(2), win('Case 2048 · Restored', row('Counter computer', 'Cleaned and checked by IT', 'ok') + row('Documents', 'Restored from offline backup', 'ok') + note('Backup stayed unreachable during attack.', ''), 'good')],
    [S(2), S(3), win('Printed response checklist', row('1. Stop', 'Hands off keyboard and mouse', 'ok') + row('2. Do not pay', 'Do not reply or negotiate', 'ok') + row('3. Report', 'Call IT via approved route', 'ok'), 'good')],
    [S(14), E(14), win('Case 2048 · Back in service', row('Scanned files', 'Open and readable', 'ok') + row('Impact', 'Counter computer isolated', 'ok') + note('Early reporting kept the attack small.', ''), 'good')],
  ],
  pages: [
    hero(S(3), S(4), 'Stop using the device and report at once', 'made/network_switch+made/own_bell', [
      ['Early isolation helped limit further damage', S(3), 'v-teal'],
    ]),
    hero(S(4), S(9), 'Offline, tested backups', 'made/own_backup_drive+made/safe', [
      ['Keep backups encrypted and off the network', S(4), 'v-teal'],
      ['Sophos 2026 · 66% of encrypted-data victims used backups to restore data', S(7), 'v-navy'],
    ]),
    hero(S(9), S(11), 'Paying does not guarantee recovery', 'made/own_money+made/ransom_laptop', [
      ['Average recovery cost: $1.7M without ransom', S(9), 'v-amber'],
      ['Payment gives no promise; theft stays stolen', S(10), 'v-coral'],
    ]),
    hero(S(11), S(14), 'Keep a printed response plan', 'made/own_incident_binder+made/own_printer', [
      ['Stop, leave device on unless told, report', S(11), 'v-teal'],
      ['Save work only in approved locations', S(13), 'v-navy'],
    ]),
  ],
}));
