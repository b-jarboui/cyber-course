// A familiar face is not proof.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '10.3',
  set: [[0, (S(13) + E(13)) / 2, 'hall'], [(S(13) + E(13)) / 2, S(14), 'office'], [S(14), D.T, 'hall']],
  actorSets: { maya: 'hall', omar: 'hall', official: 'office' },
  actors: { maya: 'counter', omar: 'colleague', official: 'desk' },
  file: [[0, D.T, 0, 0]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(3), 'staff'], [S(4), 'her'], [S(11), 'counter'], [S(13), 'her'], [(S(13) + E(13)) / 2, 'desk'], [S(14), 'counterDisplay']],
  actions: {
    maya: [[0, S(13), 'read'], [S(13), S(14), 'extension'], [S(14), D.T, 'type']],
    omar: [[0, D.T, 'listen', 'maya']],
    official: [[0, S(13), 'read'], [S(13), S(14), 'extension'], [S(14), D.T, 'read']],
  },
  displays: {
    counter: [
      [0, S(3), 'computer', 'Video call · Looks like director', 'alert'],
      [S(3), S(13), 'lock', 'Send Case 2048 · Tell no one', 'alert'],
      [S(13), S(14), 'shield', 'Call ended · Calling known number', 'safe'],
      [S(14), D.T, 'bell', 'Fake call reported · IR team', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Video call · Looks like director'],
    [S(2), E(2), 'Send Case 2048 · Tell no one'],
    [S(13), E(13), 'Verified on known internal number'],
    [S(14), E(14), 'Not sent · Reported to IR team'],
  ],
  screens: [
    [S(0), S(2), win('Incoming video call', row('Caller', 'Looks like Department Director', 'warn') + row('Voice & face', 'Familiar · Unverified', 'warn') + note('Unexpected call at the service desk.', 'warn'), 'alert')],
    [S(2), S(4), win('Video call · Request', row('Request', 'Send Case 2048 immediately', 'no') + row('New address', 'dir-urgent@outside-mail.example', 'no') + row('Condition', 'Tell no one', 'no') + note('Urgency, secrecy and a new address.', 'no'), 'alert')],
    [S(13), S(14), win('Internal directory · Verified', row('Department Director', 'Known internal Ext. 4105', 'ok') + row('Director reply', 'Did not make that call', 'ok') + row('Case 2048', 'Not sent · Call reported', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(8), 'AI speeds up attacks', 'made/robot_arm+made/own_warning_beacon', [
      ['Attackers use AI to work faster at scale', S(4), 'v-amber'],
      ['Autonomous tools run multi-step attacks', S(5), 'v-coral'],
      ['AI malware requests new code as it runs', S(6), 'v-coral'],
    ]),
    hero(S(8), S(11), 'A familiar face or voice is not proof', 'made/own_webcam+made/headset', [
      ['AI can imitate a face or voice from online media', S(8), 'v-amber'],
      ['FBI 2025 · 22,364 complaints involving AI · Nearly $893m in reported losses', S(9), 'v-coral'],
      ['Fake profiles, voice clones and videos', S(10), 'v-navy'],
    ]),
    hero(S(11), S(13), 'Urgency and secrecy are warning signs', 'made/own_clock+made/own_warning_beacon', [
      ['A familiar face or voice is not proof', S(11), 'v-coral'],
      ['Urgency, secrecy and new routes warn you', S(12), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Verify on a known number', 'made/own_desk_phone+made/own_bell', [
      ['Hang up and call the known internal number', S(14), 'v-teal'],
      ['Do not send, report', (S(14) + E(14)) / 2, 'v-teal'],
    ]),
  ],
}));
