// Tested, listed, approved, supervised.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '10.2',
  actors: { maya: 'desk', omar: 'beside' },
  shots: [[0, 'pair'], [S(1), 'display'], [S(6), 'pair'], [S(9), 'desk'], [S(12), 'display'], [S(13), 'pair']],
  actions: {
    omar: [[0, S(6), 'paper'], [S(6), S(9), 'talk', 'maya'], [S(9), D.T, 'listen', 'maya']],
    maya: [[0, S(6), 'listen', 'omar'], [S(6), S(9), 'paper'], [S(9), S(12), 'read'], [S(12), S(14), 'type'], [S(14), D.T, 'talk', 'omar']],
  },
  displays: {
    desk: [
      [0, S(6), 'file', 'Approved AI tools list', 'neutral'],
      [S(6), S(12), 'chat', 'AI draft · Date needs check', 'alert'],
      [S(12), D.T, 'tick', 'Wrong date fixed by Shaima', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Approved AI tools list'],
    [S(12), E(12), 'AI draft checked · Wrong date fixed'],
  ],
  screens: [
    [S(0), S(1), win('Approved AI tools list', row('Sadeed AI Assistant', 'Approved · Tested', 'ok') + row('Allowed tasks', 'Drafting & summaries', 'ok') + row('Allowed data', 'Applicant records · Authorised casework only', 'hi'), 'good')],
    [S(12), S(14), win('AI draft check · Case 2048', row('AI draft date', '14 March (Wrong)', 'no') + row('Case 2048 file', '24 March · Corrected', 'ok') + row('Decision owner', 'Shaima · Within authorization', 'ok'), 'good')],
  ],
  pages: [
    hero(S(1), S(6), 'Tested before use', 'made/own_zoom+made/robot_arm', [
      ['Pre-use security assessment process · 37% to 64% of respondents', S(2), 'v-teal'],
      ['87%: AI flaws are fastest-growing risk', S(3), 'v-coral'],
      ['Test how the tool handles instructions in files', S(4), 'v-amber'],
    ]),
    hero(S(6), S(9), 'On the approved list', 'made/register_book+made/rubber_stamp', [
      ['Accurate AI inventory required by policy', S(6), 'v-navy'],
      ['Inventory gaps make protection and monitoring harder', S(7), 'v-coral'],
      ['Approval states permitted tasks and data', S(8), 'v-teal'],
    ]),
    hero(S(9), S(12), 'A person decides', 'made/own_signed_document+made/laptop', [
      ['Approval never replaces human judgement', S(9), 'v-navy'],
      ['An authorised employee decides the application', S(10), 'v-teal'],
      ['AI draft is a suggestion until checked', S(11), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Listed, checked, reported', 'made/own_tick+made/own_bell', [
      ['Use listed tools and check every output', S(14), 'v-teal'],
      ['Report strange output via approved route', (S(14) + E(14)) / 2, 'v-navy'],
    ]),
  ],
}));
