// Trust between machines needs proof.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '10.3',
  actors: { maya: 'desk', omar: 'beside' },
  landline: 'desk',
  shots: [[0, 'display'], [S(1), 'pair'], [S(2), 'desk'], [S(6), 'pair'], [S(7), 'display'], [S(8), 'desk'], [S(12), 'pair']],
  actions: {
    maya: [[0, S(1), 'read'], [S(1), S(2), 'talk', 'omar'], [S(2), S(6), 'read'], [S(6), S(7), 'extension'], [S(7), S(8), 'type'], [S(8), D.T, 'read']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(2), 'talk', 'maya'], [S(2), D.T, 'listen', 'maya']],
  },
  displays: {
    desk: [
      [0, S(6), 'lock', 'AI agent · Requests case access', 'alert'],
      [S(6), S(7), 'shield', 'Not approved · Calling owner', 'neutral'],
      [S(7), S(12), 'bell', 'Unauthorised access request reported', 'safe'],
      [S(12), D.T, 'key', 'Post-quantum encryption renewal', 'neutral'],
    ],
  },
  plates: [
    [S(0), E(0), 'Unrecognised AI agent · Access request'],
    [S(6), E(6), 'Owner called on known number'],
    [S(7), E(7), 'Access not authorised · Response team notified'],
  ],
  screens: [
    [S(0), S(2), win('Access approval · AI agent', row('Agent name', 'Records-Assistant-New', 'warn') + row('Requests', 'Access to all case records', 'no') + row('Status', 'Waiting for approval', 'wait') + note('Name looks familiar — check first.', 'warn'), 'alert')],
    [S(6), S(8), win('Owner check · Reported', row('Agent owner', 'Known internal Ext. 4118', 'ok') + row('Owner reply', 'No agent authorised to request all records', 'no') + row('Action', 'Not approved · Reported to IR', 'ok'), 'good')],
  ],
  pages: [
    hero(S(2), S(6), 'A name on a screen is not proof', 'made/robot_arm+made/id_badge', [
      ['Machines and agents request access directly', S(2), 'v-navy'],
      ['Strong identity and least privilege needed', S(4), 'v-teal'],
      ['Verifiable ID and temporary task access', S(5), 'v-teal'],
    ]),
    hero(S(8), S(12), "Essential-service automation needs human oversight", 'made/control_desk+made/own_shield', [
      ['Check with the owner on a known contact', S(8), 'v-teal'],
      ['Human oversight, monitoring and failsafes', S(10), 'v-navy'],
      ['Unexpected result? Stop using it, record the facts and report', S(11), 'v-coral'],
    ]),
    hero(S(12), D.T, 'Some encryption needs a planned move to quantum-resistant methods', 'made/own_lock+made/own_calendar', [
      ['Data taken now could be opened later', S(13), 'v-amber'],
      ['UK targets · Plan by 2028 · Priority moves by 2031 · Complete by 2035', S(14), 'v-navy'],
      ['Saudi cryptographic standards · UAE centre supports transition', S(15), 'v-teal'],
    ]),
  ],
}));
