// A convincing email with a fake sign-in page.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note, mail } from './screens-tr.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '8.1',
  actors: { official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 0, 0]],
  shots: [[0, 'gathering'], [S(1), 'staff'], [S(2), 'counterDisplay'], [S(3), 'her'], [S(7), 'gathering'], [S(10), 'her'], [S(12), 'counterDisplay'], [S(13), 'staff']],
  actions: {
    official: [[0, S(3), 'paper'], [S(3), S(7), 'listen', 'omar'], [S(7), S(10), 'talk', 'maya'], [S(10), D.T, 'paper']],
    maya: [[0, S(3), 'listen', 'official'], [S(3), S(7), 'listen', 'omar'], [S(7), S(10), 'listen', 'official'], [S(10), S(12), 'read'], [S(12), D.T, 'type']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), S(7), 'talk', 'maya'], [S(7), S(12), 'listen', 'official'], [S(12), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'mail', 'Printed email · Evidence', 'neutral', 'inbox'],
      [S(2), S(12), 'lock', 'Fake sign-in page · Password taken', 'alert', 'login'],
      [S(12), D.T, 'computer', 'Known address · Safe sign-in', 'safe', 'login'],
    ],
  },
  plates: [
    [S(0), E(0), 'Printed email · Evidence'],
    [S(2), E(2), 'Link led to fake sign-in'],
    [S(10), E(10), 'Check the request, not the tone'],
    [S(12), E(12), 'Known address · Safe sign-in'],
  ],
  screens: [
    [S(0), S(2), win('Evidence · Printed email', mail('Partner Coordination', 'meetings@partner-gov-docs.example', 'Updated agenda for Thursday meeting', 'Please sign in to view Thursday meeting pack.'), 'alert')],
    [S(2), S(3), win('signin.partner-gov-docs.example', row('Web address', 'partner-gov-docs.example', 'no') + row('Password', 'Entered on fake page', 'no') + note('Polished email led to a fake sign-in.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(3), S(7), 'AI lowers the skill criminals need', 'made/own_computer+made/own_mail', [
      ['AI writes convincing messages much faster', S(3), 'v-amber'],
      ['Criminals use AI to build attack tools', S(5), 'v-coral'],
    ]),
    hero(S(7), S(10), 'Good writing proves nothing', 'made/own_file+made/own_zoom', [
      ['Stay calm; separate real threats from hype', S(7), 'v-navy'],
      ['Polished language and logos prove nothing', S(9), 'v-amber'],
    ]),
    hero(S(10), S(12), 'Check the request, not the style', 'made/own_link+made/own_warning_beacon', [
      ['Polished writing and logos do not verify the sender', S(10), 'v-navy'],
      ['Verify unexpected sign-in, file or payment requests independently', S(11), 'v-coral'],
    ]),
    hero(S(12), D.T, 'Verify through a known contact', 'made/own_desk_phone+made/own_bell', [
      ['Sign in only from the address you know', S(12), 'v-teal'],
      ['Verify unexpected requests and report them', S(13), 'v-teal'],
    ]),
  ],
}));
