// AI has owners and risk levels.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '10.2',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 0, 0]],
  shots: [[0, 'counter'], [S(1), 'file'], [S(2), 'counterDisplay'], [S(7), 'her'], [S(13), 'staff']],
  actions: {
    maya: [[0, S(1), 'listen', 'omar'], [S(1), S(2), 'talk', 'omar'], [S(2), S(13), 'file'], [S(13), D.T, 'read']],
    omar: [[0, S(1), 'talk', 'maya'], [S(1), S(2), 'listen', 'maya'], [S(2), S(7), 'read'], [S(7), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'chat', 'AI summariser · Approval not yet checked', 'alert'],
      [S(2), S(13), 'shield', 'AI governance · Risk levels', 'neutral'],
      [S(13), D.T, 'tick', 'Check approval before use', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'AI tool suggested · Case 2048'],
    [S(1), E(1), 'File kept closed · Who owns it?'],
    [S(13), E(13), 'Check approval before use'],
  ],
  screens: [
    [S(0), S(1), win('quick-summary.example', row('Tool', 'Online AI summariser', 'warn') + row('Suggested task', 'Summarise Case 2048', 'warn') + row('Approval', 'Not checked', 'no'), 'alert')],
    [S(1), S(2), win('Before entering Case 2048', row('Case file 2048', 'Kept closed', 'ok') + row('Tool owner', 'Unknown', 'no') + row('Data type', 'Applicant personal data', 'warn') + note('Check who owns and approves the tool.', 'warn'))],
  ],
  pages: [
    hero(S(2), S(7), 'Same governance, new technology', 'made/robot_arm+made/own_policy_binder', [
      ['AI needs rules, owners and accountability', S(2), 'v-navy'],
      ['UAE national policy · Saudi consultation draft', S(3), 'v-teal'],
      ['Institution stays responsible for services', S(6), 'v-navy'],
    ]),
    hero(S(7), S(13), 'Risk depends on the use', 'made/traffic_light+made/balance_scale', [
      ['Saudi AI principles · Minimal, limited, high or unacceptable risk', S(9), 'v-amber'],
      ['High-risk AI assessed before and after use', S(10), 'v-navy'],
      ['Public notice ≠ applicant personal data', S(11), 'v-coral'],
    ]),
    hero(S(13), D.T, 'Check approval before use', 'made/own_shield+made/case_folder', [
      ['Confirm approval for the task and data', S(13), 'v-teal'],
      ['Unsure? Ask before entering any data', S(14), 'v-amber'],
    ]),
  ],
}));
