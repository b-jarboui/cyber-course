// Agents act, so agents need limits.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '10.2',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, D.T, 0, 0]],
  landline: true,
  shots: [[0, 'counter'], [S(1), 'staff'], [S(2), 'her'], [S(9), 'counter'], [S(12), 'counterDisplay'], [S(13), 'her'], [S(14), 'staff']],
  actions: {
    maya: [[0, S(1), 'read'], [S(1), S(2), 'talk', 'omar'], [S(2), S(12), 'read'], [S(12), S(13), 'check'], [S(13), S(14), 'read'], [S(14), D.T, 'extension']],
    omar: [[0, S(1), 'listen', 'maya'], [S(1), S(2), 'talk', 'maya'], [S(2), S(12), 'paper'], [S(12), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(12), 'calendar', 'AI agent · Appointment reminders', 'neutral'],
      [S(12), S(13), 'mail', 'Wrong applicant case number', 'alert'],
      [S(13), S(14), 'lock', 'Shaima stopped using the agent', 'alert'],
      [S(14), D.T, 'bell', 'Reported · IR team decides', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'AI agent · Appointment reminders'],
    [S(12), E(12), 'Wrong applicant case number'],
    [S(13), E(13), 'Use stopped · Response team notified'],
  ],
  screens: [
    [S(0), S(2), win('AI agent · Hall reminders', row('Main task', 'Send appointment reminders', 'ok') + row('Extra power', 'Update case records?', 'warn') + row('Allowed limits', 'Check agent scope first', 'hi'))],
    [S(12), S(13), win('Agent activity log · Reminder', row('Recipient', 'Applicant · Case 2048', 'hi') + row('Case number shown', 'Case 2091 (Wrong applicant)', 'no') + note('Wrong applicant details in reminder.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(2), S(9), 'Low-risk task · Only the access it needs', 'made/robot_arm+made/own_key', [
      ['Agents plan steps and act on their own', S(3), 'v-navy'],
      ['Start with low-risk, well-defined tasks', S(6), 'v-teal'],
      ['Least privilege and a separate agent ID', S(7), 'v-teal'],
    ]),
    hero(S(9), S(12), 'Approval for high-impact actions', 'made/own_signed_document+made/id_badge', [
      ['High-impact steps need human approval', S(9), 'v-teal'],
      ['Hidden text in files can steer an agent', S(10), 'v-coral'],
      ['Every agent needs a named owner', S(11), 'v-navy'],
    ]),
    hero(S(13), D.T, 'Stop using the agent and report', 'made/own_warning_beacon+made/own_bell', [
      ['Stop using the agent · Leave fixes and testing to the team', S(13), 'v-coral'],
      ['Report the time, intended case and number shown', S(14), 'v-teal'],
      ['Authorized IR team decides next steps', (S(14) + E(14)) / 2, 'v-navy'],
    ]),
  ],
}));
