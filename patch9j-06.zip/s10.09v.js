// New tricks, same habit: verify first.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, phone, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '10.3',
  actors: { maya: 'counter', omar: 'desk' },
  file: [[0, D.T, 0, 0]],
  landline: true,
  shots: [[0, 'her'], [S(1), 'desk'], [S(2), 'counter'], [S(9), 'her'], [S(10), 'counterDisplay'], [S(11), 'display'], [S(12), 'desk'], [S(14), 'display'], [S(15), 'desk']],
  actions: {
    maya: [[0, S(9), 'text'], [S(9), S(10), 'extension'], [S(10), S(11), 'type'], [S(11), D.T, 'read']],
    omar: [[0, S(14), 'read'], [S(14), S(15), 'type'], [S(15), D.T, 'talk', 'maya']],
  },
  handsets: {
    maya: [
      [0, S(9), 'mail'],
      [S(9), D.T, 'shield'],
    ],
  },
  displays: {
    counter: [
      [0, S(9), 'mobile', 'SMS · Account lock link', 'alert'],
      [S(9), S(10), 'shield', 'Official portal · IT desk called', 'safe'],
      [S(10), D.T, 'bell', 'Fake text reported', 'safe'],
    ],
    desk: [
      [0, S(11), 'file', 'AI summary · Case 2048 upload', 'neutral'],
      [S(11), S(14), 'mail', 'Visible line in summary · Send records outside', 'alert'],
      [S(14), D.T, 'bell', 'Unverified summary reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Work phone SMS · Account lock link'],
    [S(1), E(1), 'AI summary · Uploaded document'],
    [S(9), E(9), 'Link ignored · IT desk called'],
    [S(11), E(11), 'Summary asks to send records outside'],
  ],
  screens: [
    [S(0), S(1), phone('Work phone · Text', row('Sender', '+971 50 000 0841', 'no') + row('Message', 'Account locks today — tap link', 'no') + row('Link', 'sadeed-unlock.example/id', 'no') + note('Urgent account lock warning.', 'no'))],
    [S(9), S(11), win('IT Service Desk · Verified', row('Official portal', 'portal.sadeed.gov.example', 'ok') + row('IT desk · Ext. 4100', 'Sent no text message', 'ok') + row('Text link', 'Not tapped · Reported', 'ok'), 'good')],
    [S(11), S(12), win('AI summary · Uploaded file', row('Summary', 'Case 2048 applicant details', 'hi') + row('Final line', 'Send records to outside address', 'no') + row('Destination', 'drop@outside-mail.example', 'no') + note('Hidden instruction in uploaded file.', 'no'), 'alert')],
  ],
  pages: [
    hero(S(2), S(9), 'Texts and calls are attack routes too', 'made/own_mobile+made/fishing_hook', [
      ['41% of studied social-engineering breaches used a channel beyond email', S(5), 'v-amber'],
      ['ENISA · Phishing began about 60% of observed intrusions', S(6), 'v-coral'],
      ['Worldwide estimate · AI-assisted phishing exceeded 80% of observed social engineering', S(7), 'v-coral'],
    ]),
    hero(S(12), S(14), 'Content an AI reads is not verified', 'made/own_file+made/robot_arm', [
      ['Hidden text in files can steer AI tools', S(12), 'v-coral'],
      ['Top AI app risk; text may be invisible', S(13), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Verify, do not act, report', 'made/own_shield+made/own_bell', [
      ['Do not tap links or follow odd AI lines', S(14), 'v-coral'],
      ['Verify via official portal or known number', (S(14) + E(14)) / 2, 'v-teal'],
      ['Report through the approved route · Name the file and tool', S(15), 'v-teal'],
    ]),
  ],
}));
