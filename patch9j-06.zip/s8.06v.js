// The systems and partners a counter service needs.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, reveal } from './screens-tr.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official', 'citizen', 'citizenYoung'];
export default chapterHall((S, E, D) => ({
  lesson: '8.2',
  whiteboard: { title: 'Case 2048 links', items: ['Portal & Digital ID', 'Payment service', 'Scanning supplier', 'Authority network'] },
  actors: { maya: 'counter', omar: 'colleague', official: 'director', citizen: 'visitor', citizenYoung: 'teamEnd' },
  file: [[0, D.T, 1, 1]],
  shots: [[0, 'queue'], [S(1), 'counterDisplay'], [S(2), 'gathering'], [S(4), 'staff'], [S(6), 'hall'], [S(9), 'gathering'], [S(12), 'counterDisplay'], [S(13), 'counter']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(4), 'listen', 'official'], [S(4), S(9), 'listen', 'omar'], [S(9), S(12), 'listen', 'official'], [S(12), S(13), 'type'], [S(13), D.T, 'read']],
    omar: [[0, S(2), 'listen', 'maya'], [S(2), S(4), 'listen', 'official'], [S(4), S(9), 'talk', 'maya'], [S(9), D.T, 'listen', 'official']],
    official: [[0, S(2), 'listen', 'maya'], [S(2), S(4), 'talk', 'maya'], [S(4), S(9), 'listen', 'omar'], [S(9), S(12), 'talk', 'maya'], [S(12), D.T, 'listen', 'maya']],
    citizen: [[0, D.T, 'listen', 'maya']],
    citizenYoung: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'clock', 'Appointment screen frozen', 'alert'],
      [S(1), S(12), 'folder', 'Case 2048 · Service unreachable', 'alert'],
      [S(12), D.T, 'bell', 'Frozen screen reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Appointment screen frozen'],
    [S(3), E(3), 'Five dependencies of the counter service'],
    [S(12), E(12), 'Frozen screen reported'],
    [S(13), E(13), 'Know your service dependencies'],
  ],
  screens: [
    [S(0), S(2), win('Counter system · Case 2048', row('Counter laptop', 'Working normally', 'ok') + row('Appointment screen', 'Frozen · Not responding', 'no') + row('Case 2048', 'Cannot open · Unreachable', 'no'), 'alert')],
    [S(2), S(4), q => win('Whiteboard · Counter service dependencies', reveal([
      row('Portal & sign-in', 'Public portal · Digital ID', 'hi'),
      row('Payments', 'Payment service', 'hi'),
      row('External partner', 'Scanning supplier', 'warn'),
      row('Connection', 'Authority network', 'hi'),
    ], q))],
    [S(12), S(13), win('Service report · Counter', row('Issue', 'Appointment screen frozen', 'warn') + row('Cause guessed', 'No — facts only', 'ok') + row('Submitted via', 'Approved reporting route', 'ok'), 'good')],
  ],
  pages: [
    hero(S(4), S(6), 'Every service has dependencies', 'made/own_whiteboard+made/network_switch', [
      ['Portal, identity, payment, supplier, network', S(4), 'v-navy'],
      ['One unavailable provider can interrupt service', S(5), 'v-coral'],
    ]),
    hero(S(6), S(9), 'Public administration: most targeted in the EU', 'made/queue_display+made/server_rack', [
      ['Public administration · About 38% of incidents ENISA analysed', S(7), 'v-coral'],
      ['UAE top targets: government, finance, energy', S(8), 'v-amber'],
    ]),
    hero(S(9), S(12), "A supplier's incident can stop our service", 'made/supplier_truck+made/own_link', [
      ['Provider ransomware forced manual check-in', S(10), 'v-amber'],
      ['Verizon 2026 · Third parties in 48% of breaches with relevant data', S(11), 'v-coral'],
    ]),
    hero(S(13), D.T, 'Know your service’s approved alternative procedure', 'made/own_policy_binder+made/own_bell', [
      ['Know dependencies and report failures early', S(13), 'v-teal'],
      ['Follow the approved alternative procedure', (S(13) + E(13)) / 2, 'v-navy'],
    ]),
  ],
}));
