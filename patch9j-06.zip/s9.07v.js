// Mistakes and shortcuts are reported too.
import { chapterHall, hero } from './chapter2-hall.js';
import { win, row, note } from './screens-tr.js';

export const texts = [];
export const cast = ['omar', 'official', 'maya', 'citizenYoung'];
export default chapterHall((S, E, D) => ({
  lesson: '9.2',
  actors: { omar: 'desk', official: 'beside', maya: 'counter', citizenYoung: 'colleague' },
  file: [[0, D.T, 1, 1]],
  landline: 'desk',
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(5), 'pair'], [S(8), 'counterDisplay'], [S(9), 'staff'], [S(12), 'pair'], [S(14), 'staff']],
  actions: {
    omar: [[0, S(3), 'read'], [S(3), S(6), 'extension'], [S(6), S(12), 'paper'], [S(12), D.T, 'listen', 'official']],
    official: [[0, S(12), 'listen', 'omar'], [S(12), D.T, 'extension']],
    maya: [[0, S(8), 'listen', 'citizenYoung'], [S(8), S(10), 'read'], [S(10), S(12), 'talk', 'citizenYoung'], [S(12), D.T, 'listen', 'citizenYoung']],
    citizenYoung: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    desk: [
      [0, S(1), 'mail', 'Sent mail · Case 2048', 'neutral', 'inbox'],
      [S(1), S(3), 'mail', 'Sent to wrong outside address', 'alert', 'inbox'],
      [S(3), D.T, 'bell', 'Accidental breach reported', 'safe'],
    ],
    counter: [
      [0, S(8), 'folder', 'Case 2048 · Summary', 'neutral'],
      [S(8), S(10), 'computer', 'Unapproved AI site · Case text', 'alert'],
      [S(10), D.T, 'bell', 'Unapproved AI use reported', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Wrong outside recipient'],
    [S(3), E(3), 'Reported straight away'],
    [S(8), E(8), 'Unapproved AI website'],
    [S(12), E(12), 'Clear roles · Response plan'],
  ],
  screens: [
    [S(1), S(2), win('Sent mail', row('To', 'm.salem@outside-mail.example', 'no') + row('Attachment', 'Case2048_page2.pdf', 'warn') + row('Status', 'Sent to wrong outside address', 'no') + note('Accidental breach · Report immediately.', 'no'), 'alert')],
    [S(8), S(9), win('quick-ai-helper.example', row('Prompt', 'Case 2048 text pasted in', 'no') + row('Approved list', 'Not approved by Authority', 'no') + note('Unapproved AI website · Stop and report.', 'warn'), 'alert')],
  ],
  pages: [
    hero(S(2), S(8), 'Wrong recipient? Report at once', 'made/own_mail+made/own_clock', [
      ['Accidental disclosure of personal data can be a breach', S(2), 'v-coral'],
      ['Record who, when and what; do not hide it', S(4), 'v-navy'],
      ['Saudi qualifying breach · 72 hours from controller awareness', S(6), 'v-amber'],
    ]),
    hero(S(9), S(12), 'Unapproved AI tool = report it', 'made/own_computer+made/own_warning_beacon', [
      ['SANS survey · 71% worried about sensitive data entered into generative AI', S(9), 'v-amber'],
      ['Ask the colleague to stop · Report without blame', S(10), 'v-teal'],
      ['Report unauthorized AI agent actions too', S(11), 'v-coral'],
    ]),
    hero(S(12), D.T, 'Staff · Response team · Management', 'made/own_policy_binder+made/own_shield', [
      ['Staff report; team checks; leaders decide', S(12), 'v-navy'],
      ['Plans set roles and channels in advance', S(13), 'v-teal'],
      ['An honest early report protects everyone', S(14), 'v-teal'],
    ]),
  ],
}));
