// 1.15 AI can help the defenders: Omar checks an AI summary against the evidence, and Shaima adds what monitoring missed.
import { V, pulse } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, cols, btn, reveal } from './screens.js';
import { office, seat2, typing, timer, SHOT } from './sets.js';

export const texts = [1, 3, 6, 7];
export const cast = ['omar', 'maya'];

export default function ({ stage, scene, S, E, ui }) {
  const omar = createPerson('omar', scene), maya = createPerson('maya', scene), { w2 } = office(scene);

  return t => {
    const k = timer(t, S);
    omar.reset(); maya.reset(); seat2(omar); omar.idle(t, 1); maya.idle(t, 2);
    typing(omar, w2, t, 1 - k(8, 0.5, 2.2));
    maya.go(t, S(8) - 0.2, S(8) + 2.6, -3.6, -0.4, -0.15, -1.55, 0, -2.6);
    if (t > S(8) + 2.2) { omar.look(maya.g.position.clone().setY(1.6), 1); maya.look(omar.g.position.clone().setY(1.15), 1); omar.smile = 0.45; maya.smile = 0.4; omar.gaze = 0; }
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), q => win('Security monitoring', row('Sign-ins', `${Math.round(q * 4200)} today`) + row('Device alerts', `${Math.round(q * 310)}`) + row('Service notices', `${Math.round(q * 96)}`))],
      [S(1), S(2), q => win('AI groups related items', reveal([row('Same account', 'Sign-in at 02:15', 'hi'), row('Same account', 'New laptop', 'hi'), row('Same account', 'Opened 40 records', 'hi')], q * 1.3))],
      [S(2), S(3), win('Proposed summary', row('Possible stolen account', '', 'warn') + row('Look first at', 'Sign-in at 02:15', 'hi') + note('A suggestion, not a finding.', 'warn'))],
      [S(3), S(4), q => win('Omar opens the source', row('Summary says', 'Foreign location', 'warn') + (q > 0.45 ? row('Log says', 'VPN exit, user location unverified', 'wait') : '') + note('Convincing is not verified. The assessment stays open.', 'warn'))],
      [S(4), S(5), win('Two AI mistakes', row('Flagged as attack', 'Approved maintenance', 'no') + row('Missed entirely', 'Unusual record access', 'no') + note('Omar corrects both.'))],
      [S(5), S(6), win('Automatic restriction', row('Account locked', 'A real case officer', 'no') + row('Work', 'Stopped by mistake', 'no') + row('Omar', 'Reviewed and restored', 'ok'), 'alert')],
      [S(6), S(7), q => win('Before a big response', row('Proposed', 'Lock 12 accounts', 'wait') + row('Account 118', 'Matches the 02:15 event', 'hi') + (q > 0.35 ? row('Other 11 accounts', 'No matching event', 'no') : '') + (q > 0.65 ? btn('Approve account 118 only', 'ok') : ''))],
      [S(7), S(8), q => win('Good use of AI in defence', reveal([row('Suitable information', '', 'ok'), row('Tool tested', 'Results checked', 'ok'), row('Clear permissions', '', 'ok'), row('Big actions', 'Wait for a person', 'ok')], q))],
      [S(8), S(9), win('Case notes', row('Automated review', 'Paused', 'wait') + row('Shaima', 'Arrives with an observation', 'hi'))],
      [S(9), E(9) + 0.4, q => win('What monitoring could not see', row('Shaima’s report', 'Call at 01:50 asked for a code', 'hi') + (q > 0.45 ? row('Linked to', 'Same account, 02:15 sign-in', 'ok') : '') + note('Early reports add the human context.'), 'good')],
    ]);

    stage.shots(t, [
      SHOT.seated2,
      { t0: S(8) + 1, t1: S(8) + 2.8, x: -0.2, y: 1.6, z: -2, w: 2.6, e: 0.42, f: 0.24 },
    ]);
  };
}
