// 1.13 AI makes deception more convincing: public scraps become a personal message, and Shaima checks it by phone.
import { V, C, pulse, mesh, rbox } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, mail, chain, reveal } from './screens.js';
import { office, seat1, typing, call, model, timer, SHOT } from './sets.js';

export const texts = [3, 5, 7];
export const cast = ['maya'];

export default async function ({ stage, scene, S, E, ui }) {
  const maya = createPerson('maya', scene), { w1 } = office(scene);
  await model('desk-phone', scene, -2.42, 0.78, -1.82, 0.13);
  const handset = mesh(rbox(0.05, 0.05, 0.2, 0.02), C.dark, 0, 0, 0, scene);
  const msg = (extra = '') => win('Shaima’s inbox', mail('Project Office', 'Sadeed licensing review', 'Licensing review: records needed today', 'Dear Shaima, for Thursday’s review please upload the case files here: sadeed-review.example') + extra);

  return t => {
    const k = timer(t, S);
    maya.reset(); seat1(maya); maya.idle(t, 1);
    const stop = pulse(t, S(5) + 0.6, S(5) + 1.2, S(10) + 3, S(10) + 3.6);
    const calling = pulse(t, S(8) + 0.2, S(8) + 1, S(9) - 0.3, S(9) + 0.2);
    typing(maya, w1, t, 1 - stop);
    maya.bend = 0.16 * stop; maya.smile = 0.3 - 0.2 * stop;
    maya.reach('R', V(-2.42, 0.9, -1.82), pulse(t, S(8), S(8) + 0.3, S(8) + 0.4, S(8) + 0.7));
    call(maya, calling);
    handset.visible = calling > 0.3;
    if (handset.visible) { maya.handPos('R', handset.position); handset.rotation.set(1.2, 0.78, 0); }
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), q => win('Public web pages', reveal([row('News', 'Licensing review on Thursday'), row('Staff page', 'Shaima, case officer'), row('Project page', 'Renewal backlog')], q * 1.3))],
      [S(1), S(2), win('An AI summary of public pages', chain([['Who', 'Shaima, case officer'], ['What', 'Licensing review', 'wait'], ['When', 'This Thursday', 'wait']]))],
      [S(2), S(3), msg()],
      [S(3), S(4), msg(row('Spelling and tone', 'Perfect', 'ok') + row('Requested action', 'Upload case files', 'hi'))],
      [S(4), S(5), win('Compare', row('Real project page', 'Licensing review', 'ok') + row('This message', 'Same name and style', 'warn') + row('Link in the message', 'sadeed-review.example', 'no') + row('Approved portal', 'portal.sadeed.example', 'ok'))],
      [S(5), S(6), msg(note('She recognizes it, and almost starts. Then she stops.', 'warn'))],
      [S(6), S(7), win('Message and proof are different', row('It looks right', '', 'ok') + row('Approval record', 'No matching approval', 'no') + note('Details do not prove who sent it.', 'no'), 'alert')],
      [S(7), S(8), win('Shaima’s work list', row('Licensing review', 'Real project', 'ok') + row('Upload request', 'Not on the list', 'warn'))],
      [S(8), S(9), q => win('Shaima checks by phone', row('Upload', 'On hold', 'wait') + row('Calling', 'Project lead, from the directory', 'hi') + (q > 0.55 ? row('Project lead', '“Not from us”', 'no') : ''))],
      [S(9), S(10), win('Report a concern', row('Unusual request', 'Reported', 'ok') + note('She does not need to prove AI wrote it.'), 'good')],
      [S(10), E(10) + 0.4, q => win('Focus on three things', reveal([row('The action', 'Upload outside Sadeed', 'no'), row('The information', 'Applicants’ case files', 'no'), row('The authority', 'No approval', 'no')], q * 1.3) + (q > 0.8 ? note('The upload never starts.') : ''))],
    ]);

    stage.shots(t, [SHOT.seated]);
  };
}
