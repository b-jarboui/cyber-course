// Who gets to give the orders?
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '6.2',
  actors: { maya: 'counter', omar: 'colleague' },
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(3), 'staff'], [S(4), 'her'], [S(14), 'counter'], [S(15), 'counterDisplay']],
  actions: {
    maya: [[0, S(3), 'read'], [S(3), S(4), 'listen', 'omar'], [S(4), S(14), 'read'], [S(14), D.T, 'type']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(4), 'point'], [S(4), S(14), 'listen', 'maya'], [S(14), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'mail', 'Shared mailbox · Case 2048', 'neutral', 'inbox'],
      [S(2), S(14), 'mail', 'Ignore rules · List files', 'alert', 'inbox'],
      [S(14), D.T, 'bell', 'Sender checked · Reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Shared mailbox · Unknown sender'],
    [S(2), E(2), 'Odd order in summary'],
    [S(3), E(3), 'Written inside the email'],
    [S(14), E(14), 'Checked via case file contact'],
  ],
  pages: [
    hero(S(4), S(7), 'Emails, web pages and files can carry orders', 'made/own_mail+made/own_link+made/own_file', [
      ['Hidden text can steer browser or mail agents', S(5), 'v-coral'],
      ['A long-term challenge, like scams', S(6), 'v-amber'],
    ]),
    hero(S(7), S(10), 'Order: Authority, then user, then outside content', 'made/register_book+made/signpost', [
      ['Attackers mimic official or urgent notices', S(8), 'v-coral'],
      ['Controls and staff keep the order', S(9), 'v-teal'],
    ]),
    hero(S(10), S(14), 'Filters alone are never enough', 'made/key_cabinet+made/case_folder', [
      ['Written limits and filters can be bypassed', S(11), 'v-amber'],
      ['Least privilege limits what AI can reach', S(13), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Outside text that gives orders is a warning sign', 'made/own_mail+made/own_bell', [
      ['Read the source and verify via official channel', S(14), 'v-teal'],
      ['Stop, verify and report', S(15), 'v-amber'],
    ]),
  ],
}));
