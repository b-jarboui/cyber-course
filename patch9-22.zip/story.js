import { AR, arabicPlate, tr, trTemplate } from './i18n.js';
// Shared by the rebuilt scenes: 2D plates over the 3D, Shaima at the counter, Omar at his desk.
import { THREE, C, V, mesh, rbox, group, ramp, pulse } from './kit.js';
import { workplace, typing, counterTyping } from './sets.js';
import { createPerson, loadMotion } from './people.js';
import { frameShots, quietScreens } from './astra.js';
import { createBoard } from './board.js';
import { concept, readyPages, seekPages } from './library-pages.js';
import { restoreTeachingTable } from './v1-set.js';

export const teal = s => `<span style="color:#2f7477">${s}</span>`;
export const coral = s => `<span style="color:#c6543b">${s}</span>`;
export const faceOf = (p, h = 1.5) => p.g.position.clone().setY(h);
export const SCREEN = V(-2.1, 1.47, -.66);
export const walkM = ['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop'], walkF = ['f_walk_start', 'f_walk_neutral_01', 'f_walk_stop'];
export const rot = -Math.PI / 2;
export const SHOTS = {
  hall: { x: -1.3, y: 1.1, z: -.1, w: 6.2, e: .55, f: .45 },
  wide: { x: -.6, y: 1.0, z: .1, w: 7.8, e: .68, f: .44 },
  counter: { x: -2.2, y: 1.2, z: -.3, w: 3.7, e: .44, f: .43 },
  her: { x: -2.25, y: 1.3, z: -.42, w: 2.7, e: .42, f: .42 },
  staff: { x: -3, y: 1.3, z: -.75, w: 2.9, e: .42, f: .42 },
  queue: { x: -1, y: 1.1, z: -.3, w: 4.2, e: .42, f: .44 },
};
export const cutTo = (x, shot) => ({ t0: x - .02, t1: x, ...shot });

export function plates(B) {
  return (a, z, html, bottom = 170) => {
    const plate = document.createElement('div');
    plate.style.cssText = `position:absolute;left:16px;bottom:${bottom}px;padding:8px 14px;border-radius:12px;background:#fffdf8;color:#26305a;font:800 22px/1.2 "Inter Tight","Segoe UI",Arial;box-shadow:0 4px 14px rgba(38,48,90,.18);opacity:0;pointer-events:none`;
    plate.innerHTML = tr(html);
    if (AR) arabicPlate(plate);
    document.getElementById('stage').after(plate);
    B.tl.fromTo(plate, { opacity: 0 }, { opacity: 1, duration: .3, immediateRender: false }, a);
    B.tl.to(plate, { opacity: 0, duration: .25 }, z);
  };
}

// Omar's desk. The chair faces away from the camera so his screen is seen facing him.
export function omarDesk(scene) {
  const OX = 3.2, OZ = -2.5, OROT = -1.45, w = workplace(scene, OX, OZ, OROT);
  const SX = OX + w.f.x * .95, SZ = OZ + w.f.z * .95, monitor = group(scene, SX, .78, SZ); monitor.rotation.y = OROT + Math.PI;
  mesh(rbox(.6, .36, .03, .012), C.dark, 0, .3, 0, monitor);
  mesh(rbox(.05, .13, .05, .01), C.metalD, 0, .06, 0, monitor); mesh(rbox(.22, .012, .14, .005), C.metalD, 0, .006, 0, monitor);
  const glow = new THREE.MeshBasicMaterial({ color: '#e4edf7', toneMapped: false }), lit = new THREE.Mesh(new THREE.PlaneGeometry(.56, .32), glow);
  lit.position.set(0, .3, .017); monitor.add(lit);
  const calm = new THREE.Color('#e4edf7'), tone = new THREE.Color();
  const at = V(SX, 1.08, SZ);
  return {
    shot: { x: OX - .4, y: 1.1, z: OZ + .05, w: 2.3, e: .42, f: .44 }, at,
    // k: how far the screen has changed to `colour`; reading: hands rest on the keys.
    seat: [OX - w.f.x * .1, OZ - w.f.z * .1, OROT],
    update(omar, t, k = 0, reading = 0, colour = '#efc46c', think = null) {
      omar.reset(); omar.at(OX - w.f.x * .1, OZ - w.f.z * .1, OROT); omar.idle(t, 2); omar.sway = 0;
      // Watching a long while, he stops and thinks with a hand to his chin.
      const chin = think ? pulse(t, think.t0, think.t0 + .8, think.end - .8, think.end) : 0;
      if (think && t >= think.t0 && t < think.end) omar.follow(think, t, true); else omar.play('m_sit_table_idle_neutral_01', t, true);
      typing(omar, w, t, 1 - reading); if (reading > 0 && chin < 1) { omar.reach('R', w.keyR, reading * (1 - chin)); omar.reach('L', w.keyL, reading * (1 - chin)); }
      omar.gaze = .1; omar.smile = .06; omar.look(at, 1);
      glow.color.copy(calm).lerp(tone.set(colour), k);
    },
  };
}

// Shaima at the counter, on recorded idle. `away` lifts her hands off the keyboard.
export function shaimaAtCounter(maya, t, deny = null) {
  maya.reset(); maya.at(-2.8, -.45, 1.8); maya.idle(t, 2); maya.sway = 0; maya.bend = .08; maya.g.visible = true;
  if (!deny || t < deny.t0) maya.play('f_idle_neutral_01', t, true); else maya.follow(deny, t, true);
  const free = deny ? pulse(t, deny.t0 - .35, deny.t0 + .05, deny.t0 + 3, deny.t0 + 3.6) : 0;
  if (free > 0) {
    maya.ik.R = maya.ik.L = null;
    if (free < 1) { maya.reach('R', V(-2.46, 1.117, -.35), 1 - free); maya.reach('L', V(-2.46, 1.111, -.55), 1 - free); }
  } else counterTyping(maya, t, 1);
  maya.look(SCREEN, 1);
  return free;
}

// A person waiting in one place, with their own recorded idle.
export function stand(p, x, z, yaw, clip, t, n = 3) {
  p.reset(); p.idle(t, n); p.sway = 0; p.g.visible = true; p.at(x, z, yaw).play(clip, t, true);
}

export const hidePeople = (stage, people, props = []) => {
  for (const p of people) p.g.visible = p.g.visible && !stage.conceptPage;
  for (const o of props) o.visible = !stage.conceptPage;
};
export { ramp, pulse };

export const CAST = ['maya', 'omar', 'priya', 'lena', 'comms', 'citizenYoung'];
export const CAST_APPLICANT = ['maya', 'omar', 'priya', 'lena', 'citizen', 'citizenYoung'];
const MOTION = ['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop', 'm_idle_neutral_01', 'm_idle_neutral_02', 'm_idle_neutral_03', 'm_sit_table_idle_neutral_01', 'm_gestic_listen_accept_01', 'm_idle_look_around_01',
  'f_idle_neutral_01', 'f_idle_neutral_02', 'f_walk_start', 'f_walk_neutral_01', 'f_walk_stop', 'f_turn_left_120', 'f_turn_left_60_to_walk', 'f_gestic_listen_deny_05', 'f_gestic_listen_accept_01', 'f_idle_look_around_01',
  'm_idle_waiting_01', 'm_idle_waiting_02', 'f_idle_waiting_01', 'f_idle_waiting_02', 'f_gestic_talk_self-assured_01', 'm_sit_table_gestic_thoughtful', 'f_documents_check'];
const WAIT_M = ['m_idle_neutral_01', 'm_idle_waiting_01', 'm_idle_look_around_01', 'm_idle_neutral_02', 'm_idle_waiting_02'], WAIT_F = ['f_idle_neutral_02', 'f_idle_waiting_01', 'f_idle_look_around_01', 'f_idle_neutral_01', 'f_idle_waiting_02'];
// A person who waits a long time: one recorded idle after another, never the same loop.
const waiting = (p, clips, x, z, T, shift = 0) => p.plan(Array.from({ length: Math.ceil(T / 8) + 2 }, (_, i) => clips[(i + shift) % clips.length]), x, z, rot, 0, .6, null);

// One hall, the same people, a scene described by its beats. Every field but shots is optional:
// plates [[a,z,html,bottom]], pages [{a,z,list:[{a,z,scene,cues}]}], screen [[a,z,colour]], tint [[a,z,amount]],
// rania {walk, deny}, lena {walk, nod, x, z}, young {walk}, front 'citizen'|'comms', serve [[a,z]], omarWatch [[a,z]].
export function hallScene(describe) {
  return async function ({ stage, scene, createCounter, S, E, D, ui }) {
    await loadMotion(MOTION);
    const c = describe(S, E, D);
    document.getElementById('kicker').textContent = trTemplate('Lesson {lesson} · Version 4', {lesson:c.lesson});
    document.getElementById('cap').style.fontSize = '21px';
    createCounter(scene);
    await restoreTeachingTable(scene);
    const maya = createPerson('maya', scene), omar = createPerson('omar', scene), rania = createPerson('priya', scene), lena = createPerson('lena', scene), young = createPerson('citizenYoung', scene);
    const front = createPerson(c.front || 'comms', scene), male = c.front === 'citizen', desk = omarDesk(scene);
    const sheet = group(scene); sheet.rotation.order = 'YZX'; sheet.name = 'Rania paper';
    mesh(rbox(.3, .0003, .21, .0001), C.paper, 0, 0, 0, sheet);
    for (const x of [.08, .04, 0, -.04, -.08]) mesh(rbox(.012, .00005, .16, .00002), C.powderD, x, .000175, 0, sheet);

    for (const p of [maya, omar, rania, lena, young, front]) p.continuousMotion = true;
    const ra = c.rania, le = c.lena, yo = c.young;
    const deny = ra?.deny ? maya.plan(['f_gestic_listen_deny_05', 'f_idle_neutral_01'], -2.8, -.45, 1.8, ra.deny, .4, 'f_idle_neutral_01') : null;
    // Along the staff aisle, then a turn towards Shaima, clear of her shoulders.
    // `at`: she is already beside Shaima with the paper; otherwise she walks in.
    const r1 = ra && ra.at ? rania.plan(['f_idle_neutral_02'], ...ra.at, 0, .3, 'f_idle_neutral_02') : ra && rania.planTo(['f_walk_start', 'f_walk_stop', 'f_turn_left_120', 'f_idle_neutral_02'], -3.55, .3, 2.1, ra.walk, .3, 'f_idle_neutral_02');
    const r2 = deny && rania.plan(['f_gestic_listen_accept_01', 'f_turn_left_60_to_walk', 'f_walk_stop', 'f_idle_neutral_02'], r1.end.x, r1.end.z, r1.yaw, deny.t0 + 3.2, .3, r1);
    const frontWait = waiting(front, male ? WAIT_M : WAIT_F, -1.3, -.3, D.T), youngWait = yo ? null : waiting(young, WAIT_M, .5, -.3, D.T, 2);
    const thinks = (c.omarWatch || []).filter(w => w[1] - w[0] > 4).map(w => Object.assign(omar.plan(['m_sit_table_gestic_thoughtful', 'm_sit_table_idle_neutral_01'], ...desk.seat, w[0] + 1, .5, 'm_sit_table_idle_neutral_01'), { end: w[1] - .3 }));
    const LZ = [le?.x ?? -3.82, le?.z ?? -.85], lYaw = .4;
    const l1 = le && lena.planTo(['f_walk_start', 'f_walk_stop', 'f_idle_neutral_02'], LZ[0], LZ[1], lYaw, le.walk);
    const l2 = le?.nod && lena.plan(['f_gestic_listen_accept_01', 'f_gestic_talk_self-assured_01', 'f_idle_neutral_02'], LZ[0], LZ[1], lYaw, le.nod, .4, l1);
    const y1 = yo && young.planTo([...walkM, 'm_idle_neutral_03'], .5, -.3, rot, yo.walk);

    const B = createBoard(D.T), say = plates(B), windows = [];
    // A long caption climbs the screen: the plate stays above it.
    for (const [a, z, html] of c.plates || []) {
      const i = D.timing.findIndex(w => a < w[1]), lines = Math.ceil((D.sentences[Math.max(0, i)] || '').length / 35);
      say(a, z, html, lines > 3 ? 182 + (lines - 3) * 24 : 170);
    }
    for (const w of c.pages || []) {
      B.open(w.a); if (w.z < D.T) B.close(w.z);
      windows.push([w.a + .4, w.z]);
      for (const p of w.list) concept(B, p.a ?? w.a, p.z ?? w.z, { scene: p.scene, cues: p.cues || {} });
    }
    B.end(); await readyPages(B);
    const body = V(0, 0, 0), during = (list, t) => (list || []).find(w => t >= w[0] && t < w[1]);
    const named = s => typeof s === 'string' ? SHOTS[s] || desk.shot : s;
    const shots = c.shots.map(s => Array.isArray(s) ? cutTo(s[0], s[1] === 'desk' ? desk.shot : named(s[1])) : s.shot ? { t0: s.t0, t1: s.t1, ...(s.shot === 'desk' ? desk.shot : named(s.shot)) } : named(s));
    // Nobody is seen crossing the glass: a person who comes in appears across a cut, close on them, then the picture returns.
    const enter = (x, view) => {
      const near = shots.find(s => s.t1 !== undefined && s.t1 >= x - 2.5 && s.t1 <= x + .3);
      if (near) return near.t1;
      const before = shots.filter(s => s.t1 === undefined || s.t1 <= x).at(-1);
      shots.push(cutTo(x, SHOTS[view]), cutTo(x + 3.2, before));
      shots.sort((a, b) => (a.t0 ?? -1) - (b.t0 ?? -1));
      return x;
    };
    const lenaIn = le ? enter(l1.segs.at(-2).t1, 'staff') : 0, raniaIn = ra && !ra.at ? enter(r1.segs[1].t1, 'staff') : 0, youngIn = yo ? enter(y1.segs.at(-2).t1, 'queue') : 0;

    return t => {
      B.tl.time(t, false);
      seekPages(B, t);
      stage.conceptPage = windows.some(w => t >= w[0] && t < w[1]);
      quietScreens(ui, t);
      stage.focus = null;

      const free = shaimaAtCounter(maya, t, deny);
      maya.look(faceOf(rania), free);
      maya.smile = .1;
      if (during(c.serve, t)) { maya.look(faceOf(front), .9); maya.smile = .3; }
      if (le?.nod) maya.look(faceOf(lena), pulse(t, le.nod - .8, le.nod - .2, le.nod + 3, le.nod + 3.5));

      front.reset(); front.idle(t, 3); front.sway = 0; front.g.visible = true; front.follow(frontWait, t, true);
      front.smile = .12; front.look(V(-2.5, 1.5, -.5), .6);
      young.reset(); young.idle(t, 4); young.sway = 0; young.smile = .1;
      if (yo) { young.g.visible = t >= youngIn; young.follow(y1, t, true); } else { young.g.visible = true; young.follow(youngWait, t, true); }
      young.look(V(-2.5, 1.5, -.5), .5);

      rania.reset(); rania.idle(t, 5); rania.sway = 0; rania.smile = .15; rania.g.visible = !!ra && t >= raniaIn;
      if (ra) {
        if (t < r1.t0) { const s = r1.segs[0]; rania.at(s.x, s.z, s.yaw).play('f_idle_neutral_02', t, true); } else if (!r2 || t < r2.t0) rania.follow(r1, t, true); else rania.follow(r2, t, true);
        rania.look(faceOf(maya), r2 ? pulse(t, r1.t0 + 2.2, r1.t0 + 2.9, r2.t0 + 1.2, r2.t0 + 1.8) : ramp(t, r1.t0 + 2.2, r1.t0 + 2.9));
        // She looks at the colleague who comes to verify the request.
        if (le) rania.look(faceOf(lena), pulse(t, l1.t1 - .8, l1.t1, D.T, D.T + 1));
        // She holds the paper in both hands, low and close, tilted up to read it.
        rania.flush(); rania.b.Bip01.getWorldPosition(body);
        const yaw = rania.g.rotation.y;
        sheet.position.copy(body).add(V(Math.sin(yaw) * .24, 0, Math.cos(yaw) * .24)).setY(1.07);
        sheet.rotation.set(0, yaw - Math.PI / 2, .5); sheet.updateMatrixWorld(true);
        rania.grasp('L', sheet, V(-.145, 0, -.095), V(1, 0, 0), 1);
        rania.grasp('R', sheet, V(-.145, 0, .095), V(1, 0, 0), 1);
      }

      const shown = during(c.screen, t), lit = shown ? pulse(t, shown[0], shown[0] + .7, shown[1] - .5, shown[1]) : 0;
      desk.update(omar, t, lit, during(c.omarWatch, t) ? 1 : 0, shown?.[2], thinks.find(p => t >= p.t0 - 1 && t < p.end + .5)); omar.g.visible = true;

      lena.reset(); lena.idle(t, 6); lena.sway = 0; lena.smile = .25; lena.g.visible = !!le && t >= lenaIn;
      if (le) {
        if (t < l1.t0) { const s = l1.segs[0]; lena.at(s.x, s.z, s.yaw).play('f_idle_neutral_02', t, true); }
        else if (!l2 || t < l2.t0) lena.follow(l1, t, true); else lena.follow(l2, t, true);
        lena.look(faceOf(maya), ramp(t, l1.t1 - 1.2 || 0, l1.t1 - .6 || 0));
      }

      hidePeople(stage, [maya, omar, rania, lena, young, front], [sheet]);
      sheet.visible = sheet.visible && !!ra;
      const tone = during(c.tint, t);
      stage.outage = tone ? tone[2] * pulse(t, tone[0], tone[0] + .8, tone[1] - .6, tone[1]) : 0;
      frameShots(stage, t, shots);
    };
  };
}
