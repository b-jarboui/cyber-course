// A file that hides a link.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['admin', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { admin: 'desk', omar: 'counterEnd' },
  shots: [[0,'desk'], [S(2),'display'], [S(7),'desk'], [S(9),'pair'], [S(10),'desk'], [S(12),'pair']],
  walks: { omar: [[S(8),E(8),'beside']] },
  actions: {
    admin: [[0,S(8),'read'], [S(8),S(10),'listen','omar'], [S(10),E(11),'call'], [S(13),D.T,'type']],
    omar: [[S(9),E(9),'talk','admin'], [S(10),D.T,'listen','admin']],
  },
  displays: { desk: [[0,S(2),'file-text','Supplier price list','neutral','inbox'], [S(2),S(10),'folder','Open shared folder','alert'], [S(10),D.T,'mobile','Supplier record','safe']] },
  plates: [[S(0),E(0),'Khalid · Procurement'], [S(1),E(1),'Supplier price list'], [S(2),E(2),'Open shared folder'], [S(11),E(11),'Nothing sent today']],
  pages: [
    hero(S(3), S(7), 'Links hide inside documents', 'file-text+folder+link', [
      ['Open shared folder', S(3), 'v-amber'],
    ]),
    hero(S(8), S(9), 'Unexpected attachment? Pause', 'mail+file-text', [
      ['Supplier price list', S(8), 'v-amber'],
    ]),
    hero(S(10), S(11), 'Verify the sender through a known contact', 'made/register_book+mobile', [
      ['Supplier record', S(10), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Report, do not forward', 'mail+bell', [
      ['Mention any file you opened', S(14), 'v-teal'],
    ]),
  ],
}));
