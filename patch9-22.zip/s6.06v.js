// Sure of itself, and steered.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '6.2',
  actors: { maya: 'counter', omar: 'colleague' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(2), 'counterDisplay'], [S(3), 'staff'], [S(4), 'her'], [S(8), 'counterDisplay'], [S(11), 'counter'], [S(12), 'her'], [S(16), 'counterDisplay']],
  actions: {
    maya: [[0, S(3), 'read'], [S(3), S(4), 'listen', 'omar'], [S(4), S(11), 'read'], [S(11), S(12), 'type'], [S(12), S(16), 'read'], [S(16), D.T, 'type']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(5), 'paper'], [S(5), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(2), 'file', 'AI draft reply · Case 2048', 'neutral'],
      [S(2), S(8), 'mail', 'Unlisted return address', 'alert'],
      [S(8), S(11), 'link', 'Forward file? Allow / Deny', 'alert'],
      [S(11), S(16), 'key', 'Request denied by Shaima', 'safe'],
      [S(16), D.T, 'bell', 'Draft and request reported', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'AI draft reply · Case 2048'],
    [S(3), E(3), 'Address not in official list'],
    [S(8), E(8), 'Permission box · Allow or Deny'],
    [S(11), E(11), 'Shaima presses Deny'],
  ],
  pages: [
    hero(S(4), S(8), 'A confident answer is not a proven answer', 'made/own_computer+made/register_book', [
      ['Steered answers can come from poisoned data', S(5), 'v-coral'],
      ['Check addresses, numbers, dates and links', S(7), 'v-teal'],
    ]),
    hero(S(9), S(12), 'No approval, no action', 'made/rubber_stamp+made/padlock_open', [
      ['Unauthorized tool request refused', S(9), 'v-coral'],
      ['A person must approve before AI acts', S(11), 'v-teal'],
    ]),
    hero(S(12), S(15), 'Reduce risk and impact', 'made/balance_scale+made/safe', [
      ['No single defence is enough alone', S(14), 'v-amber'],
      ['Humans approve high-impact actions', (S(14) + E(14)) / 2, 'v-teal'],
    ]),
    hero(S(15), D.T, 'Limit the reach, keep a record', 'made/key_cabinet+made/register_book+made/own_bell', [
      ['Minimum access, approval and tool logs', S(15), 'v-teal'],
      ['Wrong answer or request? Stop and report', S(16), 'v-amber'],
    ]),
  ],
}));
