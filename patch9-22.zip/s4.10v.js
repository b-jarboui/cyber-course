// Signed in does not mean allowed.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'priya'];
export default chapterHall((S, E, D) => ({
  lesson: '4.3',
  actors: { maya: 'counter', priya: 'desk' },
  file: [[S(0), E(0), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(4), 'counter'], [S(12), 'counterDisplay'], [S(13), 'desk'], [S(14), 'counter']],
  actions: {
    maya: [[0, S(2), 'type'], [S(2), S(12), 'read'], [S(12), S(13), 'type'], [S(13), D.T, 'read']],
    priya: [[0, S(13), 'read'], [S(13), D.T, 'type']],
  },
  displays: {
    counter: [[0, S(2), 'folder', 'Case 2048', 'safe'], [S(2), S(12), 'lock', 'Finance panel · Restricted', 'alert'], [S(12), D.T, 'file-text', 'Approved workflow', 'safe']],
    desk: [[0, S(13), 'folder', 'Finance workflow', 'neutral'], [S(13), D.T, 'tick', 'Approved result', 'safe']],
  },
  plates: [[S(0), E(0), 'Case 2048'], [S(2), E(2), 'Finance panel · Restricted'], [S(12), E(12), 'Approved workflow'], [S(13), E(13), 'Rania · Finance']],
  pages: [
    hero(S(4), S(5), 'Authentication: prove who you are', 'made/id_badge+lock', [
      ['Who are you?', S(4), 'v-teal'],
    ]),
    hero(S(5), S(8), 'Authorization: what you may do', 'key+made/filing_cabinet', [
      ['What are you allowed to do?', S(5), 'v-navy'],
      ['Segregation of duties', S(7), 'v-teal'],
    ]),
    hero(S(8), S(12), 'Only the access needed', 'made/key_cabinet+shield', [
      ['Least privilege', S(8), 'v-teal'],
      ['Never borrow or share an account', S(10), 'v-amber'],
    ]),
    hero(S(14), D.T, 'More access? Use the approved route', 'made/rubber_stamp+file-text', [
      ['Do not bypass controls', S(14), 'v-teal'],
    ]),
  ],
}));
