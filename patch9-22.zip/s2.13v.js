// An invoice nobody ordered, a record nobody asked to change.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['finance', 'admin', 'maya', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '2.3',
  actors: { finance: 'beside', admin: 'desk', maya: 'counter', citizen: 'door' },
  shots: [[0,'pair'], [S(1),'finance'], [S(3),'desk'], [S(4),'display'], [S(6),'finance'], [S(7),'counterDisplay'], [S(8),'her'], [S(10),'file'], [S(11),'door'], [S(12),'her'], [S(14),'hall']],
  file: [[S(10),(S(10)+E(10))/2,0,1]],
  actions: {
    finance: [[0,S(3),'paper'], [S(3),S(6),'talk','admin'], [S(6),E(6),'call'], [S(7),D.T,'listen','admin']],
    admin: [[S(3),S(5),'type'], [S(5),S(7),'talk','finance'], [S(14),D.T,'type']],
    maya: [[S(7),S(10),'read'], [S(10),(S(10)+E(10))/2,'file'], [(S(10)+E(10))/2,E(11),'call'], [S(14),D.T,'type']],
    citizen: [[S(10),E(11),'call']],
  },
  enter: { citizen: S(10) },
  displays: {
    desk: [[0,S(3),'mail','Workshop invoice','neutral','inbox'], [S(3),D.T,'folder','No matching order','alert']],
    counter: [[S(7),D.T,'mail','Refund account change','alert','inbox']],
  },
  plates: [[S(0),E(0),'Workshop invoice'], [S(1),E(1),'Due today'], [S(3),E(3),'Purchase order search'], [S(7),E(7),'Refund account change'], [S(10),E(10),'Number in the case file'], [S(14),E(14),'Two requests reported']],
  pages: [
    hero(S(4), S(5), 'No purchase order, no payment', 'made/register_book+money', [
      ['No matching order', S(4), 'v-amber'],
    ]),
    hero(S(5), S(6), 'Check the invoice against the record', 'file-text+made/register_book', [
      ['Approved purchase', S(5), 'v-teal'],
    ]),
    hero(S(12), S(13), 'Record changes need verification', 'made/case_folder+mobile', [
      ['Verify and authorise', S(12), 'v-teal'],
    ]),
    hero(S(13), S(14), 'Unexpected change alert? Report it', 'bell+setting', [
      ['Unrequested account change', S(13), 'v-amber'],
    ]),
  ],
}));
