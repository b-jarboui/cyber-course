// When the second code is not enough.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { maya: 'counter', omar: 'director' },
  handsets: { maya: [[S(1),S(11),'lock']] },
  shots: [[0,'counter'], [S(1),'counterDisplay'], [(S(1)+E(1))/2,'her'], [S(5),'staff'], [S(10),'her'], [S(11),'staff'], [S(13),'counter']],
  walks: { omar: [[S(9),E(9),'colleague']] },
  actions: {
    maya: [[0,S(1),'read'], [S(1),S(3),'text'], [S(3),S(10),'read'], [S(10),S(11),'text'], [S(11),S(14),'listen','omar'], [S(14),D.T,'type']],
    omar: [[S(10),S(11),'listen','maya'], [S(11),E(12),'talk','maya']],
  },
  displays: { counter: [[0,S(1),'mail','Shared case report','neutral'], [S(1),S(11),'lock','Password and code','alert','login'], [S(11),D.T,'computer','Official sign-in','safe','login']] },
  plates: [[S(0),E(0),'Shared case report'], [S(1),E(1),'Password and code'], [S(10),E(10),'Unexpected report'], [S(13),E(13),'An active session']],
  pages: [
    hero(S(3), S(10), 'Multi-factor authentication: essential, not magic', 'made/laptop+mobile+lock', [
      ['Password and code', S(3), 'v-amber'],
      ['An active session', S(5), 'v-amber'],
    ]),
    hero(S(11), S(12), 'Sign in only from the address you typed', 'computer+link', [
      ['Official sign-in', S(11), 'v-teal'],
    ]),
    hero(S(12), S(13), 'Never share a verification code', 'mobile+lock', [
      ['Keep the code private', S(12), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Report so sessions can be ended', 'computer+bell', [
      ['End active sessions', S(14), 'v-teal'],
    ]),
  ],
}));
