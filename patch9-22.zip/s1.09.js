// 1.09 A trusted account can be misused: a familiar message, a payment change, and Rania's independent call.
import { V, C, pulse, ramp, mesh, rbox } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, mail, btn, reveal } from './screens.js';
import { office, seat1, seat2, typing, call, model, timer, SHOT } from './sets.js';

export const texts = [2, 6, 8];
export const cast = ['priya', 'maya'];

export default async function ({ stage, scene, S, E, ui }) {
  const rania = createPerson('priya', scene), maya = createPerson('maya', scene), { w1, w2 } = office(scene);
  await model('desk-phone', scene, -2.42, 0.78, -1.82, 0.13);
  const handset = mesh(rbox(0.05, 0.05, 0.2, 0.02), C.dark, 0, 0, 0, scene);
  const msg = (extra = '') => win('Rania’s inbox', mail('Fahad, Supplier Accounts', 'Usual contact', 'Change of bank details', 'Please update our payment details before today’s run.') + extra);

  return t => {
    const k = timer(t, S);
    rania.reset(); maya.reset(); seat1(rania); seat2(maya); rania.idle(t, 1); maya.idle(t, 2);
    const calling = pulse(t, S(6) + 0.3, S(6) + 1, S(7) - 0.4, S(7));
    typing(rania, w1, t, 1 - pulse(t, S(4) + 0.3, S(4) + 0.9, S(8) - 0.4, S(8)));
    typing(maya, w2, t);
    rania.bend = 0.16 * pulse(t, S(4), S(4) + 0.6, S(6), S(6) + 0.5);
    rania.reach('R', V(-2.42, 0.9, -1.82), pulse(t, S(6), S(6) + 0.4, S(6) + 0.5, S(6) + 0.8));
    call(rania, calling);
    handset.visible = calling > 0.3;
    if (handset.visible) { rania.handPos('R', handset.position); handset.rotation.set(1.2, 0.78, 0); }
    rania.head.rotation.y = 0.2 * calling;
    rania.smile = 0.1 + 0.4 * k(9, 0.6, 2);
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), msg(note('It looks completely normal.'))],
      [S(1), S(2), win('Same name, different person', row('Real Fahad', 'Says he sent nothing', 'ok') + row('Message', 'Carries his name and photo', 'no') + note('Someone is using his identity.', 'no'), 'alert')],
      [S(2), S(3), win('Account security review', row('Account', 'Fahad') + row('New session', 'Unknown device', 'no') + row('Messages sent', 'From that session', 'no') + note('Stolen sign-in details let someone act as him.', 'no'), 'alert')],
      [S(3), S(4), msg(row('Earlier messages', '14 genuine ones', 'ok') + row('This request', 'Unusual', 'warn'))],
      [S(4), S(5), win('Payment change', row('Supplier', 'Current account') + row('Saved destination', 'Bank ending 4821') + row('Requested', 'Bank ending 7716', 'hi'))],
      [S(5), S(6), win('From a familiar account', row('Sender', 'Fahad, known contact', 'ok') + row('Conversation', 'Real history', 'ok') + note('Familiar. But that does not prove the request.', 'warn'))],
      [S(6), S(7), q => win('Rania checks independently', row('Change', 'On hold', 'wait') + row('Calling', 'Number from official directory', 'hi') + (q > 0.55 ? row('Fahad', '“I sent no such request”', 'no') : ''))],
      [S(7), S(8), q => win('What one small change does', row('Destination', 'Ending 7716', q > 0.4 ? 'no' : 'hi') + (q > 0.4 ? row('Payment would go to', 'The criminal', 'no') : '') + (q > 0.7 ? row('Rania', 'Stopped it before release', 'ok') : ''), 'alert')],
      [S(8), S(9), q => win('Protect the whole account', reveal([row('Compromised password', 'Changed', 'ok'), row('Recovery process', 'Reviewed', 'ok'), row('Unauthorized sessions', 'Revoked', 'ok')], q * 1.3))],
      [S(9), E(9) + 0.4, q => win('Two separate checks', row('Who is asking?', q > 0.35 ? 'Not confirmed' : 'Checking', q > 0.35 ? 'no' : 'wait') + row('Is it permitted?', q > 0.65 ? 'No approval exists' : 'Checking', q > 0.65 ? 'no' : 'wait') + note('The payment stays held.'))],
    ]);

    stage.shots(t, [
      SHOT.seated,
      { t0: S(9) + 2.4, t1: S(9) + 3.4, ...SHOT.both },
    ]);
  };
}
