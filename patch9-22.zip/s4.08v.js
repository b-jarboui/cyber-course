// The new phone that was not his.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['finance', 'visitor', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.2',
  actors: { finance: 'desk', visitor: 'door', omar: 'counter' },
  landline: 'desk',
  leave: { visitor: S(11) },
  handsets: { visitor: [[0, S(9), 'mobile']], omar: [[S(9), S(12), 'mobile']] },
  shots: [[0, 'desk'], [S(1), 'door'], [S(2), 'desk'], [S(8), 'display'], [S(9), 'desk'], [S(10), 'counter'], [S(11), 'desk'], [S(13), 'hall']],
  actions: {
    finance: [[0, S(8), 'extension'], [S(8), S(9), 'read'], [S(9), S(11), 'extension'], [S(11), D.T, 'type']],
    visitor: [[0, S(9), 'call']],
    omar: [[0, S(9), 'type'], [S(9), S(11), 'call'], [S(11), D.T, 'type']],
  },
  displays: {
    desk: [[0, S(8), 'mobile', 'Urgent reset request', 'alert'], [S(8), S(11), 'file-text', 'Official staff record', 'safe'], [S(11), D.T, 'shield', 'Reset refused · Reported', 'safe']],
    counter: [[0, D.T, 'folder', 'Case 2048', 'neutral']],
  },
  plates: [[S(0), E(0), 'IT service desk'], [S(1), E(1), 'Urgent reset request'], [S(9), E(9), 'Official staff record'], [S(10), E(10), 'No request made'], [S(11), E(11), 'Reset refused']],
  pages: [
    hero(S(3), S(5), 'Urgency is not identity', 'clock+made/id_badge', [
      ['Known details are not proof', S(3), 'v-amber'],
    ]),
    hero(S(5), S(8), 'No unknown device enrollment', 'mobile+made/padlock_open', [
      ['Attacker registers own device', S(5), 'v-coral'],
      ['Trusted way back into account', S(6), 'v-amber'],
    ]),
    hero(S(8), S(10), 'Use the approved recovery check', 'made/register_book+shield', [
      ['Ignore caller-supplied number', S(8), 'v-teal'],
    ]),
    hero(S(12), D.T, 'Call back using the official record', 'made/register_book+mobile+bell', [
      ['Never bypass the identity check', S(12), 'v-teal'],
      ['Unknown device? Report at once', S(13), 'v-amber'],
    ]),
  ],
}));
