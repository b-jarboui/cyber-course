// The director's voice, the finance rules
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["priya", "official"];
export default chapterHall((S, E, D) => ({
  lesson: "3.1",
  actors: { priya: 'desk', official: 'aisle' },
  landline: 'desk',
  enter: { official: S(11) }, walks: { official: [[S(11),E(11),'beside']] },
  shots: [[0,'desk'], [S(2),'display'], [S(3),'desk'], [S(8),'display'], [S(9),'desk'], [S(11),'pair']],
  actions: { priya: [[0,S(7),'extension'], [S(7),S(8),'read'], [S(8),S(10),'extension'], [S(10),S(12),'type'], [S(12),D.T,'listen','official']], official: [[S(11),D.T,'talk','priya']] },
  displays: { desk: [[0,S(8),'money','Payment on hold','alert'], [S(8),S(10),'mobile','Internal directory','safe'], [S(10),D.T,'file-text','No payment requested','safe']] },
  setupProps: evidence({ surfaces: { deskPaper: [[0,D.T,'form','Payment approval']] }, inserts: [[S(7),E(7),'deskPaper']] }),
  plates: [[S(0),E(0),'Rania · Finance'], [S(2),E(2),'Before the banks close'], [S(3),E(3),'Request for secrecy'], [S(11),E(11),'Report sent'],
    [S(13),E(13),'Pause when pressured'], [S(14),E(14),'Verify through a known contact'], [S(15),E(15),'Report early']],
  pages: [
    hero(S(5), S(7), "Senior voices can be cloned", "mobile+made/headset", [
      ["Claimed authority", S(6), "v-amber"],
    ]),
    hero(S(8), S(10), "Call back through the official directory", "made/register_book+mobile", [
      ["No payment requested", S(9), "v-teal"],
    ]),
    hero(S(10), S(11), "No payment without approval", "made/rubber_stamp+file-text", [
      ["Payment on hold", S(10), "v-teal"],
    ]),
  ],
}));
