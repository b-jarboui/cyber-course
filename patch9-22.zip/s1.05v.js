import { AR, arabicPlate, tr } from './i18n.js';
import { restoreTeachingTable } from './v1-set.js';
// Where weaknesses live. The story stays in the hall with the same people; each idea moves to a 2D page.
import { THREE, C, V, mesh, rbox, group, lerp, ramp, pulse } from './kit.js';
import { createPerson, loadMotion } from './people.js';
import { workplace, typing, counterTyping } from './sets.js';
import { frameShots, quietScreens } from './astra.js';
import { createBoard } from './board.js';
import { weaknessPages } from './pages2d-b.js';
import { readyPages, seekPages } from './library-pages.js';

export const texts = [];
export const cast = ['maya', 'comms', 'citizenYoung', 'priya', 'omar', 'lena'];

export default async function ({ stage, scene, b, createCounter, S, E, D, ui }) {
  await loadMotion(['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop', 'm_idle_neutral_03', 'm_sit_table_idle_neutral_01', 'f_idle_neutral_01', 'f_idle_neutral_02',
    'f_walk_start', 'f_walk_neutral_01', 'f_walk_stop', 'f_turn_left_180', 'f_gestic_listen_deny_01', 'f_gestic_listen_accept_01']);
  document.getElementById('kicker').textContent = tr('Lesson 1.1 · Version 4');
  document.getElementById('cap').style.fontSize = '21px';
  createCounter(scene);
  await restoreTeachingTable(scene);
  const maya = createPerson('maya', scene), woman = createPerson('comms', scene), young = createPerson('citizenYoung', scene), rania = createPerson('priya', scene), omar = createPerson('omar', scene), lena = createPerson('lena', scene);

  // Omar's workstation, with the same monitor as the previous scene.
  const OX = 3.2, OZ = -2.5, OROT = -1.45, w2 = workplace(scene, OX, OZ, OROT);
  const SX = OX + w2.f.x * .95, SZ = OZ + w2.f.z * .95, monitor = group(scene, SX, .78, SZ); monitor.rotation.y = OROT + Math.PI;
  mesh(rbox(.6, .36, .03, .012), C.dark, 0, .3, 0, monitor);
  mesh(rbox(.05, .13, .05, .01), C.metalD, 0, .06, 0, monitor); mesh(rbox(.22, .012, .14, .005), C.metalD, 0, .006, 0, monitor);
  const glow = new THREE.MeshBasicMaterial({ color: '#e4edf7', toneMapped: false }), lit = new THREE.Mesh(new THREE.PlaneGeometry(.56, .32), glow);
  lit.position.set(0, .3, .017); monitor.add(lit);
  const calm = new THREE.Color('#e4edf7'), warn = new THREE.Color('#efc46c');

  // The unusual request is a real sheet, carried in both hands.
  const request = group(scene); request.rotation.order = 'YZX';
  mesh(rbox(.3, .0003, .21, .0001), C.paper, 0, 0, 0, request);
  for (const x of [.08, .04, 0, -.04, -.08]) mesh(rbox(.012, .00005, .16, .00002), C.powderD, x, .000175, 0, request);

  // Routes. Only recorded motion: arrive, wait, refuse, leave.
  const rot = -Math.PI / 2, walkM = ['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop'], walkF = ['f_walk_start', 'f_walk_neutral_01', 'f_walk_stop'];
  const yRoute = young.planTo([...walkM, 'm_idle_neutral_03'], .5, -.3, rot, S(1) - 3.4);
  const R0 = [-3.86, -.05], r1 = rania.plan(['f_turn_left_180', 'f_walk_stop', 'f_idle_neutral_02'], R0[0], R0[1], rot, S(0) + 3.6, .45, 'f_idle_neutral_02');
  const deny = maya.plan(['f_gestic_listen_deny_01', 'f_idle_neutral_01'], -2.8, -.45, 1.8, S(8) + .2, .4, 'f_idle_neutral_01');
  const r2 = rania.plan(['f_gestic_listen_accept_01', 'f_turn_left_180', 'f_walk_stop', 'f_idle_neutral_02'], r1.end.x, r1.end.z, r1.yaw, deny.t0 + 2.2, .4, r1);
  const LZ = [-3.82, -.85], lYaw = .4;
  const lRoute = lena.planTo(['f_walk_start', 'f_walk_stop', 'f_idle_neutral_02'], LZ[0], LZ[1], lYaw, S(9) - 2.6);
  const lNod = lena.plan(['f_gestic_listen_accept_01', 'f_idle_neutral_02'], LZ[0], LZ[1], lYaw, S(9) + .8, .4, lRoute);

  // ---------- 2D ----------
  const B = createBoard(D.T), { tl } = B;
  const say = (a, z, html, bottom = 170) => {
    const plate = document.createElement('div');
    plate.style.cssText = `position:absolute;left:16px;bottom:${bottom}px;padding:8px 14px;border-radius:12px;background:#fffdf8;color:#26305a;font:800 22px/1.2 "Segoe UI",Arial;box-shadow:0 4px 14px rgba(38,48,90,.18);opacity:0;pointer-events:none`;
    plate.innerHTML = tr(html);
    if (AR) arabicPlate(plate);
    document.getElementById('stage').after(plate);
    tl.fromTo(plate, { opacity: 0 }, { opacity: 1, duration: .3, immediateRender: false }, a);
    tl.to(plate, { opacity: 0, duration: .25 }, z);
  };
  say(S(0) + 1.9, E(0) + .1, 'People', 258);
  say(S(0) + 3.4, E(0) + .1, 'Technology', 214);
  say(S(0) + 4.6, E(0) + .1, 'Organization');
  say(S(1) + .2, E(1) + .2, 'Under pressure<br><span style="color:#c6543b">Unusual request</span>');
  say(S(2) + .2, S(3) - .7, 'Software weakness<br><span style="color:#c6543b">Unresolved</span>');
  say(deny.t0 + .1, E(8) + .1, 'Shaima<br><span style="color:#2f7477">Follows the process</span>');
  say(S(9) + .2, E(9) + .1, 'Lina, manager<br><span style="color:#2f7477">Makes it workable</span>');
  const open1 = S(3) - .5, close1 = S(8) - .5, open2 = S(10) - .4;
  weaknessPages({ B, S, E, D, open1, close1, open2 }); B.end(); await readyPages(B);

  // ---------- the 3D story ----------
  const screenAt = V(-2.1, 1.47, -.66), keys = V(-2.46, 1.111, -.45), keyR = keys.clone().add(V(0, .006, .1)), keyL = keys.clone().add(V(0, 0, -.1));
  const faceOf = (p, h = 1.5) => p.g.position.clone().setY(h), body = V(0, 0, 0);
  const hall = { x: -1.3, y: 1.1, z: -.1, w: 6.2, e: .55, f: .45 }, counter = { x: -2.2, y: 1.2, z: -.3, w: 3.7, e: .44, f: .43 }, desk = { x: OX - .4, y: 1.1, z: OZ + .05, w: 2.3, e: .42, f: .44 }, staff = { x: -3, y: 1.3, z: -.75, w: 2.9, e: .42, f: .42 };
  const cutTo = (x, shot) => ({ t0: x - .02, t1: x, ...shot });

  return t => {
    tl.time(t, false);
    seekPages(B, t);
    stage.conceptPage = (t >= open1 + .4 && t < close1) || t >= open2 + .4;
    quietScreens(ui, t);
    stage.focus = null;

    for (const p of [maya, woman, young, rania, omar]) p.g.visible = true;

    // Shaima works; she glances up when Rania comes, and refuses later.
    maya.reset(); maya.at(-2.8, -.45, 1.8); maya.idle(t, 2); maya.sway = 0; maya.bend = .08;
    if (t < deny.t0) maya.play('f_idle_neutral_01', t, true); else maya.follow(deny, t, true);
    const free = pulse(t, deny.t0 - .35, deny.t0 + .05, deny.t0 + 3, deny.t0 + 3.6);
    if (free > 0) { maya.ik.R = maya.ik.L = null; if (free < 1) { maya.reach('R', keyR, 1 - free); maya.reach('L', keyL, 1 - free); } }
    if (free < .001) counterTyping(maya, t, 1);
    const glance = pulse(t, S(1) + .6, S(1) + 1.1, E(1) - .6, E(1));
    maya.look(screenAt, 1); maya.look(faceOf(woman), glance); maya.look(faceOf(rania), free);
    maya.look(faceOf(lena), pulse(t, S(9) + .2, S(9) + .7, E(9), E(9) + .4));
    maya.smile = t > S(9) ? .3 : .08;

    // The queue: one waits at the counter, another arrives.
    woman.reset(); woman.idle(t, 3); woman.sway = 0; woman.at(-1.3, -.3, rot).play('f_idle_neutral_02', t, true);
    young.reset(); young.idle(t, 4); young.sway = 0; young.g.visible = t >= yRoute.t0 - .1; young.follow(yRoute, t, true);
    woman.smile = young.smile = .1; woman.look(V(-2.5, 1.5, -.5), .6); young.look(V(-2.5, 1.5, -.5), .5);

    // Rania brings the request, waits, is refused and goes back with it.
    rania.reset(); rania.idle(t, 5); rania.sway = 0; rania.smile = .15;
    if (t < r1.t0) rania.at(R0[0], R0[1], rot).play('f_idle_neutral_02', t, true); else if (t < r2.t0) rania.follow(r1, t, true); else rania.follow(r2, t, true);
    rania.look(faceOf(maya), pulse(t, r1.t0 + 2.2, r1.t0 + 2.9, r2.t0 + 1.2, r2.t0 + 1.8));
    rania.flush(); rania.b.Bip01.getWorldPosition(body);
    const yaw = rania.g.rotation.y;
    request.position.copy(body).add(V(Math.sin(yaw) * .3, 0, Math.cos(yaw) * .3)).setY(1.12);
    request.rotation.set(0, yaw - Math.PI / 2, .7); request.updateMatrixWorld(true);
    rania.grasp('L', request, V(-.145, 0, -.095), V(1, 0, 0), 1);
    rania.grasp('R', request, V(-.145, 0, .095), V(1, 0, 0), 1);

    // Omar's screen shows that something is waiting to be fixed.
    const alert = ramp(t, S(2) + .2, S(2) + .9), reading = ramp(t, S(2) + .5, S(2) + 1.2);
    omar.reset(); omar.at(OX - w2.f.x * .1, OZ - w2.f.z * .1, OROT); omar.idle(t, 2); omar.sway = 0;
    omar.play('m_sit_table_idle_neutral_01', t, true);
    typing(omar, w2, t, 1 - reading); if (reading > 0) { omar.reach('R', w2.keyR, reading); omar.reach('L', w2.keyL, reading); }
    omar.gaze = .1; omar.smile = .06; omar.look(V(SX, 1.08, SZ), 1);
    glow.color.copy(calm).lerp(warn, alert);

    // Lina, the manager, comes to Shaima and agrees.
    lena.reset(); lena.idle(t, 6); lena.sway = 0; lena.smile = .25; lena.g.visible = true;
    if (t < lRoute.t0) { const start = lRoute.segs[0]; lena.at(start.x, start.z, start.yaw).play('f_idle_neutral_02', t, true); }
    else if (t < lNod.t0) lena.follow(lRoute, t, true); else lena.follow(lNod, t, true);
    lena.look(faceOf(maya), ramp(t, S(9) - .6, S(9)));

    for (const p of [maya, woman, young, rania, omar, lena]) p.g.visible = p.g.visible && !stage.conceptPage;
    request.visible = !stage.conceptPage;
    stage.outage = .1 * pulse(t, S(1), S(1) + 1, E(1), S(2));
    frameShots(stage, t, [
      hall,
      { t0: S(1) - 1.2, t1: S(1) + .4, ...counter },
      cutTo(S(2), desk),
      cutTo(close1 + .3, staff),
    ]);
  };
}
