// 1.03 One record passes three physical controls. A lock alone cannot deliver the service.
import { THREE,C,V,mesh,mat,rbox,box,cyl,sph,group,bar,folder,ramp,pulse,lerp } from './kit.js';
import { createPerson } from './people.js';
import { atCounter,SHOT } from './sets.js';
import { label,sign,showSprite,pawn,gate } from './objects.js';
import { conduit,caseCard,badge,stamp,frameShots,quietScreens,frac,clearForeground } from './astra.js';
import { placePerson,side,clamp,glyph } from './round2.js';
import { enter,hit,land,sentence } from './motion.js';
import { weight, exchange, acknowledge, beatWindow } from './colleagues.js';
import { shutter,shutterTrack,screwClamp,walkway,abutment } from './detailed-props.js';
export const texts=[1,3,6];
export const cast=['maya','citizen'];
export default async function({stage,scene,b,createCounter,S,E,ui}) {
 clearForeground(b);
 createCounter(scene);
 const maya=createPerson('maya',scene),applicant=createPerson('citizen',scene);
 const file=folder(scene,-2.28,1.09,.1,1.05);file.rotation.y=.3;file.userData.open(1);
 const root=group(scene,1.9,.12,.1);root.rotation.y=Math.PI/4;
 mesh(rbox(2.6,.12,1.25,.04),C.navy,0,.12,0,root);
 // The record is held between three connected mechanisms, all present from the start.
 const record=caseCard(root,0,1.72,0,1.35);record.rotation.x=1.08;
 const coreLabel=label('CASE 2048',root,0,2.4,.2,.18);
 const privacy=group(root,-.92,2.65,0),integrity=group(root,.92,2.65,0),available=group(root,0,.5,0);
 const stations=[privacy,integrity,available];
 const title=['Confidentiality','Integrity','Availability'].map((s,i)=>label(s,stations[i],0,i===2?-.22:.72,.2,.18));
 const checks=stations.map(g=>sign('ok',g,.43,.38,.15,.25));
 const connections=stations.map((g,i)=>conduit(root,[g.position.clone(),V(g.position.x*.6,1.65,.1),V(0,1.72,.2)],i===1?C.powderD:C.teal,.024));
 // Privacy: two solid sliding shutters and a small authorized opening.
 const shutters=[-1,1].map(s=>shutter(privacy,s));
 shutterTrack(privacy);
 const key=badge(privacy);key.scale.setScalar(.55);
 const unknown=pawn(root,-1.18,1.25,.8,.75),stopped=sign('stop',root,-1.15,1.86,.8,.28);
 const redaction=mesh(rbox(.49,.06,.6,.015),C.navy,0,.04,0,record);
 const privateLabel=label('A link is not permission',root,0,1.09,.7,.18);
 // Integrity: clamps keep the saved page fixed while a proposed replacement waits outside.
 const clamps=[-1,1].map(s=>screwClamp(integrity,s));
 const saved=caseCard(integrity,0,.28,0,.8);saved.rotation.x=1.05;
 const proposed=caseCard(root,1.65,2.9,.2,.8);proposed.rotation.x=1.05;
 const approval=stamp(integrity);approval.scale.setScalar(.7);
 const before=label('4821 · Saved',root,.95,2.38,.4,.16);
 const after=label('9305 · Reviewed',root,.95,2.38,.4,.16,C.teal);
 const pending=label('Change awaits review',root,0,3.8,.15,.18,C.amber);
 // Availability: a real hinged bridge carries a record into the service tray.
 const bridge=group(available,-.65,.17,0);
 walkway(bridge);
 for(const x of [-.9,.9])abutment(available,x);
 const courier=caseCard(available,0,.24,0,.45);
 const unavailable=sign('alert',available,0,.62,0,.32);
 const wait=label('Private + correct · Still waiting',root,0,1.0,.7,.17,C.amber);
 // The wrong destination is visibly separated from the intended tray.
 const wrong=group(root,-1.03,.56,.55),right=group(root,1.03,.56,.55);
 for(const p of [wrong,right])mesh(rbox(.47,.08,.45,.025),C.paper,0,0,0,p);
 const route=conduit(root,[V(0,1.65,.1),V(.7,1.1,.45),V(1.03,.64,.55)],C.teal,.022);
 const badRoute=conduit(root,[V(0,1.65,.1),V(-.7,1.1,.45),V(-1.03,.64,.55)],C.coral,.022);
 const wrongLabel=label('Wrong recipient',wrong,0,-.22,.2,.16,C.coral),rightLabel=label('Intended recipient',right,0,-.22,.2,.16);
 const publicBoard=group(root,0,1.55,.75);
 mesh(rbox(1.65,.82,.09,.03),C.paper,0,0,0,publicBoard);
 const friday=label('Open Friday',publicBoard,0,.05,.08,.24,C.coral),sunday=label('Open Sunday',publicBoard,0,.05,.08,.24,C.teal);
 const publicLabel=label('Public notice',publicBoard,0,.55,.05,.17);
 const oldNotice=await glyph(publicBoard,'OPEN FRIDAY',.17,'coral'),newNotice=await glyph(publicBoard,'OPEN SUNDAY',.17,'teal');
 oldNotice.position.z=newNotice.position.z=.09;
 const held=await glyph(saved,'4821',.2,'navy'),changed=await glyph(saved,'9305',.2,'teal'),asked=await glyph(proposed,'9305',.2,'amber');
 [held,changed,asked].forEach(o=>{o.rotation.x=-1.05;o.position.set(0,.09,0);});
 const questions=['Who may see?','Who may change?','Ready when needed?'].map((s,i)=>label(s,stations[i],0,i===2?.77:1.02,.3,.16));
 const origin=V(-.3,0,1.3);
 return t=>{
  atCounter(maya,applicant,t,1-ramp(t,S(6)+1,S(6)+2)+ramp(t,S(8),S(8)+.6));quietScreens(ui,t);
  const rise=ramp(t,S(0)-.1,S(0)+1.5);root.visible=rise>0;root.position.y=lerp(-1,.12,rise);
  const confidential=pulse(t,S(1),S(1)+.6,E(2)-.4,S(3));
  const authorized=pulse(t,S(1)+.8,S(1)+1.5,E(1)-.7,E(1));
  shutters.forEach((o,i)=>o.position.x=(i===0?-1:1)*(.22+.36*authorized));
  key.position.set(-.8+.8*authorized,.06,.25);key.visible=t>=S(1)&&t<S(2);
  unknown.visible=t>=S(2)&&t<S(3);showSprite(stopped,confidential*(t>=S(2)?1:0));
  redaction.visible=t>=S(2)&&t<S(3);showSprite(privateLabel,t>=S(2)&&t<S(3)?1:0);
  const change=pulse(t,S(3),S(3)+.6,E(5)-.2,S(6));
  const approve=ramp(t,S(5)+1,S(5)+2);
  proposed.visible=change>.01;
  proposed.position.set(lerp(1.8,.92,approve),2.94,lerp(.25,0,approve));
  proposed.rotation.z=.08*Math.sin(t*2)*(1-approve);
  clamps.forEach((o,i)=>o.position.x=(i===0?-1:1)*lerp(.38,.47,pulse(t,S(5)+.5,S(5)+1,S(5)+2,S(5)+2.4)));
  approval.position.set(0,lerp(.73,.35,pulse(t,S(5)+.8,S(5)+1.4,S(5)+2,S(5)+2.5)),0);
  showSprite(before,t>=S(3)&&t<S(5)+1.7?1:0);showSprite(after,t>=S(5)+1.7&&t<S(6)?1:0);
  showSprite(pending,change*(1-approve));
  const down=pulse(t,S(8),S(8)+.55,E(8)-.3,S(9));
  bridge.rotation.z=-down*1.1;
  courier.position.x=down>.1?-.72:lerp(-.9,.9,frac((t-S(6))*.3));
  courier.visible=t>=S(6)&&t<S(10);courier.rotation.y=.1*Math.sin(t);
  showSprite(unavailable,down);showSprite(wait,down);
  checks.forEach((o,i)=>showSprite(o,i===2?1-down:1));
  connections.forEach((o,i)=>o.update(t,rise*(i===2?1-down:1),.2,i*.3));
  const harmful=pulse(t,S(9),S(9)+.7,E(9)-.2,S(10));
  wrong.visible=right.visible=t>=S(9)&&t<S(10);route.update(t,0);badRoute.update(t,harmful,.3);
  showSprite(wrongLabel,harmful);showSprite(rightLabel,harmful);
  publicBoard.visible=t>=S(10)&&t<S(11);
  const correct=ramp(t,S(10)+.5,S(10)+1.25);publicBoard.rotation.y=correct*Math.PI*2;
  showSprite(friday,1-correct);showSprite(sunday,correct);showSprite(publicLabel,1);
  questions.forEach(o=>showSprite(o,ramp(t,S(11),S(11)+.7)));
  title.forEach(o=>showSprite(o,1));showSprite(coreLabel,t>=S(10)&&t<S(11)?0:1);
  frameShots(stage,t,[{x:1.9,y:2.2,z:.1,w:3.9,e:.55,f:.46},
   {t0:S(1)-.5,t1:S(1)+.6,x:1.6,y:2.3,z:.4,w:3.65,e:.5,f:.45},
   {t0:S(3)-.5,t1:S(3)+.6,x:2.1,y:2.5,z:-.1,w:3.65,e:.5,f:.45},
   {t0:S(6)-.5,t1:S(6)+.7,x:1.9,y:1.65,z:.1,w:3.5,e:.65,f:.43},
   {t0:S(7)-.3,t1:S(7)+.3,x:1.9,y:2.1,z:.1,w:3.9,e:.55,f:.46},
   {t0:S(8)-.3,t1:S(8)+.4,x:1.9,y:1.65,z:.1,w:3.5,e:.55,f:.43},
   {t0:S(10)-.3,t1:S(10)+.4,x:2.4,y:1.7,z:.6,w:2.5,e:.42,f:.44},
   {t0:S(11)-.3,t1:S(11)+.7,x:1.9,y:2.25,z:.1,w:4.1,e:.55,f:.46}]);
  // One control between two people. Preserve the original shutter/clamp/bridge actions.
  for(const [i,p] of [maya,applicant].entries()){
   p.reset();p.idle(t,i);placePerson(p,origin,i===0?-.88:.88,.15,i===0?1.02:.48);
   p.look(origin.clone().add(side(0,.7,.6)),1);
  }
  file.visible=false;root.visible=true;root.position.copy(origin).add(side(0,-.15,.65));root.scale.setScalar(1.12);
  root.children[0].visible=false;connections.forEach(c=>c.g.visible=false);
  let station=t<S(3)?0:t<S(6)?1:2;
  if(t>=S(11))station=Math.min(2,Math.floor(ramp(t,S(11),E(11))*3));
  if(t<S(1))station=Math.min(2,Math.floor(ramp(t,S(0),E(0))*3));
  stations.forEach((g,i)=>{g.visible=i===station&&!(t>=S(9)&&t<S(11));g.position.set(0,.38,0);g.scale.setScalar(i===2?1:1.35);});
  record.visible=station===0&&privacy.visible;record.position.set(0,.55,-.1);record.scale.setScalar(1.1);
  key.position.set(lerp(-.7,0,authorized),.04,.28);
  unknown.visible=t>=S(2)&&t<S(3);unknown.position.set(-.78,.3,.25);unknown.scale.setScalar(.7);
  proposed.visible=station===1&&change>.01;proposed.position.set(lerp(.84,0,approve),.8,.08);proposed.scale.setScalar(.9);
  approval.visible=station===1;approval.position.y=lerp(.4,.1,pulse(t,S(5)+.8,S(5)+1.4,S(5)+2,S(5)+2.5));
  publicBoard.position.set(0,.72,.12);publicBoard.scale.setScalar(1.05);
  wrong.position.set(-.72,.38,.2);right.position.set(.72,.38,.2);
  badRoute.g.visible=false;route.g.visible=false;
  // At the wrong-information example, the applicant receives the misrouted record.
  courier.visible=station===2&&!(t>=S(10)&&t<S(11));
  if(t>=S(9)&&t<S(10)){available.visible=true;bridge.visible=false;courier.position.x=lerp(.7,-.72,ramp(t,S(9),S(9)+1.4));}
  else bridge.visible=true;
  if(down>.1){applicant.smile=.01;applicant.bend=.08*down;}
  stopped.visible=false;
  held.visible=t<S(5)+1.7;changed.visible=!held.visible;checks[1].visible=false;
  oldNotice.visible=correct<.5;newNotice.visible=!oldNotice.visible;
  const beat=sentence(t,S,12),start=S(beat);
  // Each control lands in the common demonstration area, then performs its job.
  let arrival=start;
  if(beat===0)arrival=S(0)+(E(0)-S(0))*station/3;
  if(beat===11)arrival=S(11)+(E(11)-S(11))*station/3;
  stations.forEach(g=>g.rotation.z=0);
  // All controls are visible in the recap; hidden landing/impact poses cannot carry over.
  saved.position.y=.28;approval.rotation.z=0;
  // Wider tracks and clamp handles stay below faces at the top of their entrance drops.
  stations[station].position.y=.38+land(t,arrival,station===2?.32:.08,.4);
  stations[station].rotation.z=.035*hit(t,arrival+.4);
  if(station===0){
   const seal=beat===2?ramp(t,start+.35,start+.68):0;
   shutters.forEach((o,i)=>{const s=i===0?-1:1;o.position.x=s*(.22+.36*authorized+.38*(1-enter(t,arrival,.4))-.025*hit(t,start+.68)*seal);});
   if(beat===2){
    shutters.forEach((o,i)=>o.position.x=(i===0?-1:1)*(.22+.36*(1-seal)+.025*hit(t,start+.68)));
    unknown.position.x=lerp(-1.12,-.66,ramp(t,start+.1,start+.85))-.1*hit(t,start+.85);
    unknown.position.y=.3+land(t,start,.2,.35);
    unknown.rotation.z=-.12*hit(t,start+.85);
   }
   record.position.y=.55+.045*hit(t,arrival+.4);
  }
  if(station===1){
   const bite=ramp(t,start+.55,start+.85),review=beat===5?pulse(t,start+.55,start+.85,start+1.6,start+2):0;
   clamps.forEach((o,i)=>{o.position.x=(i===0?-1:1)*(.38+.23*(1-bite)+.15*review+.025*hit(t,start+.85));});
   saved.position.y=.28+land(t,arrival,.25,.42);
   // A proposed edit strikes the closed clamps and recoils; only review admits it.
   if(beat===4){proposed.visible=true;proposed.position.x=lerp(1.05,.53,ramp(t,start+.3,start+1.15))+.14*hit(t,start+1.15);proposed.rotation.z=.14*hit(t,start+1.15);}
   if(beat===3)proposed.position.y=.8+land(t,start+.45,.26,.4);
   if(beat===5){approval.position.y=.1+.5*(1-pulse(t,start+.5,start+1.2,start+1.5,start+2.1));approval.rotation.z=.09*hit(t,start+1.2);saved.position.y+=.04*hit(t,start+1.2);}
  }
  // Keep the proposed number in front of both clamps throughout approach/review.
  proposed.position.z=.66;
  clamps.forEach((o,i)=>o.userData.handle.rotation.y=(i?1:-1)*(.7*ramp(t,start+.55,start+.85)-.9*(beat===5?pulse(t,start+.55,start+.85,start+1.6,start+2):0)));
  // Retrieval fails physically: the bridge drops and the case tumbles into the gap.
  courier.position.y=.24;courier.position.z=0;courier.rotation.z=0;
  if(beat===8){
   const crossing=ramp(t,start,start+.6),fall=clamp((t-start-.6)/.65);
   bridge.rotation.z=-1.45*enter(t,start+.45,.4);
   courier.position.x=lerp(-.9,-.1,crossing);courier.position.y=.24-.38*fall*fall+.035*hit(t,start+1.25);
   courier.rotation.z=-.75*fall;
  }else if(station===2&&beat!==9){
   bridge.rotation.z=-.32*(1-enter(t,arrival,.45));
   courier.position.y=.24+land(t,arrival,.22,.35);
   if(beat===7){courier.position.x=lerp(-.9,.9,ramp(t,start+.2,E(7)-.1));}
  }
  if(beat===9){courier.position.y=.075+land(t,start,.24,.4);courier.position.z=.2;courier.rotation.z=.15*hit(t,start+1.4);wrong.rotation.z=.08*hit(t,start+1.4);}
  else wrong.rotation.z=0;
  // Wrong delivery is harm, not a successful availability check.
  checks[2].visible=beat!==9&&checks[2].visible;
  unavailable.position.set(beat===9?-.72:0,beat===9?.45:.62,beat===9?.2:0);
  if(beat===9)showSprite(unavailable,1);
  // The short "together" sentence needs all three controls in the same picture.
  if(beat===7){
   stations.forEach((g,i)=>{g.visible=true;g.position.set([-.86,0,.86][i],.38,0);g.scale.setScalar(i===2?.42:.5);});
   record.visible=true;record.position.set(-.86,.65,-.1);record.scale.setScalar(.5);key.visible=true;
  }
  publicBoard.position.y=.72+land(t,S(10),.35,.45);publicBoard.rotation.z=.08*hit(t,S(10)+.45);
  // Reaching and withdrawing follow the action rather than holding one pose throughout.
  const gesture=pulse(t,start+.1,start+.55,Math.min(start+1.6,E(beat)-.3),E(beat));
  maya.present('R',root.localToWorld(V(0,.8,.1)),gesture);
  maya.bend=.08*gesture;applicant.bend=(beat===2||beat===8||beat===9?-.08:.08)*gesture;
  applicant.smile=beat===2||beat===4||beat===8||beat===9?.01:.32;
  if(beat===8||beat===9){
   const back=.09*ramp(t,start+.7,start+1.25);placePerson(applicant,origin,.88+back,.15,.48);applicant.leg('R',-.12*gesture,.18*gesture);
   applicant.present('L',maya.g.position.clone().setY(1),gesture);
  }
  weight(maya,t,1);weight(applicant,t,3);
  const examine=root.localToWorld(V(0,.85,.1));
  exchange(maya,applicant,examine,t,start,E(beat));
  exchange(applicant,maya,examine,t,start,E(beat),.4);
  maya.smile=[2,4,8,9].includes(beat)?.01:.12;
  applicant.smile=[2,4,8,9].includes(beat)?.01:beat===5?.22:.08;
  // The applicant examines the result, checks with Shaima, and quietly acknowledges it.
  if(beat===5||beat===10)acknowledge(applicant,t,start+1.7);
  if(beat===4||beat===9)acknowledge(applicant,t,start+1.5,true);
  if(beat===2){
   const relief=ramp(t,start+1,start+2);applicant.smile=.02+.16*relief;
   acknowledge(maya,t,start+1.5);
  }
  if(beat===8){
   const concern=beatWindow(t,start+.8,E(beat));
   applicant.look(maya.g.position.clone().setY(1.5),concern);
   maya.look(applicant.g.position.clone().setY(1.5),beatWindow(t,start+1.25,E(beat)));
  }
  stage.focus=t>=S(10)&&t<S(11)?publicBoard:stations[station];
  frameShots(stage,t,[{x:origin.x,y:.64,z:origin.z,w:2.95,e:.24,f:.39}]);
 };
}
