// A text, then a call.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['finance', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.2',
  actors: { finance: 'beside', omar: 'desk' },
  bankCard: ['finance', S(11), E(11)],
  handsets: { finance: [[0,S(5),'chat'], [S(5),S(11),'mobile'], [E(11),D.T,'credit-card']] },
  shots: [[0,'pair'], [S(1),'finance'], [S(4),'pair'], [S(5),'finance'], [S(10),'finance'], [S(13),'pair']],
  actions: {
    finance: [[0,S(5),'text'], [S(5),S(10),'call'], [S(10),S(11),'text'], [S(11),E(11),'call'], [S(12),D.T,'text']],
    omar: [[0,S(4),'read'], [S(4),D.T,'listen','finance']],
  },
  plates: [[S(0),E(0),'Noura · Finance'], [S(1),E(1),'Salary account suspended'], [S(6),E(6),'Caller asks for a code'], [S(10),E(10),'Call ended'], [S(13),E(13),'Work phone report']],
  pages: [
    hero(S(3), S(4), 'Official bodies do not ask for bank details by text', 'mobile+credit-card', [
      ['Salary account', S(3), 'v-amber'],
    ]),
    hero(S(7), S(9), 'SMS phishing and voice phishing', 'mobile+chat', [
      ['Text followed by a call', S(7), 'v-amber'],
    ]),
    hero(S(9), S(10), 'Never share a verification code', 'mobile+lock', [
      ['One-time passcode', S(9), 'v-amber'],
    ]),
    hero((S(11)+E(11))/2, S(13), 'Hang up, then call a known number', 'credit-card+mobile', [
      ['Number on the bank card', S(11), 'v-teal'],
    ]),
  ],
}));
