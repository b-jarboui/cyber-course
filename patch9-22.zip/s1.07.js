// 1.07 Different actors, overlapping motives: three real incidents, then the analyst separates evidence from claims.
import { V, pulse } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, chain, mail, reveal } from './screens.js';
import { office, seat1, seat2, typing, timer, SHOT } from './sets.js';

export const texts = [1, 3, 5, 6];
export const cast = ['priya', 'omar'];

export default function ({ stage, scene, S, E, ui }) {
  const rania = createPerson('priya', scene), omar = createPerson('omar', scene), { w1, w2 } = office(scene);

  return t => {
    const k = timer(t, S);
    rania.reset(); omar.reset(); seat1(rania); seat2(omar); rania.idle(t, 1); omar.idle(t, 2);
    typing(rania, w1, t, 1 - pulse(t, S(1) + 0.4, S(1) + 1, S(3) - 0.5, S(3)) - pulse(t, S(8) + 0.4, S(8) + 1, S(9), S(9) + 0.5));
    typing(omar, w2, t);
    rania.bend = 0.18 * pulse(t, S(1) + 0.4, S(1) + 1, S(3) - 0.5, S(3));
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), q => win('Three incidents at public bodies', reveal([row('Payment request', 'Money sought', 'warn'), row('Confidential plans', 'Copied', 'warn'), row('Public portal', 'Interrupted', 'warn')], q * 1.3))],
      [S(1), S(2), win('Rania’s inbox', mail('Supplier Accounts', 'Finance request', 'New bank details for invoice 771', 'Please pay today. Our account has changed.') + note('Fraud for profit. The payment stays on hold.', 'warn'))],
      [S(2), S(3), q => win('Omar’s case board', head('One crime, several specialists') + reveal([row('Account A', 'Wrote the message'), row('Account B', 'Received the money'), row('Account C', 'Sold stolen logins')], q * 1.3))],
      [S(3), S(4), win('Confirmed case summary', row('Target', 'Strategic planning files', 'no') + row('Purpose', 'Intelligence', 'warn') + row('State sponsorship', 'Confirmed by specialists', 'warn'))],
      [S(4), S(5), q => win('Two things at once', row('Counter', 'Working normally', 'ok') + (q > 0.4 ? row('Copy of records', 'Outside Sadeed', 'no') : '') + note('Everything looks fine while information leaves.', 'warn'), 'alert')],
      [S(5), S(6), win('Sadeed public portal', row('Service', 'Unavailable', 'no') + row('Front page', 'Replaced by a political slogan', 'no') + note('Applicants cannot reach the service.', 'no'), 'alert')],
      [S(6), S(7), q => win('Mixed motives, actor unconfirmed', reveal([row('Demand', 'Money', 'warn'), row('Message', 'Political claim', 'warn'), row('Records', 'Disclosed', 'no')], q * 1.3))],
      [S(7), S(8), win('Analyst’s note', row('Claim', 'A group says it did this', 'warn') + row('Evidence', 'Does not confirm it', 'no') + note('Attribution unconfirmed.', 'warn'))],
      [S(8), S(9), q => win('Rania notices', row('Payment change', 'Unexpected', 'warn') + row('Affected', 'A supplier’s invoice', 'warn') + (q > 0.5 ? row('Reported', 'Reference 3188', 'ok') : ''))],
      [S(9), S(10), win('Omar’s team', row('Report received', 'Rania', 'ok') + row('Who did it?', 'Specialists assess this', 'wait') + note('Rania goes back to protecting her work.'))],
      [S(10), E(10) + 0.4, q => win('The practical question', reveal([row('Affected service', 'Payments', 'hi'), row('Affected information', 'Supplier records', 'hi'), row('Access reviewed', 'Today', 'ok'), row('Backup process', 'Ready', 'ok')], q))],
    ]);

    stage.shots(t, [
      SHOT.both,
      { t0: S(1) - 0.4, t1: S(1) + 0.3, ...SHOT.seated },
      { t0: S(2) - 0.4, t1: S(2) + 0.3, ...SHOT.seated2 },
      { t0: S(6) - 0.4, t1: S(6) + 0.4, ...SHOT.both },
      { t0: S(7) - 0.4, t1: S(7) + 0.3, ...SHOT.seated2 },
      { t0: S(8) - 0.4, t1: S(8) + 0.3, ...SHOT.seated },
      { t0: S(9) - 0.4, t1: S(9) + 0.3, ...SHOT.seated2 },
      { t0: S(10) - 0.4, t1: S(10) + 0.4, ...SHOT.both },
    ]);
  };
}
