// Whose orders is the agent following?
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['official', 'maya', 'omar', 'priya'];
export default chapterHall((S, E, D) => ({
  lesson: '6.4',
  actors: { official: 'director', maya: 'counter', omar: 'colleague', priya: 'visitor' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'gathering'], [S(1), 'counterDisplay'], [S(3), 'staff'], [S(4), 'her'], [S(7), 'counter'], [S(8), 'gathering'], [S(14), 'counterDisplay'], [S(15), 'counter']],
  actions: {
    official: [[0, S(7), 'paper'], [S(7), S(8), 'listen', 'priya'], [S(8), D.T, 'talk', 'priya']],
    maya: [[0, S(7), 'read'], [S(7), S(9), 'listen', 'priya'], [S(9), D.T, 'read']],
    omar: [[0, S(3), 'listen', 'official'], [S(3), S(7), 'point'], [S(7), D.T, 'listen', 'official']],
    priya: [[0, S(7), 'listen', 'maya'], [S(7), S(8), 'talk', 'official'], [S(8), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(1), 'file', 'Pilot agent · Day 1 log', 'neutral'],
      [S(1), S(2), 'mail', 'Collect and send files', 'alert'],
      [S(2), S(14), 'key', 'Action refused · No permission', 'safe'],
      [S(14), D.T, 'file', 'Log: Agent name · Owner name', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Agent task changed'],
    [S(2), E(2), 'Request refused · No send rights'],
    [S(7), E(7), "Request to borrow Hamad's login"],
    [S(8), E(8), 'Refused · Own identity only'],
  ],
  pages: [
    hero(S(4), S(7), "Hidden text can change an agent's goal", 'made/own_file+made/signpost', [
      ['Agent goal hijacking: works for the attacker', S(4), 'v-coral'],
      ['What an agent can do matters most', S(6), 'v-teal'],
    ]),
    hero(S(9), S(12), 'No borrowed logins: own identity, least access', 'made/id_badge+made/key_cabinet', [
      ['Borrowed login inherits every right', S(9), 'v-coral'],
      ['Excessive agency: too many powers or tools', (S(9) + E(9)) / 2, 'v-amber'],
    ]),
    hero(S(12), S(15), 'A named owner for every agent', 'made/register_book+made/own_clock', [
      ['Unique identity and short-lived credentials', S(12), 'v-teal'],
      ['Log records agent name and owner name', S(14), 'v-navy'],
    ]),
    hero(S(15), D.T, 'Protect your login', 'made/own_key+made/own_bell', [
      ['Never link an agent to your own login', S(15), 'v-coral'],
      ['Asks for more access? Stop and report', (S(15) + E(15)) / 2, 'v-amber'],
    ]),
  ],
}));
