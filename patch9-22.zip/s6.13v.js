// When agents trust each other.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '6.4',
  actors: { maya: 'counter', omar: 'colleague', official: 'director' },
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'her'], [S(3), 'staff'], [S(5), 'her'], [S(14), 'gathering'], [S(15), 'counter']],
  actions: {
    maya: [[0, S(2), 'read'], [S(2), S(3), 'type'], [S(3), S(14), 'read'], [S(14), D.T, 'listen', 'official']],
    omar: [[0, S(3), 'listen', 'maya'], [S(3), S(14), 'paper'], [S(14), D.T, 'listen', 'official']],
    official: [[0, S(14), 'listen', 'omar'], [S(14), D.T, 'talk', 'omar']],
  },
  displays: {
    counter: [
      [0, S(1), 'computer', 'Two-agent pilot · Reminder draft', 'neutral'],
      [S(1), S(2), 'mail', 'Extra line · Send ID copy', 'alert'],
      [S(2), S(14), 'bell', 'Draft blocked and reported', 'safe'],
      [S(14), D.T, 'file', 'Every agent handover logged', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Two agents · Check and draft'],
    [S(1), E(1), 'Unwritten line in reminder draft'],
    [S(3), E(3), 'Tool reply passed to Agent 2'],
    [S(14), E(14), 'Every handover recorded in log'],
  ],
  pages: [
    hero(S(5), S(8), "A tool's reply is information, not an order", 'made/own_link+made/own_file', [
      ['Hidden orders can sit in tool descriptions', S(6), 'v-coral'],
      ['Injection in an agent can trigger actions', S(7), 'v-amber'],
    ]),
    hero(S(8), S(12), 'One poisoned note can travel down the chain', 'made/own_chat+made/parcel+made/own_mail', [
      ['Agents often trust other agents by default', S(10), 'v-coral'],
      ['One flaw can cascade across the chain', S(11), 'v-amber'],
    ]),
    hero(S(12), S(15), 'A message from another agent is outside text', 'made/key_cabinet+made/register_book', [
      ['Each agent gets only its own job access', S(12), 'v-teal'],
      ['Log every handover; humans approve critical steps', S(13), 'v-navy'],
    ]),
    hero(S(15), D.T, 'Do not approve unexpected orders', 'made/rubber_stamp+made/own_bell', [
      ['Odd line in draft, tool or agent note?', S(15), 'v-coral'],
      ['Stop, verify through official channel, report', (S(15) + E(15)) / 2, 'v-teal'],
    ]),
  ],
}));
