import { AR } from './i18n.js';
// Reusable sets: pieces of furniture and models that several scenes share.
import { THREE, C, V, mat, mesh, rbox, box, group, bar, metal, laptop, monitor, officeChair, ramp, pop } from './kit.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { teachTable, plate, records, appModule, terminal, tower, powerBox, personPin, chipId, label, track, packet, showSprite, sign } from './objects.js';

export const TABLE = V(-1.35, 0, -0.3), TOP = 0.965;
// Free models (CC0), loaded once per scene.
const glb = new GLTFLoader();
export async function model(name, parent, x, y, z, height, rotY = 0) {
  const g = (await glb.loadAsync(`assets/${name}.glb`)).scene;
  const box = new THREE.Box3().setFromObject(g), size = box.getSize(V(0, 0, 0));
  const k = height / size.y;
  g.scale.setScalar(k); g.position.set(x - (box.min.x + size.x / 2) * k, y - box.min.y * k, z - (box.min.z + size.z / 2) * k);
  g.traverse(o => { if (o.isMesh) { o.castShadow = o.receiveShadow = true; } });
  const holder = group(parent, 0, 0, 0); holder.add(g); holder.rotation.y = 0;
  if (rotY) { g.rotation.y = rotY; }
  return g;
}
export const table = scene => teachTable(scene, TABLE.x, TABLE.z);
// Timing helper: k(i) rises over the start of sentence i.
export const timer = (t, S) => (i, d = 0.7, o = 0) => ramp(t, S(i) + o, S(i) + o + d);
export const lerpTo = (o, a, b, k) => o.position.lerpVectors(a, b, k);
export function showAt(o, k, base) { pop(o, k, base ?? o.userData.s ?? 1); }
export function grow(o, k, s = 1) { o.userData.s = s; pop(o, k, s); return o; }

export function desk(parent, x, z, rotY = 0, w = 1.8, d = 0.9) {
  const g = group(parent, x, 0, z); g.rotation.y = rotY;
  mesh(rbox(w, 0.06, d, 0.02), mat('#f3ecdf', { roughness: 0.6 }), 0, 0.75, 0, g);
  mesh(rbox(0.46, 0.68, d - 0.1, 0.02), C.navy, w / 2 - 0.3, 0.38, 0, g);
  for (const y of [0.2, 0.42, 0.62]) mesh(rbox(0.1, 0.016, 0.014, 0.005), C.metal, w / 2 - 0.3, y, d / 2 - 0.045, g);
  mesh(box(w - 0.3, 0.5, 0.03), C.navyD, -0.05, 0.47, -d / 2 + 0.06, g);
  for (const sx of [-1]) for (const sz of [-1, 1]) mesh(rbox(0.06, 0.72, 0.06, 0.02), C.metal, sx * (w / 2 - 0.08), 0.36, sz * (d / 2 - 0.08), g);
  g.userData.top = 0.78;
  return g;
}
// A seat for someone working at a desk: the desk is in front of them, towards the camera.
export function workplace(scene, x, z, rot = 0.78) {
  const f = V(Math.sin(rot), 0, Math.cos(rot));
  const d = desk(scene, x + f.x * 0.68, z + f.z * 0.68, rot + Math.PI);
  officeChair(scene, x - f.x * 0.06, z - f.z * 0.06, rot);
  const lap = laptop(scene, x + f.x * 0.52, 0.78, z + f.z * 0.52, rot + Math.PI, 1.05);
  return { desk: d, laptop: lap, f, keyL: V(x + f.x * 0.46 + f.z * 0.12, 0.875, z + f.z * 0.46 - f.x * 0.12), keyR: V(x + f.x * 0.46 - f.z * 0.12, 0.875, z + f.z * 0.46 + f.x * 0.12) };
}

// Everything a public service depends on, laid out on three plates in front of the counter.
export function dependencies(scene) {
  const y = 0.1, g = group(scene);
  const base = (x, z, w, d, c) => { const p = group(g, x, 0, z); mesh(rbox(w, 0.1, d, 0.03), c, 0, 0.05, 0, p); mesh(box(w + 0.05, 0.03, d + 0.05), C.sandD, 0, 0.015, 0, p); return p; };
  const assets = base(-3, 3.15, 1.85, 1.55, '#f6f0e4'), ids = base(-1.0, 3.15, 1.85, 1.55, '#f1ece4'), deps = base(1.15, 3.15, 2.1, 1.55, '#e6e2d9');
  const P = {
    assets, ids, deps,
    citizenRecord: records(assets, -0.5, y, -0.35, 0.82), staffRecord: records(assets, 0.42, y, -0.35, 0.82, C.tealD),
    device: group(assets, -0.45, y, 0.35), app: appModule(assets, 0.42, y, 0.35, 0.9),
    person: personPin(ids, -0.5, y, -0.25, 1.1), deviceId: chipId(ids, 0.45, y, -0.3, 1.1, C.powderD), appId: chipId(ids, -0.45, y, 0.38, 1.1, C.teal), agentId: chipId(ids, 0.45, y, 0.38, 1.1),
    identity: appModule(deps, -0.62, y, -0.32, 0.9, '#e7eef6'), pay: terminal(deps, 0.55, y, -0.32, 1.05), telecom: tower(deps, -0.55, y, 0.34, 1), power: powerBox(deps, 0.55, y, 0.32, 0.9),
  };
  mesh(rbox(0.42, 0.028, 0.3, 0.01), C.metal, 0, 0.014, 0, P.device);
  const lid = mesh(rbox(0.42, 0.27, 0.018, 0.01), C.metal, 0, 0.15, -0.15, P.device); lid.rotation.x = -0.28;
  P.feed = track(g, [[-1.75, 1.05], [-1.75, 2.1], [-3, 2.1], [-3, 2.42]], C.teal, 0.008);
  P.link1 = track(g, [[-2.08, 3.15], [-1.92, 3.15]], C.teal, 0.1);
  P.link2 = track(g, [[-0.08, 3.15], [0.1, 3.15]], C.navyL, 0.1);
  P.labels = {
    citizenRecord: label("Applicant's record", g, -3.5, 0.92, 2.8), staffRecord: label('Employee file', g, -2.58, 0.92, 2.8), device: label('Device', g, -3.45, 0.72, 3.5), app: label(AR ? 'Software application' : 'Application', g, -2.58, 0.68, 3.5),
    person: label('Person', g, -1.5, 0.8, 2.9), deviceId: label('Device', g, -0.55, 0.62, 2.85), appId: label(AR ? 'Software application' : 'Application', g, -1.45, 0.62, 3.53), agentId: label('AI agent', g, -0.55, 0.62, 3.53),
    identity: label('Identity checks', g, 0.53, 0.68, 2.83), pay: label('Payments', g, 1.7, 0.62, 2.83), telecom: label('Communications', g, 0.6, 1.02, 3.5), power: label('Electricity', g, 1.7, 0.84, 3.47),
  };
  Object.values(P.labels).forEach(l => showSprite(l, 0));
  return P;
}

// Shared staging for the service counter: Shaima at work, the applicant waiting.
export const SHOT = {
  shaima: { x: -2.62, y: 1.62, z: -0.4, w: 2.2, e: 0.42, f: 0.24 },
  counter: { x: -1.95, y: 1.15, z: -0.3, w: 3.1, e: 0.42 },
  applicant: { x: -1.5, y: 1.2, z: -0.25, w: 2.5, e: 0.42 },
  seated: { x: -3.0, y: 1.32, z: -1.9, w: 2.4, e: 0.42, f: 0.24 },
};
const K = V(-2.46, 1.111, -0.45), M = V(-2.1, 1.47, -0.66), _h = V(0, 0, 0);
export function atCounter(maya, applicant, t, work = 1) {
  maya.reset(); applicant.reset();
  maya.at(-2.8, -0.45, 1.5 + 0.3 * work); applicant.at(-1.3, -0.3, -Math.PI / 2);
  maya.idle(t, 2); applicant.idle(t);
  maya.bend = 0.08 * work;
  counterTyping(maya,t,work);
  maya.look(applicant.g.position.clone().setY(1.5), 1 - work);
  if (work > 0) maya.look(M, work);
  applicant.look(V(-3, 1.5, -0.4), 1);
  maya.smile = 0.3; applicant.smile = 0.25;
}
export function counterTyping(p,t,k=1) {
  for(const side of ['R','L'])p.reach(side,_h.copy(K).add(V(0,0,side==='R'?.095:-.095)),k,null,
    {grip:.15,profile:'typing',time:t,quaternion:new THREE.Quaternion().setFromAxisAngle(V(1,0,0),Math.PI),keyHeight:1.077});
}
export function typing(p, w, t, k = 1) {
  p.gaze = 0.45 * k;
  p.reach('L', w.keyL, k,null,{profile:'typing',time:t});
  p.reach('R', w.keyR, k,null,{profile:'typing',time:t});
}

// Two work desks, used by the scenes set in the office.
SHOT.seated2 = { x: -0.3, y: 1.32, z: -2.3, w: 2.4, e: 0.42, f: 0.24 };
SHOT.both = { x: -1.7, y: 1.35, z: -2.2, w: 4.6, e: 0.5, f: 0.24 };
export function office(scene) { return { w1: workplace(scene, -3.3, -2.2), w2: workplace(scene, -0.6, -2.6) }; }
export const seat1 = p => { p.at(-3.25, -2.15, 0.78); p.sit(1); };
export const seat2 = p => { p.at(-0.55, -2.55, 0.78); p.sit(1); };
// Holding the telephone to the ear: the hand rises beside the head.
export function call(p, k, side = 'R') {
  if (k <= 0) return;
  const x = side === 'R' ? -13 : 13;
  p.reach(side, p.g.localToWorld(V(x, p.dy < -0.2 ? 124 : 158, 4)), k, V(side === 'R' ? -1 : 1, -0.6, -0.2));
}
