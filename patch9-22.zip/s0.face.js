// Close look at faces and hijabs, used only to review the people.
import { createPerson } from './people.js';

export const cast = ['maya', 'priya', 'lena', 'legal'];

export default function ({ stage, scene }) {
  const list = cast.map((n, i) => createPerson(n, scene).at(-0.9 + i * 0.6, 1.2, i % 2 ? -0.25 : 0.25));
  stage.dir.set(0, 0.06, 1).normalize(); stage.lockDir = true;
  return t => {
    list.forEach((p, i) => { p.reset(); p.idle(0.4, i); p.blink = 0; p.smile = 0.5; });
    stage.shots(t, [{ x: 0, y: 1.42, z: 1.2, w: 2.5 }]);
  };
}
