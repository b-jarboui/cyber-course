// Access that should have ended.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['lena', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '4.3',
  actors: { lena: 'desk', official: 'beside' },
  shots: [[0, 'pair'], [S(1), 'display'], [S(3), 'pair'], [S(7), 'desk'], [S(12), 'display'], [S(13), 'pair']],
  actions: {
    lena: [[0, S(12), 'read'], [S(12), S(13), 'type'], [S(13), D.T, 'listen', 'official']],
    official: [[0, S(13), 'listen', 'lena'], [S(13), D.T, 'talk', 'lena']],
  },
  displays: {
    desk: [[0, S(1), 'folder', 'External access list', 'neutral'], [S(1), S(12), 'calendar', 'Contract ended · Active', 'alert'], [S(12), S(13), 'file-text', 'Procurement record', 'safe'], [S(13), D.T, 'tick', 'Removal requested', 'safe']],
  },
  plates: [[S(0), E(0), 'Lena · Procurement'], [S(1), E(1), 'Contract ended · Active'], [S(12), E(12), 'Procurement record'], [S(13), E(13), 'Removal requested']],
  pages: [
    hero(S(3), S(7), 'External access needs an owner', 'made/id_badge+made/register_book', [
      ['Identity lifecycle', S(3), 'v-navy'],
      ['Third-party breach risk', S(6), 'v-amber'],
    ]),
    hero(S(7), S(9), 'Set an end date', 'calendar+clock', [
      ['Temporary must not become permanent', S(8), 'v-amber'],
    ]),
    hero(S(9), S(11), 'Role changed? Review access', 'made/id_badge+setting', [
      ['Remove access from old role', S(10), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Contract ended? Remove access', 'calendar+shield+bell', [
      ['Approved removal process', S(13), 'v-teal'],
      ['Report mismatched access', S(14), 'v-teal'],
    ]),
  ],
}));
