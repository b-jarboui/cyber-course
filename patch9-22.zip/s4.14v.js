// Every identity, human or automated.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'comms', 'official', 'omar', 'priya', 'lena'];
export default chapterHall((S, E, D) => ({
  lesson: '4.3',
  actors: { maya: 'counter', comms: 'signer', official: 'director', omar: 'colleague', priya: 'team', lena: 'teamEnd' },
  enter: { official: S(1), omar: S(1), priya: S(1), lena: S(1) },
  file: [[0, S(1), 1, 0], [S(15), E(15), 0, 1]],
  habits: true,
  shots: [[0, 'counter'], [S(1), 'gathering'], [S(2), 'counterDisplay'], [S(3), 'gathering'], [S(11), 'habits'], [S(15), 'file']],
  actions: {
    maya: [[0, S(1), 'file'], [S(1), S(15), 'listen', 'official'], [S(15), D.T, 'file']],
    comms: [[0, S(1), 'listen', 'maya'], [S(1), D.T, 'listen', 'official']],
    official: [[S(1), D.T, 'talk', 'maya']],
    omar: [[S(1), D.T, 'listen', 'official']],
    priya: [[S(1), D.T, 'listen', 'official']],
    lena: [[S(1), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [[0, S(2), 'tick', 'Case 2048 closed', 'safe'], [S(2), S(15), 'setting', 'Staff · App · AI agent', 'safe'], [S(15), D.T, 'folder', 'Next case', 'neutral']],
  },
  plates: [[S(0), E(0), 'Case 2048 closed'], [S(1), E(1), 'Hamad · Manager'], [S(2), E(2), 'Staff · App · AI agent'], [S(15), E(15), 'Next case']],
  pages: [
    hero(S(3), S(5), 'One governed identity for every actor', 'made/id_badge+computer+setting', [
      ['Own identity and defined owner', S(4), 'v-teal'],
    ]),
    hero(S(5), S(10), 'Only the access needed', 'shield+made/key_cabinet', [
      ['No payment or identity powers', S(6), 'v-amber'],
      ['Human approval for key decisions', S(7), 'v-teal'],
    ]),
    hero(S(10), S(14), 'Review, monitor and remove', 'zoom+calendar+lock', [
      ['Retire unused identities', S(10), 'v-teal'],
      ['Protect every account', S(11), 'v-navy'],
    ]),
    hero(S(14), S(15), 'Stop, verify and report', 'shield+made/register_book+bell', [
      ['Report early through the approved route', S(14), 'v-teal'],
    ]),
  ],
}));
