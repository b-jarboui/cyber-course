// One Allow opens every door.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '5.2',
  actors: { maya: 'counter', omar: 'colleague', official: 'director' },
  enter: { official: S(12) },
  handsets: { omar: [[0, S(12), 'setting']] },
  shots: [[0, 'counter'], [S(1), 'staff'], [S(2), 'counterDisplay'], [S(3), 'her'], [S(7), 'staff'], [S(12), 'gathering'], [S(13), 'counterDisplay'], [S(14), 'counter']],
  actions: {
    maya: [[0, S(2), 'listen', 'omar'], [S(2), S(7), 'read'], [S(7), S(12), 'listen', 'omar'], [S(12), D.T, 'listen', 'official']],
    omar: [[0, S(12), 'text'], [S(12), D.T, 'listen', 'official']],
    official: [[S(12), S(14), 'talk', 'omar'], [S(14), D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(7), 'setting', 'Allow all access', 'alert'],
      [S(7), S(12), 'folder', 'Unauthorized folder data', 'alert'],
      [S(12), D.T, 'shield', 'Connected app removed', 'safe'],
    ],
  },
  plates: [
    [S(1), E(1), 'Mail, calendar and folders'],
    [S(7), E(7), 'Another department’s data'],
    [S(12), E(12), 'Connected app removed'],
  ],
  pages: [
    hero(S(3), S(5), 'Review every permission', 'mobile+lock+zoom', [
      ['Mail, calendar and shared folders', S(3), 'v-amber'],
      ['Grant only what is genuinely needed', S(4), 'v-teal'],
    ]),
    hero(S(5), S(7), 'Least privilege', 'made/key_cabinet+shield', [
      ['Avoid broad or unrestricted access', S(5), 'v-teal'],
      ['App inherits your account rights', S(6), 'v-coral'],
    ]),
    hero(S(8), S(12), 'Check every AI output', 'file-text+shield', [
      ['AI can surface unauthorized data', S(8), 'v-coral'],
      ['Models blur instructions and data', S(11), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Ask before you connect', 'link+shield+bell', [
      ['Refuse requests for all files', S(15), 'v-teal'],
      ['Unexpected data? Stop and report', S(16), 'v-amber'],
    ]),
  ],
}));
