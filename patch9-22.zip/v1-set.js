import { AR } from './i18n.js';
// Restore the approved table, with existing ready-made CC0 miniature models.
import { teachTable } from './objects.js';
import { THREE, V } from './kit.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const loader=new GLTFLoader();
export async function restoreTeachingTable(scene) {
  const table=teachTable(scene,.4,2.5); table.name='Approved teaching table';
  async function miniature(name,x,span) {
    const object=(await loader.loadAsync('assets/'+name+'.glb')).scene;
    const bounds=new THREE.Box3().setFromObject(object), size=bounds.getSize(V(0,0,0));
    const scale=span/Math.max(size.x,size.y,size.z);
    object.scale.setScalar(scale);
    object.position.set((AR ? .8-x : x)-(bounds.min.x+size.x/2)*scale,.965-bounds.min.y*scale,2.5-(bounds.min.z+size.z/2)*scale);
    object.traverse(o=>{if(o.isMesh)o.castShadow=o.receiveShadow=true});scene.add(object);
  }
  await Promise.all([miniature('server-rack',-.55,.62),miniature('clipboard',.55,.5),miniature('desk-phone',1.35,.48)]);
  return table;
}
