// Cast portrait: everyone facing the viewer, used only to review the people.
import { createPerson } from './people.js';
import { label } from './objects.js';
import { ROLES } from './library.js';

const all = Object.keys(ROLES);
const half = new URLSearchParams(location.search).get('s') === '0.cast2' ? 1 : 0;
export const cast = all.slice(half * 8, half * 8 + 8);

export default function ({ stage, scene }) {
  const list = cast.map((n, i) => createPerson(n, scene).at(-3 + i * 0.86, 1.2, 0));
  list.forEach((p, i) => label(ROLES[cast[i]], scene, p.g.position.x, i % 2 ? 2.14 : 2.0, 1.2, 0.1));
  stage.dir.set(0, 0.1, 1).normalize(); stage.lockDir = true;
  return t => {
    list.forEach((p, i) => { p.reset(); p.idle(0.4, i); p.blink = 0; p.smile = 0.5; });
    stage.shots(t, [{ x: 0, y: 1.2, z: 1.2, w: 7.3 }]);
  };
}
