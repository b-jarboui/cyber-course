// A message that knows your name.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'door' },
  shots: [[0,'counter'], [S(1),'counterDisplay'], [S(3),'her'], [S(9),'file'], [S(11),'staff'], [S(12),'door'], [S(13),'her']],
  file: [[S(10), E(10), 0, 1]],
  actions: {
    maya: [[0,S(9),'read'], [S(9),S(10),'listen','omar'], [S(10),S(11),'file'], [S(11),E(12),'call'], [S(13),D.T,'type']],
    omar: [[0,S(11),'listen','maya'], [S(11),E(11),'talk','maya']],
    citizen: [[S(11),E(12),'call']],
  },
  enter: { citizen: S(11) },
  displays: { counter: [[0,S(13),'mail','Case 2048','neutral','inbox'], [S(13),D.T,'bell','Report sent','safe']] },
  plates: [[S(1),E(1),'Case 2048'], [S(2),E(2),'Updated documents'], [S(10),E(10),'Number in the case file'], [S(12),E(12),'No email sent']],
  pages: [
    hero(S(5), S(6), 'Spear phishing: aimed at you', 'mail+made/case_folder', [
      ['Case 2048', S(5), 'v-amber'],
    ]),
    hero(S(6), S(9), 'Fluent is not genuine', 'mail+file-text', [
      ['A familiar case number', S(8), 'v-amber'],
    ]),
    hero(S(11), S(12), 'Verify through a known contact', 'made/case_folder+mobile', [
      ['Number in the case file', S(11), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Report through the approved route', 'mail+bell', [
      ['Warn other staff', S(13), 'v-teal'],
    ]),
  ],
}));
