import { AR, arabicPlate, tr } from './i18n.js';
import { restoreTeachingTable } from './v1-set.js';
// Owners and layers. The team meets at the teaching table; governance and defence in depth are 2D pages.
import { V, lerp, ramp, pulse } from './kit.js';
import { createPerson, loadMotion } from './people.js';
import { frameShots, quietScreens } from './astra.js';
import { createBoard } from './board.js';
import { ownerPages } from './pages2d-b.js';
import { readyPages, seekPages } from './library-pages.js';

export const texts = [];
export const cast = ['lena', 'maya', 'omar', 'priya'];

export default async function ({ stage, scene, createCounter, S, E, D, ui }) {
  await loadMotion(['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop', 'm_idle_neutral_01', 'm_idle_neutral_02', 'm_gestic_listen_accept_01', 'f_walk_start', 'f_walk_neutral_01', 'f_walk_stop', 'f_idle_neutral_01', 'f_idle_neutral_02', 'f_idle_neutral_03', 'f_gestic_listen_accept_01']);
  document.getElementById('kicker').textContent = tr('Lesson 1.1 · Version 4');
  document.getElementById('cap').style.fontSize = '21px';
  createCounter(scene);
  await restoreTeachingTable(scene);
  const lena = createPerson('lena', scene), maya = createPerson('maya', scene), omar = createPerson('omar', scene), rania = createPerson('priya', scene), all = [omar, lena, maya, rania];

  // Each person stands at the model that belongs to their work.
  const Z = 1.02, slots = [-.55, .15, .75, 1.4], rests = ['m_idle_neutral_01', 'f_idle_neutral_02', 'f_idle_neutral_01', 'f_idle_neutral_03'];
  const models = [V(-.55, 1.15, 2.5), V(.15, 1.0, 2.5), V(.55, 1.0, 2.5), V(1.35, 1.05, 2.5)];
  if (AR) {
    // Mirror around the table centre (x = .4), keeping people, gaze and camera with their model.
    slots.forEach((x, i) => { slots[i] = .8 - x; });
    models.forEach(model => { model.x = .8 - model.x; });
  }
  // The table is deep: hands point over its near edge, eyes go to the model.
  const point = slots.map(x => V(x, 1.08, 1.5));
  const walk = i => i === 0 ? ['m_walk_start', 'm_walk_neutral_01', 'm_walk_stop'] : ['f_walk_start', 'f_walk_neutral_01', 'f_walk_stop'];
  const arrive = all.map((p, i) => p.planTo([...walk(i), rests[i]], slots[i], Z, 0, .1 + [.5, 0, .3, .8][i]));
  const nodName = i => i === 0 ? 'm_gestic_listen_accept_01' : 'f_gestic_listen_accept_01';
  // Whose duty is being named. Rania speaks for privacy and procurement; Shaima is both owner and staff.
  const beats = [[1, 1], [2, 2], [3, 0], [4, 3], [5, 2]].map(([s, i]) => ({ i, a: S(s), z: E(s) }));
  const closing = S(10) + 1.3, routes = all.map((p, i) => {
    let from = arrive[i]; const list = [];
    for (const n of [...beats.filter(b => b.i === i).map(b => b.a + 1), closing + i * .3]) {
      from = p.plan([nodName(i), rests[i]], slots[i], Z, 0, n, .4, from); list.push(from);
    }
    return list;
  });

  // ---------- 2D ----------
  const B = createBoard(D.T), { tl } = B;
  const say = (a, z, html, bottom = 170) => {
    const plate = document.createElement('div');
    plate.style.cssText = `position:absolute;left:16px;bottom:${bottom}px;padding:8px 14px;border-radius:12px;background:#fffdf8;color:#26305a;font:800 22px/1.2 "Segoe UI",Arial;box-shadow:0 4px 14px rgba(38,48,90,.18);opacity:0;pointer-events:none`;
    plate.innerHTML = tr(html);
    if (AR) arabicPlate(plate);
    document.getElementById('stage').after(plate);
    tl.fromTo(plate, { opacity: 0 }, { opacity: 1, duration: .3, immediateRender: false }, a);
    tl.to(plate, { opacity: 0, duration: .25 }, z);
  };
  const teal = s => `<span style="color:#2f7477">${s}</span>`;
  say(S(0) + 1.5, E(0), `Cybersecurity<br>${teal('A shared responsibility')}`);
  say(S(1) + .1, E(1) + .1, `Leaders<br>${teal('Direction and resources')}`);
  say(S(2) + .1, E(2) + .1, `Service owners<br>${teal('Risk decisions')}`);
  say(S(3) + .1, E(3) + .1, `Security and technology<br>${teal('Operate protections')}`);
  say(S(4) + .1, E(4) + .1, `Privacy, procurement<br>${teal('Add their expertise')}`);
  say(S(5) + .1, E(5) + .1, `Staff<br>${teal('Protect, follow, report')}`, 205);
  say(S(10) + .1, E(10) + .1, `No single product<br>${teal('No single person')}`);
  say(S(11) + .3, D.T, `Clear owners<br>${teal('Review and practice')}`);
  const open1 = S(6) - .5, close1 = S(10) - .4;
  ownerPages({ B, S, E, D, open1, close1 }); B.end(); await readyPages(B);

  // ---------- the 3D story ----------
  const eye = p => p.g.position.clone().setY(1.5), centre = V(.4, 1.05, 2.5), hand = ['L', 'R', 'R', 'R'];
  const whole = { x: .45, y: 1.1, z: 1.4, w: 4.1, e: .46, f: .44 }, close = i => ({ x: slots[i], y: 1.25, z: 1.2, w: 2.7, e: .42, f: .43 }), wide = { x: -.6, y: 1.0, z: .6, w: 7.8, e: .68, f: .44 };

  return t => {
    tl.time(t, false);
    seekPages(B, t);
    stage.conceptPage = t >= open1 + .4 && t < close1;
    quietScreens(ui, t);
    stage.focus = null;
    const beat = beats.find(b => t >= b.a && t < b.z + .3);

    all.forEach((p, i) => {
      p.reset(); p.idle(t, i + 1); p.sway = 0; p.smile = .18;
      const route = [arrive[i], ...routes[i]].filter(r => t >= r.t0).at(-1) || arrive[i];
      p.follow(route, t, true);
      // Attention: the person being named looks at their model, the others at that person.
      if (beat) { if (beat.i === i) p.look(models[i], 1); else p.look(eye(all[beat.i]), .9); }
      else if (t >= S(10)) p.look(eye(all[(i + 1) % 4]), pulse(t, S(10) + .2 + i * .2, S(10) + .8 + i * .2, E(11) - 1, E(11)));
      else p.look(centre, ramp(t, 3, 4));
      // One deliberate reach to the model, then back to rest.
      const act = beat?.i === i ? pulse(t, beat.a + .1, beat.a + .8, beat.a + 2.6, beat.a + 3.3) : 0;
      if (act > 0) { p.reach(hand[i], point[i], act); p.bend = .07 * act; }
      p.g.visible = !stage.conceptPage;
    });

    frameShots(stage, t, [
      whole,
      ...beats.map(b => ({ t0: b.a - .5, t1: b.a + .4, ...close(b.i) })),
      { t0: E(5) - .3, t1: E(5) + .2, ...whole },
      { t0: S(10) - .3, t1: S(10), ...whole },
      { t0: S(11), t1: S(11) + 3.2, ...wide },
    ]);
  };
}
