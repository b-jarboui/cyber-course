import { AR, tr } from './i18n.js';
// The 2D page: plain graphics that replace the 3D picture when an idea needs explaining.
// One paused GSAP timeline drives it, so seeking to t always gives the same picture.
const NS = 'http://www.w3.org/2000/svg';
export const INK = '#26305a', TEAL = '#2f7477', CORAL = '#c6543b', AMBER = '#c9811a', SOFT = '#ddd7ca', PAPER = '#fffdf8', NAVY = '#333f6b';
const ICONS = {
  file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M16 7l3 3"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  id: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.4"/><path d="M5.500 17c.6-2 2-3 3.500-3s2.900 1 3.500 3M15 10h3M15 14h3"/>',
  phone: '<rect x="7" y="2.500" width="10" height="19" rx="2"/><path d="M11 18.500h2"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-5 4-7 8-7s7 2 8 7"/>',
  people: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.500"/><path d="M3 20c.5-4 3-6 6-6s5.500 2 6 6M15 14c3 0 5 2 6 5"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  send: '<path d="M3 11l18-8-8 18-2-8z"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
  counter: '<path d="M2 10h20M4 10v10h16V10M6 10l2-5h8l2 5M9 20v-5h6v5"/>',
  device: '<rect x="4" y="5" width="16" height="11" rx="1.500"/><path d="M2 19h20"/>',
  app: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M6 6.500h.01M9 6.500h.01"/>',
  store: '<rect x="4" y="3" width="16" height="7" rx="1"/><rect x="4" y="14" width="16" height="7" rx="1"/><path d="M8 6.500h.01M8 17.500h.01"/>',
  robot: '<rect x="5" y="8" width="14" height="11" rx="2"/><path d="M12 8V4M9 13h.01M15 13h.01M9 16h6"/>',
  pay: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18M7 15h3"/>',
  tower: '<path d="M12 8v13M8 21l4-13 4 13M5 5a10 10 0 0 0 0 8M19 5a10 10 0 0 1 0 8"/>',
  bolt: '<path d="M13 2L5 14h6l-1 8 8-12h-6z"/>',
  health: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M12 8v8M8 12h8"/>',
  drop: '<path d="M12 3s7 7.500 7 12a7 7 0 0 1-14 0c0-4.500 7-12 7-12z"/>',
  link: '<path d="M10 14a4 4 0 0 0 6 0l3-3a4 4 0 0 0-6-6l-1 1M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 0 0 6 6l1-1"/>',
  check: '<path d="M4 13l5 5L20 6"/>',
  history: '<path d="M4 12a8 8 0 1 0 2.500-5.800L4 8.500M4 4v4.500h4.500M12 8v4l3 2"/>',
  notice: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
};

export const el = (tag, attrs, parent, text) => {
  const e = document.createElementNS(NS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (text !== undefined) e.textContent = tr(text);if (AR && tag === 'text') {
    e.setAttribute('direction', 'rtl');
    // Reflect the glyphs back around their own writing anchor on the mirrored board.
    e.style.transformOrigin = attrs.x + 'px ' + attrs.y + 'px';
    e.style.scale = '-1 1';
  }
  parent?.append(e);
  return e;
};
export const write = (p, x, y, s, size, fill = INK, weight = 700, anchor = 'middle') => el('text', { x, y, 'font-size': size, 'font-weight': weight, fill, 'text-anchor': anchor, 'font-family': 'Segoe UI, Arial, sans-serif' }, p, s);
export const lines = (p, x, y, list, size, fill, weight, anchor, gap = 1.22) => list.map((s, i) => write(p, x, y + i * size * gap, s, size, fill, weight, anchor));
export function icon(p, name, x, y, size, colour) {
  const g = el('g', { transform: `translate(${x - size / 2} ${y - size / 2}) scale(${size / 24})`, fill: 'none', stroke: colour, 'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, p);
  g.innerHTML = ICONS[name];
  return g;
}
export const hide = o => { o.setAttribute('opacity', 0); return o; };
export const part = p => hide(el('g', {}, p));

export function createBoard(T) {
  const g = window.gsap, tl = g.timeline({ paused: true });
  const page = document.createElement('div'); page.id = 'board';
  page.style.cssText = 'position:absolute;inset:0;background:#f2eee6;pointer-events:none;visibility:hidden';
  document.getElementById('stage').after(page);
  const svg = el('svg', { viewBox: '0 0 360 640', width: '100%', height: '100%', preserveAspectRatio: 'xMidYMid meet' }, page);
  if (AR) svg.style.scale = '-1 1';
  const b = {
    tl, svg,
    panel: () => part(svg),
    // The page wipes across the 3D picture, and away again.
    open(a) { tl.set(page, { visibility: 'visible' }, a); tl.fromTo(page, { clipPath: AR ? 'inset(0 100% 0 0)' : 'inset(0 0 0 100%)' }, { clipPath: 'inset(0 0 0 0%)', duration: .4, ease: 'power2.inOut', immediateRender: false }, a); },
    close(a) { tl.fromTo(page, { clipPath: 'inset(0 0 0 0%)' }, { clipPath: AR ? 'inset(0 0 0 100%)' : 'inset(0 100% 0 0%)', duration: .4, ease: 'power2.inOut', immediateRender: false }, a); tl.set(page, { visibility: 'hidden' }, a + .41); },
    during(p, a, z) { tl.set(p, { opacity: 1 }, a); tl.set(p, { opacity: 0 }, z); },
    show(o, a, d = .35) { tl.fromTo(o, { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: d, ease: 'power2.out', immediateRender: false }, a); },
    fade(o, a, to = 0, d = .3) { tl.to(o, { opacity: to, duration: d }, a); },
    end() { tl.set({}, {}, T); },
  };
  return b;
}

// 340 accounts as a grid. Dots are accounts with permission, not people doing anything.
export function accounts(p, y0, gap = 14) {
  const cols = 20, x0 = 180 - (cols - 1) * gap / 2, g = el('g', {}, p), many = [], some = [];
  const heart = [168, 169, 170, 171, 172];
  for (let i = 0; i < 340; i++) {
    const x = x0 + (i % cols) * gap, y = y0 + Math.floor(i / cols) * gap;
    if (heart.includes(i)) some.push(hide(el('circle', { cx: x, cy: y, r: 5.5, fill: TEAL }, g)));
    else many.push(hide(el('circle', { cx: x, cy: y, r: 4.6, fill: AMBER }, g)));
  }
  return { many, some };
}
