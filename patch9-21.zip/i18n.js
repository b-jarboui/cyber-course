export const AR = new URLSearchParams(location.search).get('lang') === 'ar';
const translations = AR ? (await import('./onscreen-ar.js')).default : {};

export function tr(s) {
  if (AR && !Object.hasOwn(translations, s) && typeof s === 'string' && /[A-Za-z]{2}/.test(s.replace(/<[^>]*>/g, ''))) (window.__trMiss ??= new Set()).add(s);   // checker list: English left untranslated
  return AR && Object.hasOwn(translations, s) ? translations[s] : s;
}

export function trTemplate(key, values) {
  return tr(key).replace(/\{(\w+)\}/g, (placeholder, name) =>
    Object.hasOwn(values, name) ? String(values[name]) : placeholder);
}

export function arabicPlate(plate) {
  plate.dir = 'rtl';
  plate.classList.add('ar-plate');
  plate.style.setProperty('--ar-plate-bottom', plate.style.bottom);
}
