import { AR, tr } from './i18n.js';
// Teaching objects: the small physical models the scenes combine.
import { THREE, C, V, mat, mesh, rbox, box, cyl, sph, group, bar, metal, frosted, canvasTex, folder, ramp, lerp, clamp01 } from './kit.js';

// Floating signs. They always face the camera, so they stay readable on a phone.
const ICONS = {
  alert: (g, s) => { g.fillStyle = '#fff'; g.fillRect(s * .46, s * .24, s * .08, s * .32); g.beginPath(); g.arc(s * .5, s * .68, s * .05, 0, 7); g.fill(); },
  q: (g, s) => { g.fillStyle = '#fff'; g.font = `800 ${s * .6}px "Segoe UI",Arial`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(AR ? '؟' : '?', s * .5, s * .53); },
  ok: (g, s) => { g.strokeStyle = '#fff'; g.lineWidth = s * .1; g.lineCap = g.lineJoin = 'round'; g.beginPath(); g.moveTo(s * .29, s * .52); g.lineTo(s * .44, s * .67); g.lineTo(s * .72, s * .35); g.stroke(); },
  stop: (g, s) => { g.strokeStyle = '#fff'; g.lineWidth = s * .1; g.lineCap = 'round'; g.beginPath(); g.moveTo(s * .33, s * .33); g.lineTo(s * .67, s * .67); g.moveTo(s * .67, s * .33); g.lineTo(s * .33, s * .67); g.stroke(); },
};
const SIGN = { alert: C.amber, q: C.amber, ok: C.teal, stop: C.coral };
const signCache = {};
export function sign(kind, parent, x = 0, y = 0, z = 0, size = 0.34) {
  signCache[kind] ||= canvasTex(128, 128, (g, s) => {
    g.fillStyle = SIGN[kind]; g.beginPath(); g.roundRect(6, 6, s - 12, s - 12, 30); g.fill();
    ICONS[kind](g, s);
  });
  const o = new THREE.Sprite(new THREE.SpriteMaterial({ map: signCache[kind], transparent: true, depthWrite: false }));
  o.position.set(x, y, z); o.scale.setScalar(size); o.userData.base = size; o.renderOrder = 5;
  if (parent) parent.add(o);
  return o;
}
export function label(text, parent, x = 0, y = 0, z = 0, h = 0.2, tone = C.navy) {
  text = tr(text);
  const c = document.createElement('canvas'), g = c.getContext('2d');
  g.font = AR ? '650 44px "IBM Plex Sans Arabic",Arial' : '650 44px "Segoe UI",Arial';
  const w = Math.ceil(g.measureText(text).width) + 56;
  c.width = w; c.height = 80;
  g.font = AR ? '650 44px "IBM Plex Sans Arabic",Arial' : '650 44px "Segoe UI",Arial';
  g.fillStyle = 'rgba(255,253,248,.97)'; g.beginPath(); g.roundRect(2, 2, w - 4, 76, 18); g.fill();
  g.fillStyle = tone; g.fillRect(AR ? w - 8 : 0, 18, 8, 44);
  if(AR){g.direction='rtl';g.textAlign='right';}g.textBaseline = 'middle'; g.fillText(text, AR ? w - 30 : 30, 42);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  const o = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthWrite: false, depthTest: false }));
  o.position.set(x, y, z); o.scale.set(h * w / 80, h, 1); o.userData.base = 1; o.userData.size = [h * w / 80, h]; o.renderOrder = 8;
  if (parent) parent.add(o);
  return o;
}
export function showSprite(o, k) {
  o.visible = k > 0.01;
  o.material.opacity = k;
  if (o.userData.size) o.scale.set(o.userData.size[0], o.userData.size[1], 1);
  else o.scale.setScalar(o.userData.base * (0.6 + 0.4 * k) * (1 + 0.16 * Math.sin(Math.PI * k)));
}

// Big teaching table: cream top, steel edge, navy pedestal, as in the reference images.
export function teachTable(parent, x, z, w = 3.6, d = 2.5, rotY = 0) {
  const g = group(parent, x, 0, z); g.rotation.y = rotY;
  mesh(box(w * 0.68, 0.1, d * 0.66), C.sand, 0, 0.05, 0, g);
  mesh(rbox(w * 0.64, 0.74, d * 0.62, 0.02), C.navy, 0, 0.45, 0, g);
  mesh(rbox(w, 0.05, d, 0.02), mat(C.metal, { roughness: 0.4, metalness: 0.15 }), 0, 0.85, 0, g);
  mesh(rbox(w - 0.02, 0.09, d - 0.02, 0.03), mat('#f6f0e4', { roughness: 0.62 }), 0, 0.92, 0, g);
  g.userData.top = 0.965;
  return g;
}
export function plate(parent, x, y, z, w, d, colour = '#f6f0e4') {
  return mesh(rbox(w, 0.05, d, 0.02), colour, x, y + 0.025, z, parent);
}
export function flag(parent, x, y, z, colour = C.teal, h = 0.34) {
  const g = group(parent, x, y, z);
  mesh(cyl(0.05, 0.06, 0.02, 18), C.navy, 0, 0.01, 0, g);
  mesh(cyl(0.007, 0.007, h, 8), C.metalD, 0, h / 2, 0, g);
  const s = new THREE.Shape(); s.moveTo(0, 0); s.lineTo(0.13, -0.035); s.lineTo(0, -0.08); s.closePath();
  const f = mesh(new THREE.ExtrudeGeometry(s, { depth: 0.006, bevelEnabled: false }), colour, 0.006, h, 0, g);
  return g;
}
// A gate on the table. open(k): 0 closed, 1 open.
export function gate(parent, x, y, z, rotY = 0, w = 0.5, colour = C.amber) {
  const g = group(parent, x, y, z); g.rotation.y = rotY;
  for (const s of [-1, 1]) { mesh(cyl(0.032, 0.036, 0.3, 16), metal(), s * w / 2, 0.15, 0, g); mesh(sph(0.034), C.metalD, s * w / 2, 0.3, 0, g); }
  const hinge = group(g, -w / 2, 0.17, 0);
  const arm = mesh(rbox(w - 0.03, 0.05, 0.03, 0.012), colour, w / 2, 0, 0, hinge);
  g.userData.open = k => { hinge.rotation.z = k * 1.35; };
  return g;
}
export function glassCase(parent, x, y, z, w, h, d) {
  const g = group(parent, x, y, z);
  const sides = mesh(box(w, h, d), frosted('#dbe8e3', 0.34), 0, h / 2, 0, g); sides.castShadow = false;
  mesh(box(w + 0.03, 0.02, d + 0.03), C.metal, 0, 0.01, 0, g);
  for (const [a, b] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) bar(V(a * w / 2, 0, b * d / 2), V(a * w / 2, h, b * d / 2), 0.011, metal(), g);
  for (const s of [-1, 1]) { bar(V(-w / 2, h, s * d / 2), V(w / 2, h, s * d / 2), 0.011, metal(), g); bar(V(s * w / 2, h, -d / 2), V(s * w / 2, h, d / 2), 0.011, metal(), g); }
  return g;
}
export function tray(parent, x, y, z, w = 0.8, d = 0.6, colour = C.metal) {
  const g = group(parent, x, y, z);
  mesh(box(w, 0.02, d), colour, 0, 0.01, 0, g);
  for (const s of [-1, 1]) { mesh(rbox(w, 0.09, 0.03, 0.01), colour, 0, 0.05, s * d / 2, g); mesh(rbox(0.03, 0.09, d, 0.01), colour, s * w / 2, 0.05, 0, g); }
  return g;
}
// Flat track between points, with moving packets for flows of information.
export function track(parent, pts, colour = C.teal, y = 0, w = 0.09) {
  const g = group(parent);
  const P = pts.map(p => V(p[0], y + 0.012, p[1]));
  for (let i = 0; i + 1 < P.length; i++) {
    const a = P[i], b = P[i + 1], l = a.distanceTo(b);
    const s = mesh(rbox(l + w, 0.022, w, 0.01), colour, (a.x + b.x) / 2, a.y, (a.z + b.z) / 2, g);
    s.rotation.y = -Math.atan2(b.z - a.z, b.x - a.x);
  }
  g.userData.pts = P;
  g.userData.len = P.slice(1).reduce((s, p, i) => s + p.distanceTo(P[i]), 0);
  g.userData.at = k => { let d = clamp01(k) * g.userData.len; for (let i = 0; i + 1 < P.length; i++) { const l = P[i].distanceTo(P[i + 1]); if (d <= l || i + 2 === P.length) return P[i].clone().lerp(P[i + 1], l ? d / l : 0); d -= l; } };
  return g;
}
export function packet(parent, colour = C.sand, s = 0.09) { return mesh(rbox(s, s * 0.7, s, 0.02), colour, 0, 0, 0, parent); }

// Small models of parts of a service.
export function records(parent, x, y, z, s = 1, colour = C.navy) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(rbox(0.4, 0.46, 0.3, 0.02), colour, 0, 0.23, 0, g);
  for (const yy of [0.11, 0.24, 0.37]) { mesh(box(0.36, 0.1, 0.01), C.navyL, 0, yy, 0.152, g); mesh(rbox(0.09, 0.016, 0.014, 0.005), C.metal, 0, yy, 0.16, g); }
  return g;
}
export function appModule(parent, x, y, z, s = 1, colour = '#eaf0f6') {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(rbox(0.44, 0.2, 0.34, 0.03), colour, 0, 0.1, 0, g);
  mesh(rbox(0.3, 0.12, 0.02, 0.008), C.navy, 0, 0.11, 0.17, g);
  for (const [i, c] of [C.teal, C.amber, C.powder].entries()) mesh(sph(0.018), c, -0.08 + i * 0.08, 0.205, 0.06, g);
  return g;
}
export function terminal(parent, x, y, z, s = 1) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(rbox(0.3, 0.09, 0.24, 0.03), C.navy, 0, 0.045, 0, g);
  mesh(rbox(0.2, 0.012, 0.13, 0.005), C.teal, 0, 0.096, 0.015, g);
  const card = mesh(rbox(0.2, 0.012, 0.13, 0.008), C.sand, 0.03, 0.16, -0.08, g); card.rotation.x = -0.9;
  return g;
}
export function tower(parent, x, y, z, s = 1) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(rbox(0.3, 0.05, 0.3, 0.02), C.metal, 0, 0.025, 0, g);
  mesh(cyl(0.012, 0.04, 0.48, 12), C.navy, 0, 0.29, 0, g);
  for (const r of [0.09, 0.14]) { const m = mesh(new THREE.TorusGeometry(r, 0.008, 6, 24, Math.PI * 0.8), C.teal, 0, 0.5, 0, g); m.rotation.set(0, Math.PI / 4, Math.PI * 0.1); }
  mesh(sph(0.026), C.amber, 0, 0.53, 0, g);
  return g;
}
export function powerBox(parent, x, y, z, s = 1) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(rbox(0.38, 0.34, 0.28, 0.03), '#6f7a93', 0, 0.17, 0, g);
  const b = new THREE.Shape(); [[0.02, 0.1], [-0.05, -0.01], [-0.005, -0.01], [-0.03, -0.1], [0.05, 0.02], [0.005, 0.02]].forEach((p, i) => i ? b.lineTo(p[0], p[1]) : b.moveTo(p[0], p[1])); b.closePath();
  mesh(new THREE.ShapeGeometry(b), C.amber, 0, 0.18, 0.142, g).castShadow = false;
  return g;
}
export function cloud(parent, x, y, z, s = 1) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  const m = mat('#e7eef6', { roughness: 0.6 });
  for (const [a, b, r] of [[-0.14, 0.12, 0.1], [0, 0.17, 0.14], [0.15, 0.12, 0.1], [0.05, 0.1, 0.1]]) mesh(sph(r), m, a, b, 0, g);
  mesh(rbox(0.46, 0.09, 0.2, 0.04), m, 0, 0.05, 0, g);
  return g;
}
// Identity markers: rounded pin for people, hexagonal chip for software.
export function personPin(parent, x, y, z, s = 1, colour = C.teal) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(cyl(0.11, 0.13, 0.03, 24), C.navy, 0, 0.015, 0, g);
  mesh(cyl(0.012, 0.012, 0.16, 8), C.metalD, 0, 0.1, 0, g);
  mesh(sph(0.1), colour, 0, 0.27, 0, g).scale.set(1, 1, 0.5);
  mesh(sph(0.03), '#fff', 0, 0.3, 0.05, g).scale.z = 0.4;
  mesh(sph(0.05), '#fff', 0, 0.24, 0.05, g).scale.set(1, 0.6, 0.3);
  return g;
}
export function chipId(parent, x, y, z, s = 1, colour = C.amber) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(cyl(0.11, 0.13, 0.03, 24), C.navy, 0, 0.015, 0, g);
  const h = mesh(cyl(0.11, 0.11, 0.05, 6), colour, 0, 0.09, 0, g);
  mesh(cyl(0.05, 0.05, 0.056, 6), '#fff', 0, 0.09, 0, g);
  return g;
}
// Neutral figure for anyone who should not be a character: an unknown person, an account.
export function pawn(parent, x, y, z, s = 1, colour = '#d8d3c9') {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(cyl(0.1, 0.13, 0.04, 24), colour, 0, 0.02, 0, g);
  mesh(cyl(0.05, 0.1, 0.3, 24), colour, 0, 0.19, 0, g);
  mesh(sph(0.075), colour, 0, 0.4, 0, g);
  return g;
}
// The AI: a calm device with a ring of light. It has no face and no body.
export function aiCore(parent, x, y, z, s = 1) {
  const g = group(parent, x, y, z); g.scale.setScalar(s);
  mesh(cyl(0.3, 0.33, 0.06, 36), C.navy, 0, 0.03, 0, g);
  mesh(rbox(0.46, 0.3, 0.46, 0.09), '#eef0f3', 0, 0.21, 0, g);
  const ring = mesh(new THREE.TorusGeometry(0.15, 0.024, 12, 36), new THREE.MeshBasicMaterial({ color: C.teal }), 0, 0.365, 0, g);
  ring.rotation.x = Math.PI / 2; ring.castShadow = false;
  mesh(cyl(0.12, 0.12, 0.02, 30), C.navy, 0, 0.365, 0, g);
  g.userData.ring = ring;
  return g;
}
export function paperCard(parent, x, y, z, w = 0.42, d = 0.3, accent = C.powder) {
  const g = group(parent, x, y, z);
  mesh(rbox(w, 0.012, d, 0.006), C.paper, 0, 0.006, 0, g);
  mesh(box(w * 0.74, 0.003, d * 0.13), accent, 0, 0.014, -d * 0.28, g);
  for (const [i, k] of [0.74, 0.6, 0.68].entries()) mesh(box(w * k, 0.003, d * 0.06), '#cfd4dc', 0, 0.014, -d * 0.06 + i * d * 0.15, g);
  return g;
}
export function shelf(parent, x, y, z, s = 1) { return records(parent, x, y, z, s, C.navy); }

// Service model used across scenes: a citizen counter joined to the systems it depends on.
export function serviceModel(parent, y) {
  const g = group(parent);
  const p = {};
  p.main = track(g, [[-1.4, 0.45], [-0.5, 0.45], [-0.5, -0.45], [0.8, -0.45], [0.8, 0.5], [1.4, 0.5]], C.teal, y);
  p.side = track(g, [[-0.5, 0.0], [-1.25, -0.6]], C.navyL, y);
  p.side2 = track(g, [[0.15, -0.45], [0.15, 0.55]], C.navyL, y);
  p.portal = appModule(g, -1.4, y, 0.45, 0.95, '#f2f4f7');
  p.records = records(g, 0.15, y, 0.58, 0.9);
  p.app = appModule(g, 0.15, y, -0.5, 1.05);
  p.device = group(g, -1.25, y, -0.62);
  mesh(rbox(0.44, 0.03, 0.3, 0.01), C.metal, 0, 0.015, 0, p.device);
  const lid = mesh(rbox(0.44, 0.28, 0.02, 0.01), C.metal, 0, 0.16, -0.15, p.device); lid.rotation.x = -0.25;
  p.backup = group(g, 1.4, y, 0.5);
  mesh(rbox(0.36, 0.26, 0.3, 0.03), '#eaf0f6', 0, 0.13, 0, p.backup);
  mesh(box(0.3, 0.02, 0.01), C.teal, 0, 0.15, 0.152, p.backup);
  return { group: g, ...p };
}
