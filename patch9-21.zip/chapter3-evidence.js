// Photographs, printouts and device screens used in the Chapter 3 hall.
// Each view is made once. Seeking selects a material and a camera from narration time.
import { THREE, C, V, group, mesh, rbox, canvasTex, ramp } from './kit.js';
import { AR, tr } from './i18n.js';

const paper = '#fffaf0', ink = '#253553', teal = '#296b70', alert = '#a34435';
const during = (rows, t) => rows?.find(([a, z]) => a <= t && t < z);
const world = o => o.getWorldPosition(V());
function panel(parent, w, h, x, y, z) {
  const surface = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: paper }));
  surface.position.set(x, y, z);
  parent.add(surface);
  return surface;
}

function deviceSurface(name, hall) {
  const { scene, devices, phones, sheets, work } = hall;
  if (devices[name]) return devices[name];
  if (name.startsWith('phone:')) return phones[name.slice(6)].userData.screen;
  if (name.startsWith('paper:')) {
    const face = panel(sheets[name.slice(6)], .214, .282, 0, .004, 0);
    face.rotation.x = -Math.PI / 2;
    return face;
  }
  if (name === 'noticeBoard') {
    const board = group(scene, -4.88, 1.86, -.56);
    board.rotation.y = Math.PI / 2;
    mesh(rbox(1.43,.84,.05), C.dark, 0,0,0,board);
    return panel(board, 1.37,.78,0,0,.027);
  }
  const handset = name === 'counterPhone';
  const width = handset ? .087 : .214, height = handset ? .16 : .285;
  const base = group(scene);
  if (name === 'deskPaper') base.position.copy(work.desk.localToWorld(V(-.45,.787,-.025)));
  else base.position.set(-2.18,1.065,handset ? -.09 : .21);
  base.rotation.set(-Math.PI / 2, 0, name === 'deskPaper' ? .14 : -.18);
  mesh(rbox(width+.01,height+.01,handset ? .012 : .003,.003), handset ? C.dark : C.paper,0,0,0,base);
  return panel(base,width,height,0,0, handset ? .007 : .002);
}

// Crop a photograph from the active player's renderer without changing its playback camera.
function capture(stage, scene, target, offset, w, h, viewHeight) {
  const src = stage.renderer.domElement, aspect = w / h;
  const sh = Math.min(src.height, src.width / aspect), sw = sh * aspect;
  const vh = viewHeight * src.height / sh, vw = vh * src.width / src.height;
  const cam = new THREE.OrthographicCamera(-vw/2,vw/2,vh/2,-vh/2,.02,50);
  cam.position.copy(target).add(offset);
  cam.lookAt(target);
  stage.renderer.render(scene, cam);
  const out = document.createElement('canvas');
  out.width = w; out.height = h;
  out.getContext('2d').drawImage(src,(src.width-sw)/2,(src.height-sh)/2,sw,sh,0,0,w,h);
  return out;
}

function photographs(hall) {
  const { stage, scene, actors } = hall, cache = new Map();
  const studio = new THREE.Scene();
  studio.background = new THREE.Color('#cadcda');
  studio.add(new THREE.HemisphereLight('#fffefa','#debfa9',2));
  const light = new THREE.DirectionalLight('#ffffff',1.6);
  light.position.set(-2,3,3); studio.add(light);
  function portrait(role, frame = 0) {
    const key = role + frame;
    if (!cache.has(key)) {
      const actor = actors[role];
      studio.add(actor.g);
      try {
        actor.reset(); actor.at(0,0,frame ? .10 : 0);
        actor.jaw = frame ? .20 : 0; actor.flush();
        const eye = world(actor.b.Bip01_Head).add(V(0,-.025,0));
        cache.set(key, capture(stage,studio,eye,V(0,.03,2),224,224,.57));
      } finally { scene.add(actor.g); }
    }
    return cache.get(key);
  }
  function counter(envelope, frame) {
    const key = 'counter' + envelope + frame;
    if (!cache.has(key)) {
      const { maya, citizen } = actors;
      for (const p of Object.values(actors)) p.g.visible = false;
      maya.g.visible = true; citizen.g.visible = envelope;
      maya.reset(); maya.at(-2.74,-.38,1.4);
      citizen.reset(); citizen.at(-1.49,-.12,-1.68);
      const packet = group(scene,-2.12,1.19+frame*.015,-.2);
      packet.rotation.set(-.55,.55,.08);
      mesh(rbox(.25,.15,.008,.001), '#ddae65',0,0,0,packet);
      const flap = mesh(new THREE.ConeGeometry(.122,.073,3), '#f6cf89',0,.009,.009,packet);
      flap.rotation.z = Math.PI;
      packet.visible = envelope;
      try {
        if (envelope) {
          maya.reach('R',world(packet).add(V(-.1,0,0)),1);
          citizen.reach('R',world(packet).add(V(.1,0,0)),1);
          maya.look(world(packet),1);
        } else maya.look(world(hall.counterLaptop.userData.screen),1);
        maya.flush(); citizen.flush();
        cache.set(key,capture(stage,scene,V(-2.15,1.27,-.26),V(.46,.62,3),448,256,1.15));
      } finally {
        scene.remove(packet);
        for (const p of Object.values(actors)) p.g.visible = true;
      }
    }
    return cache.get(key);
  }
  return { portrait, counter };
}

function drawView(kind, label, subject, photos, aspect, frame) {
  const w = 640, h = Math.round(w/aspect);
  return canvasTex(w,h,(ctx) => {
    const rect = (x,y,b,d,color) => { ctx.fillStyle=color; ctx.fillRect(x,y,b,d); };
    const line = (x,y,u,v,color,weight=5) => {
      ctx.strokeStyle=color; ctx.lineWidth=weight; ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(u,v); ctx.stroke();
    };
    const ring = (x,y,r,color,weight) => {
      ctx.strokeStyle=color; ctx.lineWidth=weight; ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.stroke();
    };
    const text = (s,x,y,width,size,color=ink) => {
      ctx.font='bold '+size+'px "Segoe UI",Arial,sans-serif';
      ctx.direction=AR?'rtl':'ltr'; ctx.textAlign='center'; ctx.fillStyle=color;
      ctx.fillText(tr(s),x,y,width);
    };
    rect(0,0,w,h,paper);
    // The label has its own strip. Pictures and document marks stay below it.
    const band = Math.min(h*.22,124);
    rect(0,0,w,band,teal); text(label,w/2,band*.67,w-40,Math.min(44,band*.50),'#fff');
    const drawH = h-band;
    ctx.save();
    ctx.translate(0,band);
    const sy = Math.min(w/640,drawH/280);
    ctx.translate(0,(drawH-280*sy)/2); ctx.scale(1,sy);
    const rules = (x,y,b) => {
      for (const [i,k] of [1,.75,.93,.57].entries()) rect(x,y+i*29,b*k,8,'#a4b7ba');
    };
    const printPicture = (img,x,y,b,d) => {
      rect(x-4,y-4,b+8,d+8,'#87999c'); ctx.drawImage(img,x,y,b,d);
    };
    const tile = (role,x,y,size,f=0) => printPicture(photos.portrait(role,f),x,y,size,size);
    const stamp = (x,y) => {
      ring(x,y,38,teal,7); ring(x,y,28,teal,2);
      for(let i=-1;i<=1;i++) rect(x-17,y+i*7,34,3,teal);
    };
    switch(kind) {
      case 'wave':
        for(let i=0;i<41;i++){
          const size = 14+Math.abs(Math.sin(i*.74+frame)*Math.cos(i*.25))*104;
          rect(46+i*13,132-size/2,8,size,i<19+frame*6?teal:'#97b6b7');
        }
        rect(50,222,540,5,'#b3bec1'); rect(50,222,205+frame*80,5,teal);
        break;
      case 'call':
        ring(320,135,83,teal,7);
        ctx.strokeStyle=teal; ctx.lineWidth=20; ctx.beginPath(); ctx.arc(321,105,50,.24,Math.PI-.24);ctx.stroke();
        break;
      case 'message':
        rect(46,26,444,87,'#d1e7e2'); rules(70,44,305);
        rect(171,159,419,79,'#dce2ed'); rect(198,189,300,9,'#8496a4');
        break;
      case 'counterPhoto': case 'counterVideo': case 'cameraLog':
        if(kind==='cameraLog') {
          printPicture(photos.counter(true,0),16,55,292,167);
          printPicture(photos.counter(false,0),332,55,292,167);
        } else {
          printPicture(photos.counter(true,frame),101,10,438,250);
          if(kind==='counterVideo') { rect(112,249,414,5,'#a4b4b9'); rect(112,249,115+frame*165,5,teal); }
        }
        break;
      case 'identity': case 'portrait': case 'compare': case 'broadcast':
        if (kind==='compare' || kind==='portrait') {
          const paired = kind==='compare', x=paired ? 75 : 202, y=paired ? 26 : 18, size=paired ? 210 : 235;
          tile(subject,x,y,size);
          ctx.save(); ctx.globalAlpha=.38;
          ctx.drawImage(photos.portrait('omar'),x,y,size,size); ctx.restore();
          if (paired) tile(subject,357,26,210);
        }
        else if(kind==='broadcast') { tile(subject,231,8,180,frame); rect(85,211,470,29,'#c9e0e2');line(154,225,485,225,teal,5); }
        else { tile(subject,42,44,178); rules(264,64,295); rect(263,210,254,15,teal); }
        break;
      case 'meeting':
        subject.forEach((role,i)=>tile(role,18+i*206,34,185,(frame+i)%2));
        rect(268,240,104,18,alert);
        break;
      case 'shop':
        rect(48,16,544,235,'#c4ced1');rect(96,59,449,178,'#e0c099');rect(108,71,425,31,'#446868');
        rect(125,114,221,123,'#8ca6af');rect(367,115,143,122,'#6f8994');
        for(const [x,y,u,v] of [[212,115,196,152],[196,152,226,177],[226,177,197,232],[196,152,141,165],[226,177,288,149]])line(x,y,u,v,'#e8f1f1',5);
        break;
      case 'letter':
        rect(54,22,70,32,teal);rules(157,31,326);rules(54,159,284);
        text('Ref. 317',239,139,270,30);stamp(504,178);line(321,236,344,213,ink);line(344,213,351,231,ink);line(351,231,405,216,ink);
        break;
      case 'lookup':
        rect(51,40,537,73,'#deebe9'); text('Ref. 317',320,88,450,40);
        text(label,320,207,549,40,alert); break;
      case 'notice':
        rect(50,20,61,31,teal);rules(145,27,352);
        for(const [i,s] of ['No processing fee','Refund service open'].entries())text(s,320,170+i*54,548,38);
        break;
      case 'article': case 'draft':
        rect(26,16,kind==='draft'?267:585,41,ink);rules(40,82,kind==='draft'?213:422);
        if(kind==='draft') { rect(320,16,292,232,'#e0eeeb');rules(339,50,232);text('Unverified figure',464,213,265,28,alert); }
        else {text('No author or date',320,240,568,34,alert);}
        break;
      case 'portal':
        rect(39,16,562,42,'#c7d8db');rules(64,80,410); rect(62,210,195,38,teal);
        break;
      case 'checklist':
        for(let i=0;i<3;i++) { ctx.strokeStyle=teal;ctx.lineWidth=4;ctx.strokeRect(72,27+i*77,37,37);rect(140,41+i*77,347-i*39,10,'#95aaad'); }
        break;
      case 'form':
        rules(51,30,433);line(285,214,571,214,ink,3); break;
    }
    ctx.restore();
  });
}

// Frame the actual surface, including its bezel or paper edge. Centre it between the
// player header and captions. The normal hall shot restores the camera on every seek.
function closeUp(stage, face) {
  const camera = stage.camera, canvas = stage.renderer.domElement;
  const aspect = canvas.clientWidth / Math.max(1,canvas.clientHeight);
  const size = face.geometry.parameters, scale = face.getWorldScale(V());
  const width = size.width*scale.x, height = size.height*scale.y;
  const vh = Math.max(height/.45,width/(aspect*.73));
  camera.top = vh*.53; camera.bottom = -vh*.47;
  camera.left = -vh*aspect/2; camera.right = vh*aspect/2;
  face.getWorldQuaternion(camera.quaternion);
  camera.position.copy(face.localToWorld(V(0,0,0)));
  camera.translateZ(.16);
  camera.updateProjectionMatrix();
}

export function evidence({ surfaces, inserts = [], pointAt = [], camera = false, handoff }) {
  return hall => {
    const photos = photographs(hall), faces = {}, views = {};
    if (camera) {
      const unit = group(hall.counterLaptop,0,.337,-.246);
      mesh(rbox(.093,.04,.035,.005),C.dark,0,0,0,unit);
      const lens = mesh(new THREE.CylinderGeometry(.012,.012,.015,16),C.teal,-.025,0,.022,unit);
      lens.rotation.x = Math.PI/2;
      unit.lookAt(V(-1.28,1.5,-.14));
    }
    for (const [name,rows] of Object.entries(surfaces)) {
      const face = deviceSurface(name,hall);
      faces[name] = face;
      const { width, height } = face.geometry.parameters;
      const idle = face.material;
      const frames = rows.map(([a,z,kind,label,subject])=>{
        const animated = ['wave','counterVideo','meeting','broadcast'].includes(kind);
        const materials = Array.from({length:animated?2:1},(_,frame)=>{
          const map = drawView(kind,label,subject,photos,width/height,frame);
          return new THREE.MeshBasicMaterial({map,toneMapped:false});
        });
        return [a,z,materials];
      });
      let previous;
      views[name] = t => {
        const view = during(frames,t);
        if (view) {
          const [a,z,materials] = view;
          const index = materials.length===1 ? 0 : Math.floor((t-a)/(z-a)*12)%2;
          previous = materials[index];
          face.material = previous;
        } else if (face.material===previous) face.material=idle;
      };
    }
    return t => {
      for (const update of Object.values(views)) update(t);
      for (const [a,z,role,name] of pointAt) {
        if (a<=t && t<z) {
          const actor=hall.actors[role], target=world(faces[name]);
          actor.look(target,1); actor.reach('R',target,.94);
        }
      }
      if (handoff) {
        const [a,z,from,to] = handoff, sheet = faces.handout.parent;
        sheet.visible = t>=a;
        if (sheet.visible) {
          const giver=hall.actors[from], recipient=hall.actors[to];
          const k=ramp(t,a,z);
          const pass=V(-2.07,1.23,-.15), held=recipient.g.localToWorld(V(0,111,23));
          sheet.position.copy(giver.g.localToWorld(V(-10,116,32)));
          if(k<.5) sheet.position.lerp(pass,k*2);
          else sheet.position.copy(pass).lerp(held,k*2-1);
          sheet.rotation.set(-.88,recipient.g.rotation.y,.08,'YXZ');
          if(k<.62) giver.reach('R',sheet.position,1);
          if(k>.38) recipient.reach('R',sheet.position,1);
          if(t<z) { giver.look(sheet.position,1); recipient.look(sheet.position,1); recipient.head.rotation.x=.11*Math.sin(k*Math.PI*2); }
        }
      }
      const insert=during(inserts,t);
      if (insert) closeUp(hall.stage,faces[insert[2]]);
    };
  };
}
